package com.natwest.pbbdhb.ui.application.update.cucumber.stepdefs;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.CucumberTestProperties;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.MongoActions;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.config.HttpClientConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.POST_STP_EXCEPTION;
import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.Params.*;
import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.Params.APPLICANT_ID;
import static io.restassured.RestAssured.given;
import static org.apache.http.params.CoreConnectionPNames.CONNECTION_TIMEOUT;
import static org.apache.http.params.CoreConnectionPNames.SO_TIMEOUT;

@Slf4j

public class ExternalServicesStepDefs {
    private JsonNode externalInputsAsJsonNode;
    private JsonNode responseJsonNode;
    private String responseString;
    private String requireDocsOutput;
    private String getDocumentOutput;
    private String getApplicationData;
    private String applicantString;
    private Response response;
    private JsonNode firstDocumentInfo;
    private String caseIdCAPIE;
    private String referenceNumberCAPIE;
    private int initialNotesCount;
    private String customerResponseValue;
    private int countDocuments;
    private static String uploadedDocRequestId;
    public static String fiRequestId;
    public static String customFirequestId;
    public static String customerResponseText;
    public static String closureNoteText;
    public static String applicantID1;
    public static String applicantID2;

    public static String ADBO_UNIQUE_CASEID;
    public static String adboUIIdCAPIE;

    public static String exceptionId;
    public static String stpexceptionId;


    @Before
    public void init() throws IOException {
        externalInputsAsJsonNode = ApiTestUtil.getInputsAsJsonNode(EXTERNAL_SERVICES_JSON);
    }

    @Given("AddApplicationInformation Service endpoint exists")
    public void addApplicationInformationServiceEndpointExists() {
        RestAssured.baseURI = CucumberTestProperties.getMSVCFlowManagerURI();
    }

    @Given("UI coord application update Service endpoint exists")
    public void uiCoordApplicationUpdateServiceEndpointExists() {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
    }

    public static Long testDateFormatFull() {
        DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
        Date date = new Date();
        return Long.parseLong(dateFormat.format(date));
    }

    public Long testDateFormat() {
        DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmm");
        Date date = new Date();
        return Long.parseLong(dateFormat.format(date));
    }

    public Long newTestDateFormat() {
        DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
        Date date = new Date();
        return Long.parseLong(dateFormat.format(date));
    }

    public Long testDateFormatShort() {
        DateFormat dateFormat = new SimpleDateFormat("yyMMddHHmm");
        Date date = new Date();
        return Long.parseLong(dateFormat.format(date));
    }

    public int testDateFormatSeconds() {
        DateFormat dateFormat = new SimpleDateFormat("ss");
        Date date = new Date();
        return Integer.parseInt(dateFormat.format(date));
    }

    @When("User sends request to view caseId for applicant in CAPIE service using input {string} and verify response code")
    public void userSendsRequestToViewApplicantCaseIdInCAPIEUsingInputAndVerifyResponseCode(String inputName) throws InterruptedException, JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getCAPIEApplicantServiceURI();
        ObjectMapper mapper = new ObjectMapper();
        JsonNode requestInput = mapper.createObjectNode();
        ObjectNode addedNode = ((ObjectNode) requestInput).putObject("requestQuery");
        addedNode.put(BRAND, testInput.get(BRAND));
        addedNode.put(CASE_ID, testInput.get(REQUEST_BODY).get(CASE_ID).asText() + testDateFormat());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenCapieApplicant())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(addedNode, request, GET_APPLICANT_CASE_ID_CAPIE_PATH);
        response = request.get(GET_APPLICANT_CASE_ID_CAPIE_PATH);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @When("User sends request to view caseId for applicant {string}{int} - prefixreferenceNumber in CAPIE service")
    public void userSendsRequestToViewApplicantCaseIdInCAPIEUsingInputAndVerifyResponseCode(String prefix, int referenceNumber) throws InterruptedException, JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get("inputApplicantCaseIdDocumentIdentifier");
        RestAssured.baseURI = CucumberTestProperties.getCAPIEApplicantServiceURI();
        ObjectMapper mapper = new ObjectMapper();
        JsonNode requestInput = mapper.createObjectNode();
        ObjectNode addedNode = ((ObjectNode) requestInput).putObject("requestQuery");
        addedNode.put(BRAND, testInput.get(BRAND));
        addedNode.put(CASE_ID, prefix+referenceNumber);
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenCapieApplicant())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(addedNode, request, GET_APPLICANT_CASE_ID_CAPIE_PATH);
        response = request.get(GET_APPLICANT_CASE_ID_CAPIE_PATH);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @When("User sends request to view caseId for broker in CAPIE service using input {string} and verify response code")
    public void userSendsRequestToViewBrokerCaseIdInCAPIEUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getCAPIEBrokerServiceURI();
        ObjectMapper mapper = new ObjectMapper();
        JsonNode requestInput = mapper.createObjectNode();
        ObjectNode addedNode = ((ObjectNode) requestInput).putObject("requestQuery");
        addedNode.put(BRAND, testInput.get(BRAND));
        addedNode.put(CASE_ID, testInput.get(REQUEST_BODY).get(CASE_ID).asText() + testDateFormat());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenCapieCase())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(addedNode, request, GET_BROKER_CASE_ID_CAPIE_PATH);
        response = request.get(GET_BROKER_CASE_ID_CAPIE_PATH);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @When("User sends request to view caseId for broker {string}{int} - prefixreferenceNumber in CAPIE service")
    public void userSendsRequestToViewBrokerCaseIdInCAPIEUsingInputAndVerifyResponseCode(String prefix, int referenceNumber) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get("inputCaseIdDocumentIdentifier");
        RestAssured.baseURI = CucumberTestProperties.getCAPIEBrokerServiceURI();
        ObjectMapper mapper = new ObjectMapper();
        JsonNode requestInput = mapper.createObjectNode();
        ObjectNode addedNode = ((ObjectNode) requestInput).putObject("requestQuery");
        addedNode.put(BRAND, testInput.get(BRAND));
        addedNode.put(CASE_ID, prefix+referenceNumber);
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenCapieCase())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(addedNode, request, GET_BROKER_CASE_ID_CAPIE_PATH);
        response = request.get(GET_BROKER_CASE_ID_CAPIE_PATH);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @When("User sends request to view caseId for broker in CAPIE service for channel {string} using input {string} and verify response code")
    public void userSendsRequestToViewBrokerCaseIdInCAPIEforChannelUsingInputAndVerifyResponseCode(String channel, String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getCAPIEBrokerServiceURI();
        ObjectMapper mapper = new ObjectMapper();
        JsonNode requestInput = mapper.createObjectNode();
        ObjectNode addedNode = ((ObjectNode) requestInput).putObject("requestQuery");
        addedNode.put(BRAND, testInput.get(BRAND));
        addedNode.put(CASE_ID, testInput.get(REQUEST_BODY).get(CASE_ID).asText() + testDateFormat());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenCapieCase())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(addedNode, request, GET_BROKER_CASE_ID_CAPIE_PATH);
        response = request.get(GET_BROKER_CASE_ID_CAPIE_PATH);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @When("User sends request to view income for caseId in CAPIE service using input {string} and verify response code")
    public void userSendsRequestToViewIncomeCaseIdInCAPIEUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        String getApplicantId = (new ObjectMapper().readTree(applicantString)).get(0).get(APPLICANTS).get(0).get(APPLICANT_ID).asText();
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getIncomeServiceURI();
        ObjectMapper mapper = new ObjectMapper();
        JsonNode requestInput = mapper.createObjectNode();
        ObjectNode addedNode = ((ObjectNode) requestInput).putObject("requestQuery");
        addedNode.put(BRAND, testInput.get(BRAND));
        addedNode.put(CASE_ID, testInput.get(REQUEST_BODY).get(CASE_ID).asText() + testDateFormatShort());
        addedNode.put("requestBody.applicants[0].applicantId", getApplicantId);
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenCapieIncome())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(addedNode, request, GET_INCOME_CASE_ID_CAPIE_PATH);
        response = request.get(GET_INCOME_CASE_ID_CAPIE_PATH);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @When("User sends request to add caseId for applicant in CAPIE service using input {string} and verify response code")
    public void userSendsRequestToAddApplicantCaseIdInCAPIEUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getCAPIEApplicantServiceURI();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        caseIdCAPIE = testInput.get(REQUEST_BODY).get(CASE_ID).asText() + newTestDateFormat();
        referenceNumberCAPIE = testDateFormatShort().toString();
        doc.set("requestBody.caseId", caseIdCAPIE);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenCapieApplicant())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_APPLICANT_CASE_ID_CAPIE_PATH);
        response = request.post(POST_APPLICANT_CASE_ID_CAPIE_PATH);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        applicantString = response.asString();
        responseString = response.asString();
    }

    @When("User sends request to add caseId for applicant {string}{int} - prefixreferenceNumber in CAPIE service")
    public void userSendsRequestToAddApplicantCaseIdInCAPIEUsingInputAndVerifyResponseCode(String prefix, int referenceNumber) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get("inputApplicantCaseIdDocumentIdentifier");
        RestAssured.baseURI = CucumberTestProperties.getCAPIEApplicantServiceURI();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        referenceNumberCAPIE = testDateFormatShort().toString();
        doc.set("requestBody.caseId", prefix+referenceNumber);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenCapieApplicant())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_APPLICANT_CASE_ID_CAPIE_PATH);
        response = request.post(POST_APPLICANT_CASE_ID_CAPIE_PATH);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        applicantString = response.asString();
        responseString = response.asString();
    }

    @When("User sends request to add caseId for applicant in CAPIE service having personalDetails fields NULL using input {string} and verify response code")
    public void userSendsRequestToAddApplicantCaseIdNullPersonalDetailsInCAPIEUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getCAPIEApplicantServiceURI();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("requestBody.caseId", testInput.get(REQUEST_BODY).get(CASE_ID).asText() + testDateFormat());
        String[] personalDetailsNULL = {"title", "firstNames", "lastName", "email"};
        for(int i = 0; i<personalDetailsNULL.length; i++){
            doc.set("requestBody.personalDetails."+personalDetailsNULL[i], null);
        }
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenCapieApplicant())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_APPLICANT_CASE_ID_CAPIE_PATH);
        response = request.post(POST_APPLICANT_CASE_ID_CAPIE_PATH);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        applicantString = response.asString();
        responseString = response.asString();
    }

    @When("User sends request to add caseId for broker in CAPIE service for channel {string} using input {string} and verify response code")
    public void userSendsRequestToAddBrokerCaseIdInCAPIEUsingInputAndVerifyResponseCode(String channel, String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getCAPIEBrokerServiceURI();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("requestBody.caseId", caseIdCAPIE);
        doc.set("requestBody.channel", channel);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenCapieCase())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_BROKER_CASE_ID_CAPIE_PATH);
        response = request.post(POST_BROKER_CASE_ID_CAPIE_PATH);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @When("User sends request to add caseId for broker {string}{int} - prefixreferenceNumber in CAPIE service for channel {string}")
    public void userSendsRequestToAddBrokerCaseIdInCAPIEUsingInputAndVerifyResponseCode(String prefix, int referenceNumber, String channel) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get("inputCaseIdDocumentIdentifier");
        RestAssured.baseURI = CucumberTestProperties.getCAPIEBrokerServiceURI();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("requestBody.caseId", prefix+referenceNumber);
        doc.set("requestBody.channel", channel);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenCapieCase())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_BROKER_CASE_ID_CAPIE_PATH);
        response = request.post(POST_BROKER_CASE_ID_CAPIE_PATH);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @When("User sends request to add caseId for broker in CAPIE service for channel {string} having mortgageAdvisor fields NULL using input {string} and verify response code")
    public void userSendsRequestToAddBrokerCaseIdInCAPIEMortgageAdvisorNULLUsingInputAndVerifyResponseCode(String channel, String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getCAPIEBrokerServiceURI();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("requestBody.caseId", testInput.get(REQUEST_BODY).get(CASE_ID).asText() + testDateFormat());
        doc.set("requestBody.channel", channel);
        String[] mortgageAdvisorNULL = {"advisor", "leadAdvisor", "leadGenerator"};
        for(int i=0; i< mortgageAdvisorNULL.length; i++){
            doc.set("requestBody.mortgage.mortgageAdvisor."+mortgageAdvisorNULL[i], null);
        }
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenCapieCase())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_BROKER_CASE_ID_CAPIE_PATH);
        response = request.post(POST_BROKER_CASE_ID_CAPIE_PATH);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @When("User sends request to add income for caseId in CAPIE service using input {string} and verify response code")
    public void userSendsRequestToAddIncomeCaseIdInCAPIEUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getIncomeServiceURI();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", caseIdCAPIE);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenCapieIncome())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, PUT_INCOME_CASE_ID_CAPIE_PATH);
        response = request.put(PUT_INCOME_CASE_ID_CAPIE_PATH);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @When("User sends request to add income for caseId {string}{int} - prefixreferenceNumber in CAPIE service")
    public void userSendsRequestToAddIncomeCaseIdInCAPIEUsingInputAndVerifyResponseCode(String prefix, int referenceNumber) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get("inputIncomeDocumentIdentifier");
        RestAssured.baseURI = CucumberTestProperties.getIncomeServiceURI();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", prefix+referenceNumber);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenCapieIncome())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, PUT_INCOME_CASE_ID_CAPIE_PATH);
        response = request.put(PUT_INCOME_CASE_ID_CAPIE_PATH);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @When("User sends request to view documents for caseId using input {string} and verify response code")
    public void userSendsRequestToViewCaseIdDocumentsUsingInputAndVerifyResponseCode(String inputName) throws InterruptedException, JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getMSVCApplicationURI();
        ObjectMapper mapper = new ObjectMapper();
        JsonNode requestInput = mapper.createObjectNode();
        ObjectNode addedNode = ((ObjectNode) requestInput).putObject("requestQuery");
        addedNode.put(BRAND, testInput.get(BRAND));
        addedNode.put(CASE_ID, caseIdCAPIE);
        Thread.sleep(5000);
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenMsvcApplication())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(addedNode, request, GET_DOCUMENTS_CASE_ID_PATH);
        response = request.get(GET_DOCUMENTS_CASE_ID_PATH);
        log.info("response " + response);
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        getDocumentOutput = response.asString();
        responseString = response.asString();
    }

    @When("User sends request to view documents for referenceNumber {string}")
    public void userSendsRequestToViewCaseIdDocumentsUsingInputAndVerifyResponseCode1(String referenceNumber) throws InterruptedException, JsonProcessingException {
        RestAssured.baseURI = CucumberTestProperties.getApplicationTrackingURI();
        ObjectMapper mapper = new ObjectMapper();
        JsonNode requestInput = mapper.createObjectNode();
        ObjectNode addedNode = ((ObjectNode) requestInput).putObject("requestQuery");
        addedNode.put(BRAND, CucumberTestProperties.getBrand());
        addedNode.put(REFERENCE_NUMBER, referenceNumber);
        addedNode.put("loginUserName", "HBOPostSub8");
        Thread.sleep(10000);
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(addedNode, request, GET_APPLICATION_TRACKING_DOCUMENTS_PATH);
        response = request.headers(CucumberTestProperties.getHeaders(addedNode)).get(GET_APPLICATION_TRACKING_DOCUMENTS_PATH);
        log.info("response " + response);
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        getDocumentOutput = response.asString();
        countDocuments = (new ObjectMapper().readTree(getDocumentOutput)).get(DOCUMENTS).size();
        responseString = response.asString();
    }

    @When("User sends request to view other document for referenceNumber {string} with timeout {int}")
    public void userSendsRequestToViewOtherDocumentsUsingInputAndVerifyResponseCode1(String referenceNumber, int timeout) throws InterruptedException, JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        JsonNode requestInput = mapper.createObjectNode();
        ObjectNode addedNode = ((ObjectNode) requestInput).putObject("requestQuery");
        addedNode.put(BRAND, CucumberTestProperties.getBrand());
        addedNode.put(REFERENCE_NUMBER, referenceNumber);
        addedNode.put("loginUserName", "HBOPostSub8");
        int retries = timeout/5 + 1;
        for(int i = 0; i < retries; i++) {
            Thread.sleep(5000);
            RestAssured.baseURI = CucumberTestProperties.getApplicationTrackingURI();
            RequestSpecification request = RestAssured.given()
                    .log().all()
                    .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                    .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                    .accept(ContentType.JSON);
            ApiTestUtil.createRequestForInputParams(addedNode, request, GET_APPLICATION_TRACKING_DOCUMENTS_PATH);
            response = request.headers(CucumberTestProperties.getHeaders(addedNode)).get(GET_APPLICATION_TRACKING_DOCUMENTS_PATH);
            responseJsonNode = new ObjectMapper().readTree(response.asString());
            log.info(response.getHeaders().asList().toString());
            log.info(response.getBody().prettyPrint());
            Assertions.assertNotNull(response, "response is null");
            getDocumentOutput = response.asString();
            countDocuments = (new ObjectMapper().readTree(getDocumentOutput)).get(DOCUMENTS).size();
            String documentIdetifier = responseJsonNode.get(DOCUMENTS).get(0).get(DOCUMENT_IDENTIFIER).asText();
            if (documentIdetifier.equals("OD")) {
                String documentStatus = responseJsonNode.get(DOCUMENTS).get(0).get(DOCUMENT_INFO).get(0).get(DOCUMENT_STATUS).asText();
                if (documentStatus.equals("AV_SCAN_SUCCESS")) {
                    log.info("Upload duration: " + i * 5 + "seconds");
                    log.info("response " + response);
                    break;
                }
            }
        }
        responseString = response.asString();
    }

    @When("User sends request to view documents for caseId using input {string} and verify response code using {int} seconds timeout")
    public void userSendsRequestToViewCaseIdDocumentsUsingInputAndVerifyResponseCodeWithTimeout(String inputName, int timeout) throws InterruptedException, JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        ObjectMapper mapper = new ObjectMapper();
        JsonNode requestInput = mapper.createObjectNode();
        ObjectNode addedNode = ((ObjectNode) requestInput).putObject("requestQuery");
        addedNode.put(BRAND, testInput.get(BRAND));
        addedNode.put(CASE_ID, caseIdCAPIE);
        if(uploadedDocRequestId != null){
            addedNode.put(REQUEST_ID, uploadedDocRequestId);
        }
        int retries = timeout/5 + 1;
        for(int i = 0; i < retries; i++) {
            Thread.sleep(5000);
            RestAssured.baseURI = CucumberTestProperties.getMSVCApplicationURI();
            RequestSpecification request = RestAssured.given()
                    .log().all()
                    .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                    .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenMsvcApplication())
                    .accept(ContentType.JSON);
            Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
            ApiTestUtil.createRequestForInputParams(addedNode, request, GET_DOCUMENTS_CASE_ID_PATH);
            response = request.get(GET_DOCUMENTS_CASE_ID_PATH);
            log.info("response " + response);
            responseJsonNode = new ObjectMapper().readTree(response.asString());
            int documentsSize = responseJsonNode.get(DOCUMENTS).size();
            if(documentsSize > 0){
                int documentInfoSize = responseJsonNode.get(DOCUMENTS).get(0).get(DOCUMENT_INFO).size();
                if (documentInfoSize > 0) {
                    log.info("Upload duration: "+i*5+"seconds");
                    break;
                }
            }
        }
        uploadedDocRequestId = null;
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        getDocumentOutput = response.asString();
        responseString = response.asString();

        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        fiRequestId = responseJsonNode.get(DOCUMENTS).get(0).get(REQUEST_ID).asText();

    }

    @When("User sends request to view documents for caseId and request type {string} using input {string} and verify response code")
    public void userSendsRequestToViewCaseIdAndCategoryDocumentsUsingInputAndVerifyResponseCode(String requestType, String inputName) throws InterruptedException, JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
        ObjectMapper mapper = new ObjectMapper();
        JsonNode requestInput = mapper.createObjectNode();
        ObjectNode addedNode = ((ObjectNode) requestInput).putObject("requestQuery");
        addedNode.put(BRAND, testInput.get(BRAND));
        addedNode.put(CASE_ID, testInput.get(REQUEST_BODY).get(CASE_ID).asText() + testDateFormat());
        addedNode.put(REQUEST_TYPE, requestType);
        Thread.sleep(10000);
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(addedNode, request, GET_APPLICATION_TRACKING_DOCUMENTS_CASE_ID_PATH);
        response = request.get(GET_APPLICATION_TRACKING_DOCUMENTS_CASE_ID_PATH);
        log.info("response " + response);
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        //Assertions.assertTrue(responseJsonNode.get(DOCUMENTS).size() == 0);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        getDocumentOutput = response.asString();
        responseString = response.asString();
    }

    @When("User sends request to view customer response open tasks notifications for referenceNumber {string} using {int} seconds timeout")
    public void userSendsRequestToViewCustomerResponseTaskInformationTimeout(String referenceNumber, int timeout) throws InterruptedException, JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        JsonNode requestInput = mapper.createObjectNode();
        ObjectNode addedNode = ((ObjectNode) requestInput).putObject("requestQuery");
        addedNode.put(BRAND, CucumberTestProperties.getBrand());
        addedNode.put(REFERENCE_NUMBER, referenceNumber);
        addedNode.put(TASK_STATUS, "Open");
        addedNode.put("loginUserName", "HBOPostSub8");
        int retries = timeout/5 + 1;
        for(int i = 0; i < retries; i++) {
            Thread.sleep(5000);
            RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
            RequestSpecification request = RestAssured.given()
                    .log().all()
                    .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                    .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                    .accept(ContentType.JSON);
            ApiTestUtil.createRequestForInputParams(addedNode, request, GET_NOTES_INFORMATION_PATH);
            response = request.headers(CucumberTestProperties.getHeaders(addedNode)).get(GET_NOTES_INFORMATION_PATH);
            log.info("response " + response);
            responseJsonNode = new ObjectMapper().readTree(response.asString());
            log.info(response.getHeaders().asList().toString());
            log.info(response.getBody().prettyPrint());
            Assertions.assertNotNull(response, "response is null");
            responseString = response.asString();
            if(responseString.contains(customerResponseValue)){
                log.info("Task availability duration: "+i*5+"seconds");
                break;
            }
        }
    }

    @When("User sends request to view open tasks for referenceNumber {string} using {int} seconds timeout")
    public void userSendsRequestToViewTaskInformationTimeout(String referenceNumber, int timeout) throws InterruptedException, JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        JsonNode requestInput = mapper.createObjectNode();
        ObjectNode addedNode = ((ObjectNode) requestInput).putObject("requestQuery");
        addedNode.put(BRAND, CucumberTestProperties.getBrand());
        addedNode.put(REFERENCE_NUMBER, referenceNumber);
        addedNode.put(TASK_STATUS, "Open");
        addedNode.put("loginUserName", "HBOPostSub8");
        int retries = timeout/5 + 1;
        for(int i = 0; i < retries; i++) {
            Thread.sleep(5000);
            RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
            RequestSpecification request = RestAssured.given()
                    .log().all()
                    .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                    .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                    .accept(ContentType.JSON);
            ApiTestUtil.createRequestForInputParams(addedNode, request, GET_TASK_INFORMATION_PATH);
            response = request.headers(CucumberTestProperties.getHeaders(addedNode)).get(GET_TASK_INFORMATION_PATH);
            log.info("response " + response);
            responseJsonNode = new ObjectMapper().readTree(response.asString());
            log.info(response.getHeaders().asList().toString());
            log.info(response.getBody().prettyPrint());
            Assertions.assertNotNull(response, "response is null");
            responseString = response.asString();
            if(responseString.contains("SMS")){
                log.info("Task availability duration: "+i*5+"seconds");
                break;
            }
        }
    }

    @When("User sends request to view documents for referenceNumber using input {string} and verify response code")
    public void userSendsRequestToViewReferenceNumberDocumentsUsingInputAndVerifyResponseCode(String inputName) throws InterruptedException, JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getMSVCApplicationURI();
        ObjectMapper mapper = new ObjectMapper();
        JsonNode requestInput = mapper.createObjectNode();
        ObjectNode addedNode = ((ObjectNode) requestInput).putObject("requestQuery");
        addedNode.put(BRAND, testInput.get(BRAND));
        addedNode.put(REFERENCE_NUMBER, testDateFormatShort());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenMsvcApplication())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(addedNode, request, GET_DOCUMENTS_REFERENCE_NUMBER_PATH);
        response = request.get(GET_DOCUMENTS_REFERENCE_NUMBER_PATH);
        log.info("response " + response);
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @When("External Services - User sends request to post application for channel {string} using kafka topic input {string} and verify response code")
    public void userSendsRequestToPostApplicationUsingKafkaTopicUsingInputAndVerifyResponseCode(String channel, String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getMSVCFlowManagerURI();

        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("requestBody.caseId", caseIdCAPIE);
        doc.set("requestBody.mortgageRefNo", referenceNumberCAPIE);
        doc.set("requestBody.channel", channel);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenMsvcFlowManager())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, testInput.get(PATH).asText());
        response = request.post(testInput.get(PATH).asText());
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @When("External Services - User sends request to post application for caseId {string}{int} - prefixreferenceNumber for channel {string}")
    public void userSendsRequestToPostApplicationUsingKafkaTopicUsingInputAndVerifyResponseCode(String prefix, int referenceNumber, String channel) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get("kafkaPayloadForApplications");
        RestAssured.baseURI = CucumberTestProperties.getMSVCFlowManagerURI();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("requestBody.caseId", prefix+referenceNumber);
        doc.set("requestBody.mortgageRefNo", Integer.toString(referenceNumber));
        doc.set("requestBody.channel", channel);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenMsvcFlowManager())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, testInput.get(PATH).asText());
        response = request.post(testInput.get(PATH).asText());
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @When("User sends request to get requireDocs for caseId in CAPIE service for channel {string} using input {string} and verify response code")
    public void userSendsRequestToGetCaseIdRequireDocsInCAPIEUsingInputAndVerifyResponseCode(String channel, String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getRequireDocsServiceURI();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", caseIdCAPIE);
        doc.set(CHANNEL, channel);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenMsvcRequireDocs())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, GET_REQUIRE_DOCS_CASE_ID_CAPIE_PATH);
        response = request.get(GET_REQUIRE_DOCS_CASE_ID_CAPIE_PATH);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        requireDocsOutput = response.asString();
    }

    @When("User sends request to post document for case id using input {string} and verify response code")
    public void userSendsRequestToPostDocumentsUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        RestAssured.baseURI = CucumberTestProperties.getMSVCFlowManagerURI();
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", caseIdCAPIE);
        doc.delete("referenceNumber");
        doc.set("requestBody.caseId", caseIdCAPIE);
        doc.set("requestBody.referenceNumber", referenceNumberCAPIE);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenMsvcFlowManager())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_DOCUMENT_REQUEST_CASE_ID_PATH);
        response = request.post(POST_DOCUMENT_REQUEST_CASE_ID_PATH);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @When("User sends request to post document for {string} using input {string} and verify response code")
    public void userSendsRequestToPostDocumentsUsingInputAndVerifyResponseCode(String referenceNumber, String inputName) throws JsonProcessingException {
        RestAssured.baseURI = CucumberTestProperties.getMSVCFlowManagerURI();
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("referenceNumber", referenceNumber);
        doc.set("requestBody.referenceNumber", referenceNumber);
        doc.delete("requestBody.caseId");
        doc.delete("caseId");
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenMsvcFlowManager())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_DOCUMENT_REQUEST_PATH);
        response = request.post(POST_DOCUMENT_REQUEST_PATH);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @When("Switch first document from category to Received status for input {string}")
    public void switchDocumenttoReceivedStatus(String inputName) throws JsonProcessingException, JSONException {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        String brand = testInput.get(BRAND).asText();
        String caseId = (new ObjectMapper().readTree(getDocumentOutput)).get(CASE_ID).asText();
        String fiRequestId = (new ObjectMapper().readTree(getDocumentOutput)).get(DOCUMENTS).get(0).get(REQUEST_ID).asText();
        String status = "Closed";
        JSONObject doc = new JSONObject();
        doc.put("brand", brand);
        doc.put("caseId", caseId);
        doc.put("firequestId", fiRequestId);
        doc.put("state", status);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.toString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(testInput))
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_FI_REQUEST_UPDATE_STATUS_CASE_ID_PATH);
        response = request.put(POST_FI_REQUEST_UPDATE_STATUS_CASE_ID_PATH);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @When("Close all documents for {string}")
    public void closeAllApplication(String referenceNumber) throws JsonProcessingException, JSONException {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String brand = CucumberTestProperties.getBrand();
        JsonNode documents = (new ObjectMapper().readTree(getDocumentOutput)).get(DOCUMENTS);
        for(int i = 0; i < documents.size(); i++) {
            String fiRequestId = (new ObjectMapper().readTree(getDocumentOutput)).get(DOCUMENTS).get(i).get(REQUEST_ID).asText();
            String fiState = (new ObjectMapper().readTree(getDocumentOutput)).get(DOCUMENTS).get(i).get(STATE).asText();
            String fiType = (new ObjectMapper().readTree(getDocumentOutput)).get(DOCUMENTS).get(i).get(FI_TYPE).asText();
            String state = "Closed";
            if(!fiState.equals(state)) {
                JSONObject doc = new JSONObject();
//                JSONObject requestBody = new JSONObject();
                doc.put("brand", brand);
                doc.put("referenceNumber", referenceNumber);
                doc.put("firequestId", fiRequestId);
                doc.put("state", state);
                doc.put("loginUserName", "HBOPostSub8");
//                if(fiType.equals("Text")){
//                    doc.put("requestBody", requestBody);
//                }
                JsonNode updatedInput = new ObjectMapper().readTree(doc.toString());
                RequestSpecification request = RestAssured.given()
                        .log().all()
                        .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                        .headers(CucumberTestProperties.getHeaders(updatedInput))
                        .accept(ContentType.JSON);
                ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_FI_REQUEST_UPDATE_STATUS_PATH);
                response = request.headers(CucumberTestProperties.getHeaders(updatedInput)).put(POST_FI_REQUEST_UPDATE_STATUS_PATH);
                log.info("response " + response);
                log.info(response.getHeaders().asList().toString());
                log.info(response.getBody().prettyPrint());
                Assertions.assertEquals(200, response.getStatusCode());
                Assertions.assertNotNull(response, "response is null");
            }
        }
    }

    @When("Update customer response field for {string}")
    public void updateCustomerResponseApplication(String referenceNumber) throws JsonProcessingException, JSONException {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String brand = CucumberTestProperties.getBrand();
        JsonNode documents = (new ObjectMapper().readTree(getDocumentOutput)).get(DOCUMENTS).get(0);
        String fiRequestId = documents.get(REQUEST_ID).asText();
        String fiType = documents.get(FI_TYPE).asText();
        String state = "Open";
        JSONObject doc = new JSONObject();
        JSONObject requestBody = new JSONObject();
        doc.put("brand", brand);
        doc.put("referenceNumber", referenceNumber);
        doc.put("firequestId", fiRequestId);
        doc.put("state", state);
        doc.put("loginUserName", "HBOPostSub8");
        //if(fiType.equals("Text")){
            requestBody.put("note","text note for "+fiRequestId);
            customerResponseValue = "customer response "+testDateFormatFull().toString();
            requestBody.put("customerResponse", customerResponseValue);
            doc.put("requestBody", requestBody);
        //}
        JsonNode updatedInput = new ObjectMapper().readTree(doc.toString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(updatedInput))
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_FI_REQUEST_UPDATE_STATUS_PATH);
        response = request.headers(CucumberTestProperties.getHeaders(updatedInput)).put(POST_FI_REQUEST_UPDATE_STATUS_PATH);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
    }

    @When("Update customer response field with value greater than 1000 chars for {string}")
    public void updateCustomerResponseInvalidSizeApplication(String referenceNumber) throws JsonProcessingException, JSONException {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String brand = CucumberTestProperties.getBrand();
        JsonNode documents = (new ObjectMapper().readTree(getDocumentOutput)).get(DOCUMENTS).get(0);
        String fiRequestId = documents.get(REQUEST_ID).asText();
        String fiType = documents.get(FI_TYPE).asText();
        String state = "Closed";
        JSONObject doc = new JSONObject();
        JSONObject requestBody = new JSONObject();
        doc.put("brand", brand);
        doc.put("referenceNumber", referenceNumber);
        doc.put("firequestId", fiRequestId);
        doc.put("state", state);
        doc.put("loginUserName", "HBOPostSub8");
        if(fiType.equals("Text")){
            requestBody.put("note","text note for "+fiRequestId);
            customerResponseValue = "customer response "+testDateFormatFull().toString();
            requestBody.put("customerResponse", "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890");
            doc.put("requestBody", requestBody);
        }
        JsonNode updatedInput = new ObjectMapper().readTree(doc.toString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(updatedInput))
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_FI_REQUEST_UPDATE_STATUS_PATH);
        response = request.headers(CucumberTestProperties.getHeaders(updatedInput)).put(POST_FI_REQUEST_UPDATE_STATUS_PATH);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(400, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
    }

    @Then("Verify error message for invalid customer response size")
    public void checkErrorMeassageInvalidCustomerResponseSize() throws JsonProcessingException, JSONException {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        JsonNode testResponse = (new ObjectMapper().readTree(response.asString()));
        Assertions.assertEquals("Please enter a valid response", testResponse.get(ERROR_MESSAGES).get(0).asText());
    }

    @Then("Verify customerResponse field is not present in the response")
    public void checkCustomerResponseFieldNotAvailableInResponse() throws JsonProcessingException, JSONException {
        JsonNode documents = (new ObjectMapper().readTree(getDocumentOutput)).get(DOCUMENTS).get(0);
        Assertions.assertFalse(documents.has(CUSTOMER_RESPONSE),"customerResponse field is present in the response");
    }

    @Then("Check all documents for {string} have state Closed")
    public void checkAllDocumentsClosedForApplication(String caseId) throws JsonProcessingException, JSONException {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        JsonNode documents = (new ObjectMapper().readTree(getDocumentOutput)).get(DOCUMENTS);
        for(int i = 0; i < documents.size(); i++) {
            String state = (new ObjectMapper().readTree(getDocumentOutput)).get(DOCUMENTS).get(i).get(STATE).asText();
            Assertions.assertTrue(state.equals("Closed"));
        }
    }

    @Then("Check FST task user to be {string}")
    public void checkFSTTaskProperties(String openedBy) throws JsonProcessingException, JSONException {
        JsonNode tasks = (new ObjectMapper().readTree(responseString)).get(TASK_INFORMATION);
        boolean found = false;
        for(int i = 0; i < tasks.size(); i++) {
            if(tasks.get(i).get(CODE).asText().equals("FST")) {
                found = true;
                Assertions.assertEquals(tasks.get(i).get(OPENED_BY).asText(), openedBy);
                Assertions.assertTrue(tasks.get(i).get(STATUS).asText().equals("Open"));
            }
        }
        Assertions.assertTrue(found);
    }

    @Then("Check FST task customer response")
    public void checkFSTTaskCustomerResponse() throws JsonProcessingException, JSONException {
        JsonNode notes = (new ObjectMapper().readTree(responseString)).get(DETAILS);
        boolean found = false;
        for(int i = 0; i < notes.size(); i++) {
            if(notes.get(i).get(TASK_CODE).asText().equals("FST") && notes.get(i).get(DESCRIPTION).asText().contains(customerResponseValue)) {
                found = true;
                Assertions.assertTrue(notes.get(i).get(TASK_STATUS).asText().equals("Open"));
            }
        }
        Assertions.assertTrue(found);
    }

    @Then("Check FI document state is Open and documentInfo is empty")
    public void validateFIDocumentOpenAndDocumentInfoEmpty() throws JsonProcessingException {
        JsonNode getDocuments = (new ObjectMapper().readTree(responseString)).get(DOCUMENTS);
        Assertions.assertEquals(getDocuments.get(0).get(STATE).asText(), "Open");
        Assertions.assertTrue(getDocuments.get(0).get(DOCUMENT_INFO).size() == 0);
    }

    @When("Update document state to {string} for input {string}")
    public void switchDocumentToNewState(String state, String inputName) throws JsonProcessingException, JSONException, InterruptedException {
        Thread.sleep(20000);
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        JsonNode testInput = (new ObjectMapper().readTree(responseString));
        String brand = CucumberTestProperties.getBrand();
        String caseId = testInput.get(CASE_ID).asText();
        String fiRequestId = testInput.get(DOCUMENTS).get(0).get(REQUEST_ID).asText();
        JSONObject doc = new JSONObject();
        doc.put("brand", brand);
        doc.put("caseId", caseId);
        doc.put("firequestId", fiRequestId);
        doc.put("state", state);
        doc.put("loginUserName", "HBOPostSub8");
        JsonNode updatedInput = new ObjectMapper().readTree(doc.toString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(updatedInput))
                .headers(CucumberTestProperties.getHeaders(testInput))
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_FI_REQUEST_UPDATE_STATUS_CASE_ID_PATH);
        response = request.put(POST_FI_REQUEST_UPDATE_STATUS_CASE_ID_PATH);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @When("Mock Update document state to Draft and status of AV_SCAN_FAILURE of invalid document for input {string}")
    public void switchDocumentToNewStateMock(String inputName) throws JsonProcessingException, JSONException {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        JsonNode input = externalInputsAsJsonNode.get(inputName);
        JsonNode testInput = (new ObjectMapper().readTree(responseString));
        String caseId = testInput.get(CASE_ID).asText();
        String requestId = testInput.get(DOCUMENTS).get(0).get(REQUEST_ID).asText();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(input);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", caseId);
        doc.set("firequestId", requestId);
        doc.set("state","Draft");
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(input))
                .headers(CucumberTestProperties.getHeaders(testInput))
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_FI_REQUEST_UPDATE_STATUS_CASE_ID_PATH);
        response = request.put(POST_FI_REQUEST_UPDATE_STATUS_CASE_ID_PATH);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
    }

    @When("External Services - User sends request to post kafka message for MOCKING AV_SCAN_FAILURE on Other document for channel {string} using input {string} and verify response code")
    public void userSendsRequestToPostApplicationUsingKafkaTopicForAV_SCAN_FAILUREOtherUsingInputAndVerifyResponseCode(String channel, String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getMSVCFlowManagerURI();

        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("requestBody.mortgageRefNumber", referenceNumberCAPIE);
        doc.set("requestBody.channelId", channel);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenMsvcFlowManager())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, testInput.get(PATH).asText());
        response = request.post(testInput.get(PATH).asText());
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @When("Mock Update Other document state to Draft and status of AV_SCAN_FAILURE of invalid document for input {string}")
    public void switchOtherDocumentToNewStateMock(String inputName) throws JsonProcessingException, JSONException {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        JsonNode input = externalInputsAsJsonNode.get(inputName);
        JsonNode testInput = (new ObjectMapper().readTree(responseString));
        String caseId = testInput.get(CASE_ID).asText();
        String requestId = testInput.get(DOCUMENTS).get(0).get(REQUEST_ID).asText();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(input);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", caseId);
        doc.set("state","Draft");
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(testInput))
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_FI_REQUEST_UPDATE_STATUS_CASE_ID_PATH);
        response = request.put(POST_FI_REQUEST_UPDATE_STATUS_CASE_ID_PATH);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
    }

    @When("Update document state to Draft and status of Error document to Removed to for input {string}")
    public void switchDocumentToNewState(String inputName) throws JsonProcessingException, JSONException {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        JsonNode testInput = (new ObjectMapper().readTree(responseString));
        JsonNode input = externalInputsAsJsonNode.get(inputName);
        String requestId = testInput.get(DOCUMENTS).get(0).get(REQUEST_ID).asText();
        String documentId = testInput.get(DOCUMENTS).get(0).get(DOCUMENT_INFO).get(0).get(DOCUMENT_ID).asText();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(input);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", caseIdCAPIE);
        doc.set("firequestId", requestId);
        doc.set("state","Draft");
        doc.set("requestBody.documentInfo.[0].documentStatus","REMOVED");
        doc.set("requestBody.documentInfo.[0].documentId", documentId);
        doc.set("loginUserName", "HBOPostSub8");
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(updatedInput))
                .headers(CucumberTestProperties.getHeaders(testInput))
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_FI_REQUEST_UPDATE_STATUS_CASE_ID_PATH);
        response = request.put(POST_FI_REQUEST_UPDATE_STATUS_CASE_ID_PATH);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @Then("Check FI document state is {string}")
    public void validateFIDocumentState(String state) throws JsonProcessingException {
        JsonNode getDocuments = (new ObjectMapper().readTree(responseString)).get(DOCUMENTS);
        Assertions.assertEquals(state, getDocuments.get(0).get(STATE).asText());
    }

    @Then("Check FI documentInfo statuses are CLOSED for all uploaded documents")
    public void validateFIDocumentInfoClosedStatuses() throws JsonProcessingException {
        JsonNode documentInfo = (new ObjectMapper().readTree(responseString)).get(DOCUMENTS).get(0).get(DOCUMENT_INFO);
        for(int i=0; i< documentInfo.size(); i++){
            Assertions.assertEquals(documentInfo.get(i).get(DOCUMENT_STATUS).asText(), "CLOSED");
        }
    }

    @Then("Check FI documents identifiers")
    public void validateFIDocumentIdentifiersAreTheSame() throws JsonProcessingException {
        JsonNode getDocuments = (new ObjectMapper().readTree(responseString)).get(DOCUMENTS);
        Assertions.assertEquals(getDocuments.get(0).get(DOCUMENT_IDENTIFIER).asText(), "FI");
    }

    @Then("Validate state is Open and the documentInfo is empty")
    public void validateFIstateOpenDocumentInfoEmpty() throws JsonProcessingException {
        JsonNode getFirstDocument = (new ObjectMapper().readTree(responseString)).get(DOCUMENTS).get(0);
        String state = getFirstDocument.get(STATE).asText();
        Assertions.assertTrue(state.equals("Open"));
        Assertions.assertTrue(getFirstDocument.get(DOCUMENT_INFO).size() == 0);
    }

    @Then("Validate state is Open and the documentInfo updated")
    public void validateFIstateOpenDocumentInfoNotEmpty() throws JsonProcessingException, InterruptedException {
        JsonNode getFirstDocument = (new ObjectMapper().readTree(responseString)).get(DOCUMENTS).get(0);
        String state = getFirstDocument.get(STATE).asText();
        Assertions.assertTrue(state.equals("Open"));
        Assertions.assertTrue(getFirstDocument.get(DOCUMENT_INFO).size() > 0);
        firstDocumentInfo = getFirstDocument.get(DOCUMENT_INFO);
    }

    @When("User sends request to upload doc {string} for channel {string} using input {string} and verify response code")
    public void userSendsRequestToUploadDocUsingInputAndVerifyResponseCode(String file, String channel, String inputName) throws JsonProcessingException, InterruptedException {
        JsonNode responseInput = (new ObjectMapper().readTree(responseString));
        String caseId = caseIdCAPIE;
        String requestId = responseInput.get(DOCUMENTS).get(0).get(REQUEST_ID).asText();
        RestAssured.reset();
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String path = "/uploadDocument/case/{caseId}";
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", caseIdCAPIE);
        doc.set("formData.requestId", requestId);
        doc.set("formData.channel", channel);
        doc.set("formData.files.[0]",file);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        int CONNECTION_TIMEOUT_MS = 600000;
        RestAssuredConfig config = RestAssured.config()
                .httpClient(HttpClientConfig.httpClientConfig()
                        .dontReuseHttpClientInstance()
                        .setParam(CONNECTION_TIMEOUT, CONNECTION_TIMEOUT_MS)
                        .setParam(SO_TIMEOUT, CONNECTION_TIMEOUT_MS));
        RequestSpecification request = given().config(config)
                .header("MultiPart_Content-Type", CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(testInput))
                .formParam("channel", channel)
                //.formParam("requestId", requestId)
                .basePath(path);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, path);
        String fileType = CucumberTestProperties.getFileType(file);
        //request.multiPart("files", new File(MEDIA_FILES + file),fileType);
        setInputFiles(request, updatedInput.get(FORM_DATA).get(FILES));
        response = request.headers(CucumberTestProperties.getHeaders(testInput)).post();
        response = response.then().extract().response();
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        responseJsonNode = new ObjectMapper().readTree(response.asString());
    }

    @When("User sends request to upload Other doc {string} for channel {string} using input {string} and verify response code")
    public void userSendsRequestToUploadOtherDocUsingInputAndVerifyResponseCode(String file, String channel, String inputName) throws JsonProcessingException, InterruptedException {
        JsonNode responseInput = (new ObjectMapper().readTree(responseString));
        String caseId = caseIdCAPIE;
        RestAssured.reset();
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String path = "/uploadDocument/case/{caseId}";
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", caseId);
        doc.set("formData.channel", channel);
        doc.set("formData.files.[0]",file);
        doc.delete("formData.requestId");
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        int CONNECTION_TIMEOUT_MS = 600000;
        RestAssuredConfig config = RestAssured.config()
                .httpClient(HttpClientConfig.httpClientConfig()
                        .dontReuseHttpClientInstance()
                        .setParam(CONNECTION_TIMEOUT, CONNECTION_TIMEOUT_MS)
                        .setParam(SO_TIMEOUT, CONNECTION_TIMEOUT_MS));
        RequestSpecification request = given().config(config)
                .header("MultiPart_Content-Type", CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(testInput))
                .headers(CucumberTestProperties.getHeaders(testInput))
                .formParam("channel", channel)
                .basePath(path);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, path);
        setInputFiles(request, updatedInput.get(FORM_DATA).get(FILES));
        response = request.post();
        response = response.then().extract().response();
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        responseJsonNode = new ObjectMapper().readTree(response.asString());
    }

    @When("User sends request to upload Other doc {string} for reference number {string} channel {string} using input {string} and verify response code")
    public void userSendsRequestToUploadOtherDocUsingReferenceNumberInputAndVerifyResponseCode(String file, String referenceNumber, String channel, String inputName) throws JsonProcessingException, InterruptedException {
        RestAssured.reset();
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String path = "/uploadDocument/{referenceNumber}";
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("referenceNumber", referenceNumber);
        doc.set("formData.channel", channel);
        doc.set("formData.files.[0]",file);
        doc.delete("formData.requestId");
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        int CONNECTION_TIMEOUT_MS = 600000;
        RestAssuredConfig config = RestAssured.config()
                .httpClient(HttpClientConfig.httpClientConfig()
                        .dontReuseHttpClientInstance()
                        .setParam(CONNECTION_TIMEOUT, CONNECTION_TIMEOUT_MS)
                        .setParam(SO_TIMEOUT, CONNECTION_TIMEOUT_MS));
        RequestSpecification request = given().config(config)
                .header("MultiPart_Content-Type", CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(testInput))
                .headers(CucumberTestProperties.getHeaders(testInput))
                .formParam("channel", channel)
                .basePath(path);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, path);
        setInputFiles(request, updatedInput.get(FORM_DATA).get(FILES));
        response = request.post();
        response = response.then().extract().response();
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        responseJsonNode = new ObjectMapper().readTree(response.asString());
    }

    private void setInputFiles(RequestSpecification request,JsonNode files) {
        StreamSupport.stream(files.spliterator(), false).forEach(file -> {
            Assertions.assertNotNull(file,"filename is missing");
            Assertions.assertFalse(StringUtils.isEmpty(file.asText()),"filename is missing");
            String fileType = CucumberTestProperties.getFileType(file.asText());
            request.multiPart("files", new File(MEDIA_FILES + file.asText()),fileType);
        });
    }

    @When("Delay test start")
       public void delayTestWithSeconds() throws InterruptedException {
         int delayTimeout = 61 - testDateFormatSeconds();
        log.info("Delay execution with "+delayTimeout+" seconds");
        Thread.sleep(delayTimeout*1000);
    }

    @When("External Services - User sends request to post application for channel {string} using kafka topic input {string}")
    public void externalServicesUserSendsRequestToPostApplicationForChannelUsingKafkaTopicInput(String channel, String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getMSVCFlowManagerURI();

        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("requestBody.caseId", caseIdCAPIE);
        //doc.set("requestBody.mortgageRefNo", testInput.get("requestBody.mortgageRefNo"));
        doc.set("requestBody.channel", channel);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenMsvcFlowManager())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, testInput.get(PATH).asText());
        response = request.post(testInput.get(PATH).asText());
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();

    }

    @When("User sends request to view notes for GMS reference number using input {string} and verify response code")
    public void userSendsRequestToViewNotesForGMSReferenceNumberUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
        String GET_NOTES_INFORMATION = "/notesInformation/{referenceNumber}";
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(testInput, request, GET_NOTES_INFORMATION);
        response = request.get(GET_NOTES_INFORMATION);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
        JsonNode addGMSNoteInitialCountResponseMessage = (new ObjectMapper().readTree(responseString));
        initialNotesCount = addGMSNoteInitialCountResponseMessage.get("count").asInt();
        log.info("initial count " + initialNotesCount);
    }



    @Then("Check GMS added note {string}")
    public void checkGMSAddedNote(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
        String GET_NOTES_INFORMATION = "/notesInformation/{referenceNumber}";
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(testInput, request, GET_NOTES_INFORMATION);
        response = request.get(GET_NOTES_INFORMATION);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
        JsonNode addedGMSNoteResponseMessage = (new ObjectMapper().readTree(responseString));
        int currentNotesCount = addedGMSNoteResponseMessage.get("count").asInt();
        boolean noteFound = false;
        Assertions.assertEquals(currentNotesCount, initialNotesCount+1, "Wrong notes count");
    }

    @When("User sends request to upload doc {string} for channel {string} using input {string} and verify response codes")
    public void userSendsRequestToUploadDocForChannelUsingInputAndVerifyResponseCodes(String file, String channel, String inputName) throws JsonProcessingException, InterruptedException {

        //JsonNode responseInput = (new ObjectMapper().readTree(responseString));
        String caseId = caseIdCAPIE;
        String referenceNumber = externalInputsAsJsonNode.get("kafkaPayloadForNotes").get("requestBody").get("mortgageRefNo").asText();
        //String requestId = responseInput.get(DOCUMENTS).get(0).get(REQUEST_ID).asText();
        RestAssured.reset();
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String path = "/uploadDocument/{referenceNumber}";
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("referenceNumber", referenceNumber);
        //doc.set("formData.requestId", requestId);
        doc.set("formData.channel", channel);
        doc.set("formData.files.[0]",file);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        int CONNECTION_TIMEOUT_MS = 600000;
        RestAssuredConfig config = RestAssured.config()
                .httpClient(HttpClientConfig.httpClientConfig()
                        .dontReuseHttpClientInstance()
                        .setParam(CONNECTION_TIMEOUT, CONNECTION_TIMEOUT_MS)
                        .setParam(SO_TIMEOUT, CONNECTION_TIMEOUT_MS));
        RequestSpecification request = given().config(config)
                .header("MultiPart_Content-Type", CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(testInput))
                .formParam("channel", channel)
                //.formParam("requestId", requestId)
                .basePath(path);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, path);
        String fileType = CucumberTestProperties.getFileType(file);
        //request.multiPart("files", new File(MEDIA_FILES + file),fileType);
        setInputFiles(request, updatedInput.get(FORM_DATA).get(FILES));
        response = request.headers(CucumberTestProperties.getHeaders(testInput)).post();
        response = response.then().extract().response();
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Thread.sleep(10000);
    }

    @Then("Delete Single record in mongo db for {string}")
    public void deleteSingleRecordInMongoDbFor(String inputName) {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        MongoActions.deleteSingleRecord("application","referenceNumber",testInput.get(REFERENCE_NUMBER).asText());
        MongoActions.deleteSingleRecord("documents","referenceNumber",testInput.get(REFERENCE_NUMBER).asText());
    }

    @Then("Delete Other document for referenceNumber {string}")
    public void removeODForReferenceNumber(String referenceNumber) {
        MongoActions.removeOtherDocumentFromApplicationRecord("referenceNumber",referenceNumber);
    }

    @Then("Delete Other document for caseId {string}")
    public void removeODForCaseId(String caseId) {
        MongoActions.removeOtherDocumentFromApplicationRecord("caseId",caseId);
    }

    @When("User sends request to upload doc {string} for channel {string} using input {string} and verify response code with request id")
    public void userSendsRequestToUploadDocForChannelUsingInputAndVerifyResponseCodeWithRequestId(String file, String channel, String inputName) throws JsonProcessingException, InterruptedException {
        JsonNode responseInput = (new ObjectMapper().readTree(responseString));
        String caseId = caseIdCAPIE;
        String referenceNumber = externalInputsAsJsonNode.get("kafkaPayloadForNotes").get("requestBody").get("mortgageRefNo").asText();
        String requestId = responseInput.get(DOCUMENTS).get(1).get(REQUEST_ID).asText();
        RestAssured.reset();
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String path = "/uploadDocument/{referenceNumber}";
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("referenceNumber", referenceNumber);
        doc.set("formData.requestId", requestId);
        doc.set("formData.channel", channel);
        doc.set("formData.files.[0]",file);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        int CONNECTION_TIMEOUT_MS = 600000;
        RestAssuredConfig config = RestAssured.config()
                .httpClient(HttpClientConfig.httpClientConfig()
                        .dontReuseHttpClientInstance()
                        .setParam(CONNECTION_TIMEOUT, CONNECTION_TIMEOUT_MS)
                        .setParam(SO_TIMEOUT, CONNECTION_TIMEOUT_MS));
        RequestSpecification request = given().config(config)
                .header("MultiPart_Content-Type", CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(testInput))
                .formParam("channel", channel)
                //.formParam("requestId", requestId)
                .basePath(path);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, path);
        String fileType = CucumberTestProperties.getFileType(file);
        //request.multiPart("files", new File(MEDIA_FILES + file),fileType);
        setInputFiles(request, updatedInput.get(FORM_DATA).get(FILES));
        response = request.headers(CucumberTestProperties.getHeaders(testInput)).post();
        response = response.then().extract().response();
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Thread.sleep(120000);
    }

    @When("Update document state change to {string} for input {string}")
    public void updateDocumentStateChangeToForInput(String state, String inputName) throws JsonProcessingException, InterruptedException, JSONException {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        JsonNode responseInput = (new ObjectMapper().readTree(responseString));
        String brand = CucumberTestProperties.getBrand();
        String fiRequestId = responseInput.get(DOCUMENTS).get(1).get(REQUEST_ID).asText();
        String docid1 = responseInput.get(DOCUMENTS).get(1).get(DOCUMENT_INFO).get(0).get(DOCUMENT_ID).asText();
        String referenceNumber = externalInputsAsJsonNode.get("kafkaPayloadForNotes").get("requestBody").get("mortgageRefNo").asText();

        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("brand", brand);
        doc.set("referenceNumber",referenceNumber);
        doc.set("firequestId", fiRequestId);
        doc.set("state", state);
        doc.set("requestBody.documentInfo.[0].documentId",docid1);

        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(testInput))
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_FI_REQUEST_UPDATE_STATUS_PATH);
        response = request.put(POST_FI_REQUEST_UPDATE_STATUS_PATH);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
        Thread.sleep(10000);
    }

    @When("User sends request to upload doc {string} for channel {string} using input {string} and verify response code with bank statement request id")
    public void userSendsRequestToUploadDocForChannelUsingInputAndVerifyResponseCodeWithBankStatementRequestId(String file, String channel, String inputName) throws JsonProcessingException, InterruptedException {
        JsonNode responseInput = (new ObjectMapper().readTree(responseString));
        String caseId = caseIdCAPIE;
        String referenceNumber = externalInputsAsJsonNode.get("kafkaPayloadForNotes").get("requestBody").get("mortgageRefNo").asText();
        String requestId = responseInput.get(DOCUMENTS).get(3).get(REQUEST_ID).asText();
        uploadedDocRequestId = requestId;
        RestAssured.reset();
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String path = "/uploadDocument/{referenceNumber}";
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("referenceNumber", referenceNumber);
        doc.set("formData.requestId", requestId);
        doc.set("formData.channel", channel);
        doc.set("formData.files.[0]",file);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        int CONNECTION_TIMEOUT_MS = 600000;
        RestAssuredConfig config = RestAssured.config()
                .httpClient(HttpClientConfig.httpClientConfig()
                        .dontReuseHttpClientInstance()
                        .setParam(CONNECTION_TIMEOUT, CONNECTION_TIMEOUT_MS)
                        .setParam(SO_TIMEOUT, CONNECTION_TIMEOUT_MS));
        RequestSpecification request = given().config(config)
                .header("MultiPart_Content-Type", CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(testInput))
                .headers(CucumberTestProperties.getHeaders(testInput))
                .formParam("channel", channel)
                //.formParam("requestId", requestId)
                .basePath(path);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, path);
        String fileType = CucumberTestProperties.getFileType(file);
        //request.multiPart("files", new File(MEDIA_FILES + file),fileType);
        setInputFiles(request, updatedInput.get(FORM_DATA).get(FILES));
        response = request.headers(CucumberTestProperties.getHeaders(testInput)).post();
        response = response.then().extract().response();
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Thread.sleep(10000);//20000
    }

    @When("Update document state change to {string} for input {string} for bank statement")
    public void updateDocumentStateChangeToForInputForBankStatement(String state, String inputName) throws JsonProcessingException, InterruptedException {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        JsonNode responseInput = (new ObjectMapper().readTree(responseString));
        String brand = CucumberTestProperties.getBrand();
        String fiRequestId = responseInput.get(DOCUMENTS).get(0).get(REQUEST_ID).asText();
        String docid1 = responseInput.get(DOCUMENTS).get(0).get(DOCUMENT_INFO).get(0).get(DOCUMENT_ID).asText();
        String referenceNumber = externalInputsAsJsonNode.get("kafkaPayloadForNotes").get("requestBody").get("mortgageRefNo").asText();

        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("brand", brand);
        doc.set("referenceNumber",referenceNumber);
        doc.set("firequestId", fiRequestId);
        doc.set("state", state);
        doc.set("requestBody.documentInfo.[0].documentId",docid1);

        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(testInput))
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_FI_REQUEST_UPDATE_STATUS_PATH);
        response = request.put(POST_FI_REQUEST_UPDATE_STATUS_PATH);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
        Thread.sleep(10000);
    }

    @When("User sends request to upload doc {string} for channel {string} using input {string} and verify response code with monthly payslip request id")
    public void userSendsRequestToUploadDocForChannelUsingInputAndVerifyResponseCodeWithMonthlyPayslipRequestId(String file, String channel, String inputName) throws JsonProcessingException, InterruptedException {
        JsonNode responseInput = (new ObjectMapper().readTree(responseString));
        String caseId = caseIdCAPIE;
        String referenceNumber = externalInputsAsJsonNode.get("kafkaPayloadForNotes").get("requestBody").get("mortgageRefNo").asText();
        String requestId = responseInput.get(DOCUMENTS).get(4).get(REQUEST_ID).asText();
        uploadedDocRequestId = requestId;
        RestAssured.reset();
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String path = "/uploadDocument/{referenceNumber}";
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("referenceNumber", referenceNumber);
        doc.set("formData.requestId", requestId);
        doc.set("formData.channel", channel);
        doc.set("formData.files.[0]",file);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        int CONNECTION_TIMEOUT_MS = 600000;
        RestAssuredConfig config = RestAssured.config()
                .httpClient(HttpClientConfig.httpClientConfig()
                        .dontReuseHttpClientInstance()
                        .setParam(CONNECTION_TIMEOUT, CONNECTION_TIMEOUT_MS)
                        .setParam(SO_TIMEOUT, CONNECTION_TIMEOUT_MS));
        RequestSpecification request = given().config(config)
                .header("MultiPart_Content-Type", CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(testInput))
                .formParam("channel", channel)
                //.formParam("requestId", requestId)
                .basePath(path);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, path);
        String fileType = CucumberTestProperties.getFileType(file);
        //request.multiPart("files", new File(MEDIA_FILES + file),fileType);
        setInputFiles(request, updatedInput.get(FORM_DATA).get(FILES));
        response = request.headers(CucumberTestProperties.getHeaders(testInput)).post();
        response = response.then().extract().response();
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Thread.sleep(10000);//200000

    }

    @When("Update document state change to {string} for input {string} for monthly payslip")
    public void updateDocumentStateChangeToForInputForMonthlyPayslip(String state, String inputName) throws JsonProcessingException, InterruptedException {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        JsonNode responseInput = (new ObjectMapper().readTree(responseString));
        String brand = CucumberTestProperties.getBrand();
        String fiRequestId = responseInput.get(DOCUMENTS).get(0).get(REQUEST_ID).asText();
        String docid1 = responseInput.get(DOCUMENTS).get(0).get(DOCUMENT_INFO).get(0).get(DOCUMENT_ID).asText();
        String referenceNumber = externalInputsAsJsonNode.get("kafkaPayloadForNotes").get("requestBody").get("mortgageRefNo").asText();

        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("brand", brand);
        doc.set("referenceNumber",referenceNumber);
        doc.set("firequestId", fiRequestId);
        doc.set("state", state);
        doc.set("requestBody.documentInfo.[0].documentId",docid1);

        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(testInput))
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_FI_REQUEST_UPDATE_STATUS_PATH);
        response = request.put(POST_FI_REQUEST_UPDATE_STATUS_PATH);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
        Thread.sleep(10000);
    }

    @When("Update document state to {string} for input {string} for bank statement")
    public void updateDocumentStateToForInputForBankStatement(String state, String inputName) throws JsonProcessingException, JSONException, InterruptedException {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        JsonNode testInput = (new ObjectMapper().readTree(responseString));
        String brand = CucumberTestProperties.getBrand();
        String caseId = testInput.get(CASE_ID).asText();
        String fiRequestId = testInput.get(DOCUMENTS).get(3).get(REQUEST_ID).asText();
        JSONObject doc = new JSONObject();
        doc.put("brand", brand);
        doc.put("caseId", caseId);
        doc.put("firequestId", fiRequestId);
        doc.put("state", state);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.toString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(testInput))
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_FI_REQUEST_UPDATE_STATUS_CASE_ID_PATH);
        response = request.put(POST_FI_REQUEST_UPDATE_STATUS_CASE_ID_PATH);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @When("Update document state to {string} for input {string} for monthly payslip")
    public void updateDocumentStateToForInputForMonthlyPayslip(String state, String inputName) throws JsonProcessingException, InterruptedException, JSONException {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        JsonNode testInput = (new ObjectMapper().readTree(responseString));
        String brand = CucumberTestProperties.getBrand();
        String caseId = testInput.get(CASE_ID).asText();
        String fiRequestId = testInput.get(DOCUMENTS).get(4).get(REQUEST_ID).asText();
        JSONObject doc = new JSONObject();
        doc.put("brand", brand);
        doc.put("caseId", caseId);
        doc.put("firequestId", fiRequestId);
        doc.put("state", state);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.toString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(testInput))
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_FI_REQUEST_UPDATE_STATUS_CASE_ID_PATH);
        response = request.put(POST_FI_REQUEST_UPDATE_STATUS_CASE_ID_PATH);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @When("User able to open tasks for referenceNumber {string} using {int} seconds timeout")
    public void userAbleToOpenTasksForReferenceNumberUsingSecondsTimeout(String inputName, int timeout) throws InterruptedException, JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        JsonNode requestInput = mapper.createObjectNode();
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        ObjectNode addedNode = ((ObjectNode) requestInput).putObject("requestQuery");
        addedNode.put(BRAND, CucumberTestProperties.getBrand());
        addedNode.put(REFERENCE_NUMBER, testInput.get(REFERENCE_NUMBER).asText());
        addedNode.put(TASK_STATUS, "Open");
        addedNode.put("loginUserName", "HBOPostSub8");
        int retries = timeout/5 + 1;
        for(int i = 0; i < retries; i++) {
            Thread.sleep(5000);
            RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
            RequestSpecification request = RestAssured.given()
                    .log().all()
                    .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                    .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                    .accept(ContentType.JSON);
            ApiTestUtil.createRequestForInputParams(addedNode, request, GET_TASK_INFORMATION_PATH);
            response = request.headers(CucumberTestProperties.getHeaders(addedNode)).get(GET_TASK_INFORMATION_PATH);
            log.info("response " + response);
            responseJsonNode = new ObjectMapper().readTree(response.asString());
            log.info(response.getHeaders().asList().toString());
            log.info(response.getBody().prettyPrint());
            Assertions.assertNotNull(response, "response is null");
            responseString = response.asString();
            if(responseString.contains("FST")){
                log.info("Task availability duration: "+i*5+"seconds");
                break;
            }
        }

    }

    @Then("Check SMS task")
    public void checkSMSTask() throws JsonProcessingException {

        JsonNode tasks = (new ObjectMapper().readTree(responseString)).get(TASK_INFORMATION);
        boolean found = false;
        for(int i = 0; i < tasks.size(); i++) {
            if(tasks.get(i).get(CODE).asText().equals("SMS")) {
                found = true;
                Assertions.assertTrue(tasks.get(i).get(STATUS).asText().equals("Open"));
            }
        }
        Assertions.assertTrue(found);
    }

    @When("User able to close tasks for referenceNumber {string} using {int} seconds timeout")
    public void userAbleToCloseTasksForReferenceNumberUsingSecondsTimeout(String inputName, int timeout) throws InterruptedException, JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        JsonNode requestInput = mapper.createObjectNode();
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        ObjectNode addedNode = ((ObjectNode) requestInput).putObject("requestQuery");
        addedNode.put(BRAND, CucumberTestProperties.getBrand());
        addedNode.put(REFERENCE_NUMBER, testInput.get(REFERENCE_NUMBER).asText());
        addedNode.put(TASK_STATUS, "Close");
        addedNode.put("loginUserName", "HBOPostSub8");
        int retries = timeout/5 + 1;
        for(int i = 0; i < retries; i++) {
            Thread.sleep(5000);
            RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
            RequestSpecification request = RestAssured.given()
                    .log().all()
                    .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                    .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                    .accept(ContentType.JSON);
            ApiTestUtil.createRequestForInputParams(addedNode, request, GET_TASK_INFORMATION_PATH);
            response = request.headers(CucumberTestProperties.getHeaders(addedNode)).get(GET_TASK_INFORMATION_PATH);
            log.info("response " + response);
            responseJsonNode = new ObjectMapper().readTree(response.asString());
            log.info(response.getHeaders().asList().toString());
            log.info(response.getBody().prettyPrint());
            Assertions.assertNotNull(response, "response is null");
            responseString = response.asString();
            if(responseString.contains("FST")){
                log.info("Task availability duration: "+i*5+"seconds");
                break;
            }
        }

    }

    @Then("Check SMS task get closed")
    public void checkSMSTaskGetClosed() throws JsonProcessingException {
        JsonNode tasks = (new ObjectMapper().readTree(responseString)).get(TASK_INFORMATION);
        boolean found = false;
        for(int i = 0; i < tasks.size(); i++) {
            if(tasks.get(i).get(CODE).asText().equals("SMS")) {
                found = true;
                Assertions.assertTrue(tasks.get(i).get(STATUS).asText().equals("Closed"));
            }
        }
        Assertions.assertTrue(found);
    }


    @Then("User verify notes count using input {string} and verify response code")
    public void userVerifyNotesCountUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
        String GET_NOTES_INFORMATION = "/notesInformation/{referenceNumber}";
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(testInput, request, GET_NOTES_INFORMATION);
        response = request.get(GET_NOTES_INFORMATION);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
        JsonNode addedGMSNoteResponseMessage = (new ObjectMapper().readTree(responseString));
        int currentNotesCount = addedGMSNoteResponseMessage.get("count").asInt();
        boolean noteFound = false;
        //Assertions.assertEquals(currentNotesCount, initialNotesCount+9, "Wrong notes count");
    }

    @Then("User verify notes for opening count using input {string} and verify response code")
    public void userVerifyNotesForOpeningCountUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
        String GET_NOTES_INFORMATION = "/notesInformation/{referenceNumber}";
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(testInput, request, GET_NOTES_INFORMATION);
        response = request.get(GET_NOTES_INFORMATION);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
        JsonNode addedGMSNoteResponseMessage = (new ObjectMapper().readTree(responseString));
        int currentNotesCount = addedGMSNoteResponseMessage.get("count").asInt();
        boolean noteFound = false;
       //Assertions.assertEquals(currentNotesCount, initialNotesCount+3, "Wrong notes count");
    }

    @Then("User use get FI List endpoint using input {string} and verify response code")
    public void userUseGetFIListEndpointUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException, InterruptedException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getApplicationTrackingURI();
        String GET_FI_LIST = "/application/{referenceNumber}/filist";
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(testInput, request, GET_FI_LIST);
        response = request.get(GET_FI_LIST);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Thread.sleep(3000);

        JsonNode category = responseJsonNode.get(DOCUMENTS).get(0).get(CATEGORY);
        Assertions.assertEquals("Tele Message",category.asText());
        JsonNode documentIdentifier = responseJsonNode.get(DOCUMENTS).get(0).get(DOCUMENT_IDENTIFIER);
        Assertions.assertEquals("TM1",documentIdentifier.asText());
        JsonNode fiType = responseJsonNode.get(DOCUMENTS).get(0).get(FI_TYPE);
        Assertions.assertEquals("TeleMessage",fiType.asText());
        JsonNode customerResponse = responseJsonNode.get(DOCUMENTS).get(0).get(CUSTOMER_RESPONSE);
        Assertions.assertEquals("16/06/2023-Sumit gupta main applicant calle me-Change of product for A - B",customerResponse.asText());
    }

    @When("Verify removed documentIdentifier code {string} in the FI_types collection is not present")
    public void userSendsRequestToUploadDocUsingInputAndVerifyResponseCode(String code) throws JsonProcessingException, InterruptedException {
        ArrayList<String> codeNotAvailable = MongoActions.queryMongo("FI_types", "purpose.identifier", code);
        if( codeNotAvailable.size() > 0 ){
            log.info("removed code: "+code+"found");
            Assertions.assertTrue(false);
        } else {
            Assertions.assertTrue(true);
        }
    }

    @When("Verify attributes assesTask {string} towerCode {string} applicantLevel {string} for documentIdentifier {string} in the codes collection")
    public void verifyCodeAttributes(String assesTask, String towerCode, String applicantLevel, String identifier) throws JsonProcessingException, InterruptedException {
        JsonNode identifierAttributes = new ObjectMapper().readTree(MongoActions.queryMongo("codes", "identifier", identifier).get(0));
        Assertions.assertEquals(assesTask, identifierAttributes.get("gmsTaskCode").asText());
        Assertions.assertEquals(towerCode, identifierAttributes.get("towerCode").asText());
        String applicantLevelResponse = identifierAttributes.get("brokerEmailCopy").asText().contains("{Applicant}") ? "Yes" : "No";
        Assertions.assertEquals(applicantLevel, applicantLevelResponse);
    }

    @When("Verify attributes category {string} description {string} fiType {string} for identifier {string} in the FI_types collection")
    public void verifyCodeAttributesInFyTypes(String category, String description, String fiType, String identifier) throws JsonProcessingException, InterruptedException {
        JsonNode identifierAttributes = new ObjectMapper().readTree(MongoActions.queryMongo("FI_types", "purpose.identifier", identifier).get(0));
        Assertions.assertEquals(category, identifierAttributes.get("category").asText());
        Assertions.assertEquals(description, identifierAttributes.get("purpose").get(0).get("description").asText());
        Assertions.assertEquals(fiType, identifierAttributes.get("purpose").get(0).get("fiType").asText());
    }

    @When("User sends request to add caseId for joint applicant in CAPIE service using input {string} and check response code")
    public void userSendsRequestToAddCaseIdForJointApplicantInCAPIEServiceUsingInputAndCheckResponseCode(String inputName) throws JsonProcessingException {

        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getCAPIEApplicantServiceURI();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
       // caseIdCAPIE = testInput.get(REQUEST_BODY).get(CASE_ID).asText() + testDateFormat();
        referenceNumberCAPIE = testDateFormatShort().toString();
        doc.set("requestBody.caseId", caseIdCAPIE);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenCapieApplicant())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_APPLICANT_CASE_ID_CAPIE_PATH);
        response = request.post(POST_APPLICANT_CASE_ID_CAPIE_PATH);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        applicantString = response.asString();
        responseString = response.asString();
    }

    @When("Update document state to {string} for input {string} for FI Validation")
    public void updateDocumentStateToForInputForFIValidation(String state, String inputName) throws JsonProcessingException, JSONException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String brand = CucumberTestProperties.getBrand();
        JSONObject doc = new JSONObject();
        doc.put("brand", brand);
        doc.put("caseId", caseIdCAPIE);
        doc.put("firequestId", fiRequestId);
        doc.put("state", state);

        JsonNode updatedInput = new ObjectMapper().readTree(doc.toString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(updatedInput))
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, PUT_UPDATE_FI_STATE_CASEID_JSON_PATH_PARAM);
        response = request.put(PUT_UPDATE_FI_STATE_CASEID_JSON_PATH_PARAM);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @When("Update document state change to {string} for input {string} for FI State Validation")
    public void updateDocumentStateChangeToForInputForFIStateValidation(String state, String inputName) throws JsonProcessingException, InterruptedException {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        JsonNode responseInput = (new ObjectMapper().readTree(responseString));
        String brand = CucumberTestProperties.getBrand();
        String fiRequestId = responseInput.get(DOCUMENTS).get(0).get(REQUEST_ID).asText();
        String docid1 = responseInput.get(DOCUMENTS).get(0).get(DOCUMENT_INFO).get(0).get(DOCUMENT_ID).asText();
        String referenceNumber = externalInputsAsJsonNode.get("kafkaPayloadForFIValidation").get("requestBody").get("mortgageRefNo").asText();

        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("brand", brand);
        doc.set("referenceNumber",referenceNumber);
        doc.set("firequestId", fiRequestId);
        doc.set("state", state);
        doc.set("requestBody.documentInfo.[0].documentId",docid1);

        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(testInput))
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_FI_REQUEST_UPDATE_STATUS_PATH);
        response = request.put(POST_FI_REQUEST_UPDATE_STATUS_PATH);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
        Thread.sleep(10000);
    }

    @When("User sends request to upload doc {string} for channel {string} using input {string} and verify response code for other")
    public void userSendsRequestToUploadDocForChannelUsingInputAndVerifyResponseCodeForOther(String file, String channel, String inputName) throws JsonProcessingException, InterruptedException {
        JsonNode responseInput = (new ObjectMapper().readTree(responseString));
        String caseId = caseIdCAPIE;
        //String requestId = responseInput.get(DOCUMENTS).get(0).get(REQUEST_ID).asText();
        RestAssured.reset();
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String path = "/uploadDocument/case/{caseId}";
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", caseIdCAPIE);
        //doc.set("formData.requestId", requestId);
        doc.set("formData.channel", channel);
        doc.set("formData.files.[0]",file);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        int CONNECTION_TIMEOUT_MS = 600000;
        RestAssuredConfig config = RestAssured.config()
                .httpClient(HttpClientConfig.httpClientConfig()
                        .dontReuseHttpClientInstance()
                        .setParam(CONNECTION_TIMEOUT, CONNECTION_TIMEOUT_MS)
                        .setParam(SO_TIMEOUT, CONNECTION_TIMEOUT_MS));
        RequestSpecification request = given().config(config)
                .header("MultiPart_Content-Type", CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(testInput))
                .formParam("channel", channel)
                //.formParam("requestId", requestId)
                .basePath(path);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, path);
        String fileType = CucumberTestProperties.getFileType(file);
        //request.multiPart("files", new File(MEDIA_FILES + file),fileType);
        setInputFiles(request, updatedInput.get(FORM_DATA).get(FILES));
        response = request.headers(CucumberTestProperties.getHeaders(testInput)).post();
        response = response.then().extract().response();
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        //Thread.sleep(10000);
    }

    @Then("User use get Application Details endpoint using input {string} and verify response code")
    public void userUseGetApplicationDetailsEndpointUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getApplicationTrackingURI();
        String GET_APPLICATION = "/application/{referenceNumber}";
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(testInput, request, GET_APPLICATION);
        response = request.get(GET_APPLICATION);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        //Thread.sleep(3000);
        JsonNode applicationDetails = responseJsonNode.get("applicationDetails");
        JsonNode stageHistoryArray = applicationDetails.get("stageHistory");
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistoryAssessment = stageHistoryArray.get(1);
        JsonNode RequiredActions = stageHistoryAssessment.get("requiredActions").get(0);
        Assertions.assertEquals(RequestFurtherInformationReferenceNumberStepDefs.additionalInfoText, RequiredActions.get("description").asText());


    }

    @Then("fetch the requestid from get FI List using input {string} and verify response code")
    public void fetchTheRequestidFromGetFIListUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getApplicationTrackingURI();
        String GET_FI_LIST = "/application/{referenceNumber}/filist";
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(testInput, request, GET_FI_LIST);
        response = request.get(GET_FI_LIST);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        customFirequestId = responseJsonNode.get("documents").get(0).get("requestId").asText();

    }

    @Then("update state FI to review using using input {string} and verify response code")
    public void updateStateFIToReviewUsingUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException, InterruptedException, JSONException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String UPDATE_FI_STATE = "/application/{referenceNumber}/firequest/{firequestId}/fistate/{state}";
        customerResponseText = testInput.get(REQUEST_BODY).get("customerResponse").asText() +" "+ testDateFormat();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("firequestId", customFirequestId);
        doc.set("requestBody.customerResponse", customerResponseText);


        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(updatedInput))
                .accept(ContentType.JSON);
        Assertions.assertNotNull(updatedInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, UPDATE_FI_STATE);
        response = request.put(UPDATE_FI_STATE);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Thread.sleep(3000);
    }

    @Then("Verify customer response from notes information endpoint using input {string} and verify response code")
    public void verifyCustomerResponseFromNotesInformationEndpointUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getApplicationTrackingURI();
        String GET_NOTES_INFORMATION = "/notesInformation/{referenceNumber}";
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(testInput, request, GET_NOTES_INFORMATION);
        response = request.get(GET_NOTES_INFORMATION);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode detailsArray = responseJsonNode.get(DETAILS);
        boolean found = false;

        for (int i = 0; i < detailsArray.size(); i++) {
            String description = detailsArray.get(i).get("description").asText();
            if (description.contains(ExternalServicesStepDefs.closureNoteText)) {
                found = true;
            }
        }
        Assertions.assertTrue(found);
    }

    @Then("update state FI to closed using using input {string} and verify response code")
    public void updateStateFIToClosedUsingUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException, InterruptedException, JSONException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String UPDATE_FI_STATE = "/application/{referenceNumber}/firequest/{firequestId}/fistate/{state}";
        closureNoteText = testInput.get(REQUEST_BODY).get("note").asText() +" "+ testDateFormat();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("firequestId", customFirequestId);
        doc.set("requestBody.note", closureNoteText);

        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(updatedInput))
                .accept(ContentType.JSON);
        Assertions.assertNotNull(updatedInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, UPDATE_FI_STATE);
        response = request.put(UPDATE_FI_STATE);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Thread.sleep(3000);
    }

    @Then("User use get Application Details in broker coord endpoint using input {string} and verify response code")
    public void userUseGetApplicationDetailsInBrokerCoordEndpointUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getCoordApplicationTrackingURI();
        String GET_BROKER_APPLICATION_DETAILS = "/applicationDetails/{referenceNumber}";
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenCoordAppTracking())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(testInput, request, GET_BROKER_APPLICATION_DETAILS);
        response = request.get(GET_BROKER_APPLICATION_DETAILS);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        //Thread.sleep(3000);
        JsonNode applicationDetails = responseJsonNode.get("applicationDetails");
        JsonNode stageHistoryArray = applicationDetails.get("stageHistory");
        Assertions.assertTrue(stageHistoryArray.isArray());
        JsonNode stageHistoryAssessment = stageHistoryArray.get(0);
        JsonNode RequiredActions = stageHistoryAssessment.get("requiredActions").get(0);
        Assertions.assertEquals(RequestFurtherInformationReferenceNumberStepDefs.additionalInfoText, RequiredActions.get("description").asText());
    }

    @When("User sends request to view application data for caseId using input {string} and verify response code")
    public void userSendsRequestToViewApplicationDataForCaseIdUsingInputAndVerifyResponseCode(String inputName) throws InterruptedException, JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getMSVCApplicationURI();
        ObjectMapper mapper = new ObjectMapper();
        JsonNode requestInput = mapper.createObjectNode();
        ObjectNode addedNode = ((ObjectNode) requestInput).putObject("requestQuery");
        addedNode.put(BRAND, testInput.get(BRAND));
        addedNode.put(CASE_ID, caseIdCAPIE);
        Thread.sleep(10000);
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenMsvcApplication())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(addedNode, request, GET_APPLICATION_DATA_CASE_ID_PATH);
        response = request.get(GET_APPLICATION_DATA_CASE_ID_PATH);
        log.info("response " + response);
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        getApplicationData = response.asString();
    }

    @When("User sends request to upload main applicant doc {string} for channel {string} using input {string} and {string} and verify response code")
    public void userSendsRequestToUploadMainApplicantDocForChannelUsingInputAndAndVerifyResponseCode(String file, String channel, String inputName, String documentUploadInputName) throws JsonProcessingException, JSONException, InterruptedException {
        JsonNode applicationDataResponse = (new ObjectMapper().readTree(getApplicationData));
        JsonNode applicantArray = applicationDataResponse.get(APPLICANTS);
        String mainApplicantId = StreamSupport.stream(applicantArray.spliterator(), false)
                .filter(applicantJsonNode -> applicantJsonNode.get(MAIN_APPLICANT).asBoolean())
                .findFirst().map(applicant -> applicant.get(APPLICANT_ID).asText()).orElse(null);

        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getMSVCApplicationURI();
        ObjectMapper mapper = new ObjectMapper();
        JsonNode requestInput = mapper.createObjectNode();
        ObjectNode addedNode = ((ObjectNode) requestInput).putObject("requestQuery");
        addedNode.put(BRAND, testInput.get(BRAND));
        addedNode.put(CASE_ID, caseIdCAPIE);
        addedNode.put(APPLICATION_LEVEL, Boolean.TRUE);
        addedNode.put(APPLICANT_ID, mainApplicantId);
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenMsvcApplication())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(addedNode, request, GET_DOCUMENTS_CASE_ID_PATH);
        response = request.get(GET_DOCUMENTS_CASE_ID_PATH);
        log.info("response " + response);
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        String mainApplicantDocumentList = response.asString();

        JsonNode mainApplicantDocumentListResponse = (new ObjectMapper().readTree(mainApplicantDocumentList));
        JsonNode documentsArray = mainApplicantDocumentListResponse.get("documents");
        List<String> documentRequestIds = StreamSupport.stream(documentsArray.spliterator(), false)
                .map(document -> document.get(REQUEST_ID).asText()).collect(Collectors.toList());
        log.info("documentRequestIds : {}", documentRequestIds);
        updateStateForTheGivenRequestIds(documentRequestIds);
        uploadDocForTheGivenRequestIds(file, channel, documentUploadInputName, testInput, documentRequestIds);
    }

    private void uploadDocForTheGivenRequestIds(String file, String channel, String documentUploadInputName, JsonNode testInput, List<String> documentRequestIds) throws JsonProcessingException, InterruptedException {
        JsonNode docUploadTestInput = externalInputsAsJsonNode.get(documentUploadInputName);
        for (String requestId : documentRequestIds) {
            RestAssured.baseURI = CucumberTestProperties.getBaseURI();
            String path = "/uploadDocument/case/{caseId}";
            ObjectMapper objectMapper = new ObjectMapper();
            String json = objectMapper.writeValueAsString(docUploadTestInput);
            DocumentContext doc = JsonPath.parse(json);
            doc.set("caseId", caseIdCAPIE);
            doc.set("formData.requestId", requestId);
            doc.set("formData.channel", channel);
            doc.set("formData.files.[0]", file);
            JsonNode docUploadInput = new ObjectMapper().readTree(doc.jsonString());
            int CONNECTION_TIMEOUT_MS = 600000;
            RestAssuredConfig config = RestAssured.config()
                    .httpClient(HttpClientConfig.httpClientConfig()
                            .dontReuseHttpClientInstance()
                            .setParam(CONNECTION_TIMEOUT, CONNECTION_TIMEOUT_MS)
                            .setParam(SO_TIMEOUT, CONNECTION_TIMEOUT_MS));
            RequestSpecification docUploadRequest = given().config(config)
                    .header("MultiPart_Content-Type", CucumberTestProperties.getContentHeader())
                    .headers(CucumberTestProperties.getHeaders(docUploadTestInput))
                    .formParam("channel", channel)
                    .basePath(path);
            ApiTestUtil.createRequestForInputParams(docUploadInput, docUploadRequest, path);
            setInputFiles(docUploadRequest, docUploadInput.get(FORM_DATA).get(FILES));
            response = docUploadRequest.headers(CucumberTestProperties.getHeaders(testInput)).post();
            response = response.then().extract().response();
            log.info(response.getHeaders().asList().toString());
            log.info(response.getBody().prettyPrint());
            Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
            responseJsonNode = new ObjectMapper().readTree(response.asString());
            Thread.sleep(50000);
        }
    }

    private void updateStateForTheGivenRequestIds(List<String> documentRequestIds) throws JSONException, JsonProcessingException {
        for (String requestId : documentRequestIds) {
            RestAssured.baseURI = CucumberTestProperties.getBaseURI();
            String brand = CucumberTestProperties.getBrand();
            JSONObject doc = new JSONObject();
            doc.put("brand", brand);
            doc.put("caseId", caseIdCAPIE);
            doc.put("firequestId", requestId);
            doc.put("state", "Upload");

            JsonNode updatedInput = new ObjectMapper().readTree(doc.toString());
            RequestSpecification stateUpdateRequest = RestAssured.given()
                    .log().all()
                    .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                    .headers(CucumberTestProperties.getHeaders(updatedInput))
                    .accept(ContentType.JSON);
            ApiTestUtil.createRequestForInputParams(updatedInput, stateUpdateRequest, PUT_UPDATE_FI_STATE_CASEID_JSON_PATH_PARAM);
            response = stateUpdateRequest.put(PUT_UPDATE_FI_STATE_CASEID_JSON_PATH_PARAM);
            log.info("response " + response);
            log.info(response.getHeaders().asList().toString());
            log.info(response.getBody().prettyPrint());
            Assertions.assertEquals(200, response.getStatusCode());
            Assertions.assertNotNull(response, "response is null");
            responseString = response.asString();
        }
    }


    private void updateCustomerResonseForText(List<String> textRequestIds,String CustomerResponse) throws JSONException, JsonProcessingException {
        JsonNode customerResponseTestInput = externalInputsAsJsonNode.get(CustomerResponse);
        for (String requestId : textRequestIds) {
            RestAssured.baseURI = CucumberTestProperties.getBaseURI();
            String brand = CucumberTestProperties.getBrand();
            ObjectMapper objectMapper = new ObjectMapper();
            String json = objectMapper.writeValueAsString(customerResponseTestInput);
            DocumentContext doc = JsonPath.parse(json);
            doc.set("brand",brand);
            doc.set("firequestId", requestId);
            JsonNode stateUpdateInput = new ObjectMapper().readTree(doc.jsonString());

            RequestSpecification stateUpdateRequest = RestAssured.given()
                    .log().all()
                    .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                    .headers(CucumberTestProperties.getHeaders(stateUpdateInput))
                    .accept(ContentType.JSON);
            ApiTestUtil.createRequestForInputParams(stateUpdateInput, stateUpdateRequest, PUT_UPDATE_FI_STATE_REF_JSON_PATH_PARAM);
            response = stateUpdateRequest.put(PUT_UPDATE_FI_STATE_REF_JSON_PATH_PARAM);
            log.info("response " + response);
            log.info(response.getHeaders().asList().toString());
            log.info(response.getBody().prettyPrint());
            Assertions.assertEquals(200, response.getStatusCode());
            Assertions.assertNotNull(response, "response is null");
            responseString = response.asString();
        }
    }

    @Then("Check global and applicant one and applicant two packaging flag is false")
    public void checkGlobalAndApplicantOneAndApplicantTwoPackagingFlagIsFalse() throws JsonProcessingException {
        JsonNode getFiListAPIResponse = (new ObjectMapper().readTree(getDocumentOutput));
        Assertions.assertFalse(getFiListAPIResponse.get("isPackagingCompleted").asBoolean());
//        Assertions.assertFalse(getFiListAPIResponse.get("isPackagingCompletedForA1").asBoolean());
//        Assertions.assertFalse(getFiListAPIResponse.get("isPackagingCompletedForA2").asBoolean());
    }

    @Then("Check applicant one packaging flag is true and global and applicant two packaging flag is false")
    public void checkApplicantOnePackagingFlagIsTrueAndGlobalAndApplicantTwoPackagingFlagIsFalse() throws JsonProcessingException {
        JsonNode getFiListAPIResponse = (new ObjectMapper().readTree(getDocumentOutput));
        Assertions.assertFalse(getFiListAPIResponse.get("isPackagingCompleted").asBoolean());
//        Assertions.assertTrue(getFiListAPIResponse.get("isPackagingCompletedForA1").asBoolean());
//        Assertions.assertFalse(getFiListAPIResponse.get("isPackagingCompletedForA2").asBoolean());
    }

    @When("User sends request to upload joint applicant doc {string} for channel {string} using input {string} and {string} and verify response code")
    public void userSendsRequestToUploadJointApplicantDocForChannelUsingInputAndAndVerifyResponseCode(String file, String channel, String inputName, String documentUploadInputName) throws JsonProcessingException, JSONException, InterruptedException {
        JsonNode applicationDataResponse = (new ObjectMapper().readTree(getApplicationData));
        JsonNode applicantArray = applicationDataResponse.get(APPLICANTS);
        String jointApplicantId = StreamSupport.stream(applicantArray.spliterator(), false)
                .filter(applicantJsonNode -> !applicantJsonNode.get(MAIN_APPLICANT).asBoolean())
                .findFirst().map(applicant -> applicant.get(APPLICANT_ID).asText()).orElse(null);

        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getMSVCApplicationURI();
        ObjectMapper mapper = new ObjectMapper();
        JsonNode requestInput = mapper.createObjectNode();
        ObjectNode addedNode = ((ObjectNode) requestInput).putObject("requestQuery");
        addedNode.put(BRAND, testInput.get(BRAND));
        addedNode.put(CASE_ID, caseIdCAPIE);
        addedNode.put(APPLICANT_ID, jointApplicantId);
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenMsvcApplication())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(addedNode, request, GET_DOCUMENTS_CASE_ID_PATH);
        response = request.get(GET_DOCUMENTS_CASE_ID_PATH);
        log.info("response " + response);
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        String jointApplicantDocumentList = response.asString();

        JsonNode jointApplicantDocumentListResponse = (new ObjectMapper().readTree(jointApplicantDocumentList));
        JsonNode documentsArray = jointApplicantDocumentListResponse.get("documents");
        List<String> documentRequestIds = StreamSupport.stream(documentsArray.spliterator(), false)
                .map(document -> document.get(REQUEST_ID).asText()).collect(Collectors.toList());
        log.info("documentRequestIds : {}", documentRequestIds);
        updateStateForTheGivenRequestIds(documentRequestIds);
        uploadDocForTheGivenRequestIds(file, channel, documentUploadInputName, testInput, documentRequestIds);
    }

    @Then("Check applicant one packaging flag and global and applicant two packaging flag are true")
    public void checkApplicantOnePackagingFlagAndGlobalAndApplicantTwoPackagingFlagAreTrue() throws JsonProcessingException {
        JsonNode getFiListAPIResponse = (new ObjectMapper().readTree(getDocumentOutput));
        Assertions.assertTrue(getFiListAPIResponse.get("isPackagingCompleted").asBoolean());
//        Assertions.assertTrue(getFiListAPIResponse.get("isPackagingCompletedForA1").asBoolean());
//        Assertions.assertTrue(getFiListAPIResponse.get("isPackagingCompletedForA2").asBoolean());
    }

    @Then("User use get application data case endpoint using input {string} and get the applicantids")
    public void userUseGetApplicationDataCaseEndpointUsingInputAndGetTheApplicantids(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", caseIdCAPIE);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, GET_APPLICATION_DATA_CASE_ID_PATH);
        response = request.get(GET_APPLICATION_DATA_CASE_ID_PATH);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());

        applicantID1 = responseJsonNode.get("applicants").get(0).get("applicantId").asText();
        applicantID2 = responseJsonNode.get("applicants").get(1).get("applicantId").asText();

    }

    @When("User raise FI for applicant one using input {string} and verify response code")
    public void userRaiseFIForApplicantOneUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String POST_FI = "/application/case/{caseId}/firequest";
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", caseIdCAPIE);
        doc.set("requestBody.documentRequests[0].requiredFor[0].applicantId", applicantID1);

        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());

        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(updatedInput))
                .accept(ContentType.JSON);

        Assertions.assertNotNull(updatedInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_FI);
        response = request.post(POST_FI);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(201, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());

    }

    @Then("User use get FI List endpoint using input {string} and verify response after raising FI for applicant one")
    public void userUseGetFIListEndpointUsingInputAndVerifyResponseAfterRaisingFIForApplicantOne(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", caseIdCAPIE);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, GET_FI_LIST_CASE_ID_CAPIE_PATH);
        response = request.get(GET_FI_LIST_CASE_ID_CAPIE_PATH);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());

        JsonNode  isSIRequested = responseJsonNode.get("packagingStatus").get("isSIRequested");
        Assertions.assertEquals("true",isSIRequested.asText());

        JsonNode  isSIRequestedForA1 = responseJsonNode.get("packagingStatus").get("isSIRequestedForA1");
        Assertions.assertEquals("true",isSIRequestedForA1.asText());
    }

    @When("User raise FI for applicant two using input {string} abd verify response code")
    public void userRaiseFIForApplicantTwoUsingInputAbdVerifyResponseCode(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String POST_FI = "/application/case/{caseId}/firequest";
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", caseIdCAPIE);
        doc.set("requestBody.documentRequests[0].requiredFor[0].applicantId", applicantID2);

        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(updatedInput))
                .accept(ContentType.JSON);
        Assertions.assertNotNull(updatedInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_FI);
        response = request.post(POST_FI);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(201, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());

    }

    @Then("User use get FI List endpoint using input {string} and verify response after raising FI for applicant two")
    public void userUseGetFIListEndpointUsingInputAndVerifyResponseAfterRaisingFIForApplicantTwo(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", caseIdCAPIE);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, GET_FI_LIST_CASE_ID_CAPIE_PATH);
        response = request.get(GET_FI_LIST_CASE_ID_CAPIE_PATH);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());

        JsonNode  isSIRequested = responseJsonNode.get("packagingStatus").get("isSIRequested");
        Assertions.assertEquals("true",isSIRequested.asText());

        JsonNode  isSIRequestedForA2 = responseJsonNode.get("packagingStatus").get("isSIRequestedForA2");
        Assertions.assertEquals("true",isSIRequestedForA2.asText());

    }

    @When("User raise FI for applicant level using input {string} abd verify response code")
    public void userRaiseFIForApplicantLevelUsingInputAbdVerifyResponseCode(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String POST_FI = "/application/case/{caseId}/firequest";
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", caseIdCAPIE);

        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(updatedInput))
                .accept(ContentType.JSON);
        Assertions.assertNotNull(updatedInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_FI);
        response = request.post(POST_FI);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(201, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());

    }



    @When("User sends request to upload main applicant along with the custom FI doc {string} for channel {string} using input {string} and {string} and {string} verify response code")
    public void userSendsRequestToUploadMainApplicantAlongWithTheCustomFIDocForChannelUsingInputAndAndVerifyResponseCode(String file, String channel, String inputName, String documentUploadInputName, String CustomerResponse) throws JsonProcessingException, JSONException, InterruptedException {
        JsonNode applicationDataResponse = (new ObjectMapper().readTree(getApplicationData));
        JsonNode applicantArray = applicationDataResponse.get(APPLICANTS);
        String mainApplicantId = StreamSupport.stream(applicantArray.spliterator(), false)
                .filter(applicantJsonNode -> applicantJsonNode.get(MAIN_APPLICANT).asBoolean())
                .findFirst().map(applicant -> applicant.get(APPLICANT_ID).asText()).orElse(null);

        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getMSVCApplicationURI();
        ObjectMapper mapper = new ObjectMapper();
        JsonNode requestInput = mapper.createObjectNode();
        ObjectNode addedNode = ((ObjectNode) requestInput).putObject("requestQuery");
        addedNode.put(BRAND, testInput.get(BRAND));
        addedNode.put(CASE_ID, caseIdCAPIE);
        addedNode.put(APPLICATION_LEVEL, Boolean.TRUE);
        addedNode.put(APPLICANT_ID, mainApplicantId);
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenMsvcApplication())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(addedNode, request, GET_DOCUMENTS_CASE_ID_PATH);
        response = request.get(GET_DOCUMENTS_CASE_ID_PATH);
        log.info("response " + response);
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        String mainApplicantDocumentList = response.asString();

        JsonNode mainApplicantDocumentListResponse = (new ObjectMapper().readTree(mainApplicantDocumentList));
        JsonNode documentsArray = mainApplicantDocumentListResponse.get("documents");
        List<String> documentRequestIds = StreamSupport.stream(documentsArray.spliterator(), false).filter(a -> !"Text".equalsIgnoreCase(a.get("fiType").asText()))
                .map(document -> document.get(REQUEST_ID).asText()).collect(Collectors.toList());

        List<String> textRequestIds = StreamSupport.stream(documentsArray.spliterator(), false).filter(a -> "Text".equalsIgnoreCase(a.get("fiType").asText()))
                .map(document -> document.get(REQUEST_ID).asText()).collect(Collectors.toList());

        log.info("documentRequestIds : {}", documentRequestIds);
        updateStateForTheGivenRequestIds(documentRequestIds);
        uploadDocForTheGivenRequestIds(file, channel, documentUploadInputName, testInput, documentRequestIds);

        updateCustomerResonseForText(textRequestIds,CustomerResponse);

    }

    @When("User sends request to add caseId for broker in CAPIE service for specific type of channel {string} using input {string} and verify response code")
    public void userSendsRequestToAddCaseIdForBrokerInCAPIEServiceForSpecificTypeOfChannelUsingInputAndVerifyResponseCode(String channel, String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getCAPIEBrokerServiceURI();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("requestBody.caseId", caseIdCAPIE);
        doc.set("requestBody.channel", channel);
        if(channel.equalsIgnoreCase("INTERMEDIARY_NAPOLI") || channel.equalsIgnoreCase("INTERMEDIARY_BROKER_API"))
        {
            String referenceNumber = externalInputsAsJsonNode.get("FIValidationRef").get("referenceNumber").asText();
            doc.set("requestBody.mortgageReferenceNumber", referenceNumber);
        }
        else
        {
            log.info("proceed without reference number");
        }
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenCapieCase())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_BROKER_CASE_ID_CAPIE_PATH);
        response = request.post(POST_BROKER_CASE_ID_CAPIE_PATH);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @When("User sends request to add caseId for adbo in CAPIE service for channel {string} using input {string} and verify response code")
    public void userSendsRequestToAddCaseIdForAdboInCAPIEServiceForChannelUsingInputAndVerifyResponseCode(String channel, String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getCAPIEADBOServiceURI();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        adboUIIdCAPIE = testInput.get(REQUEST_BODY).get("adboUIId").asText() + newTestDateFormat();
        doc.set("requestBody.adboUIId", adboUIIdCAPIE);
        doc.set("requestBody.channel", channel);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenCapieCaseADBO())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_ADBO_CASE_ID_CAPIE_PATH);
        response = request.post(POST_ADBO_CASE_ID_CAPIE_PATH);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(201, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());


        JsonNode caseId = responseJsonNode.get("caseId");
        ADBO_UNIQUE_CASEID = caseId.asText();
    }

    @When("User sends request to add adbo caseId for applicant in CAPIE service using input {string} and check response code")
    public void userSendsRequestToAddAdboCaseIdForApplicantInCAPIEServiceUsingInputAndCheckResponseCode(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getCAPIEApplicantServiceURI();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        //ADBO_UNIQUE_CASEID = testInput.get(REQUEST_BODY).get(CASE_ID).asText() + testDateFormat();
        referenceNumberCAPIE = testDateFormatShort().toString();
        doc.set("requestBody.caseId", ADBO_UNIQUE_CASEID);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenCapieApplicant())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_APPLICANT_CASE_ID_CAPIE_PATH);
        response = request.post(POST_APPLICANT_CASE_ID_CAPIE_PATH);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        applicantString = response.asString();
        responseString = response.asString();
    }

    @When("User sends request to add adbo caseId for joint applicant in CAPIE service using input {string} and check response code")
    public void userSendsRequestToAddAdboCaseIdForJointApplicantInCAPIEServiceUsingInputAndCheckResponseCode(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getCAPIEApplicantServiceURI();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        //ADBO_UNIQUE_CASEID = testInput.get(REQUEST_BODY).get(CASE_ID).asText() + testDateFormat();
        referenceNumberCAPIE = testDateFormatShort().toString();
        doc.set("requestBody.caseId", ADBO_UNIQUE_CASEID);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenCapieApplicant())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_APPLICANT_CASE_ID_CAPIE_PATH);
        response = request.post(POST_APPLICANT_CASE_ID_CAPIE_PATH);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        applicantString = response.asString();
        responseString = response.asString();
    }

    @When("User sends request to add adbo income for caseId in CAPIE service using input {string} and verify response code")
    public void userSendsRequestToAddAdboIncomeForCaseIdInCAPIEServiceUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getIncomeServiceURI();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", ADBO_UNIQUE_CASEID);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenCapieIncome())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, PUT_INCOME_CASE_ID_CAPIE_PATH);
        response = request.put(PUT_INCOME_CASE_ID_CAPIE_PATH);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @When("adbo User use get Document endpoint using input {string} and verify response code")
    public void adboUserUseGetDocumentEndpointUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getMSVCApplicationURI();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", ADBO_UNIQUE_CASEID);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenMsvcApplication())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, GET_DOCUMENT_CASE_ID_CAPIE_PATH_MSVC_APPLICATION);
        response = request.get(GET_DOCUMENT_CASE_ID_CAPIE_PATH_MSVC_APPLICATION);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();

    }

    @When("adbo External Services - User sends request to post application for channel {string} using kafka topic input {string}")
    public void adboExternalServicesUserSendsRequestToPostApplicationForChannelUsingKafkaTopicInput(String channel, String inputName) throws JsonProcessingException, InterruptedException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getMSVCFlowManagerURI();

        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("requestBody.caseId", ADBO_UNIQUE_CASEID);
//        initialSequenceCount = initialSequenceCount + 1;
//        doc.set("requestBody.mortgageApplSeq", "0" + initialSequenceCount);
        doc.set("requestBody.channel", channel);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenMsvcFlowManager())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(updatedInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, testInput.get(PATH).asText());
        response = request.post(testInput.get(PATH).asText());
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
        Thread.sleep(6000);
    }

    @When("User sends request to view documents for adbo caseId using input {string} and verify response code")
    public void userSendsRequestToViewDocumentsForAdboCaseIdUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException, InterruptedException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getMSVCApplicationURI();
        ObjectMapper mapper = new ObjectMapper();
        JsonNode requestInput = mapper.createObjectNode();
        ObjectNode addedNode = ((ObjectNode) requestInput).putObject("requestQuery");
        addedNode.put(BRAND, testInput.get(BRAND));
        addedNode.put(CASE_ID, ADBO_UNIQUE_CASEID);
        Thread.sleep(10000);
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenMsvcApplication())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(addedNode, request, GET_DOCUMENTS_CASE_ID_PATH);
        response = request.get(GET_DOCUMENTS_CASE_ID_PATH);
        log.info("response " + response);
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        getDocumentOutput = response.asString();
        responseString = response.asString();
    }

    @Then("adbo User use get application data case endpoint using input {string} and get the applicantids")
    public void adboUserUseGetApplicationDataCaseEndpointUsingInputAndGetTheApplicantids(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", ADBO_UNIQUE_CASEID);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, GET_APPLICATION_DATA_CASE_ID_PATH);
        response = request.get(GET_APPLICATION_DATA_CASE_ID_PATH);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());

        applicantID1 = responseJsonNode.get("applicants").get(0).get("applicantId").asText();
        applicantID2 = responseJsonNode.get("applicants").get(1).get("applicantId").asText();

    }

    @When("adbo User raise FI for applicant one using input {string} and verify response code")
    public void adboUserRaiseFIForApplicantOneUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {

        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String POST_FI = "/application/case/{caseId}/firequest";
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", ADBO_UNIQUE_CASEID);
        doc.set("requestBody.documentRequests[0].requiredFor[0].applicantId", applicantID1);

        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());

        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(updatedInput))
                .accept(ContentType.JSON);

        Assertions.assertNotNull(updatedInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_FI);
        response = request.post(POST_FI);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(201, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());

    }

    @Then("adbo User use get FI List endpoint using input {string} and verify response after raising FI for applicant one")
    public void adboUserUseGetFIListEndpointUsingInputAndVerifyResponseAfterRaisingFIForApplicantOne(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", ADBO_UNIQUE_CASEID);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, GET_FI_LIST_CASE_ID_CAPIE_PATH);
        response = request.get(GET_FI_LIST_CASE_ID_CAPIE_PATH);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());

        JsonNode  isSIRequested = responseJsonNode.get("packagingStatus").get("isSIRequested");
        Assertions.assertEquals("true",isSIRequested.asText());

        JsonNode  isSIRequestedForA1 = responseJsonNode.get("packagingStatus").get("isSIRequestedForA1");
        Assertions.assertEquals("true",isSIRequestedForA1.asText());
    }

    @When("adbo User raise FI for applicant two using input {string} abd verify response code")
    public void adboUserRaiseFIForApplicantTwoUsingInputAbdVerifyResponseCode(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String POST_FI = "/application/case/{caseId}/firequest";
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", ADBO_UNIQUE_CASEID);
        doc.set("requestBody.documentRequests[0].requiredFor[0].applicantId", applicantID2);

        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(updatedInput))
                .accept(ContentType.JSON);
        Assertions.assertNotNull(updatedInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_FI);
        response = request.post(POST_FI);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(201, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());

    }

    @Then("adbo User use get FI List endpoint using input {string} and verify response after raising FI for applicant two")
    public void adboUserUseGetFIListEndpointUsingInputAndVerifyResponseAfterRaisingFIForApplicantTwo(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", ADBO_UNIQUE_CASEID);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, GET_FI_LIST_CASE_ID_CAPIE_PATH);
        response = request.get(GET_FI_LIST_CASE_ID_CAPIE_PATH);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode  isSIRequested = responseJsonNode.get("packagingStatus").get("isSIRequested");
        Assertions.assertEquals("true",isSIRequested.asText());

        JsonNode  isSIRequestedForA2 = responseJsonNode.get("packagingStatus").get("isSIRequestedForA2");
        Assertions.assertEquals("true",isSIRequestedForA2.asText());

    }

    @When("adbo User raise FI for applicant level using input {string} abd verify response code")
    public void adboUserRaiseFIForApplicantLevelUsingInputAbdVerifyResponseCode(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String POST_FI = "/application/case/{caseId}/firequest";
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", ADBO_UNIQUE_CASEID);

        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(updatedInput))
                .accept(ContentType.JSON);
        Assertions.assertNotNull(updatedInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_FI);
        response = request.post(POST_FI);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(201, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());

    }


    @When("adbo User sends request to view application data for caseId using input {string} and verify response code")
    public void adboUserSendsRequestToViewApplicationDataForCaseIdUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException, InterruptedException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getMSVCApplicationURI();
        ObjectMapper mapper = new ObjectMapper();
        JsonNode requestInput = mapper.createObjectNode();
        ObjectNode addedNode = ((ObjectNode) requestInput).putObject("requestQuery");
        addedNode.put(BRAND, testInput.get(BRAND));
        addedNode.put(CASE_ID, ADBO_UNIQUE_CASEID);
        Thread.sleep(10000);
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenMsvcApplication())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(addedNode, request, GET_APPLICATION_DATA_CASE_ID_PATH);
        response = request.get(GET_APPLICATION_DATA_CASE_ID_PATH);
        log.info("response " + response);
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        getApplicationData = response.asString();
    }

    @When("adbo User sends request to upload main applicant along with the custom FI doc {string} for channel {string} using input {string} and {string} and {string} verify response code")
    public void adboUserSendsRequestToUploadMainApplicantAlongWithTheCustomFIDocForChannelUsingInputAndAndVerifyResponseCode(String file, String channel, String inputName, String documentUploadInputName, String CustomerResponse) throws JsonProcessingException, JSONException, InterruptedException {
        JsonNode applicationDataResponse = (new ObjectMapper().readTree(getApplicationData));
        JsonNode applicantArray = applicationDataResponse.get(APPLICANTS);
        String mainApplicantId = StreamSupport.stream(applicantArray.spliterator(), false)
                .filter(applicantJsonNode -> applicantJsonNode.get(MAIN_APPLICANT).asBoolean())
                .findFirst().map(applicant -> applicant.get(APPLICANT_ID).asText()).orElse(null);

        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getMSVCApplicationURI();
        ObjectMapper mapper = new ObjectMapper();
        JsonNode requestInput = mapper.createObjectNode();
        ObjectNode addedNode = ((ObjectNode) requestInput).putObject("requestQuery");
        addedNode.put(BRAND, testInput.get(BRAND));
        addedNode.put(CASE_ID, ADBO_UNIQUE_CASEID);
        addedNode.put(APPLICATION_LEVEL, Boolean.TRUE);
        addedNode.put(APPLICANT_ID, mainApplicantId);
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenMsvcApplication())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(addedNode, request, GET_DOCUMENTS_CASE_ID_PATH);
        response = request.get(GET_DOCUMENTS_CASE_ID_PATH);
        log.info("response " + response);
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        String mainApplicantDocumentList = response.asString();

        JsonNode mainApplicantDocumentListResponse = (new ObjectMapper().readTree(mainApplicantDocumentList));
        JsonNode documentsArray = mainApplicantDocumentListResponse.get("documents");
        List<String> documentRequestIds = StreamSupport.stream(documentsArray.spliterator(), false).filter(a -> !"Text".equalsIgnoreCase(a.get("fiType").asText()))
                .map(document -> document.get(REQUEST_ID).asText()).collect(Collectors.toList());

        List<String> textRequestIds = StreamSupport.stream(documentsArray.spliterator(), false).filter(a -> "Text".equalsIgnoreCase(a.get("fiType").asText()))
                .map(document -> document.get(REQUEST_ID).asText()).collect(Collectors.toList());

        log.info("documentRequestIds : {}", documentRequestIds);

        adboupdateStateForTheGivenRequestIds(documentRequestIds);
        adbouploadDocForTheGivenRequestIds(file, channel, documentUploadInputName, testInput, documentRequestIds);
        updateCustomerResonseForText(textRequestIds,CustomerResponse);

    }

    private void adbouploadDocForTheGivenRequestIds(String file, String channel, String documentUploadInputName, JsonNode testInput, List<String> documentRequestIds) throws JsonProcessingException, InterruptedException {
        JsonNode docUploadTestInput = externalInputsAsJsonNode.get(documentUploadInputName);
        for (String requestId : documentRequestIds) {
            RestAssured.baseURI = CucumberTestProperties.getBaseURI();
            String path = "/uploadDocument/case/{caseId}";
            ObjectMapper objectMapper = new ObjectMapper();
            String json = objectMapper.writeValueAsString(docUploadTestInput);
            DocumentContext doc = JsonPath.parse(json);
            doc.set("caseId", ADBO_UNIQUE_CASEID);
            doc.set("formData.requestId", requestId);
            doc.set("formData.channel", channel);
            doc.set("formData.files.[0]", file);
            JsonNode docUploadInput = new ObjectMapper().readTree(doc.jsonString());
            int CONNECTION_TIMEOUT_MS = 600000;
            RestAssuredConfig config = RestAssured.config()
                    .httpClient(HttpClientConfig.httpClientConfig()
                            .dontReuseHttpClientInstance()
                            .setParam(CONNECTION_TIMEOUT, CONNECTION_TIMEOUT_MS)
                            .setParam(SO_TIMEOUT, CONNECTION_TIMEOUT_MS));
            RequestSpecification docUploadRequest = given().config(config)
                    .header("MultiPart_Content-Type", CucumberTestProperties.getContentHeader())
                    .headers(CucumberTestProperties.getHeaders(docUploadTestInput))
                    .formParam("channel", channel)
                    .basePath(path);
            ApiTestUtil.createRequestForInputParams(docUploadInput, docUploadRequest, path);
            setInputFiles(docUploadRequest, docUploadInput.get(FORM_DATA).get(FILES));
            response = docUploadRequest.headers(CucumberTestProperties.getHeaders(testInput)).post();
            response = response.then().extract().response();
            log.info(response.getHeaders().asList().toString());
            log.info(response.getBody().prettyPrint());
            Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
            responseJsonNode = new ObjectMapper().readTree(response.asString());
            Thread.sleep(50000);
        }
    }


    private void adboupdateStateForTheGivenRequestIds(List<String> documentRequestIds) throws JSONException, JsonProcessingException {
        for (String requestId : documentRequestIds) {
            RestAssured.baseURI = CucumberTestProperties.getBaseURI();
            String brand = CucumberTestProperties.getBrand();
            JSONObject doc = new JSONObject();
            doc.put("brand", brand);
            doc.put("caseId", ADBO_UNIQUE_CASEID);
            doc.put("firequestId", requestId);
            doc.put("state", "Upload");

            JsonNode updatedInput = new ObjectMapper().readTree(doc.toString());
            RequestSpecification stateUpdateRequest = RestAssured.given()
                    .log().all()
                    .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                    .headers(CucumberTestProperties.getHeaders(updatedInput))
                    .accept(ContentType.JSON);
            ApiTestUtil.createRequestForInputParams(updatedInput, stateUpdateRequest, PUT_UPDATE_FI_STATE_CASEID_JSON_PATH_PARAM);
            response = stateUpdateRequest.put(PUT_UPDATE_FI_STATE_CASEID_JSON_PATH_PARAM);
            log.info("response " + response);
            log.info(response.getHeaders().asList().toString());
            log.info(response.getBody().prettyPrint());
            Assertions.assertEquals(200, response.getStatusCode());
            Assertions.assertNotNull(response, "response is null");
            responseString = response.asString();
        }
    }


    @When("adbo User sends request to upload joint applicant doc {string} for channel {string} using input {string} and {string} and verify response code")
    public void adboUserSendsRequestToUploadJointApplicantDocForChannelUsingInputAndAndVerifyResponseCode(String file, String channel, String inputName, String documentUploadInputName) throws JsonProcessingException, JSONException, InterruptedException {

        JsonNode applicationDataResponse = (new ObjectMapper().readTree(getApplicationData));
        JsonNode applicantArray = applicationDataResponse.get(APPLICANTS);
        String jointApplicantId = StreamSupport.stream(applicantArray.spliterator(), false)
                .filter(applicantJsonNode -> !applicantJsonNode.get(MAIN_APPLICANT).asBoolean())
                .findFirst().map(applicant -> applicant.get(APPLICANT_ID).asText()).orElse(null);

        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getMSVCApplicationURI();
        ObjectMapper mapper = new ObjectMapper();
        JsonNode requestInput = mapper.createObjectNode();
        ObjectNode addedNode = ((ObjectNode) requestInput).putObject("requestQuery");
        addedNode.put(BRAND, testInput.get(BRAND));
        addedNode.put(CASE_ID, ADBO_UNIQUE_CASEID);
        addedNode.put(APPLICANT_ID, jointApplicantId);
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenMsvcApplication())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(addedNode, request, GET_DOCUMENTS_CASE_ID_PATH);
        response = request.get(GET_DOCUMENTS_CASE_ID_PATH);
        log.info("response " + response);
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        String jointApplicantDocumentList = response.asString();

        JsonNode jointApplicantDocumentListResponse = (new ObjectMapper().readTree(jointApplicantDocumentList));
        JsonNode documentsArray = jointApplicantDocumentListResponse.get("documents");
        List<String> documentRequestIds = StreamSupport.stream(documentsArray.spliterator(), false)
                .map(document -> document.get(REQUEST_ID).asText()).collect(Collectors.toList());
        log.info("documentRequestIds : {}", documentRequestIds);
        adboupdateStateForTheGivenRequestIds(documentRequestIds);
        adbouploadDocForTheGivenRequestIds(file, channel, documentUploadInputName, testInput, documentRequestIds);
    }

    @Then("User use get FI List endpoint using input {string} and verify flags for required docs and FI for applicant one and applicationlevel")
    public void userUseGetFIListEndpointUsingInputAndVerifyFlagsForRequiredDocsAndFIForApplicantOneAndApplicationlevel(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", caseIdCAPIE);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, GET_FI_LIST_CASE_ID_CAPIE_PATH);
        response = request.get(GET_FI_LIST_CASE_ID_CAPIE_PATH);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());

        JsonNode  isBasicPackagingReceived = responseJsonNode.get("packagingStatus").get("isBasicPackagingReceived");
        Assertions.assertEquals("false",isBasicPackagingReceived.asText());

        JsonNode  isBasicPackagingReceivedForA1 = responseJsonNode.get("packagingStatus").get("isBasicPackagingReceivedForA1");
        Assertions.assertEquals("true",isBasicPackagingReceivedForA1.asText());

        JsonNode  isSIReceived = responseJsonNode.get("packagingStatus").get("isSIReceived");
        Assertions.assertEquals("false",isSIReceived.asText());

        JsonNode  isSIReceivedForA1 = responseJsonNode.get("packagingStatus").get("isSIReceivedForA1");
        Assertions.assertEquals("true",isSIReceivedForA1.asText());
    }

    @Then("User use get FI List endpoint using input {string} and verify flags for required docs and FI for applicant two")
    public void userUseGetFIListEndpointUsingInputAndVerifyFlagsForRequiredDocsAndFIForApplicantTwo(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", caseIdCAPIE);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, GET_FI_LIST_CASE_ID_CAPIE_PATH);
        response = request.get(GET_FI_LIST_CASE_ID_CAPIE_PATH);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());

        JsonNode  isBasicPackagingReceived = responseJsonNode.get("packagingStatus").get("isBasicPackagingReceived");
        Assertions.assertEquals("true",isBasicPackagingReceived.asText());

        JsonNode  isBasicPackagingReceivedForA2 = responseJsonNode.get("packagingStatus").get("isBasicPackagingReceivedForA2");
        Assertions.assertEquals("true",isBasicPackagingReceivedForA2.asText());

        JsonNode  isSIReceived = responseJsonNode.get("packagingStatus").get("isSIReceived");
        Assertions.assertEquals("true",isSIReceived.asText());

        JsonNode  isSIReceivedForA2 = responseJsonNode.get("packagingStatus").get("isSIReceivedForA2");
        Assertions.assertEquals("true",isSIReceivedForA2.asText());

    }

    @When("User sends request update state to close for all the Fi and required docs for channel {string} using input {string} and {string} and {string} verify response code")
    public void userSendsRequestUpdateStateToCloseForAllTheFiAndRequiredDocsForChannelUsingInputAndAndVerifyResponseCode(String channel, String inputName, String documentUploadInputName, String CustomerResponse) throws JsonProcessingException, JSONException {
        JsonNode applicationDataResponse = (new ObjectMapper().readTree(getApplicationData));
        JsonNode applicantArray = applicationDataResponse.get(APPLICANTS);
        String allApplicantId = StreamSupport.stream(applicantArray.spliterator(), false)
                .filter(applicantJsonNode -> applicantJsonNode.get(MAIN_APPLICANT).asBoolean())
                .filter(applicantJsonNode -> !applicantJsonNode.get(MAIN_APPLICANT).asBoolean())
                .findFirst().map(applicant -> applicant.get(APPLICANT_ID).asText()).orElse(null);

        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getMSVCApplicationURI();
        ObjectMapper mapper = new ObjectMapper();
        JsonNode requestInput = mapper.createObjectNode();
        ObjectNode addedNode = ((ObjectNode) requestInput).putObject("requestQuery");
        addedNode.put(BRAND, testInput.get(BRAND));
        addedNode.put(CASE_ID, caseIdCAPIE);
        addedNode.put(APPLICANT_ID, allApplicantId);
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenMsvcApplication())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(addedNode, request, GET_DOCUMENTS_CASE_ID_PATH);
        response = request.get(GET_DOCUMENTS_CASE_ID_PATH);
        log.info("response " + response);
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");

        String allApplicantDocumentList = response.asString();

        JsonNode allApplicantDocumentListResponse = (new ObjectMapper().readTree(allApplicantDocumentList));
        JsonNode documentsArray = allApplicantDocumentListResponse.get("documents");
        List<String> documentRequestIds = StreamSupport.stream(documentsArray.spliterator(), false)
                .map(document -> document.get(REQUEST_ID).asText()).collect(Collectors.toList());
        log.info("documentRequestIds : {}", documentRequestIds);
        updateStateToClosedForTheGivenRequestIds(documentRequestIds);

    }

    private void updateStateToClosedForTheGivenRequestIds(List<String> documentRequestIds) throws JSONException, JsonProcessingException {
        for (String requestId : documentRequestIds) {
            RestAssured.baseURI = CucumberTestProperties.getBaseURI();
            String brand = CucumberTestProperties.getBrand();
            JSONObject doc = new JSONObject();
            doc.put("brand", brand);
            doc.put("caseId", caseIdCAPIE);
            doc.put("firequestId", requestId);
            doc.put("state", "Closed");
            JsonNode updatedInput = new ObjectMapper().readTree(doc.toString());
            RequestSpecification stateUpdateRequest = RestAssured.given()
                    .log().all()
                    .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                    .headers(CucumberTestProperties.getHeaders(updatedInput))
                    .accept(ContentType.JSON);
            ApiTestUtil.createRequestForInputParams(updatedInput, stateUpdateRequest, PUT_UPDATE_FI_STATE_CASEID_JSON_PATH_PARAM);
            response = stateUpdateRequest.put(PUT_UPDATE_FI_STATE_CASEID_JSON_PATH_PARAM);
            log.info("response " + response);
            log.info(response.getHeaders().asList().toString());
            log.info(response.getBody().prettyPrint());
            Assertions.assertEquals(200, response.getStatusCode());
            Assertions.assertNotNull(response, "response is null");
            responseString = response.asString();
        }


    }



    private void updateStateToPSTREVIEWCOMPLETEForTheGivenRequestIds(List<String> documentRequestIds) throws JSONException, JsonProcessingException {
        for (String requestId : documentRequestIds) {
            RestAssured.baseURI = CucumberTestProperties.getBaseURI();
            String brand = CucumberTestProperties.getBrand();
            JSONObject doc = new JSONObject();
            doc.put("brand", brand);
            doc.put("caseId", caseIdCAPIE);
            doc.put("firequestId", requestId);
            doc.put("state", "PST_Review_Complete");
            JsonNode updatedInput = new ObjectMapper().readTree(doc.toString());
            RequestSpecification stateUpdateRequest = RestAssured.given()
                    .log().all()
                    .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                    .headers(CucumberTestProperties.getHeaders(updatedInput))
                    .accept(ContentType.JSON);
            ApiTestUtil.createRequestForInputParams(updatedInput, stateUpdateRequest, PUT_UPDATE_FI_STATE_CASEID_JSON_PATH_PARAM);
            response = stateUpdateRequest.put(PUT_UPDATE_FI_STATE_CASEID_JSON_PATH_PARAM);
            log.info("response " + response);
            log.info(response.getHeaders().asList().toString());
            log.info(response.getBody().prettyPrint());
            Assertions.assertEquals(200, response.getStatusCode());
            Assertions.assertNotNull(response, "response is null");
            responseString = response.asString();
        }


    }

    private void adboupdateStateToClosedForTheGivenRequestIds(List<String> documentRequestIds) throws JSONException, JsonProcessingException {
        for (String requestId : documentRequestIds) {
            RestAssured.baseURI = CucumberTestProperties.getBaseURI();
            String brand = CucumberTestProperties.getBrand();
            JSONObject doc = new JSONObject();
            doc.put("brand", brand);
            doc.put("caseId", ADBO_UNIQUE_CASEID);
            doc.put("firequestId", requestId);
            doc.put("state", "Closed");
            JsonNode updatedInput = new ObjectMapper().readTree(doc.toString());
            RequestSpecification stateUpdateRequest = RestAssured.given()
                    .log().all()
                    .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                    .headers(CucumberTestProperties.getHeaders(updatedInput))
                    .accept(ContentType.JSON);
            ApiTestUtil.createRequestForInputParams(updatedInput, stateUpdateRequest, PUT_UPDATE_FI_STATE_CASEID_JSON_PATH_PARAM);
            response = stateUpdateRequest.put(PUT_UPDATE_FI_STATE_CASEID_JSON_PATH_PARAM);
            log.info("response " + response);
            log.info(response.getHeaders().asList().toString());
            log.info(response.getBody().prettyPrint());
            Assertions.assertEquals(200, response.getStatusCode());
            Assertions.assertNotNull(response, "response is null");
            responseString = response.asString();
        }


    }

    @Then("User use get FI List endpoint using input {string} and verify flags for after closing all the required docs and FI")
    public void userUseGetFIListEndpointUsingInputAndVerifyFlagsForAfterClosingAllTheRequiredDocsAndFI(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", caseIdCAPIE);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, GET_FI_LIST_CASE_ID_CAPIE_PATH);
        response = request.get(GET_FI_LIST_CASE_ID_CAPIE_PATH);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());

        JsonNode  isBasicPackagingClosed = responseJsonNode.get("packagingStatus").get("isBasicPackagingClosed");
        Assertions.assertEquals("true",isBasicPackagingClosed.asText());

        JsonNode  isBasicPackagingClosedForA1 = responseJsonNode.get("packagingStatus").get("isBasicPackagingClosedForA1");
        Assertions.assertEquals("true",isBasicPackagingClosedForA1.asText());

        JsonNode  isBasicPackagingClosedForA2 = responseJsonNode.get("packagingStatus").get("isBasicPackagingClosedForA2");
        Assertions.assertEquals("true",isBasicPackagingClosedForA2.asText());

        JsonNode  isSIClosed = responseJsonNode.get("packagingStatus").get("isSIClosed");
        Assertions.assertEquals("true",isSIClosed.asText());

        JsonNode  isSIClosedForA1 = responseJsonNode.get("packagingStatus").get("isSIClosedForA1");
        Assertions.assertEquals("true",isSIClosedForA1.asText());

        JsonNode  isSIClosedForA2 = responseJsonNode.get("packagingStatus").get("isSIClosedForA2");
        Assertions.assertEquals("true",isSIClosedForA2.asText());



    }

    @Then("adbo User use get FI List endpoint using input {string} and verify flags for required docs and FI for applicant one and applicationlevel")
    public void adboUserUseGetFIListEndpointUsingInputAndVerifyFlagsForRequiredDocsAndFIForApplicantOneAndApplicationlevel(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", ADBO_UNIQUE_CASEID);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, GET_FI_LIST_CASE_ID_CAPIE_PATH);
        response = request.get(GET_FI_LIST_CASE_ID_CAPIE_PATH);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());

        JsonNode  isBasicPackagingReceived = responseJsonNode.get("packagingStatus").get("isBasicPackagingReceived");
        Assertions.assertEquals("false",isBasicPackagingReceived.asText());

        JsonNode  isBasicPackagingReceivedForA1 = responseJsonNode.get("packagingStatus").get("isBasicPackagingReceivedForA1");
        Assertions.assertEquals("true",isBasicPackagingReceivedForA1.asText());

        JsonNode  isSIReceived = responseJsonNode.get("packagingStatus").get("isSIReceived");
        Assertions.assertEquals("false",isSIReceived.asText());

        JsonNode  isSIReceivedForA1 = responseJsonNode.get("packagingStatus").get("isSIReceivedForA1");
        Assertions.assertEquals("true",isSIReceivedForA1.asText());

    }

    @Then("adbo use get FI List endpoint using input {string} and verify flags for required docs and FI for applicant two")
    public void adboUseGetFIListEndpointUsingInputAndVerifyFlagsForRequiredDocsAndFIForApplicantTwo(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", ADBO_UNIQUE_CASEID);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, GET_FI_LIST_CASE_ID_CAPIE_PATH);
        response = request.get(GET_FI_LIST_CASE_ID_CAPIE_PATH);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());

        JsonNode  isBasicPackagingReceived = responseJsonNode.get("packagingStatus").get("isBasicPackagingReceived");
        Assertions.assertEquals("true",isBasicPackagingReceived.asText());

        JsonNode  isBasicPackagingReceivedForA2 = responseJsonNode.get("packagingStatus").get("isBasicPackagingReceivedForA2");
        Assertions.assertEquals("true",isBasicPackagingReceivedForA2.asText());

        JsonNode  isSIReceived = responseJsonNode.get("packagingStatus").get("isSIReceived");
        Assertions.assertEquals("true",isSIReceived.asText());

        JsonNode  isSIReceivedForA2 = responseJsonNode.get("packagingStatus").get("isSIReceivedForA2");
        Assertions.assertEquals("true",isSIReceivedForA2.asText());
    }

    @When("adbo User sends request update state to close for all the Fi and required docs for channel {string} using input {string} and {string} and {string} verify response code")
    public void adboUserSendsRequestUpdateStateToCloseForAllTheFiAndRequiredDocsForChannelUsingInputAndAndVerifyResponseCode(String channel, String inputName, String documentUploadInputName, String CustomerResponse) throws JsonProcessingException, JSONException {
        JsonNode applicationDataResponse = (new ObjectMapper().readTree(getApplicationData));
        JsonNode applicantArray = applicationDataResponse.get(APPLICANTS);
        String allApplicantId = StreamSupport.stream(applicantArray.spliterator(), false)
                .filter(applicantJsonNode -> applicantJsonNode.get(MAIN_APPLICANT).asBoolean())
                .filter(applicantJsonNode -> !applicantJsonNode.get(MAIN_APPLICANT).asBoolean())
                .findFirst().map(applicant -> applicant.get(APPLICANT_ID).asText()).orElse(null);

        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getMSVCApplicationURI();
        ObjectMapper mapper = new ObjectMapper();
        JsonNode requestInput = mapper.createObjectNode();
        ObjectNode addedNode = ((ObjectNode) requestInput).putObject("requestQuery");
        addedNode.put(BRAND, testInput.get(BRAND));
        addedNode.put(CASE_ID, ADBO_UNIQUE_CASEID);
        addedNode.put(APPLICANT_ID, allApplicantId);
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenMsvcApplication())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(addedNode, request, GET_DOCUMENTS_CASE_ID_PATH);
        response = request.get(GET_DOCUMENTS_CASE_ID_PATH);
        log.info("response " + response);
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");

        String allApplicantDocumentList = response.asString();

        JsonNode allApplicantDocumentListResponse = (new ObjectMapper().readTree(allApplicantDocumentList));
        JsonNode documentsArray = allApplicantDocumentListResponse.get("documents");
        List<String> documentRequestIds = StreamSupport.stream(documentsArray.spliterator(), false)
                .map(document -> document.get(REQUEST_ID).asText()).collect(Collectors.toList());
        log.info("documentRequestIds : {}", documentRequestIds);
        adboupdateStateToClosedForTheGivenRequestIds(documentRequestIds);
    }

    @Then("adbo User use get FI List endpoint using input {string} and verify flags for after closing all the required docs and FI")
    public void adboUserUseGetFIListEndpointUsingInputAndVerifyFlagsForAfterClosingAllTheRequiredDocsAndFI(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", ADBO_UNIQUE_CASEID);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, GET_FI_LIST_CASE_ID_CAPIE_PATH);
        response = request.get(GET_FI_LIST_CASE_ID_CAPIE_PATH);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());

        JsonNode  isBasicPackagingClosed = responseJsonNode.get("packagingStatus").get("isBasicPackagingClosed");
        Assertions.assertEquals("true",isBasicPackagingClosed.asText());

        JsonNode  isBasicPackagingClosedForA1 = responseJsonNode.get("packagingStatus").get("isBasicPackagingClosedForA1");
        Assertions.assertEquals("true",isBasicPackagingClosedForA1.asText());

        JsonNode  isBasicPackagingClosedForA2 = responseJsonNode.get("packagingStatus").get("isBasicPackagingClosedForA2");
        Assertions.assertEquals("true",isBasicPackagingClosedForA2.asText());

        JsonNode  isSIClosed = responseJsonNode.get("packagingStatus").get("isSIClosed");
        Assertions.assertEquals("true",isSIClosed.asText());

        JsonNode  isSIClosedForA1 = responseJsonNode.get("packagingStatus").get("isSIClosedForA1");
        Assertions.assertEquals("true",isSIClosedForA1.asText());

        JsonNode  isSIClosedForA2 = responseJsonNode.get("packagingStatus").get("isSIClosedForA2");
        Assertions.assertEquals("true",isSIClosedForA2.asText());



    }


    @Then("Verify the response code for basic packaging non adbo in coord update {string}")
    public void verifyTheResponseCodeForBasicPackagingNonAdboInCoordUpdate(String inputName) throws JsonProcessingException, JSONException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        String brand = CucumberTestProperties.getBrand();
        doc.set("brand",brand);
        doc.set("caseId", caseIdCAPIE);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification stateUpdateRequest = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(updatedInput))
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppUpdate())
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, stateUpdateRequest, POST_UPDATE_BASIC_PACKAGING);
        response = stateUpdateRequest.post(POST_UPDATE_BASIC_PACKAGING);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(201, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();

        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode  basicPackaging = responseJsonNode.get("documents").get(0).get("requestType");
        Assertions.assertEquals("Basic Packaging",basicPackaging.asText());
    }

    @Then("Verify the response code for basic packaging non adbo in flow manger {string}")
    public void verifyTheResponseCodeForBasicPackagingNonAdboInFlowManger(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getMSVCFlowManagerURI();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        String brand = CucumberTestProperties.getBrand();
        doc.set("brand",brand);
        doc.set("caseId", caseIdCAPIE);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification packagingUpdateRequest = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenMsvcFlowManager())
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, packagingUpdateRequest, POST_FLOW_MANAGER_BASIC_PACKAGING);
        response = packagingUpdateRequest.post(POST_FLOW_MANAGER_BASIC_PACKAGING);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(201, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();

        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode  basicPackaging = responseJsonNode.get("requestType");
        Assertions.assertEquals("Basic Packaging",basicPackaging.asText());

    }

    @Then("Verify the error response code when basic packaging for the non adbo case has been created already in coord update {string}")
    public void verifyTheErrorResponseCodeWhenBasicPackagingForTheNonAdboCaseHasBeenCreatedAlreadyInCoordUpdate(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        String brand = CucumberTestProperties.getBrand();
        doc.set("brand",brand);
        doc.set("caseId", caseIdCAPIE);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification stateUpdateRequest = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(updatedInput))
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppUpdate())
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, stateUpdateRequest, POST_UPDATE_BASIC_PACKAGING);
        response = stateUpdateRequest.post(POST_UPDATE_BASIC_PACKAGING);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(412, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assert.assertEquals("Packaging for this case has been created already.", responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }

    @Then("Verify the error response code when basic packaging for the non adbo case has been created already in flow manager {string}")
    public void verifyTheErrorResponseCodeWhenBasicPackagingForTheNonAdboCaseHasBeenCreatedAlreadyInFlowManager(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getMSVCFlowManagerURI();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        String brand = CucumberTestProperties.getBrand();
        doc.set("brand",brand);
        doc.set("caseId", caseIdCAPIE);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification packagingUpdateRequest = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenMsvcFlowManager())
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, packagingUpdateRequest, POST_FLOW_MANAGER_BASIC_PACKAGING);
        response = packagingUpdateRequest.post(POST_FLOW_MANAGER_BASIC_PACKAGING);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(412, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();

        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assert.assertEquals("Packaging for this case has been created already.", responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }

    @Then("Verify the error response code when no matching record found for the non adbo case in coord update {string}")
    public void verifyTheErrorResponseCodeWhenNoMatchingRecordFoundForTheNonAdboCaseInCoordUpdate(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        String brand = CucumberTestProperties.getBrand();
        doc.set("brand",brand);
        doc.set("caseId", caseIdCAPIE);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification stateUpdateRequest = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(updatedInput))
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppUpdate())
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, stateUpdateRequest, POST_UPDATE_BASIC_PACKAGING);
        response = stateUpdateRequest.post(POST_UPDATE_BASIC_PACKAGING);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(404, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assert.assertEquals("No matching record found for this case.", responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }

    @Then("Verify the error response code when no matching record found for the non adbo case in flow manager {string}")
    public void verifyTheErrorResponseCodeWhenNoMatchingRecordFoundForTheNonAdboCaseInFlowManager(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getMSVCFlowManagerURI();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        String brand = CucumberTestProperties.getBrand();
        doc.set("brand",brand);
        doc.set("caseId", caseIdCAPIE);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification packagingUpdateRequest = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenMsvcFlowManager())
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, packagingUpdateRequest, POST_FLOW_MANAGER_BASIC_PACKAGING);
        response = packagingUpdateRequest.post(POST_FLOW_MANAGER_BASIC_PACKAGING);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(404, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();

        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assert.assertEquals("No matching record found for this case.", responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }

    @Then("Verify the response code for basic packaging adbo in coord update {string}")
    public void verifyTheResponseCodeForBasicPackagingAdboInCoordUpdate(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        String brand = CucumberTestProperties.getBrand();
        doc.set("brand",brand);
        doc.set("caseId", ADBO_UNIQUE_CASEID);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification stateUpdateRequest = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(updatedInput))
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppUpdate())
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, stateUpdateRequest, POST_UPDATE_BASIC_PACKAGING);
        response = stateUpdateRequest.post(POST_UPDATE_BASIC_PACKAGING);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(201, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();

        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode  basicPackaging = responseJsonNode.get("documents").get(0).get("requestType");
        Assertions.assertEquals("Basic Packaging",basicPackaging.asText());
    }

    @Then("Verify the response code for basic packaging adbo in flow manager {string}")
    public void verifyTheResponseCodeForBasicPackagingAdboInFlowManager(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getMSVCFlowManagerURI();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        String brand = CucumberTestProperties.getBrand();
        doc.set("brand",brand);
        doc.set("caseId", ADBO_UNIQUE_CASEID);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification packagingUpdateRequest = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenMsvcFlowManager())
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, packagingUpdateRequest, POST_FLOW_MANAGER_BASIC_PACKAGING);
        response = packagingUpdateRequest.post(POST_FLOW_MANAGER_BASIC_PACKAGING);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(201, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();

        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode  basicPackaging = responseJsonNode.get("requestType");
        Assertions.assertEquals("Basic Packaging",basicPackaging.asText());

    }

    @Then("Verify the error response code when basic packaging for the adbo case has been created already in coord update {string}")
    public void verifyTheErrorResponseCodeWhenBasicPackagingForTheAdboCaseHasBeenCreatedAlreadyInCoordUpdate(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        String brand = CucumberTestProperties.getBrand();
        doc.set("brand",brand);
        doc.set("caseId", ADBO_UNIQUE_CASEID);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification stateUpdateRequest = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(updatedInput))
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppUpdate())
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, stateUpdateRequest, POST_UPDATE_BASIC_PACKAGING);
        response = stateUpdateRequest.post(POST_UPDATE_BASIC_PACKAGING);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(412, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assert.assertEquals("Packaging for this case has been created already.", responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }

    @Then("Verify the error response code when basic packaging for the adbo case has been created already in flow manager {string}")
    public void verifyTheErrorResponseCodeWhenBasicPackagingForTheAdboCaseHasBeenCreatedAlreadyInFlowManager(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getMSVCFlowManagerURI();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        String brand = CucumberTestProperties.getBrand();
        doc.set("brand",brand);
        doc.set("caseId", ADBO_UNIQUE_CASEID);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification packagingUpdateRequest = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenMsvcFlowManager())
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, packagingUpdateRequest, POST_FLOW_MANAGER_BASIC_PACKAGING);
        response = packagingUpdateRequest.post(POST_FLOW_MANAGER_BASIC_PACKAGING);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(412, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();

        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assert.assertEquals("Packaging for this case has been created already.", responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }

    @Then("Verify the error response code when no matching record found for the adbo case in coord update {string}")
    public void verifyTheErrorResponseCodeWhenNoMatchingRecordFoundForTheAdboCaseInCoordUpdate(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        String brand = CucumberTestProperties.getBrand();
        doc.set("brand",brand);
        doc.set("caseId", ADBO_UNIQUE_CASEID);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification stateUpdateRequest = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(updatedInput))
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppUpdate())
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, stateUpdateRequest, POST_UPDATE_BASIC_PACKAGING);
        response = stateUpdateRequest.post(POST_UPDATE_BASIC_PACKAGING);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(404, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assert.assertEquals("No matching record found for this case.", responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }

    @Then("Verify the error response code when no matching record found for the adbo case in flow manager {string}")
    public void verifyTheErrorResponseCodeWhenNoMatchingRecordFoundForTheAdboCaseInFlowManager(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getMSVCFlowManagerURI();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        String brand = CucumberTestProperties.getBrand();
        doc.set("brand",brand);
        doc.set("caseId", ADBO_UNIQUE_CASEID);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification packagingUpdateRequest = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenMsvcFlowManager())
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, packagingUpdateRequest, POST_FLOW_MANAGER_BASIC_PACKAGING);
        response = packagingUpdateRequest.post(POST_FLOW_MANAGER_BASIC_PACKAGING);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(404, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();

        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assert.assertEquals("No matching record found for this case.", responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }

    @Then("User use get FI List endpoint using input {string} and verify flags for isBasicPackagingGenerated true")
    public void userUseGetFIListEndpointUsingInputAndVerifyFlagsForIsBasicPackagingGeneratedTrue(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", caseIdCAPIE);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, GET_FI_LIST_CASE_ID_CAPIE_PATH);
        response = request.get(GET_FI_LIST_CASE_ID_CAPIE_PATH);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());

        JsonNode  isBasicPackagingGenerated = responseJsonNode.get("packagingStatus").get("isBasicPackagingGenerated");
        Assertions.assertEquals("true",isBasicPackagingGenerated.asText());

    }

    @Then("User use get FI List endpoint using input {string} and verify flags for no isBasicPackagingGenerated")
    public void userUseGetFIListEndpointUsingInputAndVerifyFlagsForNoIsBasicPackagingGenerated(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", caseIdCAPIE);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, GET_FI_LIST_CASE_ID_CAPIE_PATH);
        response = request.get(GET_FI_LIST_CASE_ID_CAPIE_PATH);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(404, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());
    }

    @Then("adbo User use get FI List endpoint using input {string} and verify flags for isBasicPackagingGenerated true")
    public void adboUserUseGetFIListEndpointUsingInputAndVerifyFlagsForIsBasicPackagingGeneratedTrue(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", ADBO_UNIQUE_CASEID);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, GET_FI_LIST_CASE_ID_CAPIE_PATH);
        response = request.get(GET_FI_LIST_CASE_ID_CAPIE_PATH);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());

        JsonNode  isBasicPackagingGenerated = responseJsonNode.get("packagingStatus").get("isBasicPackagingGenerated");
        Assertions.assertEquals("true",isBasicPackagingGenerated.asText());

    }

    @Then("adbo User use get FI List endpoint using input {string} and verify flags for no isBasicPackagingGenerated")
    public void adboUserUseGetFIListEndpointUsingInputAndVerifyFlagsForNoIsBasicPackagingGenerated(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", ADBO_UNIQUE_CASEID);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, GET_FI_LIST_CASE_ID_CAPIE_PATH);
        response = request.get(GET_FI_LIST_CASE_ID_CAPIE_PATH);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(404, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());

    }

    @When("User raise FI for using ref input {string} and verify response code")
    public void userRaiseFIForUsingRefInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String POST_FI = "/application/{referenceNumber}/firequest";
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("referenceNumber", testInput.get("referenceNumber").asText());
        doc.set("requestBody.documentRequests[0].requiredFor[0].applicantId", applicantID1);

        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());

        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(updatedInput))
                .accept(ContentType.JSON);

        Assertions.assertNotNull(updatedInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_FI);
        response = request.post(POST_FI);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(201, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());
    }

    @Then("User use get FI List endpoint using input {string} and verify flags for isBasicPackagingGenerated false")
    public void userUseGetFIListEndpointUsingInputAndVerifyFlagsForIsBasicPackagingGeneratedFalse(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("referenceNumber", testInput.get("referenceNumber").asText());
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, GET_FI_LIST_REF);
        response = request.get(GET_FI_LIST_REF);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());

        JsonNode  isBasicPackagingGenerated = responseJsonNode.get("packagingStatus").get("isBasicPackagingGenerated");
        Assertions.assertEquals("false",isBasicPackagingGenerated.asText());

    }

    @When("adbo User raise FI for using ref input {string} and verify response code")
    public void adboUserRaiseFIForUsingRefInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String POST_FI = "/application/{referenceNumber}/firequest";
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("referenceNumber", testInput.get("referenceNumber").asText());
        doc.set("requestBody.documentRequests[0].requiredFor[0].applicantId", applicantID1);

        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());

        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(updatedInput))
                .accept(ContentType.JSON);

        Assertions.assertNotNull(updatedInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_FI);
        response = request.post(POST_FI);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(201, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());
    }


    @Then("adbo User use get FI List endpoint using input {string} and verify flags for isBasicPackagingGenerated false")
    public void adboUserUseGetFIListEndpointUsingInputAndVerifyFlagsForIsBasicPackagingGeneratedFalse(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("referenceNumber", testInput.get("referenceNumber").asText());
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, GET_FI_LIST_REF);
        response = request.get(GET_FI_LIST_REF);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());

        JsonNode  isBasicPackagingGenerated = responseJsonNode.get("packagingStatus").get("isBasicPackagingGenerated");
        Assertions.assertEquals("false",isBasicPackagingGenerated.asText());

    }

    @When("User sends request to get Open task information using input {string} and verify response code")
    public void userSendsRequestToGetOpenTaskInformationUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(testInput, request, GET_TASK_INFORMATION_PATH);
        response = request.get(GET_TASK_INFORMATION_PATH);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());

    }

    @Then("Verify open FST Task NOT present")
    public void verifyOpenFSTTaskNOTPresent() throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        responseJsonNode.get(TASK_INFORMATION).forEach(jsonNode -> {
            Assert.assertEquals("Closed",jsonNode.get("status").asText());

        });
    }

    @When("Delete Single record in mongodb STP outcome collection {string}")
    public void deleteSingleRecordInMongodbSTPOutcomeCollection(String inputName) {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        MongoActions.deleteSingleRecord("stp_outcome","referenceNumber",testInput.get(REFERENCE_NUMBER).asText());
    }

    @When("External Services - User sends request to post stp out come for channel {string} using kafka topic input {string}")
    public void externalServicesUserSendsRequestToPostStpOutComeForChannelUsingKafkaTopicInput(String channel, String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getMSVCFlowManagerURI();

        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenMsvcFlowManager())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, testInput.get(PATH).asText());
        response = request.post(testInput.get(PATH).asText());
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();

    }

    @When("User sends request to patch case allocation endpoint using input {string} and verify response code")
    public void userSendsRequestToPatchCaseAllocationEndpointUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String PATCH_CASE_ALLOCATION = "/application/stp/case/assign";
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());

        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(updatedInput))
                .accept(ContentType.JSON);

        Assertions.assertNotNull(updatedInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, PATCH_CASE_ALLOCATION);
        response = request.patch(PATCH_CASE_ALLOCATION);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());

    }

    private List<String> getOpenFiRequestIdForCase(String caseId, String brand) throws JsonProcessingException {
        List<String> requestIds = new ArrayList<>();
        RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        request.header(BRAND, brand);
        request.pathParam(CASE_ID, caseId);
        response = request.get("application/case/{caseId}/filist");
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        Assertions.assertEquals(200, response.getStatusCode());
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        responseJsonNode.get("documents").forEach(jsonNode -> {
            requestIds.add(jsonNode.get("requestId").asText());

        });
        return requestIds;
    }


    private List<String> getDocumentId(String caseId, String brand) throws JsonProcessingException {
        List<String> documentIds = new ArrayList<>();
        RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        request.header(BRAND, brand);
        request.pathParam(CASE_ID, caseId);
        response = request.get("application/case/{caseId}/filist");
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        Assertions.assertEquals(200, response.getStatusCode());
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        responseJsonNode.get("documents").forEach(documents -> {
            JsonNode documentInfo = documents.get("documentInfo");
            documentInfo.forEach(jsonNode -> {
                documentIds.add(jsonNode.get("documentId").asText());
            });
        });
        return documentIds;
    }


    @When("patch DisAssociate using input {string}")
    public void patchDisAssociateUsingInput(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        String patchDisAssociate = "application/case/{caseId}/documentRequest/{requestId}/document/{documentId}/disassociate";
        List<String> fiRequestList = getOpenFiRequestIdForCase(caseIdCAPIE, testInput.get(BRAND).asText());
        List<String> documentIds = getDocumentId(caseIdCAPIE, testInput.get(BRAND).asText());
        for (String requestId : fiRequestList) {
            for (String documentId : documentIds) {
                ObjectMapper objectMapper = new ObjectMapper();
                String json = objectMapper.writeValueAsString(testInput);
                DocumentContext doc = JsonPath.parse(json);
                doc.set("caseId", caseIdCAPIE);
                doc.set("requestId", requestId);
                doc.set("documentId", documentId);
                JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
                RestAssured.baseURI = CucumberTestProperties.getBaseURI();
                RequestSpecification request = RestAssured.given()
                        .log().all()
                        .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                        .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppUpdate())
                        .accept(ContentType.JSON);
                ApiTestUtil.createRequestForInputParams(updatedInput, request, patchDisAssociate);
                response = request.headers(CucumberTestProperties.getHeaders(updatedInput)).patch(patchDisAssociate);
                System.out.println("response " + response);
                log.info(response.getHeaders().asList().toString());
                log.info(response.getBody().prettyPrint());
                Assertions.assertNotNull(response, "response is null");
                responseString = response.asString();
            }
        }
    }

    @Then("User use get document List endpoint using input {string} and verify disassociated flag")
    public void userUseGetDocumentListEndpointUsingInputAndVerifyDisassociatedFlag(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
        String GET_DOCUMENT_LIST_CASE_ID = "/application/case/{caseId}/documentlist";
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", caseIdCAPIE);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, GET_DOCUMENT_LIST_CASE_ID);
        response = request.get(GET_DOCUMENT_LIST_CASE_ID);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());


        JsonNode documents = responseJsonNode.get(DOCUMENTS);
        Assertions.assertTrue(documents.size() == 0);
//        for(int i=0; i<documents.size(); i++){
//           Assert.assertEquals(documents.get(i).get(DOCUMENT_INFO).get(0).get("originalFileName").asText(),"PDFDocument.pdf");
//        }

    }

    @Then("adbo User use get document List endpoint using input {string} and verify disassociated flag")
    public void adboUserUseGetDocumentListEndpointUsingInputAndVerifyDisassociatedFlag(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
        String GET_DOCUMENT_LIST_CASE_ID = "/application/case/{caseId}/documentlist";
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", ADBO_UNIQUE_CASEID);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, GET_DOCUMENT_LIST_CASE_ID);
        response = request.get(GET_DOCUMENT_LIST_CASE_ID);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());

        JsonNode documents = responseJsonNode.get(DOCUMENTS);
        Assertions.assertTrue(documents.size() == 0);
//        for(int i=1; i<documents.size(); i++){
//            Assert.assertEquals(documents.get(i).get(DOCUMENT_INFO).get(0).get("originalFileName").asText(),"PDFDocument.pdf");
//        }

    }

    @When("adbo User patch DisAssociate using input {string}")
    public void adboUserPatchDisAssociateUsingInput(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        String patchDisAssociate = "application/case/{caseId}/documentRequest/{requestId}/document/{documentId}/disassociate";
        List<String> fiRequestList = getOpenFiRequestIdForCase(ADBO_UNIQUE_CASEID, testInput.get(BRAND).asText());
        List<String> documentIds = getDocumentId(ADBO_UNIQUE_CASEID, testInput.get(BRAND).asText());
        for (String requestId : fiRequestList) {
            for (String documentId : documentIds) {
                ObjectMapper objectMapper = new ObjectMapper();
                String json = objectMapper.writeValueAsString(testInput);
                DocumentContext doc = JsonPath.parse(json);
                doc.set("caseId", ADBO_UNIQUE_CASEID);
                doc.set("requestId", requestId);
                doc.set("documentId", documentId);
                JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
                RestAssured.baseURI = CucumberTestProperties.getBaseURI();
                RequestSpecification request = RestAssured.given()
                        .log().all()
                        .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                        .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppUpdate())
                        .accept(ContentType.JSON);
                ApiTestUtil.createRequestForInputParams(updatedInput, request, patchDisAssociate);
                response = request.headers(CucumberTestProperties.getHeaders(updatedInput)).patch(patchDisAssociate);
                System.out.println("response " + response);
                log.info(response.getHeaders().asList().toString());
                log.info(response.getBody().prettyPrint());
                Assertions.assertNotNull(response, "response is null");
                responseString = response.asString();
            }
        }
    }

    @When("verify post STP Exception using input {string}")
    public void verifyPostSTPExceptionUsingInput(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getMSVCFlowManagerURI();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("requestBody.caseId", caseIdCAPIE);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenMsvcFlowManager())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(updatedInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_STP_EXCEPTION);
        response = request.post(POST_STP_EXCEPTION);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(201, response.getStatusCode());
        exceptionId = responseJsonNode.get("exceptionId").asText();


    }

    @Then("patch STP Exception Assign using input {string}")
    public void patchSTPExceptionAssignUsingInput(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getMSVCFlowManagerURI();
        String PATCH_STP_EXCEPTION_ASSIGN ="/stp/exception/assign";
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", caseIdCAPIE);
        doc.set("exceptionId",exceptionId);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenMsvcFlowManager())
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, PATCH_STP_EXCEPTION_ASSIGN);
        response = request.headers(CucumberTestProperties.getHeaders(updatedInput)).patch(PATCH_STP_EXCEPTION_ASSIGN);
        System.out.println("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(200, response.getStatusCode());
    }

    @When("Delete Single record in STP Exception collection mongo db for {string}")
    public void deleteSingleRecordInSTPExceptionCollectionMongoDbFor(String inputName) {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        MongoActions.deleteSingleRecord("exceptions","caseId",caseIdCAPIE);
    }


    @Then("Verify final note count using input {string} and verify response code")
    public void verifyFinalNoteCountUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
        String GET_NOTES_INFORMATION = "/notesInformation/{referenceNumber}";
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(testInput, request, GET_NOTES_INFORMATION);
        response = request.get(GET_NOTES_INFORMATION);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
        JsonNode addedGMSNoteResponseMessage = (new ObjectMapper().readTree(responseString));
        int finalNotesCount = addedGMSNoteResponseMessage.get("count").asInt();
        log.info("final count " + finalNotesCount);
        boolean noteFound = false;
    }

    @Then("Verify adbo user final note count using input {string} and verify response code")
    public void verifyAdboUserFinalNoteCountUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
        String GET_NOTES_INFORMATION = "/notesInformation/{referenceNumber}";
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(testInput, request, GET_NOTES_INFORMATION);
        response = request.get(GET_NOTES_INFORMATION);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
        JsonNode addedGMSNoteResponseMessage = (new ObjectMapper().readTree(responseString));
        int finalNotesCount = addedGMSNoteResponseMessage.get("count").asInt();
        log.info("final count " + finalNotesCount);
        boolean noteFound = false;
    }

    @Then("verify GET STP Exception Assign using input {string}")
    public void verifyGETSTPExceptionAssignUsingInput(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
        String GET_STP_EXCEPTION ="/stp/exceptions";
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId",caseIdCAPIE);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, GET_STP_EXCEPTION);
        if(Objects.isNull(testInput.get(caseIdCAPIE)) && ObjectUtils.allNull(testInput.get("fromDate"), testInput.get("toDate"))){
            request.queryParam("fromDate", LocalDate.now().minusDays(7).toString());
            request.queryParam("toDate", LocalDate.now().toString());
        }
        response = request.get(GET_STP_EXCEPTION);
        System.out.println("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(200, response.getStatusCode());
    }

    @Then("Verify state as PST Review")
    public void verifyStateAsPSTReview() throws JsonProcessingException {
//        responseJsonNode = new ObjectMapper().readTree(response.asString());
//        responseJsonNode.get("documents").forEach(jsonNode -> {
//            Assert.assertEquals("PST_Review",jsonNode.get("state").asText());
//
//        });
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode documentsArray = responseJsonNode.get("documents");
        boolean found = false;
        for (int i = 0; i < documentsArray.size(); i++) {
            String state = documentsArray.get(i).get("state").asText();
            if (state.contains("PST_Review")) {
                found = true;
            }
        }
        Assertions.assertTrue(found);
    }

    @Then("Verify the note for PST using input {string}")
    public void verifyTheNoteForPSTUsingInput(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
        String GET_NOTES_INFORMATION ="/notesInformation/{referenceNumber}";
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, GET_NOTES_INFORMATION);
        response = request.get(GET_NOTES_INFORMATION);
        System.out.println("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(200, response.getStatusCode());

        JsonNode detailsArray = responseJsonNode.get(DETAILS);
        boolean found = false;
        for (int i = 0; i < detailsArray.size(); i++) {
            String description = detailsArray.get(i).get("description").asText();
            if (description.contains("Case added to Packaging Support Team WorkList")) {
                found = true;
            }
        }
        Assertions.assertTrue(found);
    }

    @Then("Verify the note for PST Raise SI using input {string}")
    public void verifyTheNoteForPSTRaiseSIUsingInput(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
        String GET_NOTES_INFORMATION ="/notesInformation/{referenceNumber}";
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, GET_NOTES_INFORMATION);
        response = request.get(GET_NOTES_INFORMATION);
        System.out.println("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(200, response.getStatusCode());

        JsonNode detailsArray = responseJsonNode.get(DETAILS);
        boolean found = false;
        for (int i = 0; i < detailsArray.size(); i++) {
            String description = detailsArray.get(i).get("description").asText();
            if (description.contains("SI requested by PST user")) {
                found = true;
            }
        }
        Assertions.assertTrue(found);
    }

    @When("user get the exception Id using input {string}")
    public void userGetTheExceptionIdUsingInput(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
        String GET_STP_EXCEPTION ="/stp/exceptions";
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId",caseIdCAPIE);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, GET_STP_EXCEPTION);
        if(Objects.isNull(testInput.get(caseIdCAPIE)) && ObjectUtils.allNull(testInput.get("fromDate"), testInput.get("toDate"))){
            request.queryParam("fromDate", LocalDate.now().minusDays(7).toString());
            request.queryParam("toDate", LocalDate.now().toString());
        }
        response = request.get(GET_STP_EXCEPTION);
        System.out.println("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(200, response.getStatusCode());

        JsonNode exceptionIdArray = responseJsonNode.get("exceptionResponse");
        exceptionId = exceptionIdArray.get(0).get("exceptionId").asText();

    }

    @When("User sends request to view documents for caseId to get the request ID using input {string} and verify response code")
    public void userSendsRequestToViewDocumentsForCaseIdToGetTheRequestIDUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getMSVCApplicationURI();
        ObjectMapper mapper = new ObjectMapper();
        JsonNode requestInput = mapper.createObjectNode();
        ObjectNode addedNode = ((ObjectNode) requestInput).putObject("requestQuery");
        addedNode.put(BRAND, testInput.get(BRAND));
        addedNode.put(CASE_ID, caseIdCAPIE);
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenMsvcApplication())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(addedNode, request, GET_DOCUMENTS_CASE_ID_PATH);
        response = request.get(GET_DOCUMENTS_CASE_ID_PATH);
        log.info("response " + response);
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        getDocumentOutput = response.asString();
        responseString = response.asString();

        JsonNode DocumentsArray = responseJsonNode.get("documents");
        fiRequestId = DocumentsArray.get(0).get("requestId").asText();

    }

    @When("User sends request update state to close using input {string} and verify response code")
    public void userSendsRequestUpdateStateToCloseUsingInputAndVerifyResponseCode(String arg0) throws JsonProcessingException, JSONException {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String brand = CucumberTestProperties.getBrand();
        JSONObject doc = new JSONObject();
        doc.put("brand", brand);
        doc.put("caseId", caseIdCAPIE);
        doc.put("firequestId", fiRequestId);
        doc.put("state", "Closed");
        JsonNode updatedInput = new ObjectMapper().readTree(doc.toString());
        RequestSpecification stateUpdateRequest = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(updatedInput))
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, stateUpdateRequest, PUT_UPDATE_FI_STATE_CASEID_JSON_PATH_PARAM);
        response = stateUpdateRequest.put(PUT_UPDATE_FI_STATE_CASEID_JSON_PATH_PARAM);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @Then("Verify state as PST Complete")
    public void verifyStateAsPSTComplete() throws JsonProcessingException {
//        responseJsonNode = new ObjectMapper().readTree(response.asString());
//        JsonNode DocumentsArray = responseJsonNode.get("documents");
//        Assert.assertEquals("PST_REVIEW_COMPLETED",DocumentsArray.get(0).get("state").asText());

        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode documentsArray = responseJsonNode.get("documents");
        boolean found = false;
        for (int i = 0; i < documentsArray.size(); i++) {
            String state = documentsArray.get(i).get("state").asText();
            if (state.contains("PST_REVIEW_COMPLETED")) {
                found = true;
            }
        }
        Assertions.assertTrue(found);

    }

    @When("post STP exception using kafka topic input {string}")
    public void postSTPExceptionUsingKafkaTopicInput(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getMSVCFlowManagerURI();
        String STP_KAFKA_EXCPETION ="/kafkaMessage";
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("requestBody.caseId", caseIdCAPIE);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenMsvcFlowManager())
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, STP_KAFKA_EXCPETION);
        response = request.post(STP_KAFKA_EXCPETION);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @Then("PST Update State as Closed")
    public void pstUpdateStateAsClosed() throws JSONException, JsonProcessingException {

        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String brand = CucumberTestProperties.getBrand();
        JSONObject doc = new JSONObject();
        doc.put("brand", brand);
        doc.put("caseId", caseIdCAPIE);
        doc.put("firequestId", "ALL");
        doc.put("state", "Closed");
        JsonNode updatedInput = new ObjectMapper().readTree(doc.toString());
        RequestSpecification stateUpdateRequest = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(updatedInput))
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, stateUpdateRequest, PUT_UPDATE_FI_STATE_CASEID_JSON_PATH_PARAM);
        response = stateUpdateRequest.put(PUT_UPDATE_FI_STATE_CASEID_JSON_PATH_PARAM);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @Then("PST Update State as Review")
    public void pstUpdateStateAsReview() throws JsonProcessingException, JSONException {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String brand = CucumberTestProperties.getBrand();
        JSONObject doc = new JSONObject();
        doc.put("brand", brand);
        doc.put("caseId", caseIdCAPIE);
        doc.put("firequestId", "ALL");
        doc.put("state", "Review");
        JsonNode updatedInput = new ObjectMapper().readTree(doc.toString());
        RequestSpecification stateUpdateRequest = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(updatedInput))
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, stateUpdateRequest, PUT_UPDATE_FI_STATE_CASEID_JSON_PATH_PARAM);
        response = stateUpdateRequest.put(PUT_UPDATE_FI_STATE_CASEID_JSON_PATH_PARAM);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }


    @Then("Verify state as only Review")
    public void verifyStateAsOnlyReview() throws JsonProcessingException {

        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode documentsArray = responseJsonNode.get("documents");
        boolean found = false;
        for (int i = 0; i < documentsArray.size(); i++) {
            String state = documentsArray.get(i).get("state").asText();
            if (state.contains("Review")) {
                found = true;
            }
        }
        Assertions.assertTrue(found);
    }

    @When("User sends request update state to pst complete for all the Fi and required docs for channel {string} using input {string} and {string} and {string} verify response code")
    public void userSendsRequestUpdateStateToPstCompleteForAllTheFiAndRequiredDocsForChannelUsingInputAndAndVerifyResponseCode(String channel, String inputName, String documentUploadInputName, String CustomerResponse) throws JsonProcessingException, JSONException {
        JsonNode applicationDataResponse = (new ObjectMapper().readTree(getApplicationData));
        JsonNode applicantArray = applicationDataResponse.get(APPLICANTS);
        String allApplicantId = StreamSupport.stream(applicantArray.spliterator(), false)
                .filter(applicantJsonNode -> applicantJsonNode.get(MAIN_APPLICANT).asBoolean())
                .filter(applicantJsonNode -> !applicantJsonNode.get(MAIN_APPLICANT).asBoolean())
                .findFirst().map(applicant -> applicant.get(APPLICANT_ID).asText()).orElse(null);

        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getMSVCApplicationURI();
        ObjectMapper mapper = new ObjectMapper();
        JsonNode requestInput = mapper.createObjectNode();
        ObjectNode addedNode = ((ObjectNode) requestInput).putObject("requestQuery");
        addedNode.put(BRAND, testInput.get(BRAND));
        addedNode.put(CASE_ID, caseIdCAPIE);
        addedNode.put(APPLICANT_ID, allApplicantId);
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenMsvcApplication())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(addedNode, request, GET_DOCUMENTS_CASE_ID_PATH);
        response = request.get(GET_DOCUMENTS_CASE_ID_PATH);
        log.info("response " + response);
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");

        String allApplicantDocumentList = response.asString();

        JsonNode allApplicantDocumentListResponse = (new ObjectMapper().readTree(allApplicantDocumentList));
        JsonNode documentsArray = allApplicantDocumentListResponse.get("documents");
        List<String> documentRequestIds = StreamSupport.stream(documentsArray.spliterator(), false)
                .map(document -> document.get(REQUEST_ID).asText()).collect(Collectors.toList());
        log.info("documentRequestIds : {}", documentRequestIds);
        updateStateToPSTREVIEWCOMPLETEForTheGivenRequestIds(documentRequestIds);

    }

    @Then("Get the exception id in STP exception using input {string} and verify response code")
    public void getTheExceptionIdInSTPExceptionUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {

        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getMSVCApplicationURI();
        String STP_EXCEPTION = "/stp/exceptions";
        ObjectMapper mapper = new ObjectMapper();
        JsonNode requestInput = mapper.createObjectNode();
        ObjectNode addedNode = ((ObjectNode) requestInput).putObject("requestQuery");
        addedNode.put(BRAND, testInput.get(BRAND));
        addedNode.put(CASE_ID, caseIdCAPIE);
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenMsvcApplication())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(addedNode, request, STP_EXCEPTION);
        response = request.get(STP_EXCEPTION);
        log.info("response " + response);
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode exceptionsArray = responseJsonNode.get("exceptionResponse");
        stpexceptionId = exceptionsArray.get(0).get("exceptionId").asText();
    }


    @Then("Patch STP assign to allocate case using input {string}")
    public void patchSTPAssignToAllocateCaseUsingInput(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getMSVCFlowManagerURI();
        String PATCH_STP_ASSIGN ="/stp/exception/assign";
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("exceptionId",stpexceptionId);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenMsvcFlowManager())
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, PATCH_STP_ASSIGN);
        response = request.headers(CucumberTestProperties.getHeaders(updatedInput)).patch(PATCH_STP_ASSIGN);
        System.out.println("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(200, response.getStatusCode());

    }

    @When("Delete Single record in nft nwb mongo db for {string}")
    public void deleteSingleRecordInNftNwbMongoDbFor(String inputName) {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        MongoActions.NFTNWBdeleteSingleRecord("application","referenceNumber",testInput.get(REFERENCE_NUMBER).asText());
        MongoActions.NFTNWBdeleteSingleRecord("documents","referenceNumber",testInput.get(REFERENCE_NUMBER).asText());

    }

    @When("User sends request to add caseId for nft broker in CAPIE service for specific type of channel {string} using input {string} and verify response code")
    public void userSendsRequestToAddCaseIdForNftBrokerInCAPIEServiceForSpecificTypeOfChannelUsingInputAndVerifyResponseCode(String channel, String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getCAPIEBrokerServiceURI();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("requestBody.caseId", caseIdCAPIE);
        doc.set("requestBody.channel", channel);
        if(channel.equalsIgnoreCase("INTERMEDIARY_NAPOLI") || channel.equalsIgnoreCase("INTERMEDIARY_BROKER_API"))
        {
            String referenceNumber = externalInputsAsJsonNode.get("NFTFIValidationRef").get("referenceNumber").asText();
            doc.set("requestBody.mortgageReferenceNumber", referenceNumber);
        }
        else
        {
            log.info("proceed without reference number");
        }
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenCapieCase())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_BROKER_CASE_ID_CAPIE_PATH);
        response = request.post(POST_BROKER_CASE_ID_CAPIE_PATH);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();

    }

    @When("Delete Single record in nft rbs mongo db for {string}")
    public void deleteSingleRecordInNftRbsMongoDbFor(String inputName) {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        MongoActions.NFTRBSdeleteSingleRecord("application","referenceNumber",testInput.get(REFERENCE_NUMBER).asText());
        MongoActions.NFTRBSdeleteSingleRecord("documents","referenceNumber",testInput.get(REFERENCE_NUMBER).asText());
    }

    @When("Delete Single record in nft mongo db for {string}")
    public void deleteSingleRecordInNftMongoDbFor(String inputName) {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        if(testInput.get(BRAND).asText().equalsIgnoreCase("nwb"))
        {
            deleteSingleRecordInNftNwbMongoDbFor(inputName);
        }
        else if(testInput.get(BRAND).asText().equalsIgnoreCase("rbs"))
        {
            deleteSingleRecordInNftRbsMongoDbFor(inputName);
        }
        else{
            System.out.println("nothing to delete");
        }
    }

    @When("User sends request to upload different type document main applicant doc {string} for channel {string} for {string} using input {string} and {string} and verify response code")
    public void userSendsRequestToUploadDifferentTypeDocumentMainApplicantDocForChannelForUsingInputAndAndVerifyResponseCode(String file, String channel,String documentType, String inputName, String documentUploadInputName) throws JSONException, JsonProcessingException, InterruptedException {
        JsonNode applicationDataResponse = (new ObjectMapper().readTree(getApplicationData));
        JsonNode applicantArray = applicationDataResponse.get(APPLICANTS);
        String mainApplicantId = StreamSupport.stream(applicantArray.spliterator(), false)
                .filter(applicantJsonNode -> applicantJsonNode.get(MAIN_APPLICANT).asBoolean())
                .findFirst().map(applicant -> applicant.get(APPLICANT_ID).asText()).orElse(null);

        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getMSVCApplicationURI();
        ObjectMapper mapper = new ObjectMapper();
        JsonNode requestInput = mapper.createObjectNode();
        ObjectNode addedNode = ((ObjectNode) requestInput).putObject("requestQuery");
        addedNode.put(BRAND, testInput.get(BRAND));
        addedNode.put(CASE_ID, caseIdCAPIE);
        addedNode.put(APPLICATION_LEVEL, Boolean.TRUE);
        addedNode.put(APPLICANT_ID, mainApplicantId);
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenMsvcApplication())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(addedNode, request, GET_DOCUMENTS_CASE_ID_PATH);
        response = request.get(GET_DOCUMENTS_CASE_ID_PATH);
        log.info("response " + response);
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        String mainApplicantDocumentList = response.asString();

        JsonNode mainApplicantDocumentListResponse = (new ObjectMapper().readTree(mainApplicantDocumentList));
        JsonNode documentsArray = mainApplicantDocumentListResponse.get("documents");
        List<String> documentRequestIds = StreamSupport.stream(documentsArray.spliterator(), false)
                .map(document -> document.get(REQUEST_ID).asText()).collect(Collectors.toList());
        log.info("documentRequestIds : {}", documentRequestIds);
        updateStateForTheGivenRequestIds(documentRequestIds);
        uploadDocForTheGivenRequestIdsforDifferenetDocumentType(file, channel, documentType, documentUploadInputName, testInput, documentRequestIds);

    }

    private void uploadDocForTheGivenRequestIdsforDifferenetDocumentType(String file, String channel,String documentType, String documentUploadInputName, JsonNode testInput, List<String> documentRequestIds) throws JsonProcessingException, InterruptedException {
        JsonNode docUploadTestInput = externalInputsAsJsonNode.get(documentUploadInputName);
            RestAssured.baseURI = CucumberTestProperties.getBaseURI();
            String path = "/uploadDocument/case/{caseId}";
            ObjectMapper objectMapper = new ObjectMapper();
            String json = objectMapper.writeValueAsString(docUploadTestInput);
            DocumentContext doc = JsonPath.parse(json);
            doc.set("caseId", caseIdCAPIE);
           // doc.set("formData.requestId", requestId);
            doc.set("formData.channel", channel);
            doc.set("formData.files.[0]", file);
            doc.set ("formData.documentType",documentType);
            JsonNode docUploadInput = new ObjectMapper().readTree(doc.jsonString());
            int CONNECTION_TIMEOUT_MS = 600000;
            RestAssuredConfig config = RestAssured.config()
                    .httpClient(HttpClientConfig.httpClientConfig()
                            .dontReuseHttpClientInstance()
                            .setParam(CONNECTION_TIMEOUT, CONNECTION_TIMEOUT_MS)
                            .setParam(SO_TIMEOUT, CONNECTION_TIMEOUT_MS));
            RequestSpecification docUploadRequest = given().config(config)
                    .header("MultiPart_Content-Type", CucumberTestProperties.getContentHeader())
                    .headers(CucumberTestProperties.getHeaders(docUploadTestInput))
                    .formParam("channel", channel)
                    .basePath(path);
            ApiTestUtil.createRequestForInputParams(docUploadInput, docUploadRequest, path);
            setInputFiles(docUploadRequest, docUploadInput.get(FORM_DATA).get(FILES));
            response = docUploadRequest.headers(CucumberTestProperties.getHeaders(testInput)).post();
            response = response.then().extract().response();
            log.info(response.getHeaders().asList().toString());
            log.info(response.getBody().prettyPrint());
            Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
            responseJsonNode = new ObjectMapper().readTree(response.asString());
            Thread.sleep(20000);

    }


    @Then("Verify the get FI List using input {string} and {string}")
    public void verifyTheGetFIListUsingInputAnd(String inputName, String categoryValue) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
        String GET_FI_LIST ="/application/case/{caseId}/filist";
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", caseIdCAPIE);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, GET_FI_LIST);
        response = request.get(GET_FI_LIST);
        System.out.println("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(200, response.getStatusCode());

        JsonNode documentsArray = responseJsonNode.get(DOCUMENTS);
        boolean found = false;
        for (int i = 0; i < documentsArray.size(); i++) {
            String categoryDescription = documentsArray.get(i).get("category").asText();
            if (categoryDescription.contains(categoryValue)) {
                found = true;
            }
        }
        Assertions.assertTrue(found);
    }

    @When("User sends request to telemessage for PST referencenumber using input {string} and verify response code")
    public void userSendsRequestToTelemessageForPSTReferencenumberUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String POST_TeleMessage ="/application/{referenceNumber}/telemessage";
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppUpdate())
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_TeleMessage);
        response = request.post(POST_TeleMessage);
        System.out.println("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(201, response.getStatusCode());
    }

    @When("User send request to msvc property using input {string} and verify response code")
    public void userSendRequestToMsvcPropertyUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getCAPIEProperty();
        String POST_PROPERTY = "/v2/properties";
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("requestBody.caseId", caseIdCAPIE);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenCapieProperty())
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_PROPERTY);
        response = request.post(POST_PROPERTY);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();

    }

    @Then("Verify state as MA Review")
    public void verifyStateAsMAReview() throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode documentsArray = responseJsonNode.get("documents");
        boolean found = false;
        for (int i = 0; i < documentsArray.size(); i++) {
            String state = documentsArray.get(i).get("state").asText();
            if (state.contains("MA_Review")) {
                found = true;
            }
        }
        Assertions.assertTrue(found);
    }

    @When("User raise FI for applicant one using input {string} {string} {string}and verify response code")
    public void userRaiseFIForApplicantOneUsingInputAndVerifyResponseCode(String inputName, String documentIdentifier, String category) throws JsonProcessingException {

        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String POST_FI = "/application/case/{caseId}/firequest";
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", caseIdCAPIE);
        doc.set("requestBody.documentRequests[0].requiredFor[0].applicantId", applicantID1);
        doc.set("requestBody.documentRequests[0].documentIdentifier", documentIdentifier);
        doc.set("requestBody.documentRequests[0].category", category);

        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());

        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(updatedInput))
                .accept(ContentType.JSON);

        Assertions.assertNotNull(updatedInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_FI);
        response = request.post(POST_FI);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(201, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());

    }


    @Then("User verify case tracking copy in GET FI List caseId using input {string} {string} and verify response code")
    public void userVerifyCaseTrackingCopyInGETFIListCaseIdUsingInputAndVerifyResponseCode(String inputName, String Description) throws JsonProcessingException {

        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        String FI_LIST_CASE_ID_PATH = "/application/case/{caseId}/filist";
        RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", caseIdCAPIE);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(updatedInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, FI_LIST_CASE_ID_PATH);
        response = request.get(FI_LIST_CASE_ID_PATH);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());

        JsonNode fiListDocumentArray = responseJsonNode.get(DOCUMENTS);
        boolean found = false;
        for (int i = 0; i < fiListDocumentArray.size(); i++) {
            String internalCaseTrackingCopy = fiListDocumentArray.get(i).get("description").asText();
            if (internalCaseTrackingCopy.contains(Description)) {
                found = true;
            }

        }
        Assertions.assertTrue(found);

    }

    @Then("User verify case tracking copy in GET FI List ref using input {string} {string} and verify response code")
    public void userVerifyCaseTrackingCopyInGETFIListRefUsingInputAndVerifyResponseCode(String inputName, String Description) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        String FI_LIST_REF_ID_PATH = "/application/{referenceNumber}/filist";
        RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(updatedInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, FI_LIST_REF_ID_PATH);
        response = request.get(FI_LIST_REF_ID_PATH);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());

        JsonNode fiListDocumentArray = responseJsonNode.get(DOCUMENTS);
        boolean found = false;
        for (int i = 0; i < fiListDocumentArray.size(); i++) {
            String internalCaseTrackingCopy = fiListDocumentArray.get(i).get("description").asText();
            if (internalCaseTrackingCopy.contains(Description)) {
                found = true;
            }

        }
        Assertions.assertTrue(found);

    }

    @Then("verify Get STP report data using only from and to date input {string}")
    public void verifyGetSTPReportDataUsingOnlyFromAndToDateInput(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
        String GET_STP_DATA_REPORT ="/stp/exceptions/report/data";
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, GET_STP_DATA_REPORT);
        if(Objects.isNull(testInput.get(caseIdCAPIE)) && ObjectUtils.allNull(testInput.get("fromDate"), testInput.get("toDate"))){
            request.queryParam("fromDate", LocalDate.now().minusDays(7).toString());
            request.queryParam("toDate", LocalDate.now().toString());
        }
        response = request.get(GET_STP_DATA_REPORT);
        System.out.println("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
        Assertions.assertEquals(200, response.getStatusCode());

        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode exceptionReportResponseArray = responseJsonNode.get("exceptionReportResponse");
        boolean found = false;
        for (int i = 0; i < exceptionReportResponseArray.size(); i++) {
            String cycleTime = exceptionReportResponseArray.get(i).get("cycleTime").asText();
            if (cycleTime!=null) {
                found = true;
            }
        }
        Assertions.assertTrue(found);
    }

    @When("adbo User send request to msvc property using input {string} and verify response code")
    public void adboUserSendRequestToMsvcPropertyUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getCAPIEProperty();
        String POST_PROPERTY = "/v2/properties";
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("requestBody.caseId", ADBO_UNIQUE_CASEID);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenCapieProperty())
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_PROPERTY);
        response = request.post(POST_PROPERTY);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();

    }

    @When("External Services - User sends request to post application for channel {string} and {string} using kafka topic input {string}")
    public void externalServicesUserSendsRequestToPostApplicationForChannelAndUsingKafkaTopicInput(String channel, String inputName, String status) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getMSVCFlowManagerURI();

        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("requestBody.caseId", caseIdCAPIE);
        doc.set("requestBody.channel", channel);
        doc.set("requestBody.status", status);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenMsvcFlowManager())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, testInput.get(PATH).asText());
        response = request.post(testInput.get(PATH).asText());
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();

    }

    @Then("Verify state as Review")
    public void verifyStateAsReview() throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode documentsArray = responseJsonNode.get("documents");
        boolean found = false;
        for (int i = 0; i < documentsArray.size(); i++) {
            String state = documentsArray.get(i).get("state").asText();
            if (state.contains("Review")) {
                found = true;
            }
        }
        Assertions.assertTrue(found);
    }


    @Then("User use get FI List endpoint using input {string} and verify MAF")
    public void userUseGetFIListEndpointUsingInputAndVerifyMAF(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getUICoordApplicationTracking();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", caseIdCAPIE);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, GET_FI_LIST_CASE_ID_CAPIE_PATH);
        response = request.get(GET_FI_LIST_CASE_ID_CAPIE_PATH);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode documentsArray = responseJsonNode.get("documents");
        boolean found = false;
        for (int i = 0; i < documentsArray.size(); i++) {
            String category = documentsArray.get(i).get("category").asText();
            if (category.contains("MAF - Mortgage Application Form")) {
                found = true;
            }
        }
        Assertions.assertTrue(found);

    }

    @Then("User use get application data from msvc applicant endpoint using input {string} and get the applicantids")
    public void userUseGetApplicationDataFromMsvcApplicantEndpointUsingInputAndGetTheApplicantids(String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getCAPIEApplicantServiceURI();
        String GET_APPLICANT = "/v2/applicants/case/{caseId}";
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("caseId", caseIdCAPIE);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenCapieApplicant())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, GET_APPLICANT);
        response = request.get(GET_APPLICANT);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(200, response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseJsonNode = new ObjectMapper().readTree(response.asString());

        applicantID1 = responseJsonNode.get(0).get("applicantId").asText();
        applicantID2 = responseJsonNode.get(1).get("applicantId").asText();

        responseString = response.asString();

    }

    @When("External Services - User sends request to post MAF for avscan for channel {string} using kafka topic input {string}")
    public void externalServicesUserSendsRequestToPostMAFForAvscanForChannelUsingKafkaTopicInput(String channel, String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getMSVCFlowManagerURI();

        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("requestBody.caseId", caseIdCAPIE);
        //doc.set("requestBody.mortgageRefNo", testInput.get("requestBody.mortgageRefNo"));
        doc.set("requestBody.channelId", channel);
        doc.set("requestBody.applicantId", applicantID1);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenMsvcFlowManager())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, testInput.get(PATH).asText());
        response = request.post(testInput.get(PATH).asText());
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();

    }

    @When("Delete multiple record in consumer failed kafka event mongo db for {string}")
    public void deleteMultipleRecordInConsumerFailedKafkaEventMongoDbFor(String inputName) {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        MongoActions.deleteManyRecords("consumer_failed_kafka_events","message.mortgageRefNo",testInput.get(REFERENCE_NUMBER).asText());
    }

    @When("User sends request to add caseId for pst broker in CAPIE service for specific type of channel {string} using input {string} and verify response code")
    public void userSendsRequestToAddCaseIdForPstBrokerInCAPIEServiceForSpecificTypeOfChannelUsingInputAndVerifyResponseCode(String channel, String inputName) throws JsonProcessingException {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getCAPIEBrokerServiceURI();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        doc.set("requestBody.caseId", caseIdCAPIE);
        doc.set("requestBody.channel", channel);
        if(channel.equalsIgnoreCase("INTERMEDIARY_NAPOLI") || channel.equalsIgnoreCase("INTERMEDIARY_BROKER_API"))
        {
            String referenceNumber = externalInputsAsJsonNode.get("PST_REVIEW_ValidationRef").get("referenceNumber").asText();
            doc.set("requestBody.mortgageReferenceNumber", referenceNumber);
        }
        else
        {
            log.info("proceed without reference number");
        }
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenCapieCase())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_BROKER_CASE_ID_CAPIE_PATH);
        response = request.post(POST_BROKER_CASE_ID_CAPIE_PATH);
        log.info("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @When("user close FST task from eventbridge for {string} {string}")
    public void userCloseFSTTaskFromEventbridgeFor(String inputName, String channel) throws JsonProcessingException {
        for(int i= 0;i<=7; i++) {
        JsonNode testInput = externalInputsAsJsonNode.get(inputName);
        RestAssured.baseURI = CucumberTestProperties.getIntGMSEventBridge();
        String POST_CLOSE_TASK_EVENT_BRIDGE = "/closeTask";
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        if (channel.equalsIgnoreCase("INTERMEDIARY_NAPOLI") || channel.equalsIgnoreCase("INTERMEDIARY_BROKER_API") || channel.equalsIgnoreCase("BRANCH")) {
                doc.set("requestBody.userId", "OLBR");
            } else {
                doc.set("requestBody.userId", "OLXO");
            }

            JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
            RequestSpecification request = RestAssured.given()
                    .log().all()
                    .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                    .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenEventBridge())
                    .accept(ContentType.JSON);
            Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
            ApiTestUtil.createRequestForInputParams(updatedInput, request, POST_CLOSE_TASK_EVENT_BRIDGE);
            response = request.post(POST_CLOSE_TASK_EVENT_BRIDGE);
            log.info("response " + response);
            log.info(response.getHeaders().asList().toString());
            log.info(response.getBody().prettyPrint());
            Assertions.assertNotNull(response, "response is null");
            responseString = response.asString();
        }
    }
}
