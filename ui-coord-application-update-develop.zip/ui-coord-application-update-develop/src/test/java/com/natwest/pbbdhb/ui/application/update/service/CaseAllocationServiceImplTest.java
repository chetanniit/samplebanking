package com.natwest.pbbdhb.ui.application.update.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.flowmanager.FlowManagerCaseAllocationRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.flowmanager.FlowManagerCaseDeallocationRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.stp.CaseAllocationResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.stp.ExceptionAllocationResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.stp.ExceptionDeallocationResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.userinformation.UserInformationResponse;
import com.natwest.pbbdhb.ui.application.update.service.auth.AuthorizationService;
import com.natwest.pbbdhb.ui.application.update.service.stp.impl.CaseAllocationServiceImpl;
import com.natwest.pbbdhb.ui.application.update.util.ErrorMessageConfigReader;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import static com.natwest.pbbdhb.ui.application.update.util.TestConstants.*;
import static com.natwest.pbbdhb.ui.application.update.util.TestUtil.createUserInformationResponse;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.WARN)
class CaseAllocationServiceImplTest {

    public static final String BASE_URL = "https://msvc-application-flow-manager-v1-hboapiplatform.dev.internal-paas-ms.api.banksvcs.net/mortgages/v1/flow-manager/";
    public static final String ENDPOINT = "caseAllocation";
    public static final String UNASSIGN_EXCEPTION_ENDPOINT = "stp/exception/unassign";
    @InjectMocks
    CaseAllocationServiceImpl service;
    @Mock
    private RestTemplate restTemplate;
    @Mock
    private ObjectMapper objectMapper;
    @Mock
    private AuthorizationService authorizationService;
    @Mock
    ErrorMessageConfigReader errorMessageConfigReader;
    @Captor
    private ArgumentCaptor<HttpEntity<FlowManagerCaseAllocationRequest>> caseAllocationRequestHttpEntityCaptor;

    @Captor
    private ArgumentCaptor<HttpEntity<FlowManagerCaseDeallocationRequest>> caseDeallocationRequestHttpEntityCaptor;

    @BeforeEach
    public void setUp() {
        ReflectionTestUtils.setField(service, "flowManagerParentEndpoint", BASE_URL);
        ReflectionTestUtils.setField(service, "flowManagerCaseAllocationEndpoint", ENDPOINT);
        ReflectionTestUtils.setField(service, "flowManagerCaseDeallocationEndpoint", UNASSIGN_EXCEPTION_ENDPOINT);
    }


    @Test
    void testAllocateCase() {
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());

        when(restTemplate.exchange(any(), any(), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>(CaseAllocationResponse.builder().build().toString(), HttpStatus.OK));
        service.allocateCase(NWB_BRAND, CASE_ID);
        verify(restTemplate).exchange(any(), any(), any(), eq(String.class));
    }

    @Test
    void testAllocateCaseWithReferenceNumber() throws JsonProcessingException {
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());

        when(restTemplate.exchange(any(), any(), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>(CaseAllocationResponse.builder().referenceNumber(REFERENCE_NUMBER).build().toString(), HttpStatus.OK));
        when(objectMapper.readValue(anyString(), eq(ExceptionAllocationResponse.class)))
                .thenReturn(new ObjectMapper()
                        .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
                        .convertValue(
                                CaseAllocationResponse.builder().referenceNumber(REFERENCE_NUMBER).build(),
                                ExceptionAllocationResponse.class
                        )
                );
        ResponseEntity<ExceptionAllocationResponse> responseEntity = service.allocateCase(NWB_BRAND, CASE_ID);
        verify(restTemplate).exchange(any(), any(), any(), eq(String.class));
        assertNotNull(responseEntity.getBody());
        assertEquals(REFERENCE_NUMBER, responseEntity.getBody().getReferenceNumber());
    }

    @Test
    void testAllocateCaseException() {
        when(restTemplate.exchange(any(), any(), any(), eq(String.class)))
                .thenThrow(HttpClientErrorException.class);
        assertThrows(HttpClientErrorException.class,
                () -> service.allocateCase(NWB_BRAND, CASE_ID));
        verify(restTemplate).exchange(any(), any(), any(), eq(String.class));
    }

    @Test
    void testAllocateCaseJsonProcessingException() throws JsonProcessingException {
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());
        when(restTemplate.exchange(any(), any(), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>(CaseAllocationResponse.builder().build().toString(), HttpStatus.OK));
        when(objectMapper.readValue(anyString(), eq(CaseAllocationResponse.class))).thenThrow(JsonProcessingException.class);
        ResponseEntity<ExceptionAllocationResponse> response = service.allocateCase(NWB_BRAND, EXCEPTION_ID);
        assertNull(response.getBody());
        verify(restTemplate).exchange(any(), any(), any(), eq(String.class));
    }

    @ParameterizedTest
    @ValueSource(strings = {"PstUserGroup", "CinUserGroup"})
    void testAllocateCaseWithIsPSTUserFlag(final String userGroup) {
        UserInformationResponse userData = createUserInformationResponse();
        userData.setUserGroups(new String[]{userGroup});
        when(authorizationService.getUserData()).thenReturn(userData);

        when(restTemplate.exchange(any(), any(), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>(CaseAllocationResponse.builder().build().toString(), HttpStatus.OK));
        service.allocateCase(NWB_BRAND, CASE_ID);

        verify(restTemplate).exchange(any(), any(), caseAllocationRequestHttpEntityCaptor.capture(), eq(String.class));

        FlowManagerCaseAllocationRequest requestSent = caseAllocationRequestHttpEntityCaptor.getValue().getBody();
        Assertions.assertThat(requestSent)
                .isNotNull()
                .satisfies(r -> {
                    Assertions.assertThat(r.getUserFullName()).isEqualTo("owendame");
                    Assertions.assertThat(r.getUserRACFId()).isEqualTo("owend");
                    Assertions.assertThat(r.getUserGroups()).contains(userGroup);
                });
    }

    @Test
    void testAllocateCaseWithIsPSTUserFlagWhenUserDataIsNull() {
        when(authorizationService.getUserData()).thenReturn(null);
        when(restTemplate.exchange(any(), any(), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>(CaseAllocationResponse.builder().build().toString(), HttpStatus.OK));
        service.allocateCase(NWB_BRAND, CASE_ID);

        verify(restTemplate).exchange(any(), any(), caseAllocationRequestHttpEntityCaptor.capture(), eq(String.class));

        FlowManagerCaseAllocationRequest requestSent = caseAllocationRequestHttpEntityCaptor.getValue().getBody();
        Assertions.assertThat(requestSent)
                .isNotNull()
                .satisfies(r -> {
                    Assertions.assertThat(r.getUserFullName()).isNull();
                    Assertions.assertThat(r.getUserRACFId()).isNull();
                    Assertions.assertThat(r.getUserGroups()).isNull();
                });
    }

    @Test
    void testDeallocateCase() {
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());
        when(restTemplate.exchange(any(), any(), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>("anyString", HttpStatus.OK));
        service.deallocateCase(NWB_BRAND, EXCEPTION_ID);
        verify(restTemplate).exchange(any(), any(), any(), eq(String.class));
    }

    @Test
    void testDeallocateCaseWithReferenceNumber() throws JsonProcessingException {
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());
        when(restTemplate.exchange(any(), any(), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>(ExceptionDeallocationResponse.builder().referenceNumber(REFERENCE_NUMBER).build().toString(), HttpStatus.OK));
        when(objectMapper.readValue(anyString(), eq(ExceptionDeallocationResponse.class)))
                .thenReturn(ExceptionDeallocationResponse.builder().referenceNumber(REFERENCE_NUMBER).build());
        ResponseEntity<ExceptionDeallocationResponse> responseEntity = service.deallocateCase(NWB_BRAND, EXCEPTION_ID);
        verify(restTemplate).exchange(any(), any(), any(), eq(String.class));
        assertNotNull(responseEntity.getBody());
        assertEquals(REFERENCE_NUMBER, responseEntity.getBody().getReferenceNumber());
    }

    @ParameterizedTest
    @ValueSource(booleans = {false, true})
    void testDeallocateCaseWithIsPSTUserFlag(final boolean isPSTUser) {
        UserInformationResponse userData = createUserInformationResponse();
        userData.setPSTUser(isPSTUser);
        when(authorizationService.getUserData()).thenReturn(userData);

        when(restTemplate.exchange(any(), any(), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>("anyString", HttpStatus.OK));
        service.deallocateCase(NWB_BRAND, EXCEPTION_ID);

        verify(restTemplate).exchange(any(), any(), caseDeallocationRequestHttpEntityCaptor.capture(), eq(String.class));

        FlowManagerCaseDeallocationRequest requestSent = caseDeallocationRequestHttpEntityCaptor.getValue().getBody();
        Assertions.assertThat(requestSent)
                .isNotNull()
                .satisfies(r -> {
                    Assertions.assertThat(r.getUserRACFId()).isEqualTo("owend");
                    Assertions.assertThat(r.isPSTUser()).isEqualTo(isPSTUser);
                });
    }

    @Test
    void testDeAllocateCaseWithIsPSTUserFlagWhenUserDataIsNull() {
        when(authorizationService.getUserData()).thenReturn(null);
        when(restTemplate.exchange(any(), any(), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>("anyString", HttpStatus.OK));
        service.deallocateCase(NWB_BRAND, EXCEPTION_ID);

        verify(restTemplate).exchange(any(), any(), caseDeallocationRequestHttpEntityCaptor.capture(), eq(String.class));

        FlowManagerCaseDeallocationRequest requestSent = caseDeallocationRequestHttpEntityCaptor.getValue().getBody();
        Assertions.assertThat(requestSent)
                .isNotNull()
                .satisfies(r -> {
                    Assertions.assertThat(r.getUserRACFId()).isNull();
                    Assertions.assertThat(r.isPSTUser()).isEqualTo(false);
                });
    }


}
