package com.natwest.pbbdhb.ui.application.update;

import com.natwest.pbbdhb.ui.application.update.service.MockDataLoader;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Assertions;

@SpringBootTest
@ActiveProfiles({"local","unsecure"})
class ApplicationUpdateAppTests {

    @Autowired
    MockDataLoader loader;

    @Test
    void testGetInvalidReferenceNumber() {
        List<String> invalidReferenceNumber = loader.getInvalidReferenceNumber();
        assertTrue(invalidReferenceNumber.size() > 0);
    }

    @Test
    void testGetNotValidUser() {
        List<String> notValidUser = loader.getNotValidUser();
        assertTrue(notValidUser.size() > 0);
    }

    @Test
    void testGetInvalidApplicationId() {
        List<String> invalidApplicationId = loader.getInvalidApplicationId();
        assertTrue(invalidApplicationId.size() > 0);
    }

    @Test
    void testGetClosedTask() {
        List<String> closedTask = loader.getClosedTask();
        assertTrue(closedTask.size() > 0);
    }

    @Test
    void testGetUnprocessedEntity() {
        List<String> unprocessedEntity = loader.getUnprocessedEntity();
        assertTrue(unprocessedEntity.size() > 0);
    }

    @Test
    void testGetNotAuthorizedUser() {
        List<String> notAuthorizedUser = loader.getNotAuthorizedUser();
        assertTrue(notAuthorizedUser.size() > 0);
    }

    @Test
    void testContextLoads() {
        Assertions.assertTrue(true);
    }
}
