package com.natwest.pbbdhb.ui.application.update.controller;


import com.natwest.pbbdhb.ui.application.update.model.dto.exception.TokenExpiredException;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.userinformation.UserInformationResponse;
import com.natwest.pbbdhb.ui.application.update.service.auth.impl.AuthorizationServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static com.natwest.pbbdhb.ui.application.update.util.TestConstants.*;
import static com.natwest.pbbdhb.ui.application.update.util.TestUtil.VALID_RACF;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(value = UserDetailsController.class, properties = {"spring.profiles.active=test"})
@DisplayName("UserDetailsController - MVC Test")
class UserDetailsControllerTest {

    @MockBean(name = "authorizationServiceImpl")
    private AuthorizationServiceImpl authorizationServiceImpl;

    @Autowired
    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetUserWithValidToken() throws Exception {
        UserInformationResponse actualResponse = UserInformationResponse.builder().isMCCUser(true).isUWUser(true).racfID("owend")
                .username("owendame").build();
        when(authorizationServiceImpl.getUserData()).thenReturn(actualResponse);

        MvcResult result = mockMvc.perform(get("/getUserDetails")).andExpect(status().isOk()).andReturn();

        assertEquals(200, result.getResponse().getStatus());
        assertEquals(VALID_RACF, actualResponse.getRacfID());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testGetUserWithInvalidToken() throws Exception {
        when(authorizationServiceImpl.getUserData()).thenThrow(
                new UsernameNotFoundException("invalid token : please supply a valid authentication token"));
        MvcResult result = mockMvc.perform(get("/getUserDetails")).andExpect(status().isForbidden()).andReturn();

        assertEquals(403, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testGetUserWithExpiredToken() throws Exception {
        when(authorizationServiceImpl.getUserData()).thenThrow(
                new TokenExpiredException("token expired : please supply a valid authentication token"));
        MvcResult result = mockMvc.perform(get("/getUserDetails")).andExpect(status().isForbidden()).andReturn();

        assertEquals(403, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }
}
