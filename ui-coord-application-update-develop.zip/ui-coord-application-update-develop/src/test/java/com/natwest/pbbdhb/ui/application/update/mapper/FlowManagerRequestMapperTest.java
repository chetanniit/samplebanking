package com.natwest.pbbdhb.ui.application.update.mapper;


import com.natwest.pbbdhb.ui.application.update.model.dto.FlowManagerAddDocumentResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.FlowManagerDocumentRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.notes.DocumentNotesRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.AddTeleMessageRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.DocumentInfo;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.FlowManagerDocumentInfo;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.firequest.Document;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.firequest.FlowManagerDocument;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.flowmanager.*;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;

import static com.natwest.pbbdhb.ui.application.update.util.TestUtil.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class FlowManagerRequestMapperTest {

    @InjectMocks
    private FlowManagerRequestMapperImpl mapper;

    @Test
    void testToFlowManagerFIRequest(){
        FlowManagerFIRequest flowManagerFIRequest = mapper.toFlowManagerFIRequest(createFIRequest());
        assertNotNull(flowManagerFIRequest);
    }

    @Test
    void testToFlowManagerDocumentNotesRequest(){
        FlowManagerDocumentNotesRequest flowManagerDocumentNotesRequest = mapper.toFlowManagerDocumentNotesRequest(createDocumentNotesRequest());
        assertNotNull(flowManagerDocumentNotesRequest);
    }



    @Test
    void testToFlowManagerDocumentReminder(){
        FlowManagerDocumentReminder flowManagerDocumentReminder = mapper.toFlowManagerDocumentReminder(createDocumentReminder());
        assertNotNull(flowManagerDocumentReminder);
    }

    @Test
    void testToFlowManagerAddNoteRequest(){
        FlowManagerAddNoteRequest flowManagerAddNoteRequest = mapper.toFlowManagerAddNoteRequest(createAddNoteRequest());
        assertNotNull(flowManagerAddNoteRequest);
    }

    @Test
    void testToFlowManagerApplicationInformationUpdateRequest(){
        FlowManagerApplicationInformationUpdateRequest flowManagerApplicationInformationUpdateRequest = mapper.toFlowManagerApplicationInformationUpdateRequest(createApplicationInfoUpdateRequest());
        assertNotNull(flowManagerApplicationInformationUpdateRequest);
    }

    @Test
    void testToFlowManagerFIStatusRequest(){
        FlowManagerFIStatusRequest flowManagerFIStatusRequest = mapper.toFlowManagerFIStatusRequest(createFIStatusWithNoteRequest());
        assertNotNull(flowManagerFIStatusRequest);
    }

    @Test
    void testToFlowManagerDocumentInfo() {
        FlowManagerDocumentInfo flowManagerDocumentInfo = mapper.toFlowManagerDocumentInfo(DocumentInfo.builder().build());
        assertNotNull(flowManagerDocumentInfo);
    }

    @Test
    void testToFlowManagerDocumentInfoNull() {
        FlowManagerDocumentInfo flowManagerDocumentInfo = mapper.toFlowManagerDocumentInfo((DocumentInfo) null);
        assertNull(flowManagerDocumentInfo);
    }

    @Test
    void testToFlowManagerDocumentInfoList() {
        List<FlowManagerDocumentInfo> flowManagerDocumentInfo = mapper.toFlowManagerDocumentInfo(Collections.singletonList(DocumentInfo.builder().build()));
        assertNotNull(flowManagerDocumentInfo);
    }

    @Test
    void testToFlowManagerDocumentInfoListNull() {
        List<FlowManagerDocumentInfo> flowManagerDocumentInfo = mapper.toFlowManagerDocumentInfo((List<DocumentInfo>) null);
        assertNull(flowManagerDocumentInfo);
    }

    @Test
    void testToFlowManagerDocumentList() {
        List<FlowManagerDocument> flowManagerDocuments = mapper.toFlowManagerDocument(Collections.singletonList(Document.builder().build()));
        assertNotNull(flowManagerDocuments);
    }

    @Test
    void testToFlowManagerDocumentListNull() {
        List<FlowManagerDocument> flowManagerDocuments = mapper.toFlowManagerDocument((List<Document>) null);
        assertNull(flowManagerDocuments);
    }

    @Test
    void testToFlowManagerDocument() {
        FlowManagerDocument flowManagerDocument = mapper.toFlowManagerDocument(Document.builder().timePeriod("3 Monthly").build());
        assertNotNull(flowManagerDocument);
    }

    @Test
    void testToFlowManagerDocumentNull() {
        FlowManagerDocument flowManagerDocument = mapper.toFlowManagerDocument((Document) null);
        assertNull(flowManagerDocument);
    }

    @Test
    void testToFlowManagerDocumentLatest() {
        FlowManagerDocument flowManagerDocument = mapper.toFlowManagerDocument(Document.builder().timePeriod("Latest").build());
        assertNotNull(flowManagerDocument);
    }

    @Test
    void testToDocumentRequest() {
        DocumentRequestResponse documentRequest = mapper.toDocumentRequest(FlowManagerDocumentRequest.builder().count("3").frequency("Monthly").build());
        assertNotNull(documentRequest);
    }

    @Test
    void testToDocumentRequestNull() {
        DocumentRequestResponse documentRequest = mapper.toDocumentRequest((FlowManagerDocumentRequest) null);
        assertNull(documentRequest);
    }

    @Test
    void testToDocumentRequestLatestTimePeriod() {
        DocumentRequestResponse documentRequest = mapper.toDocumentRequest(FlowManagerDocumentRequest.builder().count("0").frequency("Latest").build());
        assertNotNull(documentRequest);
    }

    @Test
    void testToDocumentRequestTimePeriodNull() {
        DocumentRequestResponse documentRequest = mapper.toDocumentRequest(FlowManagerDocumentRequest.builder().build());
        assertNotNull(documentRequest);
    }

    @Test
    void testToFlowManagerFIRequestNull(){
        FlowManagerFIRequest flowManagerFIRequest = mapper.toFlowManagerFIRequest(null);
        assertNull(flowManagerFIRequest);
    }

    @Test
    void testToAddDocumentResponse() {
        AddDocumentResponse addDocumentResponse = mapper.toAddDocumentResponse(FlowManagerAddDocumentResponse.builder().build());
        assertNotNull(addDocumentResponse);
    }

    @Test
    void testToAddDocumentResponseNull() {
        AddDocumentResponse addDocumentResponse = mapper.toAddDocumentResponse(null);
        assertNull(addDocumentResponse);
    }

    @Test
    void testToDocumentRequestList() {
        List<DocumentRequestResponse> documentRequest = mapper.toDocumentRequest(Collections.singletonList(FlowManagerDocumentRequest.builder().count("3").frequency("Monthly").build()));
        assertNotNull(documentRequest);
    }

    @Test
    void testToDocumentRequestListNull() {
        List<DocumentRequestResponse> documentRequest = mapper.toDocumentRequest((List<FlowManagerDocumentRequest>) null);
        assertNull(documentRequest);
    }

    @Test
    void testToFlowManagerAddTeleMessageRequest() {
        FlowManagerAddTeleMessageRequest flowManagerAddTeleMessageRequest = mapper.toFlowManagerAddTeleMessageRequest(AddTeleMessageRequest.builder().build());
        assertNotNull(flowManagerAddTeleMessageRequest);
    }

    @Test
    void testToFlowManagerAddTeleMessageRequestNull() {
        FlowManagerAddTeleMessageRequest flowManagerAddTeleMessageRequest = mapper.toFlowManagerAddTeleMessageRequest(null);
        assertNull(flowManagerAddTeleMessageRequest);
    }

    @Test
    void testToBasicPackagingDocumentResponse() {
        BasicPackagingDocumentResponse basicPackagingDocumentResponse = mapper.toBasicPackagingDocumentResponse(FlowManagerBasicPackagingDocumentResponse.builder()
                .documents(Collections.singletonList(FlowManagerDocumentDetail.builder().count("1").frequency("Monthly").build())).build());
        assertNotNull(basicPackagingDocumentResponse);
    }

    @Test
    void testToBasicPackagingDocumentResponseNull() {
        BasicPackagingDocumentResponse basicPackagingDocumentResponse = mapper.toBasicPackagingDocumentResponse(null);
        assertNull(basicPackagingDocumentResponse);
    }

    @ParameterizedTest
    @ValueSource(booleans = {true, false})
    void testToFlowManagerDocumentNotesWithPrefixFlagRequest(boolean flagValue) {
        DocumentNotesRequest request = createDocumentNotesRequest();
        request.setSkipPrefix(flagValue);
        FlowManagerDocumentNotesRequest flowManagerDocumentNotesRequest = mapper.toFlowManagerDocumentNotesRequest(request);
        assertNotNull(flowManagerDocumentNotesRequest);
        assertEquals(flagValue, flowManagerDocumentNotesRequest.isSkipPrefix());
    }
}
