package com.natwest.pbbdhb.ui.application.update.service;

import com.natwest.pbbdhb.applicant.dto.ApplicantDto;
import com.natwest.pbbdhb.ui.application.update.service.impl.ApplicantServiceImpl;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import javax.json.Json;
import javax.json.JsonPatch;
import javax.json.JsonReader;

import java.io.StringReader;
import java.util.Arrays;

import static com.natwest.pbbdhb.ui.application.update.util.TestConstants.APPLICANT_ID;
import static com.natwest.pbbdhb.ui.application.update.util.TestConstants.CASE_ID;
import static com.natwest.pbbdhb.ui.application.update.util.TestConstants.NWB_BRAND;
import static com.natwest.pbbdhb.ui.application.update.util.TestUtil.getPersonDetailsDto;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.WARN)
class ApplicantServiceImplTest {

    @InjectMocks
    private ApplicantServiceImpl service;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private ApplicationEventPublisher eventPublisher;

    public static final String BASE_URL = "https://v1-msvc-applicant-dev.edi02-apps.dev-pcf.lb4.rbsgrp.net";
    public static final String ENDPOINT = "/v1/applicants/1234567";

    @AfterEach
    void verifyAfter() {
        verifyNoMoreInteractions(restTemplate);
    }

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        ReflectionTestUtils.setField(service, "msvcApplicantParentEndpoint", BASE_URL);
        ReflectionTestUtils.setField(service, "msvcApplicantApplicantsEndpoint", ENDPOINT);
        ReflectionTestUtils.setField(service,"msvcApplicantApplicantsPatchEndpoint",ENDPOINT);
        ReflectionTestUtils.setField(service,"applicantInfoUpdateAllowedFields",
                Arrays.asList("/personalDetails/email","/personalDetails/telephones"));
    }

    @Test
    void testUpdateApplicants(){
        ApplicantDto applicantDto = ApplicantDto.builder().build();
        applicantDto.setMainApplicant(true);
        applicantDto.setPersonalDetails(getPersonDetailsDto());
        applicantDto.setCaseId(CASE_ID);

        when(restTemplate.exchange(any(),any(), any(), eq(ApplicantDto.class)))
                .thenReturn(new ResponseEntity<>(applicantDto, HttpStatus.OK));

        service.updateApplicants(NWB_BRAND, APPLICANT_ID, applicantDto);

        verify(restTemplate).exchange(any(),any(), any(), eq(ApplicantDto.class));
    }

    @Test
    void testPatchApplicantUpdate() {
        String body = "[{\"op\": \"replace\", \"path\": \"/kycChannel\", \"value\": \"WEB\" }]";

        JsonReader jsonReader = Json.createReader(new StringReader(body));
        JsonPatch jsonPatch = Json.createPatch(jsonReader.readArray());
        when(restTemplate.exchange(any(), any(), any(), eq(ApplicantDto.class)))
                .thenReturn(new ResponseEntity<>(ApplicantDto.builder().build(), HttpStatus.OK));
        service.patchApplicantUpdate(NWB_BRAND, CASE_ID,APPLICANT_ID, jsonPatch);
        verify(restTemplate).exchange(any(), any(), any(), eq(ApplicantDto.class));
        verifyNoInteractions(eventPublisher);
    }
}