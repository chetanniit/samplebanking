package com.natwest.pbbdhb.ui.application.update.cucumber.stepdefs;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.CucumberTestProperties;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Assertions;

import java.io.IOException;
import java.util.ArrayList;

import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.UPDATE_CASE_OWNER_REFERENCE_NUMBER_JSON;
import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.Params.*;

@Slf4j
public class PatchUpdateApplicationCaseOwnerReferenceNumberStepDefs {
    private JsonNode inputsAsJsonNode;
    private JsonNode responseJsonNode;
    private String responseString;
    private Response response;

    @Before
    public void init() throws IOException {
        inputsAsJsonNode = ApiTestUtil.getInputsAsJsonNode(UPDATE_CASE_OWNER_REFERENCE_NUMBER_JSON);
    }

    @Given("UI coord application Case Owner update Service endpoint is exists")
    public void uiCoordApplicationCaseOwnerUpdateServiceEndpointExistsEndpointExists() {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String path = inputsAsJsonNode.get(PATH).asText();
        Assertions.assertNotNull(path, "path is null");
    }

    @When("User Patch request for update Case Owner for multiple case using input {string} and verify response code")
    public void patchrequestforupdatecaseownerUsingReferenceNumAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        String path = inputsAsJsonNode.get(PATH).asText();
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .accept(ContentType.JSON);
        JsonNode testInput = inputsAsJsonNode.get(inputName);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(testInput, request, path);
        response = request.patch(inputsAsJsonNode.get(PATH).asText());
        response = request
                .headers(CucumberTestProperties.getHeaders(testInput))
                .patch(inputsAsJsonNode.get(PATH).asText());
        System.out.println("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }


    @Then("Verify response code while providing valid input in the request parameter of case Owner endpoint in ui coord application update for the input {string}")
    public void verifyResponseCodeWhileProvidingValidInputInTheRequestParameterOfCaseOwnerEndpointInUiCoordApplicationUpdateForTheInput(String arg0) {
        Assertions.assertEquals(200, response.getStatusCode());
    }


    @Then("Verify error code 400 Bad request for the UI Coord Application CaseOwner update response for the invalid input {string}")
    public void verifyPatchApplicantByApplicantIdNotFoundResponse(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.body().asString());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertNotNull(response, "response is null");
        Assertions.assertEquals(400, response.getStatusCode());
    }


    @Then("Verify error code 206 Bad request for the UI Coord Application CaseOwner update response for partial update case owner input {string}")
    public void verifyErrorCodeBadRequestForTheUICoordApplicationCaseOwnerUpdateResponseForPartialUpdateCaseOwnerInput(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.body().asString());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertNotNull(response, "response is null");
        Assertions.assertEquals(206, response.getStatusCode());
    }

    @Then("Verify error code 409 Bad request for the UI Coord Application CaseOwner update response for Conflict Case owner input {string}")
    public void verifyErrorCodeBadRequestForTheUICoordApplicationCaseOwnerUpdateResponseForConflictCaseOwnerInput(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.body().asString());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertNotNull(response, "response is null");
        Assertions.assertEquals(409, response.getStatusCode());
    }

    @Then("Verify error {int} returned due to invalid reference Number input {string}")
    public void verifyErrorReturnedDueToInvalidJsonPatchInput(int errorCode, String inputName) {
        JsonNode input = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(input.get("responseCode").asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        Assertions.assertEquals(errorCode, response.getStatusCode());
        int failed_request_Size = responseJsonNode.get(FAILEDREQUESTS).size();
        Assertions.assertTrue(failed_request_Size>0);
    }
}
