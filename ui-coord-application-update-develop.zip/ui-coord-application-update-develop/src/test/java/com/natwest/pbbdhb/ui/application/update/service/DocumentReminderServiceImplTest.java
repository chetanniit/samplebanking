package com.natwest.pbbdhb.ui.application.update.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.ui.application.update.mapper.FlowManagerRequestMapper;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.DocumentReminder;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.ApplicationInformationUpdateRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.SuccessResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.application.ApplicationInformationUpdateResponse;
import com.natwest.pbbdhb.ui.application.update.service.auth.AuthorizationService;
import com.natwest.pbbdhb.ui.application.update.service.impl.DocumentReminderServiceImpl;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.REQUEST_REMINDER_RESPONSE;
import static com.natwest.pbbdhb.ui.application.update.util.TestConstants.*;
import static com.natwest.pbbdhb.ui.application.update.util.TestUtil.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.WARN)
public class DocumentReminderServiceImplTest {

    private static String REFERENCE_NUMBER = "84153756";
    private static String REQUEST_ID = "12341234";

    @InjectMocks
    private DocumentReminderServiceImpl service;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private AuthorizationService authorizationService;

    @Mock
    private FlowManagerRequestMapper flowManagerRequestMapper;

    @Mock
    private ObjectMapper objectMapper;

    public static final String BASE_URL = "http://11.15.0.124:8082/mortgages/v1/flow-manager/";
    public static final String ENDPOINT = "sendReminder";

    @BeforeEach
    public void setUp() {
        ReflectionTestUtils.setField(service, "flowManagerParentEndpoint", BASE_URL);
        ReflectionTestUtils.setField(service, "flowManagerReminderEndpoint", ENDPOINT);
    }

    @AfterEach
    void verifyAfter() {
        verifyNoMoreInteractions(restTemplate);
    }

    @Test
    void testSendReminder() throws JsonProcessingException {
        DocumentReminder reminder = createDocumentReminder();
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());
        when(flowManagerRequestMapper.toFlowManagerDocumentReminder(any())).thenReturn(createFlowManagerDocumentReminder());
        when(restTemplate.exchange(any(),any(), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>(REQUEST_REMINDER_RESPONSE + "ABC", HttpStatus.OK));
        when(objectMapper.readValue(anyString(), eq(SuccessResponse.class))).thenReturn(new SuccessResponse(REQUEST_REMINDER_RESPONSE + "ABC"));
        ResponseEntity<SuccessResponse> response = service.sendReminder(NWB_BRAND,reminder,REFERENCE_NUMBER,null);
        assertEquals(response.getBody().getSuccessMessage(), REQUEST_REMINDER_RESPONSE + "ABC");

        verify(restTemplate).exchange(any(),any(), any(), eq(String.class));
    }

    @Test
    void testSendReminderException() {
        DocumentReminder reminder = createDocumentReminder();
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());
        when(flowManagerRequestMapper.toFlowManagerDocumentReminder(any())).thenReturn(createFlowManagerDocumentReminder());
        when(restTemplate.exchange(any(),any(), any(), eq(String.class)))
                .thenThrow(HttpClientErrorException.class);
        HttpClientErrorException processFailException = assertThrows(HttpClientErrorException.class,
                () -> service.sendReminder(NWB_BRAND,reminder,REFERENCE_NUMBER,null));

        verify(restTemplate).exchange(any(),any(), any(), eq(String.class));
    }
    @Test
    void testJsonProcessingException() throws JsonProcessingException {
        DocumentReminder reminder = createDocumentReminder();
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());
        when(flowManagerRequestMapper.toFlowManagerDocumentReminder(any())).thenReturn(createFlowManagerDocumentReminder());
        when(restTemplate.exchange(any(),any(), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>(REQUEST_REMINDER_RESPONSE + "ABC", HttpStatus.OK));
        when(objectMapper.readValue(anyString(), eq(SuccessResponse.class))).thenThrow(JsonProcessingException.class);
        ResponseEntity<SuccessResponse> response = service.sendReminder(NWB_BRAND,reminder,null,CASE_ID);
        assertNull(response.getBody());
        verify(restTemplate).exchange(any(),any(), any(), eq(String.class));
    }




    @Test
    void testSendReminderCaseId() throws JsonProcessingException {
        DocumentReminder reminder = createDocumentReminder();
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());
        when(flowManagerRequestMapper.toFlowManagerDocumentReminder(any())).thenReturn(createFlowManagerDocumentReminder());
        when(restTemplate.exchange(any(),any(), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>(REQUEST_REMINDER_RESPONSE + "ABC", HttpStatus.OK));
        when(objectMapper.readValue(anyString(), eq(SuccessResponse.class))).thenReturn(new SuccessResponse(REQUEST_REMINDER_RESPONSE + "ABC"));
        ResponseEntity<SuccessResponse> response = service.sendReminder(NWB_BRAND,reminder,null,CASE_ID);
        assertEquals(response.getBody().getSuccessMessage(), REQUEST_REMINDER_RESPONSE + "ABC");

        verify(restTemplate).exchange(any(),any(), any(), eq(String.class));
    }
}
