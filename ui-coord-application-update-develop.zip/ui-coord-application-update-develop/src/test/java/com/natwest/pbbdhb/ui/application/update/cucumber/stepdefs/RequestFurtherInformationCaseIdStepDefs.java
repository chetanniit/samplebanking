package com.natwest.pbbdhb.ui.application.update.cucumber.stepdefs;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.CucumberTestProperties;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.TestEnvironment;
import com.natwest.pbbdhb.ui.application.update.cucumber.token.AccessTokenGenerator;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.stream.StreamSupport;

import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.Params.*;
import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.REQUEST_FURTHER_INFORMATION_CASE_ID_JSON;

@Slf4j
public class RequestFurtherInformationCaseIdStepDefs {
    private JsonNode inputsAsJsonNode;
    private JsonNode responseJsonNode;
    private String responseString;
    private Response response;

    @Before
    public void init() throws IOException {
        inputsAsJsonNode = ApiTestUtil.getInputsAsJsonNode(REQUEST_FURTHER_INFORMATION_CASE_ID_JSON);

    }

    private void validateBadRequest(JsonNode responseJsonNode, String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode error_message_Array = responseJsonNode.get(ERROR_MESSAGES).get(0);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGES).asText(), error_message_Array.asText());
    }

    private void validateNotFound(JsonNode responseJsonNode, String inputName) throws JsonProcessingException{
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(NOT_FOUND, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode error_message_Array = responseJsonNode.get(ERROR_MESSAGES).get(0);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGES).asText(), error_message_Array.asText());
        // Assertions.assertEquals(inputs.get(RESPONSE_CODE).asText(), responseJsonNode.get(RESPONSE_CODE).asText());

    }
    private void validateBadRequestForMissingInput(JsonNode responseJsonNode, String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode error_message_Array = responseJsonNode.get(ERROR_MESSAGES).get(0);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGES).asText(), error_message_Array.asText());
    }


    @Given("All raise Request Further Information Service case id endpoint exists")
    public void allRaiseRequestFurtherInformationServiceEndpointExists() {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String path = inputsAsJsonNode.get(PATH).asText();
        Assertions.assertNotNull(path, "path is null");
    }

    public Long newTestDateFormat() {
        DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
        Date date = new Date();
        return Long.parseLong(dateFormat.format(date));
    }

    @When("User sends request to raise Request Further Information case id using input {string} and verify response code")
    public void userSendsRequestToRaiseRequestFurtherInformationUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        String path = inputsAsJsonNode.get(PATH).asText();
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        StreamSupport.stream(inputs.get(REQUEST_BODY).get("documentRequests").spliterator(), false).forEach(documentRequest -> {
            JsonNode requiredForArray = documentRequest.get("requiredFor");
            StreamSupport.stream(requiredForArray.spliterator(), false).forEach(requiredFor -> {
                ((ObjectNode) requiredFor).put("applicantId", RandomStringUtils.randomAlphabetic(1, 30) + newTestDateFormat());
            });
        });
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(inputs, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(inputs, request, path);
        response = request.headers(CucumberTestProperties.getHeaders(inputs)).post(inputsAsJsonNode.get(PATH).asText());
        System.out.println("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(inputs.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @When("Get documents for application caseId from input {string}")
    public void getFIList(String inputName) throws JsonProcessingException, InterruptedException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        RestAssured.baseURI = CucumberTestProperties.getApplicationTrackingURI();
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        ObjectMapper mapper = new ObjectMapper();
        JsonNode requestInput = mapper.createObjectNode();
        ObjectNode testInput = ((ObjectNode) requestInput);
        testInput.put(RESPONSE_CODE, "200");
        testInput.put(BRAND, inputs.get(BRAND));
        testInput.put(CASE_ID, inputs.get(CASE_ID));
        String GET_PATH = "/application/case/{caseId}/filist";
        RequestSpecification request = RestAssured.given().when()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(testInput,"AT"))
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(testInput, request, GET_PATH);
        response = request.get(GET_PATH);
        log.info("response " + response);
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @Then("Check FI document identifier")
    public void validateFIDocumentIdentifiersAreTheSame() throws JsonProcessingException {
        JsonNode getDocuments = (new ObjectMapper().readTree(responseString)).get(DOCUMENTS);
        Assertions.assertEquals(getDocuments.get(0).get(DOCUMENT_IDENTIFIER).asText(), "F1");
    }

    @Then("Verify case id response for channel having Intermediary Case for request further information as the endpoint input {string}")
    public void verifyResponseForChannelHavingIntermediaryCaseForRequestFurtherInformationAsTheEndpointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify case id response for channel having Direct Advised Case for request further information as the endpoint input {string}")
    public void verifyResponseForChannelHavingDirectAdvisedCaseForRequestFurtherInformationAsTheEndpointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify case id response for channel having Digital Non-Advised Case for request further information as the endpoint input {string}")
    public void verifyResponseForChannelHavingDigitalNonAdvisedCaseForRequestFurtherInformationAsTheEndpointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify case id response for channel having Advisor for request further information as the endpoint input {string}")
    public void verifyResponseForChannelHavingAdvisorForRequestFurtherInformationAsTheEndpointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }

    @Then("Verify the case id error response for invalid value for reference number for the end point input {string}")
    public void verifyTheErrorResponseForInvalidValueForReferenceNumberForTheEndPointInput(String inputName) throws JsonProcessingException{
        validateBadRequest(responseJsonNode, inputName);

       /* responseJsonNode = new ObjectMapper().readTree(response.asString());
         Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode error_message_Array = responseJsonNode.get(ERROR_MESSAGES).get(0);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGES).asText(), error_message_Array.asText());*/

    }

    @Then("Verify the case id display of error message for missing brand for the end point input {string}")
    public void verifyTheDisplayOfErrorMessageForMissingBrandForTheEndPointInput(String inputName) throws JsonProcessingException {
        validateBadRequestForMissingInput(responseJsonNode, inputName);
    }

   /* @Then("Verify the display of error message for all mandatory fields left blank for the end point input  {string}")
    public void verifyTheDisplayOfErrorMessageForAllMandatoryFieldsLeftBlankForTheEndPointInput(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        String[] errorMessages = inputs.get(ERROR_MESSAGES).asText().split(",");
        String responseError = "";
        for(int i=0;i<responseJsonNode.get(ERROR_MESSAGES).size();i++){
            responseError +=responseJsonNode.get(ERROR_MESSAGES).get(i);
        }
        for(String error:errorMessages){
            Assertions.assertTrue(responseError.contains(error));
        }
        Assertions.assertEquals(5, responseJsonNode.get(ERROR_MESSAGES).size());
    }*/


    @Then("Validate the case id error message for forbidden user for request FI {string}")
    public void validateTheErrorMessageForForbiddenUserForRequestFI(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assert.assertEquals(FORBIDDEN,responseJsonNode.get(RESPONSE_STATUS).asText());
        Assert.assertEquals(inputs.get(ERROR_MESSAGES).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }

    @Then("Verify the case id error response for invalid value for case is for the end point input {string}")
    public void verifyTheCaseIdErrorResponseForInvalidValueForCaseIsForTheEndPointInput(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode, inputName);
    }

    @Then("Verify further information case id as a request input parameter which accepts Fifty alphanumeric only for the end point input {string}")
    public void verifyFurtherInformationCaseIdAsARequestInputParameterWhichAcceptsFiftyAlphanumericOnlyForTheEndPointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_FI_RESPONSE_MESSAGE));
    }
    @When("Enabling case id the under writer rights for user")
    public void enablingTheUnderWriterRightsForUser() throws JsonProcessingException {
        AccessTokenGenerator.accessToken=null;
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String path = inputsAsJsonNode.get(PATH).asText();
        Assertions.assertNotNull(path, "path is null");
        TestEnvironment testEnv = CucumberTestProperties.getTestEnv();
        if (testEnv.name().equals("DEV")){
            RequestSpecification request = RestAssured.given()
                    .log().all()
                    .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                    .accept(ContentType.JSON);
            String rights = "{\"isMCCUser\": false,\"isMopsUser\": false,\"isUWUser\": true, \"isUWLead\": true,\"isDocViewer\": false, \"isMopsDataEntry\": false, \"racfID\": \"string\", \"username\": \"string\"}";
            request.body(rights);
            response = request.post("enableMockUsers");
            Assertions.assertEquals(200, response.getStatusCode());
            Assertions.assertNotNull(response, "response is null");
            responseString = response.asString();
        }
    }
    @When("Enabling case id the MCC user rights for user")
    public void enablingTheMCCUserRightsForUser() throws JsonProcessingException {
        AccessTokenGenerator.accessToken=null;
        TestEnvironment testEnv = CucumberTestProperties.getTestEnv();
        if (testEnv.name().equals("DEV")) {
            RequestSpecification request = RestAssured.given()
                    .log().all()
                    .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                    .accept(ContentType.JSON);
            String rights = "{\"isMCCUser\": true,\"isMopsUser\": false,\"isUWUser\": false, \"isUWLead\": false,\"isDocViewer\": false, \"isMopsDataEntry\": false, \"racfID\": \"string\", \"username\": \"string\"}";
            request.body(rights);
            response = request.post("enableMockUsers");
            Assertions.assertEquals(200, response.getStatusCode());
            Assertions.assertNotNull(response, "response is null");
            responseString = response.asString();
        }
    }

    @When("Enabling case id the other user rights for user")
    public void enablingCaseIdTheOtherUserRightsForUser() throws JsonProcessingException {
        AccessTokenGenerator.accessToken=null;
        TestEnvironment testEnv = CucumberTestProperties.getTestEnv();
        if (testEnv.name().equals("DEV")){
            RequestSpecification request = RestAssured.given()
                    .log().all()
                    .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                    .accept(ContentType.JSON);
            String rights = "{\"isMCCUser\": false, \"isMopsUser\": false, \"isUWUser\": false, \"isUWLead\": true}";
            request.body(rights);
            response = request.post("enableMockUsers");
            Assertions.assertEquals(200, response.getStatusCode());
            Assertions.assertNotNull(response, "response is null");
            responseString = response.asString();
        }
    }

    @Then("Verify error message for duplicate FI check for caseid the input {string}")
    public void verifyErrorMessageForDuplicateFICheckForCaseidTheInput(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assert.assertEquals("409",responseJsonNode.get(RESPONSE_CODE).asText());
        Assert.assertEquals(inputs.get(MESSAGE).asText(), responseJsonNode.get("message").asText());
    }


    public Long testDateFormat() {
        DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmm");
        Date date = new Date();
        return Long.parseLong(dateFormat.format(date));
    }

    @When("User sends request duplicate FI to raise Request Further Information case id using input {string} and verify response code")
    public void userSendsRequestDuplicateFIToRaiseRequestFurtherInformationCaseIdUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        String path = inputsAsJsonNode.get(PATH).asText();
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(inputs);
        DocumentContext doc = JsonPath.parse(json);
        String randomizedString = RandomStringUtils.randomAlphabetic(1, 10);
        String applicantId = inputs.get(REQUEST_BODY).get("documentRequests").get(0).get("requiredFor").get(0).get("applicantId").asText() + randomizedString;
        doc.set("requestBody.documentRequests[0].requiredFor[0].applicantId", applicantId);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .accept(ContentType.JSON);
        Assertions.assertNotNull(inputs, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, path);
        response = request.headers(CucumberTestProperties.getHeaders(inputs)).post(inputsAsJsonNode.get(PATH).asText());
        System.out.println("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(inputs.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }


    @Then("Verify error message for partial duplicate FI check for case id the input {string}")
    public void verifyErrorMessageForPartialDuplicateFICheckForCaseIdTheInput(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assert.assertEquals("206",responseJsonNode.get(RESPONSE_CODE).asText());
        Assert.assertEquals(inputs.get(MESSAGE).asText(), responseJsonNode.get("message").asText());
    }

    @When("User sends request to raise Request Further Information case id using input {string} and verify response codes")
    public void userSendsRequestToRaiseRequestFurtherInformationCaseIdUsingInputAndVerifyResponseCodes(String inputName) throws JsonProcessingException {
        String path = inputsAsJsonNode.get(PATH).asText();
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .accept(ContentType.JSON);
        JsonNode testInput = inputsAsJsonNode.get(inputName);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(testInput, request, path);
        response = request.headers(CucumberTestProperties.getHeaders(testInput)).post(inputsAsJsonNode.get(PATH).asText());
        System.out.println("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }
}