package com.natwest.pbbdhb.ui.application.update.util;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest
@TestPropertySource(properties = {"dbretry.count=1", "dbretry.delay=1000"})
public class DBUpdateRetryPropertiesReaderTest {

    @Autowired
    DBUpdateRetryPropertiesReader dbUpdateRetryPropertiesReader;

    @Test
    void testDBUpdatePropertiesReader() {
        int count = dbUpdateRetryPropertiesReader.getCount();
        long delay = dbUpdateRetryPropertiesReader.getWaitDelay();
        assertEquals(1,count);
        assertEquals(1000,delay);
    }
}
