package com.natwest.pbbdhb.ui.application.update.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.ui.application.update.mapper.FlowManagerRequestMapper;
import com.natwest.pbbdhb.ui.application.update.model.dto.notes.DocumentNotesRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.SuccessResponse;
import com.natwest.pbbdhb.ui.application.update.service.auth.AuthorizationService;
import com.natwest.pbbdhb.ui.application.update.service.impl.DocumentNotesServiceImpl;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import static com.natwest.pbbdhb.ui.application.update.util.TestConstants.*;
import static com.natwest.pbbdhb.ui.application.update.util.TestUtil.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.WARN)
public class DocumentNotesServiceImplTest {

    public static final String BASE_URL = "https://msvc-application-flow-manager-v1-hboapiplatform.dev.internal-paas-ms.api.banksvcs.net/mortgages/v1/flow-manager/";
    public static final String ENDPOINT = "addNote";
    @InjectMocks
    DocumentNotesServiceImpl service;
    @Mock
    private RestTemplate restTemplate;

    @Mock
    private AuthorizationService authorizationService;

    @Mock
    private FlowManagerRequestMapper flowManagerRequestMapper;

    @Mock
    private ObjectMapper objectMapper;

    @BeforeEach
    public void setUp() {
        ReflectionTestUtils.setField(service, "flowManagerParentEndpoint", BASE_URL);
        ReflectionTestUtils.setField(service, "flowManagerAddNoteEndpoint", ENDPOINT);
    }

    @AfterEach
    void verifyAfter() {
        verifyNoMoreInteractions(restTemplate);
    }

    @Test
    void testAddNoteSuccess() throws JsonProcessingException {
        DocumentNotesRequest request = createDocumentNotesRequest();
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());
        when(flowManagerRequestMapper.toFlowManagerDocumentNotesRequest(any())).thenReturn(createFlowManagerDocumentNotesRequest());
        when(restTemplate.exchange(any(),any(), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>(NOTES_ADDED_SUCCESSFULLY, HttpStatus.OK));
        when(objectMapper.readValue(anyString(), eq(SuccessResponse.class))).thenReturn(new SuccessResponse(NOTES_ADDED_SUCCESSFULLY));
        ResponseEntity<SuccessResponse> response = service.addDocumentRequestNotes(NWB_BRAND,REFERENCE_NUMBER, null, request);
        assertEquals(NOTES_ADDED_SUCCESSFULLY, response.getBody().getSuccessMessage());
        verify(restTemplate).exchange(any(),any(), any(), eq(String.class));
    }

    @Test
    void testAddNoteWithCaseIdSuccess() throws JsonProcessingException {
        DocumentNotesRequest request = createDocumentNotesRequest();
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());
        when(flowManagerRequestMapper.toFlowManagerDocumentNotesRequest(any())).thenReturn(createFlowManagerDocumentNotesRequest());
        when(restTemplate.exchange(any(),any(), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>(NOTES_ADDED_SUCCESSFULLY, HttpStatus.OK));
        when(objectMapper.readValue(anyString(), eq(SuccessResponse.class))).thenReturn(new SuccessResponse(NOTES_ADDED_SUCCESSFULLY));
        ResponseEntity<SuccessResponse> response = service.addDocumentRequestNotes(NWB_BRAND,null, CASE_ID, request);
        assertEquals(NOTES_ADDED_SUCCESSFULLY, response.getBody().getSuccessMessage());
        verify(restTemplate).exchange(any(),any(), any(), eq(String.class));
    }

    @Test
    void testAddNoteSuccessWithoutRequestId() throws JsonProcessingException {
        DocumentNotesRequest request = createDocumentNotesRequestWithoutRequestId();
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());
        when(flowManagerRequestMapper.toFlowManagerDocumentNotesRequest(any())).thenReturn(createFlowManagerDocumentNotesRequest());
        when(restTemplate.exchange(any(),any(), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>(NOTES_ADDED_SUCCESSFULLY, HttpStatus.OK));
        when(objectMapper.readValue(anyString(), eq(SuccessResponse.class))).thenReturn(new SuccessResponse(NOTES_ADDED_SUCCESSFULLY));
        ResponseEntity<SuccessResponse> response = service.addDocumentRequestNotes(NWB_BRAND,REFERENCE_NUMBER, null, request);
        assertEquals(NOTES_ADDED_SUCCESSFULLY, response.getBody().getSuccessMessage());
        verify(restTemplate).exchange(any(),any(), any(), eq(String.class));
    }

    @Test
    void testAddNoteCaseIdSuccessWithoutRequestId() throws JsonProcessingException {
        DocumentNotesRequest request = createDocumentNotesRequestWithoutRequestId();
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());
        when(flowManagerRequestMapper.toFlowManagerDocumentNotesRequest(any())).thenReturn(createFlowManagerDocumentNotesRequest());
        when(restTemplate.exchange(any(),any(), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>(NOTES_ADDED_SUCCESSFULLY, HttpStatus.OK));
        when(objectMapper.readValue(anyString(), eq(SuccessResponse.class))).thenReturn(new SuccessResponse(NOTES_ADDED_SUCCESSFULLY));
        ResponseEntity<SuccessResponse> response = service.addDocumentRequestNotes(NWB_BRAND,null, CASE_ID, request);
        assertEquals(NOTES_ADDED_SUCCESSFULLY, response.getBody().getSuccessMessage());
        verify(restTemplate).exchange(any(),any(), any(), eq(String.class));
    }

    @Test
    void testSendReminderException() {
        DocumentNotesRequest request = createDocumentNotesRequest();
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());
        when(flowManagerRequestMapper.toFlowManagerDocumentNotesRequest(any())).thenReturn(createFlowManagerDocumentNotesRequest());
        when(restTemplate.exchange(any(),any(), any(), eq(String.class)))
                .thenThrow(HttpClientErrorException.class);
        HttpClientErrorException processFailException = assertThrows(HttpClientErrorException.class,
                () -> service.addDocumentRequestNotes(NWB_BRAND,REFERENCE_NUMBER, null,request));
        verify(restTemplate).exchange(any(),any(), any(), eq(String.class));
    }

    @Test
    void testJsonProcessingException() throws JsonProcessingException {
        DocumentNotesRequest request = createDocumentNotesRequestWithoutRequestId();
        when(authorizationService.getUserData()).thenReturn(createUserInformationResponse());
        when(flowManagerRequestMapper.toFlowManagerDocumentNotesRequest(any())).thenReturn(createFlowManagerDocumentNotesRequest());
        when(restTemplate.exchange(any(),any(), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>(NOTES_ADDED_SUCCESSFULLY, HttpStatus.OK));
        when(objectMapper.readValue(anyString(), eq(SuccessResponse.class))).thenThrow(JsonProcessingException.class);
        ResponseEntity<SuccessResponse> response = service.addDocumentRequestNotes(NWB_BRAND,null, CASE_ID, request);
        assertNull(response.getBody());
        verify(restTemplate).exchange(any(),any(), any(), eq(String.class));
    }

}
