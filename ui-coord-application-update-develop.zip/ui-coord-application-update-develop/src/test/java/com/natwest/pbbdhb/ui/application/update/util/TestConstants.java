package com.natwest.pbbdhb.ui.application.update.util;

import java.math.BigDecimal;

public class TestConstants {

    public static final String NWB_BRAND = "NWB";
    public static final String INVALID_BRAND = "NWB1";
    public static final String BRAND = "brand";
    public static final String PAYSLIPS = "Payslips";
    public static final String ADD_TASK_RESPONSE = "Task has been added successfully";
    public static final String ADD_NOTE_RESPONSE = "Note added into the database";
    public static final String DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mmXXX";
    public static final String DATE_FORMAT_YYYY_MM_DD = "yyyy-MM-dd";
    public static final String UK_TIME_ZONE = "Europe/London";
    public static final String CLOSE_TASK_RESPONSE = "Task has been closed successfully";
    public static final String TASK_NOT_ELIGIBLE = "This task is not eligible to close";
    public static final String USER_NOT_AUTHORIZED = "User not authorised to perform this action";
    public static final String USER_NOT_VALID = "User Not Valid";
    public static final String RECORD_NOT_FOUND = "Record Not Found";
    public static final String ACTION_NOT_ALLOWED = "This action is not allowed";
    public static final String CSP_VALUE = "default-src 'none'; script-src 'self'; connect-src 'self'; img-src 'self' data: http://www.w3.org/; font-src 'self'; style-src 'self' 'unsafe-inline';base-uri 'self';form-action 'self'";
    public static final String NO_CACHE = "no-cache";
    public static final String PRAGMA = "Pragma";
    public static final String CACHE_CONTROL = "Cache-control";
    public static final String CONTENT_SECURITY_POLICY = "Content-Security-Policy";
    public static final String ADD_FI_RESPONSE = "Further Information added successfully";
    public static final String INCOME_CREATED_MSG = "Income has been created successfully";
    public static final String UNPROCESSABLE_ENTITY = "This record is not able to process";

    public static final String NOTE = "Test Notes";
    public static final String REQUESTED = "REQUESTED";
    public static final String ADDED_BY_RACFID = "dcabk";
    public static final String REFERENCE_NUMBER ="84145778";
    public static final String CASE_ID = "CASEID00012";
    public static final String EXCEPTION_ID="2a6205a6-1dbb-4868-a3bb-bf4da3276399";
    public static final String SEQUENCE_NUMBER ="01";
    public static final String REQUEST_ID ="624aaa874899e7674d47c8d0";
    public static final String ADDED_FULL_NAME ="Paul Terry Baldwin";
    public static final String NOTES_ADDED_SUCCESSFULLY = "Note added successfully";
    public static final String NOTES_ADDITION_FAILED = "Note addition failed";
    public static final String PARAM_FILES = "files";
    public static final String TEST_IMAGE = "testfiles/natwest_logo.jpg";
    public static final String APPLICANT_ID ="62ff78f3c3885d5604225410";
    public static final String TRANSACTION_ID = "959e6b00c10a0bb62a953feaf930b8ca48184504";
    public static final String EXCLUDE_REASON = "excludeReason";
    public static final BigDecimal OUTSTANDING_BALANCE = BigDecimal.valueOf(10000);
    public static final BigDecimal CONSOLIDATION_AMOUNT = BigDecimal.valueOf(1000);
}