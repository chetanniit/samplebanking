package com.natwest.pbbdhb.ui.application.update.cucumber.stepdefs;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.CucumberConfigReader;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.CucumberTestProperties;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.TestEnvironment;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.config.HttpClientConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.configuration2.FileBasedConfiguration;
import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.springframework.http.HttpStatus;

import java.io.File;
import java.io.IOException;
import java.util.stream.StreamSupport;

import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.POST_UPLOAD_DOCUMENT_INPUT_JSON;
import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.Params.*;
import static io.restassured.RestAssured.given;
import static org.apache.http.params.CoreConnectionPNames.CONNECTION_TIMEOUT;
import static org.apache.http.params.CoreConnectionPNames.SO_TIMEOUT;

@Slf4j
public class PostUploadDocumentStepDefs
{
    private JsonNode inputsAsJsonNode;
    private JsonNode responseJsonNode;
    private Response response;
    private static FileBasedConfiguration prop = CucumberConfigReader.readProperties();

    @Before
    public void init() throws IOException {
        inputsAsJsonNode = ApiTestUtil.getInputsAsJsonNode(POST_UPLOAD_DOCUMENT_INPUT_JSON);
    }

    @Given("Upload Document endpoint exists")
    public void uploadDocumentEndpointExists() {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String path = inputsAsJsonNode.get(PATH).asText();
        Assertions.assertNotNull(path, "path is null");
    }

    @When("User sends request to upload Document using input {string} and verify response code")
    public void userSendsRequestToUploadDocumentUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException, InterruptedException {
        RestAssured.reset();
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String path = inputsAsJsonNode.get(PATH).asText();
        JsonNode testInput = inputsAsJsonNode.get(inputName);
        int CONNECTION_TIMEOUT_MS = 600000;

        RestAssuredConfig config = RestAssured.config()
                .httpClient(HttpClientConfig.httpClientConfig()
                        .dontReuseHttpClientInstance()
                        .setParam(CONNECTION_TIMEOUT, CONNECTION_TIMEOUT_MS)
                        .setParam(SO_TIMEOUT, CONNECTION_TIMEOUT_MS));

        RequestSpecification request = given().config(config)
                .header(MULTIPART_CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(testInput))
                .basePath(inputsAsJsonNode.get(PATH).asText());
        ApiTestUtil.createRequestForInputParams(testInput, request, path);
        setInputFiles(request, testInput.get(FORM_DATA).get(FILES));
        log.info(testInput.toString());
        response = request.post().then().extract().response();
        //log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        responseJsonNode = new ObjectMapper().readTree(response.asString());
    }

    @When("Enabling the MOPS user rights for user")
    public void enablingTheMOPSUserRightsForUser() throws JsonProcessingException {
        //AccessTokenGenerator.accessToken=null;
        TestEnvironment testEnv = CucumberTestProperties.getTestEnv();
        if (testEnv.name().equalsIgnoreCase("DEV")) {
            RequestSpecification request = RestAssured.given()
                    .log().all()
                    .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                    .accept(ContentType.JSON);
            String rights = "{\"isMCCUser\": false,\"isMopsUser\": true,\"isUWUser\": false, \"isUWLead\": false,\"isDocViewer\": false, \"isMopsDataEntry\": false, \"racfID\": \"string\", \"username\": \"string\"}";
            request.body(rights);
            response = request.post("enableMockUsers");
            Assertions.assertEquals(200, response.getStatusCode());
            Assertions.assertNotNull(response, "response is null");
        }
    }

    @When("Enabling the UW user rights for user")
    public void enablingTheUWUserRightsForUser() throws JsonProcessingException {
        //AccessTokenGenerator.accessToken=null;
        TestEnvironment testEnv = CucumberTestProperties.getTestEnv();
        if (testEnv.name().equalsIgnoreCase("DEV")) {
            RequestSpecification request = RestAssured.given()
                    .log().all()
                    .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                    .accept(ContentType.JSON);
            String rights = "{\"isMCCUser\": false,\"isMopsUser\": false,\"isUWUser\": true, \"isUWLead\": true,\"isDocViewer\": false, \"isMopsDataEntry\": false, \"racfID\": \"string\", \"username\": \"string\"}";
            request.body(rights);
            response = request.post("enableMockUsers");
            Assertions.assertEquals(200, response.getStatusCode());
            Assertions.assertNotNull(response, "response is null");
        }
    }

    @Then("Verify response code when the request payload document is too large")
    public void verifyResponseCodeWhenTheRequestPayloadDocumentIsTooLarge() {
        Assertions.assertEquals(HttpStatus.BAD_REQUEST.value(), response.getStatusCode());
    }

    @Then("Verify response code when UW user is enabled")
    public void VerifyResponseCodeWhenUWUserIsEnabled() {
        Assertions.assertEquals(String.valueOf(HttpStatus.FORBIDDEN.value()), responseJsonNode.get(RESPONSE_CODE).asText());
    }

    private void setInputFiles(RequestSpecification request,JsonNode file) {
        Assertions.assertNotNull(file,"filename is missing");
        Assertions.assertFalse(StringUtils.isEmpty(file.asText()),"filename is missing");
        String fileType = getFileType(file.asText());
        request.multiPart("file", new File(MEDIA_FILES + file.asText()),fileType);
    }

    private String getFileType(String file) {

        if(file.toUpperCase().endsWith("PNG")){
            return APPLICATION_PNG;
        }
        else if(file.toUpperCase().endsWith("DOC"))
        {
            return APPLICATION_WORD_DOC;
        }
        else if(file.toUpperCase().endsWith("JPEG"))
        {
            return APPLICATION_JPEG;
        }
        else if(file.toUpperCase().endsWith("JPG"))
        {
            return APPLICATION_JPEG;
        }
        else if(file.toUpperCase().endsWith("PPT"))
        {
            return APPLICATION_PPT;
        }
        else if(file.toUpperCase().endsWith("ZIP"))
        {
            return APPLICATION_ZIP;
        }
        else if(file.toUpperCase().endsWith("XLSX"))
        {
            return APPLICATION_XLS;
        }
        return APPLICATION_PDF;
    }

    @Then("Verify the upload document id in response using input {string}")
    public void verifyTheDocumentIdInResponseUsingInput(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        JsonNode responseFiles =responseJsonNode.get("successfulUploads");
        JsonNode files = inputs.get(FORM_DATA).get(FILES);
        StreamSupport.stream(responseFiles.spliterator(), false).forEach(responseFile -> {
            Assert.assertNotNull(responseFile.get(DOCUMENT_ID));
        });
    }


    @Then("Verify the unsupported media type for the input")
    public void verifyTheUnsupportedMediaTypeForTheInput() {
        Assert.assertEquals("HTTP/1.1 415",response.getStatusLine().trim());
    }

    @Then("Verify the upload document bad request error message using input {string}")
    public void verifyTheUploadDocumentBadRequestErrorMessageUsingInput(String inputName) {
        validateBadRequest(responseJsonNode,inputName);
    }

    @Then("Verify the precondition failed response code using input {string}")
    public void verifyThePreConditionFailedResponseCode(String inputName) {
        validatePreConditionFailure(responseJsonNode,inputName);
    }

    private void validateBadRequest(JsonNode responseJsonNode, String inputName) {
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        String[] inputErrorMessages = inputs.get(ERROR_MESSAGES).asText().split(",");
        String responseErrorMessages = responseJsonNode.get(ERROR_MESSAGES).toString();
        for (String inputErrorMessage : inputErrorMessages){
            Assert.assertTrue(responseErrorMessages.contains(inputErrorMessage));
        }
    }

    private void validatePreConditionFailure(JsonNode responseJsonNode, String inputName) {
        Assertions.assertEquals(PRECONDITION_FAILED, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        String[] inputErrorMessages = inputs.get(ERROR_MESSAGES).asText().split(",");
        String responseErrorMessages = responseJsonNode.get(ERROR_MESSAGES).toString();
        for (String inputErrorMessage : inputErrorMessages){
            Assert.assertTrue(responseErrorMessages.contains(inputErrorMessage));
        }
    }
}

