package com.natwest.pbbdhb.ui.application.update.service;

import com.natwest.pbbdhb.ui.application.update.model.dto.exception.ClosedTaskException;
import com.natwest.pbbdhb.ui.application.update.model.dto.exception.ResourceNotFoundException;
import com.natwest.pbbdhb.ui.application.update.model.dto.exception.UserNotAuthorizedException;
import com.natwest.pbbdhb.ui.application.update.model.dto.exception.UserNotValidException;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.CloseTaskRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.TaskRequest;
import com.natwest.pbbdhb.ui.application.update.service.impl.TaskServiceImpl;
import org.apache.commons.lang.StringUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.text.ParseException;
import java.util.Arrays;

import static com.natwest.pbbdhb.ui.application.update.util.TestConstants.*;
import static com.natwest.pbbdhb.ui.application.update.util.TestUtil.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.WARN)
class TaskServiceImplTest {

    @InjectMocks
    private TaskServiceImpl service;

    @Mock
    private MockDataLoader mockDataLoader;

    @Test
    void testAddTasks() throws ParseException {
        TaskRequest taskrequest = createTaskRequest();
        String response = service.addTask(NWB_BRAND,taskrequest);
        assertTrue(StringUtils.contains(response, ADD_TASK_RESPONSE));
    }

    @Test
    void testCloseTask() throws ParseException {
        CloseTaskRequest taskRequest = createCloseTaskRequest();
        String response = service.closeTask(NWB_BRAND,taskRequest);
        assertTrue(StringUtils.contains(response, CLOSE_TASK_RESPONSE));
    }

    @Test
    void testClosedTaskException() {
        CloseTaskRequest closeTaskrequest = createTaskNotEligibleToCloseTaskRequest();
        when(mockDataLoader.getClosedTask()).thenReturn(Arrays.asList("000163654561"));
        ClosedTaskException closedTaskException = assertThrows(ClosedTaskException.class,
                () -> service.closeTask(NWB_BRAND, closeTaskrequest));
        assertEquals(TASK_NOT_ELIGIBLE, getErrorMap().get(closedTaskException.getMessage()));
    }

    @Test
    void testUserNotAuthorizedToCloseTaskException() {
        CloseTaskRequest closeTaskrequest = createUserNotAuthorizedToCloseTaskRequest();
        when(mockDataLoader.getNotAuthorizedUser()).thenReturn(Arrays.asList("AKHTASJ"));
        UserNotAuthorizedException userNotAuthorizedException = assertThrows(UserNotAuthorizedException.class,
                () -> service.closeTask(NWB_BRAND, closeTaskrequest));
        assertEquals(USER_NOT_AUTHORIZED, getErrorMap().get(userNotAuthorizedException.getMessage()));
    }

    @Test
    void testUserNotValidToCloseTaskException() {
        CloseTaskRequest closeTaskrequest = createUserNotValidToCloseTaskRequest();
        when(mockDataLoader.getNotValidUser()).thenReturn(Arrays.asList("EVANSLD"));
        UserNotValidException userNotValidException = assertThrows(UserNotValidException.class,
                () -> service.closeTask(NWB_BRAND, closeTaskrequest));
        assertEquals(USER_NOT_VALID, getErrorMap().get(userNotValidException.getMessage()));
    }

    @Test
    void testRecordNotFoundToCloseTaskException() {
        CloseTaskRequest closeTaskrequest = createInvalidReferenceCloseTaskRequest();
        when(mockDataLoader.getInvalidReferenceNumber()).thenReturn(Arrays.asList("83550216"));
        ResourceNotFoundException resourceNotFoundException = assertThrows(ResourceNotFoundException.class,
                () -> service.closeTask(NWB_BRAND, closeTaskrequest));
        assertEquals(RECORD_NOT_FOUND, getErrorMap().get(resourceNotFoundException.getMessage()));
    }

    @Test
    void testUserNotAuthorizedToAddTaskException() {
        TaskRequest taskrequest = createUserNotAuthorizedToAddTaskRequest();
        when(mockDataLoader.getNotAuthorizedUser()).thenReturn(Arrays.asList("AKHTASJ"));
        UserNotAuthorizedException userNotAuthorizedException = assertThrows(UserNotAuthorizedException.class,
                () -> service.addTask(NWB_BRAND, taskrequest));
        assertEquals(USER_NOT_AUTHORIZED, getErrorMap().get(userNotAuthorizedException.getMessage()));
    }

    @Test
    void testUserNotValidToAddTaskException() {
        TaskRequest taskrequest = createUserNotValidToAddTaskRequest();
        when(mockDataLoader.getNotValidUser()).thenReturn(Arrays.asList("EVANSLD"));
        UserNotValidException userNotValidException = assertThrows(UserNotValidException.class,
                () -> service.addTask(NWB_BRAND, taskrequest));
        assertEquals(USER_NOT_VALID, getErrorMap().get(userNotValidException.getMessage()));
    }

    @Test
    void testRecordNotFoundToAddTaskException() {
        TaskRequest taskrequest = createInvalidReferenceToAddTaskRequest();
        when(mockDataLoader.getInvalidReferenceNumber()).thenReturn(Arrays.asList("83550216"));
        ResourceNotFoundException resourceNotFoundException = assertThrows(ResourceNotFoundException.class,
                () -> service.addTask(NWB_BRAND, taskrequest));
        assertEquals(RECORD_NOT_FOUND, getErrorMap().get(resourceNotFoundException.getMessage()));
    }
}