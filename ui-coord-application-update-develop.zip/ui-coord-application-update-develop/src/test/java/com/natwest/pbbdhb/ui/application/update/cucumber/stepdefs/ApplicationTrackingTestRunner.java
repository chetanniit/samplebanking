package com.natwest.pbbdhb.ui.application.update.cucumber.stepdefs;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = {"classpath:features"},
        glue = {"com.natwest.pbbdhb.ui.application.update.cucumber.stepdefs"},
        plugin = {"pretty", "html:target/cucumber-report/cucumber-reports.html", "json:target/cucumber-report/cucumber.json"},
        monochrome = true,
        //tags="@SmokeTest"

        tags="@E2EPATCH_STP_EXCEPTION_ASSIGN or @APIManualChaserCaseId or @APIManualChaserRef or @CustomFITrackingCopy or @PostTeleMessageRef or @PatchDipId or @PatchIncomeByCaseId or @PutIncomeByCaseId or @PutExpenseByCaseId or @PatchCapiePropertyInformationByCaseId or @PatchCapieCaseInformation or @PatchCapieApplicantInformationByApplicantId or @PutPropertyByCaseId or @ApplicantsApplicantId or @AddApplicationNote or @UploadDOC or @PutUpdateFIStatus or @UpdateApplicationInformation or @AddApplicationNoteCaseId or @UploadDOCCaseId or\n" +
               "@PutUpdateFIStatusCaseId or @RequestFurtherInformation or @RequestFurtherInformationCaseId or @UpdateApplicationInformationCaseId or @PutCaseByCaseId or @UploadDocument or @PatchExpenseByCaseId or @GMSChannelUpdate or @DocumentFITypeText or @PatchCapieCaseADBOInformation"


//        tags="@RBSE2EPATCH_STP_EXCEPTION_ASSIGN or @RBSAPIManualChaserCaseId or @RBSAPIManualChaserRef or @RBSCustomFITrackingCopy or @RBSPostTeleMessageRef or @RBSPatchDipId or @RBSPatchIncomeByCaseId or @RBSPutIncomeByCaseId or @RBSPutExpenseByCaseId or @RBSPatchCapiePropertyInformationByCaseId or @RBSPatchCapieCaseInformation or @RBSPatchCapieApplicantInformationByApplicantId or @RBSPutPropertyByCaseId or RBSApplicantsApplicantId or @RBSUpdateApplicationInformation or @RBSAddApplicationNote or @RBSRequestFurtherInformation or @RBSUploadDOC or " +
//             "@RBSPutUpdateFIStatus or @RBSAddApplicationNoteCaseId or @RBSPutUpdateFIStatusCaseId or @RBSUpdateApplicationInformationCaseId or @RBSUploadDOCCaseId or @RBSRequestFurtherInformationCaseId or @RBSUploadDocument or @RBSPatchExpenseByCaseId or @RBSGMSChannelUpdate or @RBSDocumentFITypeText or @RBSPatchCapieCaseADBOInformation"

        // Test suites with mocked data @AddTasks or @CloseTasks -> NWB and RBS

        // This suites takes long time for execution please don't mix with the other suites
        // Long duration NWB @PostBasicPackingNonADBO or @PostBasicPackingADBO or @E2ESTPForApplicantLevelDocument or @E2EUploadDOCLongDuration or @E2EUploadDOCCaseIdLongDuration or @AddDetailedNoteForOther or @NoteAddedDocumentReceived or @OpenAssessmentTask or @CloseAssessmentTask or @OtherBucketBehaviour or @EnhancementNotesOpen or @EnhancementNotesClose
        // Long duration RBS @RBSPostBasicPackingNonADBO or @RBSPostBasicPackingADBO or @RBSE2ESTPForApplicantLevelDocument or @RBSE2EUploadDOCLongDuration or @RBSE2EUploadDOCCaseIdLongDuration or @RBSAddDetailedNoteForOther or @RBSNoteAddedDocumentReceived or @RBSOpenAssessmentTask or @RBSCloseAssessmentTask or @RBSOtherBucketBehaviour or @RBSEnhancementNotesOpen or @RBSEnhancementNotesClose
        //tags = "@PutIncomeByCaseId" //@PutCaseByCaseId"

        // TC temporary disabled for Napoli day 1 release, please turn on after the release date
        // tags="@GMSChannelUpdate and @RBSGMSChannelUpdate"

        //TC tooks more than 70 mins hence putting for separate run
        //tags=" @E2ENONADBO or @E2EADBO or @E2ENewDBFieldGetAPI or @E2ENewDBFieldGetAPIADBO or @RBSE2ENewDBFieldGetAPI or @RBSE2ENewDBFieldGetAPIADBO"
)
public class ApplicationTrackingTestRunner {

}
