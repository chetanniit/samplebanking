package com.natwest.pbbdhb.ui.application.update.cucumber.token;

import com.natwest.pbbdhb.ui.application.update.cucumber.config.CucumberTestProperties;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.TestEnvironment;
import io.restassured.RestAssured;
import io.restassured.config.EncoderConfig;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.Assertions;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Slf4j
public class AccessTokenGenerator {

    public static String clientId = "client_staff_wiam02_HBOPostSub";
    public static String username = "HBOPostSub13";
    public static String defaultUsername = "HBOPostSub13";
    public static String password = "W$lcome$321";
    public static TestEnvironment testEnv = CucumberTestProperties.getTestEnv();
    public static String accessToken = null;

    public static String getBearerToken(String userName, String passWord, String ... externalEnvTag) {
        String externalEnvTagValue = externalEnvTag.length > 0 ? externalEnvTag[0] : "";
        TestEnvironment testEnv = CucumberTestProperties.getTestEnv(externalEnvTagValue);
        if(!(userName == null)) {
            if(!userName.equals(username)) {
                log.info("generate access token");
            } else {
                if (null != accessToken) {
                    log.info("authToken --> " + accessToken);
                    return accessToken;
                }
            }
        } else {
            userName = defaultUsername;
            if (null != accessToken) {
                log.info("authToken --> " + accessToken);
                return accessToken;
            }
        }
        Response pfzResponse = RestAssured.given()
                .config(RestAssured.config().encoderConfig(EncoderConfig.encoderConfig().appendDefaultContentCharsetToContentTypeIfUndefined(false)))
                .contentType(ContentType.fromContentType("application/x-www-form-urlencoded"))
                .queryParams(getPingRedirectQueryParams())
                .when().redirects().follow(false)
                .log().all()
                .get(testEnv.getIamUrl())
                .then()
                .log().all()
                .statusCode(302)
                .extract()
                .response();

        String pingResumeLocation = pfzResponse.getHeader("Location");

        Map<String, String> formParamMap = getPingLoginParamMap(Optional.ofNullable(userName).orElse(username), Optional.ofNullable(passWord).orElse(password));
        Response response2 = getPingPostResponse(pingResumeLocation, formParamMap, pfzResponse.getCookies());
        Response response3 = getPingPostResponse(pingResumeLocation, formParamMap, response2.getCookies());
        Response response4 = getPingPostResponse(pingResumeLocation, formParamMap, response3.getCookies());

        String authTokenLocation = response4.getHeader("Location");
        String[] auth1 = authTokenLocation.split("#access_token=");
        String[] auth2 = auth1[1].split("&");
        String authToken = auth2[0];
        log.info("authToken --> " + authToken);
        accessToken = authToken;
        username = userName;
        return accessToken;

    }

    @NotNull
    private static Map<String, String> getPingRedirectQueryParams() {
        Map<String, String> queryParamMap = new HashMap<>();
        queryParamMap.put("response_type", "token");
        queryParamMap.put("client_id", clientId);
        queryParamMap.put("redirect_uri", testEnv.getRedirectUri());
        return queryParamMap;
    }

    @NotNull
    private static Map<String, String> getPingLoginParamMap(String userName, String passWord) {
        Map<String, String> formParamMap = new HashMap<>();
        formParamMap.put("pf.username", userName);
        formParamMap.put("pf.pass", passWord);
        formParamMap.put("pf.ok", "clicked");
        formParamMap.put("pf.cancel", "");
        formParamMap.put("pf.adapterId", "test");
        return formParamMap;
    }

    private static Response getPingPostResponse(String location1, Map<String, String> formParamMap, Map<String, String> cookieMap) {
        return RestAssured.given()
                .config(RestAssured.config().encoderConfig(EncoderConfig.encoderConfig().appendDefaultContentCharsetToContentTypeIfUndefined(false)))
                .relaxedHTTPSValidation()
                .contentType(ContentType.fromContentType("application/x-www-form-urlencoded"))
                .formParams(formParamMap)
                .cookies(cookieMap)
                .when().redirects().follow(false)
                .log().all()
                .post(location1)
                .then()
                .log().all()
                .extract().response();
    }

    //    @Test
    public void testGetAccessToken() {
        String accessToken = getBearerToken("HBOPostSub13", "W$lcome$321");
        Assertions.assertNotNull(accessToken);
    }

}