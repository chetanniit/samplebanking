package com.natwest.pbbdhb.ui.application.update.cucumber.config;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.Params.*;

import com.natwest.pbbdhb.ui.application.update.cucumber.stepdefs.ApiTestUtil;
import com.natwest.pbbdhb.ui.application.update.cucumber.token.AccessTokenGenerator;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import org.apache.commons.configuration2.FileBasedConfiguration;
import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.Assertions;
import org.springframework.http.HttpHeaders;
import org.springframework.util.Assert;

import java.util.Optional;

public class CucumberTestProperties {
    private static FileBasedConfiguration prop = CucumberConfigReader.readProperties();

    public static String getTestInputPath() {
        return prop.getString("testInputPath");
    }

    public static String getTestEnvName() {
        return prop.getString("testenv");
    }

    public static String getBaseURI() {
        String baseURI;
        if(getTestEnvName().equals("NFT")) {
            baseURI = prop.getString("baseURI").replace("dev.edi01",getTestEnvName().toLowerCase()+".edi01");
        } else {
            if (getTestEnv().getIsAuthEnabled()) {
                baseURI = getTestEnv().getTykUrl();
            } else {
                baseURI = prop.getString("baseURI");
            }
        }
        return baseURI;
    }

    public static String getContentHeader() {
        return prop.getString("Content-Type");
    }

    public static TestEnvironment getTestEnv(String... externalEnvTag) {
        TestEnvironment testEnv = null;
        String testEnvProp = getTestEnvName();
        Assert.notNull(testEnvProp, "testenv is null");
        String externalEnvTagValue = externalEnvTag.length > 0 ? externalEnvTag[0] : "";
        String env = null;
        if(externalEnvTag.length > 0){
            env = externalEnvTag[0] + testEnvProp;
        } else {
            env = testEnvProp;
        }
        testEnv = TestEnvironment.valueOf(env);
        return testEnv;
    }

    @NotNull
    public static Headers getHeaders(JsonNode testInput, String... externalEnvTag) throws JsonProcessingException {
        Headers headers = new Headers();
        if (getTestEnvName().equals("NFT")) {
            Header header = new Header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppUpdate());
            headers = new Headers(header);
        } else if (getTestEnvName().equals("UAT")) {
            String externalEnvTagValue = externalEnvTag.length > 0 ? externalEnvTag[0] : "";
            if (getTestEnv().getIsAuthEnabled()) {
                String bearerToken = AccessTokenGenerator.getBearerToken(Optional.ofNullable(testInput.get("loginUserName")).map(JsonNode::asText).orElse(null), Optional.ofNullable(testInput.get("loginPassword")).map(JsonNode::asText).orElse(null), externalEnvTagValue);
                Assertions.assertNotNull(bearerToken, "bearerToken should not be null");
                Header header = new Header(HttpHeaders.AUTHORIZATION, "Bearer " + bearerToken);
                headers = new Headers(header);
            }
        }
        return headers;
    }

    public static String getBrand() {
        String brand = prop.getString("testInputPath").substring(prop.getString("testInputPath").length()-3, prop.getString("testInputPath").length());
        return brand;
    }

    public static String getServiceURI(String configURI) {
        if(getTestEnvName().equals("DEV")) {
            return prop.getString(configURI);
        }
        return prop.getString(configURI).replace("dev.edi01",getTestEnvName().toLowerCase()+".edi01");
    }

    public static String getJWTTokenForService(String serviceJWTId) throws JsonProcessingException {
        if(getTestEnvName().equals("DEV")){
            return "";
        }
        return ApiTestUtil.getJWTToken(getTestEnvName().toLowerCase(),serviceJWTId);
    }

    public static String getApplicationTrackingURI(){ return getServiceURI("applicationTrackingURI");}

    public static String getCoordApplicationTrackingURI(){ return getServiceURI("CoordApplicationTrackingURI");}

    public static String getMSVCApplicationURI() {
        return getServiceURI("msvcApplicationURI");
    }
    public static String getUICoordApplicationTracking() {
        return getServiceURI("uiCoordApplicationTrackingURI");
    }
    public static String getMSVCFlowManagerURI() {
        return getServiceURI("msvcFlowManagerURI");
    }
    public static String getCAPIEApplicantServiceURI() {
        return getServiceURI("CAPIEApplicantServiceURI");
    }
    public static String getCAPIEBrokerServiceURI() {
        return getServiceURI("CAPIEBrokerServiceURI");
    }
    public static String getIncomeServiceURI() {
        return getServiceURI("IncomeServiceURI");
    }
    public static String getRequireDocsServiceURI() {
        return getServiceURI("RequireDocsServiceURI");
    }

    public static String getCAPIEADBOServiceURI() {
        return getServiceURI("CAPIEADBOServiceURI");
    }

    public static String getCAPIEProperty() {
        return getServiceURI("CAPIEPropertyServiceURI");
    }

    public static String getintGMSEventBridge() {
        return getServiceURI("intGMSEventBridge");
    }

    public static String getJWTTokenCapieProperty() throws JsonProcessingException {
        return getJWTTokenForService("msvc-property");
    }

    public static String getMultipartContentHeader() {
        return prop.getString("MultiPart_Content-Type");
    }
    public static String getIntGMSEventBridge() { return prop.getString("intGMSEventBridge"); }

    public static String getJWTTokenURI() { return prop.getString("JWTTokenURI"); }


    public static String getJWTTokenCapieCase() throws JsonProcessingException {
        return getJWTTokenForService("msvc-case");
    }

    public static String getJWTTokenCapieApplicant() throws JsonProcessingException {
        return getJWTTokenForService("msvc-applicant");
    }

    public static String getJWTTokenCapieIncome() throws JsonProcessingException {
        return getJWTTokenForService("msvc-income-expenditure");
    }

    public static String getJWTTokenMsvcFlowManager() throws JsonProcessingException {
        return getJWTTokenForService("msvc-flow-manager");
    }

    public static String getJWTTokenMsvcApplication() throws JsonProcessingException {
        return getJWTTokenForService("app-tracking");
    }

    public static String getJWTTokenMsvcIntGmsAppTracking() throws JsonProcessingException {
        return getJWTTokenForService("int-gms-app-tracking");
    }

    public static String getJWTTokenMsvcRequireDocs() throws JsonProcessingException {
        return getJWTTokenForService("msvc-packaging-document-rules");
    }

    public static String getJWTTokenCoordAppTracking() throws JsonProcessingException {
        return getJWTTokenForService("coord-app-tracking");
    }

    public static String getJWTTokenUICoordAppTracking() throws JsonProcessingException {
        return getJWTTokenForService("uicoord-app-tracking");
    }

    public static String getJWTTokenUICoordAppUpdate() throws JsonProcessingException {
        return getJWTTokenForService("ui-coord-app-update");
    }

    public static String getJWTTokenCapieCaseADBO() throws JsonProcessingException {
        return getJWTTokenForService("msvc-case-adbo");
    }

    public static String getJWTTokenEventBridge() throws JsonProcessingException {
        return getJWTTokenForService("int-gms-event-bridge");
    }
    public static String getFileType(String file) {

        if(file.toUpperCase().endsWith("PNG")){
            return APPLICATION_PNG;
        }
        else if(file.toUpperCase().endsWith("DOC"))
        {
            return APPLICATION_WORD_DOC;
        }
        else if(file.toUpperCase().endsWith("JPEG"))
        {
            return APPLICATION_JPEG;
        }
        else if(file.toUpperCase().endsWith("JPG"))
        {
            return APPLICATION_JPEG;
        }
        else if(file.toUpperCase().endsWith("PPT"))
        {
            return APPLICATION_PPT;
        }
        else if(file.toUpperCase().endsWith("ZIP"))
        {
            return APPLICATION_ZIP;
        }
        else if(file.toUpperCase().endsWith("XLSX"))
        {
            return APPLICATION_XLS;
        }
        return APPLICATION_PDF;
    }
}


