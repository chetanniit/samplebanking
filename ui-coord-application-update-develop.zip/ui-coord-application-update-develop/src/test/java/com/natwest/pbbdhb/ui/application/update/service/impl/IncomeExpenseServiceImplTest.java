package com.natwest.pbbdhb.ui.application.update.service.impl;

import com.natwest.pbbdhb.income.expense.model.domain.CaseStatusDto;
import com.natwest.pbbdhb.income.expense.model.expense.request.CaseExpenseDto;
import com.natwest.pbbdhb.income.expense.model.expense.response.ValidatedCaseExpenseDto;
import com.natwest.pbbdhb.income.expense.model.income.request.CaseIncomeDto;
import com.natwest.pbbdhb.income.expense.model.income.response.ValidatedCaseIncomeDto;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import static com.natwest.pbbdhb.ui.application.update.util.TestConstants.NWB_BRAND;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.verify;


@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.WARN)
class IncomeExpenseServiceImplTest {

    @InjectMocks
    private IncomeExpenseServiceImpl service;

    @Mock
    private RestTemplate restTemplate;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        ReflectionTestUtils.setField(service, "msvcIncomeExpenseParentEndpoint", "https://v1-msvc-income-expenditure-dev.edi01-apps.dev-pcf.lb4.rbsgrp.net");
        ReflectionTestUtils.setField(service, "incomeEndPoint", "/income/caseId");
        ReflectionTestUtils.setField(service, "expenseEndPoint", "/expense/caseId");
    }

    @AfterEach
    void verifyAfter() {
        verifyNoMoreInteractions(restTemplate);
    }

    @Test
    void testSaveAndValidateIncomeData() {
        CaseIncomeDto request = CaseIncomeDto.builder().build();
        when(restTemplate.exchange(any(), any(), any(), eq(ValidatedCaseIncomeDto.class)))
                .thenReturn(new ResponseEntity<>(Mockito.mock(ValidatedCaseIncomeDto.class), HttpStatus.OK));
        ValidatedCaseIncomeDto response = service.saveAndValidateIncomeData(NWB_BRAND, "caseId", request);
        assertNotNull(response);
        verify(restTemplate).exchange(any(), any(), any(), eq(ValidatedCaseIncomeDto.class));
    }

    @Test
    void testSaveAndValidateIncomeDataException() {
        CaseIncomeDto request = CaseIncomeDto.builder().build();
        when(restTemplate.exchange(any(), any(), any(), eq(ValidatedCaseIncomeDto.class)))
                .thenThrow(HttpClientErrorException.class);
        HttpClientErrorException exception = assertThrows(HttpClientErrorException.class,
                () -> service.saveAndValidateIncomeData(NWB_BRAND, "caseId", request));
        verify(restTemplate).exchange(any(), any(), any(), eq(ValidatedCaseIncomeDto.class));
    }

    @Test
    void testSaveAndValidateExpenseData() {
        CaseExpenseDto request = CaseExpenseDto.builder().build();
        when(restTemplate.exchange(any(), any(), any(), eq(ValidatedCaseExpenseDto.class)))
                .thenReturn(new ResponseEntity<>(Mockito.mock(ValidatedCaseExpenseDto.class), HttpStatus.OK));
        ValidatedCaseExpenseDto response = service.saveAndValidateExpenseData(NWB_BRAND, "caseId", request);
        assertNotNull(response);
        verify(restTemplate).exchange(any(), any(), any(), eq(ValidatedCaseExpenseDto.class));
    }

    @Test
    void testSaveAndValidateExpenseDataException() {
        CaseExpenseDto request = CaseExpenseDto.builder().build();
        when(restTemplate.exchange(any(), any(), any(), eq(ValidatedCaseExpenseDto.class)))
                .thenThrow(HttpClientErrorException.class);
        HttpClientErrorException exception = assertThrows(HttpClientErrorException.class,
                () -> service.saveAndValidateExpenseData(NWB_BRAND, "caseId", request));
        verify(restTemplate).exchange(any(), any(), any(), eq(ValidatedCaseExpenseDto.class));
    }

    @Test
    void testMarkExpenseValidated() {
        CaseStatusDto request = CaseStatusDto.builder().build();
        when(restTemplate.exchange(any(), any(), any(), eq(ValidatedCaseExpenseDto.class)))
                .thenReturn(new ResponseEntity<>(Mockito.mock(ValidatedCaseExpenseDto.class), HttpStatus.OK));
        ValidatedCaseExpenseDto response = service.markExpenseValidated(NWB_BRAND, "caseId", request);
        assertNotNull(response);
        verify(restTemplate).exchange(any(), any(), any(), eq(ValidatedCaseExpenseDto.class));
    }

    @Test
    void testMarkIncomeValidated() {
        CaseStatusDto request = CaseStatusDto.builder().build();
        when(restTemplate.exchange(any(), any(), any(), eq(ValidatedCaseIncomeDto.class)))
                .thenReturn(new ResponseEntity<>(Mockito.mock(ValidatedCaseIncomeDto.class), HttpStatus.OK));
        ValidatedCaseIncomeDto response = service.markIncomeValidated(NWB_BRAND, "caseId", request);
        assertNotNull(response);
        verify(restTemplate).exchange(any(), any(), any(), eq(ValidatedCaseIncomeDto.class));
    }
}