package com.natwest.pbbdhb.ui.application.update.cucumber.stepdefs;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.CucumberTestProperties;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;

import java.io.IOException;
import java.util.ArrayList;


import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.PUT_UPDATE_PROPERTY_CASE_ID_JSON;
import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.Params.*;

@Slf4j
public class UpdatePropertyByCaseIdStepDefs {

    private JsonNode inputsAsJsonNode;
    private JsonNode responseJsonNode;
    private String responseString;
    private Response response;
    private String propertyVersion;

    @Before
    public void init() throws IOException {
        inputsAsJsonNode = ApiTestUtil.getInputsAsJsonNode(PUT_UPDATE_PROPERTY_CASE_ID_JSON);
    }

    @Given("UpdatePropertyInformation Service case id endpoint exists")
    public void updatePropertyInformationServiceCaseIdEndpointExists() {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String path = inputsAsJsonNode.get(PATH).asText();
        Assertions.assertNotNull(path, "path is null");
    }

    private void validateBadRequest(String inputName) throws JsonProcessingException {
        JsonNode responseJsonNode = new ObjectMapper().readTree(response.asString());
        if(responseJsonNode.get(RESPONSE_STATUS) == null){
            JsonNode inputs = inputsAsJsonNode.get(inputName);
            JsonNode error_message_Array = responseJsonNode.get(ERRORS).get(0).get(MESSAGE);
            Assertions.assertTrue(error_message_Array.asText().contains(inputs.get(ERROR_MESSAGES).asText()));
        }else{
            Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
            JsonNode inputs = inputsAsJsonNode.get(inputName);
            validateResponseErrorContains(responseJsonNode, inputs.get(ERROR_MESSAGES));
        }

    }

    private void validateNotFound(JsonNode responseJsonNode, String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals("NOT_FOUND", responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode error_message_Array = responseJsonNode.get(ERROR_MESSAGE).get(0);
        Assertions.assertTrue(error_message_Array.asText().contains(inputs.get(ERROR_MESSAGE).asText()));
    }

    private void validateResponseErrorContains(JsonNode inputs, JsonNode itemSearched) {
        validateArrayContains(inputs, itemSearched, ERROR_MESSAGES);
    }

    private void validateArrayContains(JsonNode array, JsonNode itemSearched, String inputField) {
        ArrayList<String> predefined = new ObjectMapper().convertValue(array.get(inputField), ArrayList.class);
        predefined.forEach(s -> Assertions.assertTrue(itemSearched.asText().contains(s)));
    }


    @When("UpdatePropertyInformation - User sends case id request to put property information using input {string} and verify response code")
    public void updatePropertyInformationByCaseId(String inputName) throws JsonProcessingException {
        String path = inputsAsJsonNode.get(PATH).asText();
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .accept(ContentType.JSON);
        JsonNode testInput = inputsAsJsonNode.get(inputName);
        if(CucumberTestProperties.getTestEnvName().equals("UAT")){
            testInput = (inputsAsJsonNode.get(inputName+"UAT") != null ) ? inputsAsJsonNode.get(inputName+"UAT") : testInput;
        }
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        if(propertyVersion == null){
            propertyVersion = testInput.get(REQUEST_BODY).get(VERSION).asText();
        }
        doc.set("requestBody.version", propertyVersion);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        Assertions.assertNotNull(updatedInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, path);
        response = request.headers(CucumberTestProperties.getHeaders(updatedInput)).put(inputsAsJsonNode.get(PATH).asText());
        System.out.println("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @When("UpdatePropertyInformation - User sends case id request to get property information using input {string} and verify response code")
    public void getPropertyInformationByCaseId(String inputName) throws JsonProcessingException {
        String path = inputsAsJsonNode.get(PATH).asText();
        RestAssured.baseURI = CucumberTestProperties.getApplicationTrackingURI();
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        JsonNode testInput = inputsAsJsonNode.get(inputName);
        if(CucumberTestProperties.getTestEnvName().equals("UAT")){
            testInput = (inputsAsJsonNode.get(inputName+"UAT") != null ) ? inputsAsJsonNode.get(inputName+"UAT") : testInput;
        }
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(testInput, request, path);
        response = request.headers(CucumberTestProperties.getHeaders(testInput)).get(inputsAsJsonNode.get(PATH).asText());
        System.out.println("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        propertyVersion = responseJsonNode.get(VERSION).asText();
    }

    @Then("Verify property information in Put property case id response output for the input {string}")
    public void verifyPropertySuccessfulResponse(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertNotNull(response, "response is null");
        Assertions.assertEquals(200, response.getStatusCode());

        if(StringUtils.equals(inputs.get("brand").asText(), "RBS")) {
            if (CucumberTestProperties.getTestEnvName().equals("UAT")) {
                Assert.assertEquals("CPKJ1667905840954", responseJsonNode.get("caseId").asText());
            } else {
                Assert.assertEquals("110222105061932438", responseJsonNode.get("caseId").asText());
            }
        } else {
            if (CucumberTestProperties.getTestEnvName().equals("UAT")) {
                Assert.assertEquals("CPKJ1667905840954", responseJsonNode.get("caseId").asText());
            } else {
                Assert.assertEquals("220222105061932438", responseJsonNode.get("caseId").asText());
            }
        }

        Assert.assertTrue(responseJsonNode.get("nhbcCertificate").booleanValue());
        Assert.assertTrue(responseJsonNode.get("consentToShareDetailsWithSurveyProvider").booleanValue());


        JsonNode valuationDetails = responseJsonNode.get("valuation");
        Assert.assertEquals("KERBSIDE_VALUATION", valuationDetails.get("type").asText());

        JsonNode addressDetails = responseJsonNode.get("address");
        Assert.assertEquals("8", addressDetails.get("flat").asText());
        Assert.assertEquals("33", addressDetails.get("houseNumber").asText());
    }


    @Then("Verify error code 404 Not Found for the UI Coord Application Update Property service response for the input {string}")
    public void verifyPropertyNotFoundResponse(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.body().asString());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertNotNull(response, "response is null");
        Assertions.assertEquals(404, response.getStatusCode());
        JsonNode error_message_Array = responseJsonNode.get(ERRORS).get(0).get(MESSAGE);
        Assertions.assertTrue(error_message_Array.asText().contains(inputs.get(ERROR_MESSAGES).asText()));
    }

    @Then("Verify error code 400 bad request for the UI Coord Application Update Property service response for the input {string}")
    public void verifyPropertyBadRequestResponse(String inputName) throws JsonProcessingException {
        validateBadRequest(inputName);
    }

    @Then("Verify property information valuation details in Put property case id response output for the input {string}")
    public void verifyPropertyValuationDetailsSuccessfulResponse(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertNotNull(response, "response is null");
        Assertions.assertEquals(200, response.getStatusCode());

        if(StringUtils.equals(inputs.get("brand").asText(), "RBS")) {
            if (CucumberTestProperties.getTestEnvName().equals("UAT")) {
                Assert.assertEquals("CPKJ1667905840954", responseJsonNode.get("caseId").asText());
            } else {
                Assert.assertEquals("110222105061932438", responseJsonNode.get("caseId").asText());
            }
        } else {
            if (CucumberTestProperties.getTestEnvName().equals("UAT")) {
                Assert.assertEquals("CPKJ1667905840954", responseJsonNode.get("caseId").asText());
            } else {
                Assert.assertEquals("220222105061932438", responseJsonNode.get("caseId").asText());
            }
        }
        Assert.assertTrue(responseJsonNode.get("nhbcCertificate").booleanValue());
        Assert.assertTrue(responseJsonNode.get("consentToShareDetailsWithSurveyProvider").booleanValue());


        JsonNode valuationDetails = responseJsonNode.get("valuation");
        Assert.assertEquals("KERBSIDE_VALUATION", valuationDetails.get("type").asText());
        Assert.assertEquals("1994-05-09", valuationDetails.get("date").asText());
        Assert.assertEquals("new firm", valuationDetails.get("firmName").asText());
        Assert.assertTrue(valuationDetails.get("received").asBoolean());
        Assert.assertEquals("20.23", valuationDetails.get("amount").asText());

        JsonNode addressDetails = responseJsonNode.get("address");
        Assert.assertEquals("8", addressDetails.get("flat").asText());
        Assert.assertEquals("33", addressDetails.get("houseNumber").asText());
    }
}
