package com.natwest.pbbdhb.ui.application.update.cucumber.stepdefs;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.CucumberTestProperties;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;

import java.io.IOException;
import java.util.ArrayList;


import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.PATCH_APPLICANT_APPLICANT_ID_JSON;
import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.Params.*;

@Slf4j
public class PatchCapieApplicantInformationApplicantIdStepDefs {

    private JsonNode inputsAsJsonNode;
    private JsonNode responseJsonNode;
    private Response response;

    @Before
    public void init() throws IOException {
        inputsAsJsonNode = ApiTestUtil.getInputsAsJsonNode(PATCH_APPLICANT_APPLICANT_ID_JSON);
    }

    @Given("PatchCapieApplicantInformation Service applicant id endpoint exists")
    public void patchCapieApplicantInformationServiceApplicantIdEndpointExists() {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String path = inputsAsJsonNode.get(PATH).asText();
        Assertions.assertNotNull(path, "path is null");
    }

    private void validateBadRequest(String inputName) throws JsonProcessingException {
        JsonNode responseJsonNode = new ObjectMapper().readTree(response.asString());
        if(responseJsonNode.get(RESPONSE_STATUS) == null){
            JsonNode inputs = inputsAsJsonNode.get(inputName);
            JsonNode error_message_Array = responseJsonNode.get(ERRORS).get(0).get(MESSAGE);
            Assertions.assertTrue(error_message_Array.asText().contains(inputs.get(ERROR_MESSAGES).asText()));
        }else{
            Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
            JsonNode inputs = inputsAsJsonNode.get(inputName);
            validateResponseErrorContains(responseJsonNode, inputs.get(ERROR_MESSAGES));
        }

    }

    private void validateNotFound(JsonNode responseJsonNode, String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals("NOT_FOUND", responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode error_message_Array = responseJsonNode.get(ERROR_MESSAGE).get(0);
        Assertions.assertTrue(error_message_Array.asText().contains(inputs.get(ERROR_MESSAGE).asText()));
    }

    private void validateResponseErrorContains(JsonNode inputs, JsonNode itemSearched) {
        validateArrayContains(inputs, itemSearched, ERROR_MESSAGES);
    }

    private void validateArrayContains(JsonNode array, JsonNode itemSearched, String inputField) {
        ArrayList<String> predefined = new ObjectMapper().convertValue(array.get(inputField), ArrayList.class);
        Assertions.assertTrue(predefined.contains(itemSearched.asText()));
    }


    @When("PatchCapieApplicantInformation - User sends applicant id request to patch applicant information using input {string} and verify response code")
    public void patchCapieApplicantInformationUserSendsApplicantIdRequestToPatchApplicantInformationUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        String path = inputsAsJsonNode.get(PATH).asText();
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, "application/json-patch+json")
                .accept(ContentType.JSON);
        JsonNode testInput = inputsAsJsonNode.get(inputName);
        if(CucumberTestProperties.getTestEnvName().equals("UAT")){
            testInput = (inputsAsJsonNode.get(inputName+"UAT") != null ) ? inputsAsJsonNode.get(inputName+"UAT") : testInput;
        }
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(testInput, request, path);
        response = request.headers(CucumberTestProperties.getHeaders(testInput)).patch(inputsAsJsonNode.get(PATH).asText());
        System.out.println("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
    }

    @Then("Verify applicant information in patch Applicant response output for the input {string}")
    public void verifyApplicantInformationInpatchApplicantResponseOutputForTheInput(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode input = inputsAsJsonNode.get(inputName);
        Assertions.assertNotNull(response, "response is null");
        Assertions.assertEquals(input.get("responseCode").asInt(), response.getStatusCode());
        Assert.assertEquals("cin12345", responseJsonNode.get("cin").asText());
    }

    @Then("Verify error code 404 Not Found for the UI Coord Application patch applicant service response for the input {string}")
    public void verifyPatchApplicantByApplicantIdNotFoundResponse(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.body().asString());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertNotNull(response, "response is null");
        Assertions.assertEquals(404, response.getStatusCode());
        JsonNode error_message_Array = responseJsonNode.get(ERRORS).get(0).get(MESSAGE);
        Assertions.assertTrue(error_message_Array.asText().contains(inputs.get(ERROR_MESSAGES).asText()));
    }

    @Then("Verify error code 400 bad request for the UI Coord Application patch applicant service response for the input {string}")
    public void verifyPatchApplicantByApplicantIdBadRequestResponse(String inputName) throws JsonProcessingException {
        validateBadRequest(inputName);
    }
}
