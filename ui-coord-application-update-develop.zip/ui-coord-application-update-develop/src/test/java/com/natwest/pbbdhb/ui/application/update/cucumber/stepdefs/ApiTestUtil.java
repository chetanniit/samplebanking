package com.natwest.pbbdhb.ui.application.update.cucumber.stepdefs;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.CucumberConfigReader;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.CucumberTestProperties;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.commons.configuration2.FileBasedConfiguration;
import org.junit.jupiter.api.Assertions;

import java.io.File;
import java.io.IOException;

import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.Params.*;
import static com.natwest.pbbdhb.ui.application.update.cucumber.config.CucumberTestProperties.getTestInputPath;

public class ApiTestUtil {
    private static FileBasedConfiguration prop = CucumberConfigReader.readProperties();

    public static JsonNode getInputsAsJsonNode(String inputFileName) throws IOException {
        String testInputPath = getTestInputPath();
        Assertions.assertNotNull(testInputPath, ApiTestConstants.Errors.TEST_INPUT_PATH_IS_NULL);
        String inputFilePath = testInputPath.concat(inputFileName);
        JsonNode inputsAsJsonNode = new ObjectMapper().readTree(new File(inputFilePath));
        Assertions.assertNotNull(inputsAsJsonNode, String.format(ApiTestConstants.Errors.INPUTS_MISSING_FOR, inputsAsJsonNode.get(PATH).asText()));
        return inputsAsJsonNode;
    }
    public static void createRequestForInputParams(JsonNode testInput, RequestSpecification request, String path) {

        JsonNode brand = testInput.get(BRAND);
        if (brand != null && !"null".equals(brand.asText())) {
            request.header(BRAND, brand.asText());
        }else{
            JsonNode isSkipBrandNode = testInput.get(IS_SKIP_BRAND);
            boolean isSkipBrand = false;
            if(isSkipBrandNode != null){
                isSkipBrand = isSkipBrandNode.asBoolean(false);
            }
            if(!isSkipBrand){
                request.header(BRAND, CucumberTestProperties.getBrand());
            }
       }
        JsonNode referenceNumber = testInput.get(REFERENCE_NUMBER);
        if (referenceNumber != null && !"null".equals(referenceNumber.asText())) {
            if(path.contains(REFERENCE_NUMBER)){
                request.pathParam(REFERENCE_NUMBER, referenceNumber.asText());
            }else {
                request.queryParam(REFERENCE_NUMBER, referenceNumber.asText());
            }
        }
        JsonNode caseId = testInput.get(CASE_ID);
        if (caseId != null && !"null".equals(caseId.asText())) {
            if(path.contains(CASE_ID)){
                request.pathParam(CASE_ID, caseId.asText());
            }else {
                request.queryParam(CASE_ID, caseId.asText());
            }
        }

        JsonNode dipId = testInput.get(DIP_ID);
        if (dipId != null && !"null".equals(dipId.asText())) {
            if(path.contains(DIP_ID)){
                request.pathParam(DIP_ID, dipId.asText());
            }else {
                request.queryParam(DIP_ID, dipId.asText());
            }
        }

        JsonNode exceptionId = testInput.get(EXCEPTION_ID);
        if (exceptionId != null && !"null".equals(exceptionId.asText())) {
            if(path.contains(EXCEPTION_ID)){
                request.pathParam(EXCEPTION_ID, exceptionId.asText());
            }else {
                request.queryParam(EXCEPTION_ID, exceptionId.asText());
            }
        }

        JsonNode reviewId = testInput.get("reviewId");
        if (reviewId != null && !"null".equals(reviewId.asText())) {
            if(path.contains("reviewId")){
                request.pathParam("reviewId", reviewId.asText());
            }else {
                request.queryParam("reviewId", reviewId.asText());
            }
        }

        JsonNode documentId = testInput.get(DOCUMENT_ID);
        if (documentId != null && !"null".equals(documentId.asText())) {
            if(path.contains(DOCUMENT_ID)){
                request.pathParam(DOCUMENT_ID, documentId.asText());
            } else {
                request.queryParam(DOCUMENT_ID, documentId.asText());
            }
        }
        JsonNode applicantID = testInput.get(APPLICANT_ID);
        if (applicantID != null && !"null".equals(applicantID.asText())) {
            if (path.contains(APPLICANT_ID)) {
                request.pathParam(APPLICANT_ID, applicantID.asText());
            } else {
                request.queryParam(APPLICANT_ID, applicantID.asText());
            }
        }
        JsonNode applicationLevel = testInput.get(APPLICATION_LEVEL);
        if (applicationLevel != null && !"null".equals(applicationLevel.asText())) {
            if (path.contains(APPLICATION_LEVEL)) {
                request.pathParam(APPLICATION_LEVEL, applicationLevel.asBoolean());
            } else {
                request.queryParam(APPLICATION_LEVEL, applicationLevel.asBoolean());
            }
        }
        JsonNode firequestId= testInput.get(FIREQUEST_ID);
        if (firequestId != null && !"null".equals(firequestId.asText())) {
            if(path.contains(FIREQUEST_ID)){
                request.pathParam(FIREQUEST_ID, firequestId.asText());
            }else {
                request.queryParam(FIREQUEST_ID, firequestId.asText());
            }
        }

        JsonNode firequestIds= testInput.get(FIREQUEST_IDS);
        if (firequestIds != null && !"null".equals(firequestIds.asText())) {
            if(path.contains(FIREQUEST_IDS)){
                request.pathParam(FIREQUEST_IDS, firequestIds.asText());
            }else {
                request.queryParam(FIREQUEST_IDS, firequestIds.asText());
            }
        }

        JsonNode requestId1= testInput.get(REQUEST_ID);
        if (requestId1!= null && !"null".equals(requestId1.asText())) {
            if(path.contains(REQUEST_ID)){
                request.pathParam(REQUEST_ID, requestId1.asText());
            }else {
                request.queryParam(REQUEST_ID, requestId1.asText());
            }
        }

        JsonNode brokerEmailId = testInput.get("brokerEmailId");
        if (brokerEmailId != null && !"null".equals(brokerEmailId.asText())) {
            request.queryParam("brokerEmailId", brokerEmailId.asText());
        }

        JsonNode brokerFirstName = testInput.get("brokerFirstName");
        if (brokerFirstName != null && !"null".equals(brokerFirstName.asText())) {
            request.queryParam("brokerFirstName", brokerFirstName.asText());
        }

        JsonNode brokerLastName = testInput.get("brokerLastName");
        if (brokerLastName != null && !"null".equals(brokerLastName.asText())) {
            request.queryParam("brokerLastName", brokerLastName.asText());
        }

        JsonNode brokerPostcode = testInput.get("brokerPostcode");
        if (brokerPostcode != null && !"null".equals(brokerPostcode.asText())) {
            request.queryParam("brokerPostcode", brokerPostcode.asText());
        }

        JsonNode fcaNumber = testInput.get("fcaNumber");
        if (fcaNumber != null && !"null".equals(fcaNumber.asText())) {
            request.queryParam("fcaNumber", fcaNumber.asText());
        }

        JsonNode firmPostcode = testInput.get("firmPostcode");
        if (firmPostcode != null && !"null".equals(firmPostcode.asText())) {
            request.queryParam("firmPostcode", firmPostcode.asText());
        }

        JsonNode loanPurpose1 = testInput.get(LOAN_PURPOSE);
        if (loanPurpose1 != null && !"null".equals(loanPurpose1.asText())) {
            if (path.contains(LOAN_PURPOSE)) {
                request.pathParam(LOAN_PURPOSE, loanPurpose1.asText());
            } else {
                request.queryParam(LOAN_PURPOSE, loanPurpose1.asText());
            }
        }





        if (testInput.has(FORM_DATA)){
            JsonNode applicantId = testInput.get(FORM_DATA).get(APPLICANT_ID);
            if (applicantId != null && !"null".equals(applicantId.asText())) {
                request.formParam(APPLICANT_ID, applicantId.asText());
            }
            JsonNode requestId = testInput.get(FORM_DATA).get(REQUEST_ID);
            if (requestId != null && !"null".equals(requestId.asText())) {
                request.formParam(REQUEST_ID, requestId.asText());
            }
            JsonNode channel = testInput.get(FORM_DATA).get(CHANNEL_ID);
            if (channel != null && !"null".equals(channel.asText())) {
                request.formParam(CHANNEL_ID, channel.asText());
            }
            JsonNode main_applicant = testInput.get(MAIN_APPLICANT);
            if (main_applicant != null && !"null".equals(main_applicant.asText())) {
                request.queryParam(MAIN_APPLICANT, main_applicant.asText());
            }
            JsonNode classificationCode = testInput.get(FORM_DATA).get(CLASSIFICATION_CODE);
            if (classificationCode != null && !"null".equals(classificationCode.asText())) {
                request.formParam(CLASSIFICATION_CODE, classificationCode.asText());
            }

            JsonNode documentType = testInput.get(FORM_DATA).get(DOCUMENT_TYPE);
            if (documentType != null && !"null".equals(documentType.asText())) {
                request.formParam(DOCUMENT_TYPE, documentType.asText());
            }
            
            JsonNode loanPurpose = testInput.get(FORM_DATA).get(LOAN_PURPOSE);
            if (loanPurpose != null && !"null".equals(loanPurpose.asText())) {
                request.formParam(LOAN_PURPOSE, loanPurpose.asText());
            }
        }
        JsonNode channel = testInput.get(CHANNEL);
        if (channel != null && !"null".equals(channel.asText())) {
            if(path.contains(CHANNEL)){
                request.pathParam(CHANNEL, channel.asText());
            } else {
                request.queryParam(CHANNEL, channel.asText());
            }
        }
        JsonNode kafkaTopic = testInput.get(KAFKA_TOPIC);
        if (kafkaTopic != null && !"null".equals(kafkaTopic.asText())) {
            if(path.contains(KAFKA_TOPIC)){
                request.pathParam(KAFKA_TOPIC, kafkaTopic.asText());
            } else {
                request.queryParam(KAFKA_TOPIC, kafkaTopic.asText());
            }
        }
        JsonNode category = testInput.get(CATEGORY);
        if (category != null && !"null".equals(category.asText())) {
            request.queryParam(CATEGORY, category.asText());
        }
        JsonNode user = testInput.get(USER);
        if (user != null && !"null".equals(user.asText())) {
            request.queryParam(USER, user.asText());
        }
       JsonNode postRequestField = testInput.get(REQUEST_BODY);
        if (postRequestField != null && !"null".equals(postRequestField.asText())) {
            request.body(postRequestField);
        }
        JsonNode application_id = testInput.get(APPLICATION_ID);
        if (application_id != null && !"null".equals(application_id.asText())) {
            request.queryParam(APPLICATION_ID, application_id.asText());
        }
        JsonNode channel_id = testInput.get(CHANNEL_ID);
        if (channel_id != null && !"null".equals(channel_id.asText())) {
            request.queryParam(CHANNEL_ID, channel_id.asText());
        }
        JsonNode files = testInput.get(FILES);
        if (files != null && !"null".equals(files.asText())) {
            request.queryParam(FILES, files.asText());
        }

        JsonNode status = testInput.get(STATUS);
        if (status != null && !"null".equals(status.asText())) {
            if(path.contains(STATUS)){
                request.pathParam(STATUS, status.asText());
            }else {
                request.queryParam(STATUS, status.asText());
            }
        }
        JsonNode state = testInput.get(STATE);
        if (state != null && !"null".equals(state.asText())) {
            if(path.contains(STATE)){
                request.pathParam(STATE, state.asText());
            }else {
                request.queryParam(STATE, state.asText());
            }
        }
        JsonNode taskStatus = testInput.get(TASK_STATUS);
        if (taskStatus != null && !"null".equals(taskStatus.asText())) {
            if(path.contains(TASK_STATUS)){
                request.pathParam(TASK_STATUS, taskStatus.asText());
            }else {
                request.queryParam(TASK_STATUS, taskStatus.asText());
            }
        }

        JsonNode taskCode = testInput.get(TASK_CODE);
        if (taskCode != null && !"null".equals(taskCode.asText())) {
            request.queryParam(TASK_CODE, taskCode.asText());
        }
    }

    public static void createReqPathForInputParams(JsonNode testInput, RequestSpecification request) {

        JsonNode brand = testInput.get(BRAND);
        if (brand != null && !"null".equals(brand.asText())) {
            request.header(BRAND, brand.asText());
        }
        JsonNode category = testInput.get(CATEGORY);
        if (category != null && !"null".equals(category.asText())) {
            request.queryParam(CATEGORY, category.asText());
        }
        JsonNode user = testInput.get(USER);
        if (user != null && !"null".equals(user.asText())) {
            request.queryParam(USER, user.asText());
        }
        JsonNode postRequestField = testInput.get(REQUEST_BODY);
        if (postRequestField != null && !"null".equals(postRequestField.asText())) {
            request.body(postRequestField);
        }
        JsonNode referenceNumber = testInput.get(REFERENCE_NUMBER);
        if (referenceNumber != null && !"null".equals(referenceNumber.asText())) {
            request.queryParam(REFERENCE_NUMBER, referenceNumber.asText());
        }
        JsonNode sequenceNumber = testInput.get(SEQUENCE_NUMBER);
        if (sequenceNumber != null && !"null".equals(sequenceNumber.asText())) {
            request.queryParam(SEQUENCE_NUMBER,sequenceNumber.asText());
        }
        JsonNode caseId = testInput.get(CASE_ID);
        if (caseId != null && !"null".equals(caseId.asText())) {
            request.queryParam(CASE_ID,caseId.asText());
        }
        JsonNode application_id = testInput.get(APPLICATION_ID);
        if (application_id != null && !"null".equals(application_id.asText())) {
            request.queryParam(APPLICATION_ID, application_id.asText());
        }
        JsonNode channel_id = testInput.get(CHANNEL_ID);
        if (channel_id != null && !"null".equals(channel_id.asText())) {
            request.queryParam(CHANNEL_ID, channel_id.asText());
        }
        JsonNode files = testInput.get(FILES);
        if (files != null && !"null".equals(files.asText())) {
            request.queryParam(FILES, files.asText());
        }
        JsonNode applicantID = testInput.get(APPLICANT_ID);
        if (applicantID != null && !"null".equals(applicantID.asText())) {
            request.queryParam(APPLICANT_ID,applicantID.asText());
        }
        JsonNode requestId = testInput.get(REQUEST_ID);
        if (requestId != null && !"null".equals(requestId.asText())) {
            request.pathParam(REQUEST_ID,requestId.asText());
        }
    }

    public static String getJWTToken(String environment, String serviceName) throws JsonProcessingException {
        String testInput = "{"+
                "  \"serviceBeingTested\": \""+serviceName+"\"," +
                "  \"expiryInMinutes\": 60," +
                "  \"isMSGenerated\": false" +
                "}";

        RestAssured.baseURI = CucumberTestProperties.getJWTTokenURI().replace("<environment>", environment);
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, "application/json")
                .accept("*/*")
                .body(testInput);
        System.out.println(testInput);
        Response response = request.post();
        return (new ObjectMapper().readTree(response.asString())).get("iam-claimsetjwt").asText();
    }
}
