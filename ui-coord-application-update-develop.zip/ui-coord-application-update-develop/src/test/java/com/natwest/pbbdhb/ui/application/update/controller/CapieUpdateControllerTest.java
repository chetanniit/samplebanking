package com.natwest.pbbdhb.ui.application.update.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.ui.application.update.service.auth.impl.AuthorizationServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static com.natwest.pbbdhb.ui.application.update.converter.JsonPatchHttpMessageConverter.JSON_PATCH;
import static com.natwest.pbbdhb.ui.application.update.util.TestConstants.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(value = CapieUpdateController.class, properties = {"spring.profiles.active=test"})
@DisplayName("CapieUpdateControllerTest - MVC Test")
public class CapieUpdateControllerTest {

    public static final String NWB_BRAND = "NWB";
    public static final String CASE_ID = "CASE220222105061932438";

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CapieUpdateController capieUpdateController;

    @MockBean(name = "authorizationServiceImpl")
    private AuthorizationServiceImpl authorizationServiceImpl;

    @Autowired
    private ObjectMapper objectMapper;


    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void TestPatchADBOCaseByCaseIdSuccess() throws Exception {
        String jsonString = "[{\"op\": \"replace\", \"path\": \"/loanPurpose\", \"value\": \"ADDITIONAL_BORROWING\" }]";
        MvcResult result =
                mockMvc.perform(
                                patch("/capie/case-adbo/" + CASE_ID)
                                        .header(BRAND, NWB_BRAND)
                                        .contentType(JSON_PATCH)
                                        .content(jsonString)
                        )
                        .andExpect(status().isOk())
                        .andReturn();

        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
        assertEquals(200, result.getResponse().getStatus());
    }

    @Test
    void TestPatchADBOCaseByCaseIdFailedForInvalidCaseId() throws Exception {
        MvcResult result =
                mockMvc.perform(
                                patch("/capie/case-adbo/" + "@CASE220222105061932438")
                                        .header(BRAND, NWB_BRAND)
                                        .contentType(JSON_PATCH)
                        )
                        .andExpect(status().isBadRequest())
                        .andReturn();

        assertEquals(400, result.getResponse().getStatus());
    }

    @Test
    void TestPatchADBOCaseByCaseIdFailedForInvalidBrand() throws Exception {
        MvcResult result =
                mockMvc.perform(
                                patch("/capie/case-adbo/" + CASE_ID)
                                        .header(BRAND, INVALID_BRAND)
                                        .contentType(JSON_PATCH)
                        )
                        .andExpect(status().isBadRequest())
                        .andReturn();

        assertEquals(400, result.getResponse().getStatus());
    }

}
