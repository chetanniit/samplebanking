package com.natwest.pbbdhb.ui.application.update.cucumber.stepdefs;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.CucumberTestProperties;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;

import java.io.IOException;
import java.util.ArrayList;

import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.PATCH_PROPERTY_CASE_ID_JSON;
import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.Params.*;

@Slf4j
public class PatchCapiePropertyInformationCaseIdStepDefs {

    private JsonNode inputsAsJsonNode;
    private JsonNode responseJsonNode;
    private Response response;

    @Before
    public void init() throws IOException {
        inputsAsJsonNode = ApiTestUtil.getInputsAsJsonNode(PATCH_PROPERTY_CASE_ID_JSON);
    }

    @Given("PatchCapiePropertyInformation Service case id endpoint exists")
    public void patchCapiePropertyInformationServiceCaseIdEndpointExists() {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String path = inputsAsJsonNode.get(PATH).asText();
        Assertions.assertNotNull(path, "path is null");
    }

    private void validateBadRequest(String inputName) throws JsonProcessingException {
        JsonNode responseJsonNode = new ObjectMapper().readTree(response.asString());
        if(responseJsonNode.get(RESPONSE_STATUS) == null){
            JsonNode inputs = inputsAsJsonNode.get(inputName);
            JsonNode error_message_Array = responseJsonNode.get(ERRORS).get(0).get(MESSAGE);
            Assertions.assertTrue(error_message_Array.asText().contains(inputs.get(ERROR_MESSAGES).asText()));
        }else{
            Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
            JsonNode inputs = inputsAsJsonNode.get(inputName);
            validateResponseErrorContains(responseJsonNode, inputs.get(ERROR_MESSAGES));
        }

    }

    private void validateNotFound(JsonNode responseJsonNode, String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals("NOT_FOUND", responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode error_message_Array = responseJsonNode.get(ERROR_MESSAGE).get(0);
        Assertions.assertTrue(error_message_Array.asText().contains(inputs.get(ERROR_MESSAGE).asText()));
    }

    private void validateResponseErrorContains(JsonNode inputs, JsonNode itemSearched) {
        validateArrayContains(inputs, itemSearched, ERROR_MESSAGES);
    }

    private void validateArrayContains(JsonNode array, JsonNode itemSearched, String inputField) {
        ArrayList<String> predefined = new ObjectMapper().convertValue(array.get(inputField), ArrayList.class);
        predefined.forEach(s -> Assertions.assertTrue(itemSearched.asText().contains(s)));
    }


    @When("PatchCapiePropertyInformation - User sends case id request to patch property information using input {string} and verify response code")
    public void patchCapiePropertyInformationUserSendsCaseIdRequestToPatchPropertyInformationUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        String path = inputsAsJsonNode.get(PATH).asText();
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        JsonNode testInput = inputsAsJsonNode.get(inputName);
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, "application/json-patch+json")
                .accept(ContentType.JSON);
        if(CucumberTestProperties.getTestEnvName().equals("UAT")){
            testInput = (inputsAsJsonNode.get(inputName+"UAT") != null ) ? inputsAsJsonNode.get(inputName+"UAT") : testInput;
        }
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(testInput, request, path);
        response = request.headers(CucumberTestProperties.getHeaders(testInput)).patch(inputsAsJsonNode.get(PATH).asText());
        System.out.println("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
    }

    @Then("Verify property information in patch Property response output for the input {string}")
    public void verifyAPropertyInformationInPatchPropertyResponseOutputForTheInput(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode address = responseJsonNode.get("address");
        JsonNode input = inputsAsJsonNode.get(inputName);
        Assertions.assertNotNull(response, "response is null");
        Assertions.assertEquals(input.get("responseCode").asInt(), response.getStatusCode());
        Assert.assertEquals("1", responseJsonNode.get("floor").asText());
        Assert.assertEquals("9", address.get("flat").asText());
    }

    @Then("Verify error code 404 Not Found for the UI Coord Application patch property service response for the input {string}")
    public void verifyPatchPropertyByCaseIdNotFoundResponse(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.body().asString());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertNotNull(response, "response is null");
        Assertions.assertEquals(404, response.getStatusCode());
        JsonNode error_message_Array = responseJsonNode.get(ERRORS).get(0).get(MESSAGE);
        Assertions.assertTrue(error_message_Array.asText().contains(inputs.get(ERROR_MESSAGES).asText()));
    }

    @Then("Verify error code 400 bad request for the UI Coord Application patch property service response for the input {string}")
    public void verifyPatchPropertyInformationByCaseIdBadRequestResponse(String inputName) throws JsonProcessingException {
        validateBadRequest(inputName);
    }

    @Then("Verify property information valuation details in patch Property response output for the input {string}")
    public void verifyAPropertyInformationValuationDetailsInPatchPropertyResponseOutputForTheInput(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode address = responseJsonNode.get("address");
        JsonNode input = inputsAsJsonNode.get(inputName);
        Assertions.assertNotNull(response, "response is null");
        Assertions.assertEquals(input.get("responseCode").asInt(), response.getStatusCode());
        Assert.assertEquals("1", responseJsonNode.get("floor").asText());
        Assert.assertEquals("9", address.get("flat").asText());

        JsonNode valuationDetails = responseJsonNode.get("valuation");
        Assert.assertEquals("KERBSIDE_VALUATION", valuationDetails.get("type").asText());
        Assert.assertEquals("1994-05-09", valuationDetails.get("date").asText());
        Assert.assertEquals("new firm", valuationDetails.get("firmName").asText());
        Assert.assertTrue(valuationDetails.get("received").asBoolean());
        Assert.assertEquals("20.23", valuationDetails.get("amount").asText());
    }
}
