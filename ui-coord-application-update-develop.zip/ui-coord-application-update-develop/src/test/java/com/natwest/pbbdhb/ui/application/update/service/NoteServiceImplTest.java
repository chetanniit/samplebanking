package com.natwest.pbbdhb.ui.application.update.service;


import com.natwest.pbbdhb.ui.application.update.model.dto.exception.ClosedTaskException;
import com.natwest.pbbdhb.ui.application.update.model.dto.exception.ResourceNotFoundException;
import com.natwest.pbbdhb.ui.application.update.model.dto.exception.UserNotAuthorizedException;
import com.natwest.pbbdhb.ui.application.update.model.dto.exception.UserNotValidException;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.NoteRequest;
import com.natwest.pbbdhb.ui.application.update.service.impl.NoteServiceImpl;
import org.apache.commons.lang.StringUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.text.ParseException;
import java.util.Collections;

import static com.natwest.pbbdhb.ui.application.update.util.TestConstants.*;
import static com.natwest.pbbdhb.ui.application.update.util.TestUtil.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.WARN)
class NoteServiceImplTest {

    @InjectMocks
    private NoteServiceImpl noteService;

    @Mock
    private MockDataLoader mockDataLoader;

    @Test
    void testAddNote() throws ParseException {
        NoteRequest noteRequest = getNoteRequest();
        String response = noteService.addNote(NWB_BRAND, noteRequest);
        assertTrue(StringUtils.contains(response, ADD_NOTE_RESPONSE));
    }

    @Test
    void testAddNoteDateNull() throws ParseException {
        NoteRequest noteRequest = getNoteRequest();
        noteRequest.setDueDate(null);
        noteRequest.setDate(null);
        String response = noteService.addNote(NWB_BRAND, noteRequest);
        assertTrue(StringUtils.contains(response, ADD_NOTE_RESPONSE));
    }

    @Test
    void testClosedTaskException() {
        NoteRequest noteRequest = getActionNotAllowedNoteRequest();
        when(mockDataLoader.getClosedTask()).thenReturn(Collections.singletonList("000163654561"));
        ClosedTaskException closedTaskException = assertThrows(ClosedTaskException.class,
                () -> noteService.addNote(NWB_BRAND, noteRequest));
        assertEquals(ACTION_NOT_ALLOWED, getErrorMap().get(closedTaskException.getMessage()));
    }

    @Test
    void testUserNotAuthorizedToAddNoteException() {
        NoteRequest noteRequest = getUserNotAuthorizedNoteRequest();
        when(mockDataLoader.getNotAuthorizedUser()).thenReturn(Collections.singletonList("AKHTASJ"));
        UserNotAuthorizedException userNotAuthorizedException = assertThrows(UserNotAuthorizedException.class,
                () -> noteService.addNote(NWB_BRAND, noteRequest));
        assertEquals(USER_NOT_AUTHORIZED, getErrorMap().get(userNotAuthorizedException.getMessage()));
    }

    @Test
    void testUserNotValidToAddNoteException() {
        NoteRequest noteRequest = getUserNotFoundNoteRequest();
        when(mockDataLoader.getNotValidUser()).thenReturn(Collections.singletonList("EVANSLD"));
        UserNotValidException userNotValidException = assertThrows(UserNotValidException.class,
                () -> noteService.addNote(NWB_BRAND, noteRequest));
        assertEquals(USER_NOT_VALID, getErrorMap().get(userNotValidException.getMessage()));
    }

    @Test
    void testRecordNotFoundToAddNoteException() {
        NoteRequest noteRequest = getRecordNotFoundNoteRequest();
        when(mockDataLoader.getInvalidReferenceNumber()).thenReturn(Collections.singletonList("83550216"));
        ResourceNotFoundException resourceNotFoundException = assertThrows(ResourceNotFoundException.class,
                () -> noteService.addNote(NWB_BRAND, noteRequest));
        assertEquals(RECORD_NOT_FOUND, getErrorMap().get(resourceNotFoundException.getMessage()));
    }
}
