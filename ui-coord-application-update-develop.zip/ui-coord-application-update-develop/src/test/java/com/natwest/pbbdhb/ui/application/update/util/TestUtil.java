package com.natwest.pbbdhb.ui.application.update.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.applicant.dto.PersonDetailsDto;
import com.natwest.pbbdhb.applicant.dto.PersonTelephoneDto;
import com.natwest.pbbdhb.commondictionaries.enums.cases.LoanPurpose;
import com.natwest.pbbdhb.income.expense.model.enums.*;
import com.natwest.pbbdhb.income.expense.model.expense.dto.ExpenseApplicantDto;
import com.natwest.pbbdhb.income.expense.model.expense.dto.ExpenseTransactionDto;
import com.natwest.pbbdhb.income.expense.model.expense.dto.MerchantName;
import com.natwest.pbbdhb.income.expense.model.expense.request.CaseExpenseDto;
import com.natwest.pbbdhb.income.expense.model.income.dto.AddressDto;
import com.natwest.pbbdhb.income.expense.model.income.dto.ContactTelephoneDto;
import com.natwest.pbbdhb.income.expense.model.income.dto.JobDetailsDto;
import com.natwest.pbbdhb.income.expense.model.income.request.CaseIncomeDto;
import com.natwest.pbbdhb.income.expense.model.income.request.IncomeApplicantRequestDto;
import com.natwest.pbbdhb.ui.application.update.model.dto.document.DocumentUploadResponseDto;
import com.natwest.pbbdhb.ui.application.update.model.dto.document.SuccessfulUpload;
import com.natwest.pbbdhb.ui.application.update.model.dto.notes.DocumentNotesRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.*;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.*;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.document.Channel;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.document.DocUploadChannelEnum;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.document.DocumentRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.document.DocumentUploadRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.firequest.*;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.flowmanager.*;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.application.ApplicationInformationUpdateResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.application.BrokerInformationUpdateStatus;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.userinformation.UserInformationResponse;
import org.assertj.core.util.Lists;
import org.jetbrains.annotations.NotNull;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;

import static com.natwest.pbbdhb.ui.application.update.util.TestConstants.*;

public class TestUtil {

    public static final String VALID_RACF = "owend";

    public static String asJsonString(final Object obj) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            mapper.findAndRegisterModules();
            return mapper.writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static TaskRequest createTaskRequest(){
        return TaskRequest.builder().applicationSequenceNumber("01").operatorName("JOHN KENNEDY")
                .operatorRacfId("KENNEJF")
                .referenceNumber("84153756")
                .stageNumber("25")
                .taskCode("AVR")
                .taskName("Await Valuation Report")
                .date("2025-11-25T18:30+00:00")
                .build();
    }

    public static TaskRequest createInvalidTaskRequest(){
        return TaskRequest.builder().applicationSequenceNumber("01").operatorName("JOHN KENNEDY")
                .operatorRacfId("KENNEJF1")
                .referenceNumber("84153756e")
                .stageNumber("253a")
                .taskCode("AVRdgfd")
                .taskName("Await Valuation Report")
                .date("2023-11-25T18:30+00:00")
                .build();
    }

    public static NoteRequest getNoteRequest(){
        return NoteRequest.builder()
                .date("2022-11-25T18:30+00:00")
                .description("note for test")
                .dueDate("2022-11-25")
                .operatorName("JOHN KENNEDY")
                .operatorRacfId("KENNEJF")
                .referenceNumber("8415375678")
                .sequenceNumber("01")
                .taskCode("AVR")
                .taskID("taskID123/")
                .taskName("Await Valuation Report")
                .documentRequired("Example - Payslip")
                .duration("4 months")
                .fromDate("2021-06-26")
                .reason("Need to check the expenses")
                .requiredFor("applicant one - John smith")
                .toDate("2021-07-26")
                .build();
    }


    public static CloseTaskRequest createCloseTaskRequest(){
        return CloseTaskRequest.builder().applicationSequenceNumber("01").operatorName("JOHN KENNEDY")
                .operatorRacfId("KENNEJF")
                .referenceNumber("84153756")
                .stageNumber("25")
                .taskCode("AVR")
                .taskId("24")
                .taskName("Await Valuation Report")
                .date("2025-11-25T18:30+00:00")
                .build();
    }


    public static CloseTaskRequest createCloseTaskInvalidRequest(){
        return CloseTaskRequest.builder().applicationSequenceNumber("01").operatorName("JOHN KENNEDY")
                .operatorRacfId("KENNEJF")
                .referenceNumber("84153756abc")
                .stageNumber("25")
                .taskCode("AVR")
                .taskId("24")
                .taskName("Await Valuation Report")
                .date("2023-11-25T18:30+00:00")
                .build();
    }

    public static CloseTaskRequest createInvalidReferenceCloseTaskRequest(){
        return CloseTaskRequest.builder().applicationSequenceNumber("01").operatorName("JOHN KENNEDY")
                .operatorRacfId("KENNEJF")
                .referenceNumber("83550216")
                .stageNumber("25")
                .taskCode("AVR")
                .taskName("Await Valuation Report")
                .date("2022-11-25T18:30+00:00")
                .taskId("000173654561")
                .build();
    }

    public static CloseTaskRequest createUserNotValidToCloseTaskRequest(){
        return CloseTaskRequest.builder().applicationSequenceNumber("01").operatorName("JOHN KENNEDY")
                .operatorRacfId("EVANSLD")
                .referenceNumber("83550212")
                .stageNumber("25")
                .taskCode("AVR")
                .taskName("Await Valuation Report")
                .date("2022-11-25T18:30+00:00")
                .taskId("000173654561")
                .build();
    }

    public static CloseTaskRequest createUserNotAuthorizedToCloseTaskRequest(){
        return CloseTaskRequest.builder().applicationSequenceNumber("01").operatorName("JOHN KENNEDY")
                .operatorRacfId("AKHTASJ")
                .referenceNumber("83550212")
                .stageNumber("25")
                .taskCode("AVR")
                .taskName("Await Valuation Report")
                .date("2022-11-25T18:30+00:00")
                .taskId("000173654561")
                .build();
    }

    public static CloseTaskRequest createTaskNotEligibleToCloseTaskRequest(){
        return CloseTaskRequest.builder().applicationSequenceNumber("01").operatorName("JOHN KENNEDY")
                .operatorRacfId("KENNEJF")
                .referenceNumber("83550212")
                .stageNumber("25")
                .taskCode("AVR")
                .taskName("Await Valuation Report")
                .date("2022-11-25T18:30+00:00")
                .taskId("000163654561")
                .build();
    }

    public static TaskRequest createInvalidReferenceToAddTaskRequest(){
        return TaskRequest.builder().applicationSequenceNumber("01").operatorName("JOHN KENNEDY")
                .operatorRacfId("KENNEJF")
                .referenceNumber("83550216")
                .stageNumber("25")
                .taskCode("AVR")
                .taskName("Await Valuation Report")
                .date("2022-11-25T18:30+00:00")
                .build();
    }

    public static TaskRequest createUserNotValidToAddTaskRequest(){
        return TaskRequest.builder().applicationSequenceNumber("01").operatorName("JOHN KENNEDY")
                .operatorRacfId("EVANSLD")
                .referenceNumber("83550212")
                .stageNumber("25")
                .taskCode("AVR")
                .taskName("Await Valuation Report")
                .date("2022-11-25T18:30+00:00")
                .build();
    }

    public static TaskRequest createUserNotAuthorizedToAddTaskRequest(){
        return TaskRequest.builder().applicationSequenceNumber("01").operatorName("JOHN KENNEDY")
                .operatorRacfId("AKHTASJ")
                .referenceNumber("83550212")
                .stageNumber("25")
                .taskCode("AVR")
                .taskName("Await Valuation Report")
                .date("2022-11-25T18:30+00:00")
                .build();
    }

    public static NoteRequest getUserNotFoundNoteRequest(){
        return NoteRequest.builder()
                .date("2022-11-25T18:30+00:00")
                .description("note for test")
                .dueDate("2022-11-25")
                .operatorName("JOHN KENNEDY")
                .operatorRacfId("EVANSLD")
                .referenceNumber("8415375678")
                .sequenceNumber("01")
                .taskCode("AVR")
                .taskID("taskID123/")
                .taskName("Await Valuation Report")
                .build();
    }

    public static NoteRequest getUserNotAuthorizedNoteRequest(){
        return NoteRequest.builder()
                .date("2022-11-25T18:30+00:00")
                .description("note for test")
                .dueDate("2022-11-25")
                .operatorName("JOHN KENNEDY")
                .operatorRacfId("AKHTASJ")
                .referenceNumber("8415375678")
                .sequenceNumber("01")
                .taskCode("AVR")
                .taskID("taskID123/")
                .taskName("Await Valuation Report")
                .build();
    }

    public static NoteRequest getActionNotAllowedNoteRequest(){
        return NoteRequest.builder()
                .date("2022-11-25T18:30+00:00")
                .description("note for test")
                .dueDate("2022-11-25")
                .operatorName("JOHN KENNEDY")
                .operatorRacfId("KENNEJF")
                .referenceNumber("8415375678")
                .sequenceNumber("01")
                .taskCode("AVR")
                .taskID("000163654561")
                .taskName("Await Valuation Report")
                .build();
    }

    public static NoteRequest getRecordNotFoundNoteRequest(){
        return NoteRequest.builder()
                .date("2022-11-25T18:30+00:00")
                .description("note for test")
                .dueDate("2022-11-25")
                .operatorName("JOHN KENNEDY")
                .operatorRacfId("KENNEJF")
                .referenceNumber("83550216")
                .sequenceNumber("01")
                .taskCode("AVR")
                .taskID("taskID123/")
                .taskName("Await Valuation Report")
                .build();
    }

    public static TaskRequest createTaskNoteRequest(){
        return TaskRequest.builder().applicationSequenceNumber("01").operatorName("JOHN KENNEDY")
                .operatorRacfId("KENNEJF")
                .referenceNumber("84153756")
                .stageNumber("25")
                .taskCode("AVR")
                .taskName("Await Valuation Report")
                .date("2025-11-25T18:30+00:00")
                .reason("Testing note")
                .fromDate("2020-11-13")
                .toDate("2021-03-12")
                .build();
    }

    public static TaskRequest createInvalidTaskNoteRequest(){
        return TaskRequest.builder().applicationSequenceNumber("01").operatorName("JOHN KENNEDY")
                .operatorRacfId("KENNEJF")
                .referenceNumber("84153756")
                .stageNumber("25")
                .taskCode("AVR")
                .taskName("Await Valuation Report")
                .date("2022-11-25T18:30+00:00")
                .description("Testing invalid note")
                .fromDate("11-12-2020")
                .toDate("11-03-2021")
                .build();
    }

    public static Map<String, String> getErrorMap(){
        Map<String, String> errorMap = new HashMap<>();
        errorMap.put("400", "Please enter a valid {0}");
        errorMap.put("403-user-not-authorised", "User not authorised to perform this action");
        errorMap.put("404-record-not-found", "Record Not Found");
        errorMap.put("404-user-not-valid", "User Not Valid");
        errorMap.put("412-not-eligible-to-close", "This task is not eligible to close");
        errorMap.put("412-action-not-allowed", "This action is not allowed");
        errorMap.put("422-unprocessable-entity", "This record is not able to process");
        errorMap.put("412-caseid_not_valid", "CaseId should be same");
        return errorMap;
    }

    /**
     * Method is used to create FIRequest
     * @return - FIRequest object
     */
    public static FIRequest createFIRequest(){
        return FIRequest.builder()
                .documentRequests(Collections.singletonList(getDocument()))
                .build();
    }

    public static AddTeleMessageRequest createAddTeleMessageRequest(){
        return AddTeleMessageRequest.builder().documentIdentifier("TM1").category("Tele Message").callerInfo("Main Applicant")
                .callReason("Product Switch").dueDate("2023-08-17").build();
    }

    public static FlowManagerFIRequest createFlowManagerFIRequest(){
        return FlowManagerFIRequest.builder()
                .userFullName("John smith").userRACFId("KENNEJF")
                .documentRequests(Collections.singletonList(getFlowManagerDocument()))
                .build();
    }

    /**
     * Method is used to create FIRequest
     * @return - FIRequest object
     */
    public static FIStatusRequest createFIStatusRequest(){
        return FIStatusRequest.builder()
                .build();
    }

    public static FlowManagerFIStatusRequest createFlowManagerFIStatusRequest(){
        return FlowManagerFIStatusRequest.builder().referenceNumber("84153756")
                .updatedByFullName("John smith").updatedByRACFID("KENNEJF")
                .state("Review")
                .requestId("TEST123456789")
                .build();
    }

    /**
     * Method is used to create FIRequest
     * @return - FIRequest object
     */
    public static FIStatusRequest createFIStatusWithNoteRequest(){
        return FIStatusRequest.builder()
                //.status("Reviewed")
                .note("TEST")
                .build();
    }

    public static FlowManagerFIStatusRequest createFlowManagerFIStatusWithNoteRequest(){
        return FlowManagerFIStatusRequest.builder().referenceNumber("84153756")
                .updatedByFullName("John smith").updatedByRACFID("KENNEJF")
                .state("Review")
                .requestId("TEST123456789")
                .note("TEST")
                .build();
    }

    public static FlowManagerAddNoteRequest createFlowManagerAddNoteRequest(){
        return FlowManagerAddNoteRequest.builder().referenceNumber("84153756")
                .userFullName("John smith").userRACFId("KENNEJF")
                .requestId("TEST123456789")
                .note("TEST")
                .build();
    }
    /**
     *
     * Method is used to create FIRequest
     * @return - FIRequest object
     */
    public static DocumentReminder createDocumentReminder(){
        return DocumentReminder.builder()
                .build();
    }

    public static FlowManagerDocumentReminder createFlowManagerDocumentReminder(){
        return FlowManagerDocumentReminder.builder().referenceNumber("84153756")
                .userFullName("John smith").userRACFId("KENNEJF")
                .build();
    }
    private static Document getDocument(){
        return Document.builder().requiredFor(
                        Collections.singletonList(DocumentFor.builder().applicantId("12345").build())
                ).documentIdentifier("D1").fromDate("2021-06-26").toDate("2021-07-26").dueDate("2022-06-03")
                .timePeriod("4 months").build();
    }

    private static FlowManagerDocument getFlowManagerDocument() {
        return FlowManagerDocument.builder().requiredFor(
                Collections.singletonList(DocumentFor.builder().applicantId("12345").build())
        ).documentIdentifier("D1").category("payslip").fromDate("2021-06-26").toDate("2021-07-26").dueDate("2022-06-03")
                .purpose(Collections.singletonList("Need to check the expenses"))
                .taskCode("AVP").count("4").frequency("months").build();
    }

    private static ApplicantInformation getApplicationInfo(){
        return ApplicantInformation.builder().title("MR").lastName("HLRJHBRKGP").firstName("EMNJ").applicantId("12345")
                .emailAddress("david@listers.ltd.uk").isNotificationRequired(true).mobileNumber("3445545803").build();
    }

    private static BrokerInformation getBrokerInfo(){
        return BrokerInformation.builder().emailAddress("david@listers.ltd.uk").firmName("Listers Limited (83738)")
                .fullName("David Sutherland")
                .isNotificationRequired(true).mobileNumber("3445545803").build();
    }

    public static DocumentNotesRequest createDocumentNotesRequest() {
        return  DocumentNotesRequest.builder()
                .requestId(REQUEST_ID)
                .note(NOTE)
                .build();
    }

    public static DocumentNotesRequest createDocumentNotesRequestWithoutRequestId() {
        return  DocumentNotesRequest.builder()
                .note(NOTE)
                .build();
    }

    public static FlowManagerDocumentNotesRequest createFlowManagerDocumentNotesRequest() {
        return FlowManagerDocumentNotesRequest.builder()
                .referenceNumber(REFERENCE_NUMBER)
                .requestId(REQUEST_ID)
                .userFullName(ADDED_FULL_NAME)
                .userRACFId(ADDED_BY_RACFID)
                .note(NOTE)
                .build();
    }

    public static ApplicationInformationUpdateRequest createApplicationInformationUpdateRequest() {
        return  ApplicationInformationUpdateRequest.builder()
                .build();
    }

    public static FlowManagerApplicationInformationUpdateRequest createFlowManagerApplicationInformationUpdateRequest() {
        return  FlowManagerApplicationInformationUpdateRequest.builder()
                .referenceNumber("80132415")
                .caseId("ID129272625")
                .userFullName("Colin")
                .userRACFId("laksht")
                .build();
    }

    public static ApplicationInformationUpdateResponse createApplicationInformationUpdateResponse() {
        return  ApplicationInformationUpdateResponse.builder().brokerInfo(BrokerInformationUpdateStatus.builder().status("Updated").build())
                .build();
    }

    public static UserInformationResponse createUserInformationResponse() {
        return UserInformationResponse.builder().
                isMCCUser(true).
                isUWUser(true).
                isUWLead(true).
                racfID("owend").
                username("owendame").
                build();
    }
    public static DocumentUploadResponseDto createDocumentUploadResponseDtoWithOnlySuccesses() {
        List<SuccessfulUpload> successfulUploads = new ArrayList<>();
        successfulUploads.add(upload());
        return DocumentUploadResponseDto.builder()
                .successfulUploads(successfulUploads)
                .build();
    }
    public static SuccessfulUpload upload(){
        return SuccessfulUpload.builder()
                .originalFileName("natwest_logo.jpg")
                .documentId("49bffb0f-0353-45ab-b1c3-6e3de471e0a7")
                .build();
    }
    public static DocumentRequest createDocumentRequest() throws IOException {
        return DocumentRequest.builder()
                .applicantId("123456")
                .channel(DocUploadChannelEnum.INTERNET)
                .files(getMultipartFiles())
                .documentType("OTHER")
                .loanPurpose(LoanPurpose.HOUSE_PURCHASE.toString())
                .build();
    }

    public static DocumentRequest createPreClassifiedDocumentRequest() throws IOException {
        return DocumentRequest.builder()
                .channel(DocUploadChannelEnum.INTERNET)
                .files(getMultipartFiles())
                .documentType("EECOT")
                .loanPurpose(LoanPurpose.REMORTGAGE.toString())
                .build();
    }

    public static DocumentRequest createPreClassifiedDocRequestWithMultipleFiles() throws IOException {
        return DocumentRequest.builder()
                .channel(DocUploadChannelEnum.INTERNET)
                .files(getMultipleMultipartFiles())
                .documentType("EECOT")
                .build();
    }

    @NotNull
    private static List<MultipartFile> getMultipartFiles() throws IOException {
        Resource fileResource = new ClassPathResource(
                "testfiles/natwest_logo.jpg");

        MockMultipartFile file = new MockMultipartFile(
                "files", fileResource.getFilename(),
                MediaType.MULTIPART_FORM_DATA_VALUE,
                fileResource.getInputStream());

        List<MultipartFile> fileList = new ArrayList<>();
        fileList.add(file);
        return fileList;
    }

    @NotNull
    private static List<MultipartFile> getMultipleMultipartFiles() throws IOException {
        Resource fileResource = new ClassPathResource(
                "testfiles/natwest_logo.jpg");

        MockMultipartFile file1 = new MockMultipartFile(
                "files", fileResource.getFilename(),
                MediaType.MULTIPART_FORM_DATA_VALUE,
                fileResource.getInputStream());
        MockMultipartFile file2 = new MockMultipartFile(
                "files", fileResource.getFilename(),
                MediaType.MULTIPART_FORM_DATA_VALUE,
                fileResource.getInputStream());

        return new ArrayList<>(Arrays.asList(file1,file2));
    }

    public static PersonDetailsDto getPersonDetailsDto(){
        List<PersonTelephoneDto> list = new ArrayList<>();
        list.add(PersonTelephoneDto.builder().type(TelephoneType.WORK.name()).number("123456").build());
        list.add(PersonTelephoneDto.builder().type(TelephoneType.MOBILE.name()).number("1234567890").build());

        return PersonDetailsDto.builder()
                .email("test@gmail.com")
                .firstNames("test")
                .lastName("test")
                .telephones(list)
                .build();
    }

    public static CaseIncomeDto getCaseIncomeDto() {
        LocalDate employmentStartDate = LocalDate.of(1990, 10, 12);
        return CaseIncomeDto.builder()
                .stage(CaseStage.DIP)
                .applicants(Lists.newArrayList(IncomeApplicantRequestDto.builder().applicantId("65172362")
                        .cin(1234567890L)
                        .breakInEmploymentInLastSixMonths(YesNo.N)
                        .primaryJob(JobDetailsDto.builder()
                                .jobId("NatWest_101")
                                .employmentStatus(EmploymentStatus.EMPLOYED)
                                .employmentType(EmploymentType.PERMANENT)
                                .occupationType(OccupationType.AGRICULTURAL_WORKERS_GENERAL)
                                .industryType(IndustryType.AGRICULTURE_HUNTING_FORESTRY)
                                .payslipFrequency(PayslipFrequency.MONTHLY)
                                .employerName("Natwest")
                                .employmentStartDate(employmentStartDate)
                                .basicPayAnnualIncome(new BigDecimal("1200000"))
                                .employerAddress(AddressDto.builder()
                                        .houseName("Someplace")
                                        .houseNumber("62")
                                        .flat("5B")
                                        .street("Some Street")
                                        .district("An area")
                                        .county("A county")
                                        .town("My Town")
                                        .postcode("W1 2TW")
                                        .build())
                                .preferredEmployerTelephone(ContactTelephoneDto.builder()
                                        .number("+449999999999")
                                        .type(TelephoneType.WORK)
                                        .build())
                                .additionalEmployerTelephones(Lists.newArrayList(ContactTelephoneDto.builder()
                                        .number("+441111111111")
                                        .type(TelephoneType.FAX)
                                        .build()))
                                .build())
                        .breakInEmploymentInLastSixMonths(YesNo.N)
                        .build())).build();
    }

    public static CaseExpenseDto getCaseExpenseDto(){
        return CaseExpenseDto.builder()
                .stage(CaseStage.DIP)
                .applicants(Collections.singletonList(getExpenseApplicantDto()))
                .build();

    }

    public static ExpenseApplicantDto getExpenseApplicantDto() {
        return ExpenseApplicantDto.builder()
                .applicantId("1")
                .cin(1456876534L)
                .dependentCostsExcludeReason(EXCLUDE_REASON)
                .excludedTransactionsReason("String")
                .sourceOfExpenditureVerification(YesNo.Y)
                .transactions(Collections.singletonMap(TRANSACTION_ID, getExpenseTransactionDto()))
                .build();
    }

    public static ExpenseTransactionDto getExpenseTransactionDto() {
        return ExpenseTransactionDto.builder()
                .categoryCode(ExpenseCategory.CREDIT_CARD)
                .otherCommittedExpenditureFreeFormText("medicines")
                .description("description")
                .frequency(ExpenseFrequency.MONTHLY)
                .amount(CONSOLIDATION_AMOUNT)
                .merchantName(MerchantName.BARCLAYS)
                .outstandingBalance(OUTSTANDING_BALANCE)
                .remainingMonths(10)
                .remainingYears(0)
                .consolidationAmount(CONSOLIDATION_AMOUNT)
                .numberOfConsolidation(1)
                .redeemedOrLessThanSixMonths(YesNo.Y)
                .transactionGroup("rental_property_1")
                .build();
    }

    public static DocumentUploadRequest createDocumentUploadRequest() throws IOException {
        Resource fileResource = new ClassPathResource(
                "testfiles/22345678natwest_logo.jpg");

        MockMultipartFile file = new MockMultipartFile(
                "files", fileResource.getFilename(),
                MediaType.MULTIPART_FORM_DATA_VALUE,
                fileResource.getInputStream());


        return DocumentUploadRequest.builder()
                .file(file)
                .Channel(Channel.FOCUS)
                .build();
    }

    public static AddNoteRequest createAddNoteRequest(){
        return AddNoteRequest.builder().referenceNumber("84153756")
                .requestID("TEST123456789")
                .note("TEST")
                .build();
    }

    public static ApplicationInformationUpdateRequest createApplicationInfoUpdateRequest() {
        return  ApplicationInformationUpdateRequest.builder()
                .applicants(Collections.singletonList(UpdateApplicantInformation.builder()
                        .mainApplicant(true)
                        .emailAddress("david@listers.ltd.uk")
                        .mobileNumber("3445545803")
                        .build()))
                .brokerInfo(UpdateBrokerInformation.builder()
                        .emailAddress("david12@listers.ltd.uk")
                         .notificationRequired(true)
                        .build())
                .sourceInfo(UpdateSourceInformation.builder()
                        .advisor("advisor")
                        .racfId("rehap")
                        .build())
                .build();
    }

    public static MockUsersRequest getMockUsersRequest(){
        return MockUsersRequest.builder()
                .isMCCUser(true)
                .isMopsUser(true)
                .isUWUser(true)
                .isUWLead(true)
                .isDocViewer(true)
                .isMopsDataEntry(true)
                .isDisassociateDocument(true)
                .isPSTUser(true)
                .isMAUser(true)
                .isCINUser(true)
                .isRBSIUser(true)
                .username("test user")
                .racfID("test")
                .build();
    }

    public static UpdateCaseOwnerRequest getApplicationCaseOwnerUpdateRequest(String referenceNumber, String caseOwner) {
        List<ApplicationCaseOwner> applicationCaseOwnerList = new ArrayList<>();
        applicationCaseOwnerList.add(ApplicationCaseOwner.builder().referenceNumber(referenceNumber).caseOwner(caseOwner).build());
        applicationCaseOwnerList.add(ApplicationCaseOwner.builder().referenceNumber(referenceNumber).caseOwner(caseOwner).build());
        applicationCaseOwnerList.add(ApplicationCaseOwner.builder().referenceNumber(referenceNumber).caseOwner(caseOwner).build());

        return UpdateCaseOwnerRequest.builder()
                .caseOwnerRequest(applicationCaseOwnerList)
                .build();
    }

    public static CaseUpdateCaseOwnerRequest getCaseApplicationCaseOwnerUpdateRequest(String caseId, String caseOwner) {
        List<CaseApplicationCaseOwner> applicationCaseOwnerList = new ArrayList<>();
        applicationCaseOwnerList.add(CaseApplicationCaseOwner.builder().caseId(caseId).caseOwner(caseOwner).build());
        applicationCaseOwnerList.add(CaseApplicationCaseOwner.builder().caseId(caseId).caseOwner(caseOwner).build());

        return CaseUpdateCaseOwnerRequest.builder()
                .caseOwnerRequest(applicationCaseOwnerList)
                .build();
    }

}
