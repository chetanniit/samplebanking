package com.natwest.pbbdhb.ui.application.update.controller;

import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.CaseTransferRequest;
import com.natwest.pbbdhb.ui.application.update.service.ApplicationUpdateService;
import com.natwest.pbbdhb.ui.application.update.service.auth.impl.AuthorizationServiceImpl;
import com.natwest.pbbdhb.ui.application.update.service.stp.CaseAllocationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.web.context.WebApplicationContext;

import java.util.UUID;

import static com.natwest.pbbdhb.ui.application.update.util.TestConstants.*;
import static com.natwest.pbbdhb.ui.application.update.util.TestUtil.asJsonString;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doReturn;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(value = {StpCaseController.class}, properties = {"spring.profiles.active=test"})
@DisplayName("StpCaseController - MVC Test")
public class StpCaseControllerTest {

    @MockBean(name = "authorizationServiceImpl")
    private AuthorizationServiceImpl authorizationServiceImpl;

    @Autowired
    private WebApplicationContext webApplicationContext;

    @MockBean
    private ApplicationUpdateService applicationUpdateService;

    @MockBean
    private CaseAllocationService caseAllocationService;

    @Autowired
    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testAllocateCaseSuccess() throws Exception {
        doReturn(true).when(authorizationServiceImpl).isUWUser();


        MvcResult result = mockMvc.perform(patch("/stp/exception/assign")
                        .header(BRAND, NWB_BRAND)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().is2xxSuccessful())
                .andReturn();
        assertEquals(200, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testInvalidBrand() throws Exception {
        doReturn(true).when(authorizationServiceImpl).isUWUser();


        MvcResult result = mockMvc.perform(patch("/stp/exception/assign")
                        .header(BRAND, "NBB")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest())
                .andReturn();
        assertEquals(400, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }


    @Test
    void testUserPermissionFail() throws Exception {
        doReturn(false).when(authorizationServiceImpl).isUWUser();


        MvcResult result = mockMvc.perform(patch("/stp/exception/assign")
                        .header(BRAND, "NBB")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isForbidden())
                .andReturn();
        assertEquals(403, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testTransferCase() throws Exception {
        doReturn(true).when(authorizationServiceImpl).isUWUser();
        CaseTransferRequest request = CaseTransferRequest
                .builder().note("Hello").build();
        MvcResult result = mockMvc.perform(patch("/case/Case12345678/caseTransfer")
                .header(BRAND, NWB_BRAND)
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(request)))
                .andExpect(status().isOk())
                .andReturn();
        assertEquals(200, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testTransferCaseBadRequest() throws Exception {
        doReturn(true).when(authorizationServiceImpl).isUWUser();
        CaseTransferRequest request = CaseTransferRequest
                .builder().note("Hello").build();
        MvcResult result = mockMvc.perform(patch("/case/Case1234567!8/caseTransfer")
                .header(BRAND, NWB_BRAND)
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(request)))
                .andExpect(status().isBadRequest())
                .andReturn();
        assertEquals(400, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testTransferCaseForbidden() throws Exception {
        doReturn(false).when(authorizationServiceImpl).isUWUser();
        doReturn(false).when(authorizationServiceImpl).isDevTestUser();
        CaseTransferRequest request = CaseTransferRequest
                .builder().note("Hello").build();
        MvcResult result = mockMvc.perform(patch("/case/Case1234567!8/caseTransfer")
                .header(BRAND, NWB_BRAND)
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(request)))
                .andExpect(status().isForbidden())
                .andReturn();
        assertEquals(403, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }
    @Test
    void testDeallocateCaseSuccessForUWUser() throws Exception {
        doReturn(true).when(authorizationServiceImpl).isUWUser();

        String exceptionId = UUID.randomUUID().toString();
        MvcResult result = mockMvc.perform(patch("/stp/exception/unassign")
                        .header(BRAND, NWB_BRAND)
                        .param("exceptionId", exceptionId)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().is2xxSuccessful())
                .andReturn();
        assertEquals(200, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testDeallocateCaseSuccessForPSTUser() throws Exception {
        doReturn(true).when(authorizationServiceImpl).isPSTUser();

        String exceptionId = UUID.randomUUID().toString();
        MvcResult result = mockMvc.perform(patch("/stp/exception/unassign")
                        .header(BRAND, NWB_BRAND)
                        .param("exceptionId", exceptionId)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().is2xxSuccessful())
                .andReturn();
        assertEquals(200, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testInvalidBrandForDeallocateCase() throws Exception {
        doReturn(true).when(authorizationServiceImpl).isUWUser();

        String exceptionId = UUID.randomUUID().toString();
        MvcResult result = mockMvc.perform(patch("/stp/exception/unassign")
                        .header(BRAND, "NBB")
                        .param("exceptionId", exceptionId)
                        .contentType(MediaType.APPLICATION_JSON)
                )
                .andExpect(status().isBadRequest())
                .andReturn();
        assertEquals(400, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

    @Test
    void testUserPermissionFailForDeallocateCase() throws Exception {
        doReturn(false).when(authorizationServiceImpl).isUWUser();

        String exceptionId = UUID.randomUUID().toString();
        MvcResult result = mockMvc.perform(patch("/stp/exception/unassign")
                        .header(BRAND, NWB_BRAND)
                        .param("exceptionId", exceptionId)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isForbidden())
                .andReturn();
        assertEquals(403, result.getResponse().getStatus());
        assertEquals(NO_CACHE, result.getResponse().getHeader(PRAGMA));
        assertEquals(NO_CACHE, result.getResponse().getHeader(CACHE_CONTROL));
        assertEquals(CSP_VALUE, result.getResponse().getHeader(CONTENT_SECURITY_POLICY));
    }

}
