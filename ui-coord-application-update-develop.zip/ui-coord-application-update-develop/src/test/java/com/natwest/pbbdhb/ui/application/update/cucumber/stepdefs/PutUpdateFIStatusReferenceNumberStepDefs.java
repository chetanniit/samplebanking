package com.natwest.pbbdhb.ui.application.update.cucumber.stepdefs;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.CucumberTestProperties;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;

import java.io.IOException;
import java.util.ArrayList;

import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.*;
import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.Params.*;
import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.Params.RESPONSE_CODE;

@Slf4j
public class PutUpdateFIStatusReferenceNumberStepDefs {
    private JsonNode inputsAsJsonNode;
    private JsonNode responseJsonNode;
    private String responseString;
    private Response response;

    @Before
    public void init() throws IOException {
       inputsAsJsonNode = ApiTestUtil.getInputsAsJsonNode(PUT_UPDATE_FI_STATUS_INPUT_JSON);
    }

    @Given("UpdateFIStatus Service endpoint exists")
    public void updateFIStatusServiceEndpointExists() {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String path = inputsAsJsonNode.get(PATH).asText();
        Assertions.assertNotNull(path, "path is null");
    }

    public boolean validateNumberSize(JsonNode number, int size) {
        long test = number.asLong();
        return test >= 0 && test < Math.pow(10, size);
    }

    private void validateArrayContains(JsonNode array, JsonNode itemSearched, String inputField) {
        ArrayList<String> predefined = new ObjectMapper().convertValue(array.get(inputField), ArrayList.class);
        Assertions.assertTrue(predefined.contains(itemSearched.asText()));
    }

    private void validatePredefinedContains(JsonNode inputs, JsonNode itemSearched) {
        validateArrayContains(inputs, itemSearched, PREDEFINED);
    }

    private void validateResponseErrorContains(JsonNode inputs, JsonNode itemSearched) {
        validateArrayContains(inputs, itemSearched, ERROR_MESSAGES);
    }

    private void validateBadRequest(JsonNode responseJsonNode, String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        validateResponseErrorContains(responseJsonNode, inputs.get(ERROR_MESSAGE));
    }


    private void validateNotFound(JsonNode responseJsonNode, String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(NOT_FOUND, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        String error = inputs.get(ERROR_MESSAGE).asText()
                +inputs.get(REQUEST_BODY).get(REFERENCE_NUMBER).asText();
        Assertions.assertEquals(responseJsonNode.get(ERROR_MESSAGES).get(0).asText(),error);
    }

    @When("User sends request to add notes using input {string} and verify response code")
    public void userSendsRequestToAddNotesUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        String path = inputsAsJsonNode.get(PATH).asText();
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .accept(ContentType.JSON);
        JsonNode testInput = inputsAsJsonNode.get(inputName);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(testInput, request, path);
        response = request
                .headers(CucumberTestProperties.getHeaders(testInput))
                .headers(CucumberTestProperties.getHeaders(testInput))
                .put(inputsAsJsonNode.get(PATH).asText());
        System.out.println("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @Then("Validate the Coord Application Update service successful response {string}")
    public void verifySuccessfulResponse(String inputName) throws JsonProcessingException {
        Assertions.assertTrue(response.asString().contains(SUCCESSFUL_UPDATE_FI_STATUS_MESSAGE));
     /*  JsonNode inputs = inputsAsJsonNode.get(inputName).get(REQUEST_BODY);
        Assertions.assertTrue(responseString.contains(SUCCESSFUL_UPDATE_FI_STATUS_MESSAGE
                +REFERENCE_NUMBER+" "+inputs.get(REFERENCE_NUMBER).asText()+", "
                +"isActive true, "
                +"requestID"+" "+inputs.get(REQUEST_ID).asText()
        ));*/;
    }

    @Then("Validate the Coord Application Update service response keeping brand predefined value {string}")
    public void validateTheResponseCodeBrand(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        validatePredefinedContains(inputs,inputs.get(BRAND));
    }

    @Then("Validate the Coord Application Update service response keeping referenceNumber value in bigdecimal up to 10 chars {string}")
    public void validateTheResponseCodeReferenceNumber(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertTrue(inputs.get(REQUEST_BODY).get(REFERENCE_NUMBER).size() < 11 );
    }

    @Then("Validate the Coord Application Update service response keeping requestID value up to 50 chars - only in a-zA-Z0-9 range {string}")
    public void validateTheResponseCodeRequestID(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertTrue(inputs.get(FI_REQUEST_ID).asText().matches("^[a-zA-Z0-9]{1,50}$"));
    }

    @Then("Validate the Coord Application Update service response keeping status predefined value {string}")
    public void validateTheResponseCodeStatus(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        validatePredefinedContains(inputs,inputs.get(STATUS));
    }

    @Then("Validate the Coord Application Update service response keeping note value up to 4000 chars {string}")
    public void validateTheResponseCodeNote(String inputName)  {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertTrue(inputs.get(REQUEST_BODY).get(NOTE).size() < 4001 );
    }

    @Then("Validate the Coord Application Update service response keeping invalid value for brand {string}")
    public void verifyResponseForTheInvalidValueForBrand(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode,inputName);
    }

    @Then("Validate the Coord Application Update service response keeping invalid value for referenceNumber {string}")
    public void validateTheCoordApplicationUpdateServiceResponseKeepingInvalidValueForReferenceNumber(String arg0) {
    }

    @Then("Validate the Coord Application Update service response keeping invalid value for updatedByFullName {string}")
    public void verifyResponseForTheInvalidValueForUpdatedByFullName(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode,inputName);
    }

    @Then("Validate the Coord Application Update service response keeping invalid value for updatedByRACFID {string}")
    public void verifyResponseForTheInvalidValueForUpdatedByRACFID(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode,inputName);
    }

    @Then("Validate the Coord Application Update service response keeping invalid value for requestID {string}")
    public void verifyResponseForTheInvalidValueForRequestID(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode,inputName);
    }

    @Then("Validate the Coord Application Update service response keeping invalid value for status {string}")
    public void verifyResponseForTheInvalidValueForStatus(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode,inputName);
    }

    @Then("Validate the Coord Application Update service response keeping invalid value for note {string}")
    public void verifyResponseForTheInvalidValueForNote(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode,inputName);
    }

    @Then("Validate the Coord Application Update service response for brand value that doesn't exists {string}")
    public void verifyResponseForBrandNotFound(String inputName) throws JsonProcessingException {
        validateNotFound(responseJsonNode,inputName);
    }

    @Then("Validate the Coord Application Update service response for referenceNumber value that doesn't exists {string}")
    public void verifyResponseForReferenceNumberNotFound(String inputName) throws JsonProcessingException {
        validateNotFound(responseJsonNode,inputName);
    }

    @Then("Validate the Coord Application Update service response for sequenceNumber value that doesn't exists {string}")
    public void verifyResponseForSequenceNumberNotFound(String inputName) throws JsonProcessingException {
        validateNotFound(responseJsonNode,inputName);
    }

    @Then("Validate the Coord Application Update service response for updatedByFullName value that doesn't exists {string}")
    public void verifyResponseForUpdatedByFullNameNotFound(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode,inputName);
    }

    @Then("Validate the Coord Application Update service response for updatedByRACFID value that doesn't exists {string}")
    public void verifyResponseForUpdatedByRACFIDNotFound(String inputName) throws JsonProcessingException {
        validateBadRequest(responseJsonNode,inputName);
    }

    @Then("Validate the Coord Application Update service response for requestID value that doesn't exists {string}")
    public void verifyResponseForRequestIDNotFound(String inputName) throws JsonProcessingException {
        validateNotFound(responseJsonNode,inputName);
    }

    @Then("Validate the Coord Application Update service response keeping switch status from Reviewed to Partially Close {string}")
    public void validateTheResponseCodeTransitionStatusReviewedToPartiallyClose(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        validatePredefinedContains(inputs,inputs.get(STATUS));
    }

    @Then("Validate the Coord Application Update service response keeping switch status from Partially Close to Close {string}")
    public void validateTheResponseCodeTransitionStatusPartiallyCloseToClose(String inputName){
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        validatePredefinedContains(inputs,inputs.get(STATUS));
    }

    @Then("Validate the Coord Application Update service response keeping switch status from Close to Remove {string}")
    public void validateTheResponseCodeTransitionStatusCloseToRemove(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        validatePredefinedContains(inputs,inputs.get(STATUS));
    }

    @Then("Validate the Coord Application Update service response keeping switch status from Remove to Reviewed {string}")
    public void validateTheResponseCodeTransitionStatusRemoveToReviewed(String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        validatePredefinedContains(inputs,inputs.get(STATUS));
    }

    @Then("Validate the error message for forbidden user for update status {string}")
    public void validateTheErrorMessageForForbiddenUserForUpdateStatus(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assert.assertEquals(FORBIDDEN,responseJsonNode.get(RESPONSE_STATUS).asText());
        Assert.assertEquals(inputs.get(ERROR_MESSAGES).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }

    @When("E2E User sends request to update FI status for input {string}, status {string} and verify response code")
    public void userSendsRequestToAddNotesUsingInputAndVerifyResponseCode1(String inputName, String status) throws JsonProcessingException {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String path = inputsAsJsonNode.get(PATH).asText();
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        ObjectMapper mapper = new ObjectMapper();
        JsonNode requestInput = mapper.createObjectNode();
        ObjectNode testInput = ((ObjectNode) requestInput);
        testInput.put(RESPONSE_CODE, "200");
        testInput.put(BRAND, inputs.get(BRAND));
        testInput.put(REFERENCE_NUMBER,inputs.get(REFERENCE_NUMBER));
        testInput.put(FI_REQUEST_ID,inputs.get(FIREQUEST_ID));
        testInput.put(STATUS,status);
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(testInput, request, path);
        response = request
                .headers(CucumberTestProperties.getHeaders(testInput))
                .put(inputsAsJsonNode.get(PATH).asText());
        System.out.println("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @When("E2E User sends request to get FI for {string} status {string} and verify response code")
    public void getFIList(String inputName, String status) throws JsonProcessingException {
        RestAssured.baseURI = CucumberTestProperties.getApplicationTrackingURI();
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        ObjectMapper mapper = new ObjectMapper();
        JsonNode requestInput = mapper.createObjectNode();
        ObjectNode testInput = ((ObjectNode) requestInput);
        testInput.put(RESPONSE_CODE, "200");
        testInput.put(BRAND, inputs.get(BRAND));
        testInput.put(REFERENCE_NUMBER, inputs.get(REFERENCE_NUMBER));
        testInput.put(REQUEST_ID, inputs.get(FIREQUEST_ID));
        testInput.put(STATUS,status);
        String GET_PATH = "/application/{referenceNumber}/filist";
        String path = inputsAsJsonNode.get(PATH).asText();
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .headers(CucumberTestProperties.getHeaders(testInput,"AT"))
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        ApiTestUtil.createRequestForInputParams(testInput, request, GET_PATH);
        response = request.get(GET_PATH);
        System.out.println("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @Then("E2E Validate that the document for input {string} having state {string} with status {string}")
    public void verifyDocumentStatusAndState(String inputName, String state, String status) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assert.assertEquals(inputs.get(REFERENCE_NUMBER).asText(),responseJsonNode.get(REFERENCE_NUMBER).asText());
        Assert.assertEquals(inputs.get(FIREQUEST_ID).asText(),responseJsonNode.get(DOCUMENTS).get(0).get(REQUEST_ID).asText());
        Assert.assertEquals(status,responseJsonNode.get(DOCUMENTS).get(0).get(STATUS).asText());
        Assert.assertEquals(state,responseJsonNode.get(DOCUMENTS).get(0).get(STATE).asText());
    }


    @Then("Validate API will throw an error if we use originalFileName and customerResponse for closing the state {string}")
    public void validateAPIWillThrowAnErrorIfWeUseOriginalFileNameAndCustomerResponseForClosingTheState(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGES).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }
}