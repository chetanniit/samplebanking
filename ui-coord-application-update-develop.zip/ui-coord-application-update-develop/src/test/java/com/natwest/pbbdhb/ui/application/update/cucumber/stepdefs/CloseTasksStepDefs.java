package com.natwest.pbbdhb.ui.application.update.cucumber.stepdefs;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.CucumberTestProperties;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.junit.jupiter.api.Assertions;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;

import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.CLOSE_TASK_INPUT_JSON;
import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.Params.*;

@Slf4j

public class CloseTasksStepDefs {

    private JsonNode inputsAsJsonNode;
    private JsonNode responseJsonNode;
    private String responseString;
    private Response response;

    @Before
    public void init() throws IOException {
        inputsAsJsonNode = ApiTestUtil.getInputsAsJsonNode(CLOSE_TASK_INPUT_JSON);
    }

    @Given("all close Task Service endpoint exists")
    public void allCloseTaskServiceEndpointExists() {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String path = inputsAsJsonNode.get(PATH).asText();
        Assertions.assertNotNull(path, "path is null");
    }

    @When("User sends request to close Task using input {string} and verify response code")
    public void userSendsRequestToCloseTaskUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        String path = inputsAsJsonNode.get(PATH).asText();
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .accept(ContentType.JSON);
        JsonNode testInput = inputsAsJsonNode.get(inputName);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(testInput, request, path);
        response = request
                .headers(CucumberTestProperties.getHeaders(testInput))
                .put(inputsAsJsonNode.get(PATH).asText());
        System.out.println("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @Then("Verify the response code all correct request parameters for the close Task end point input {string}")
    public void verifyTheResponseCodeAllCorrectRequestParametersForTheCloseTaskEndPointInput(String inputName) {
        Assertions.assertEquals(CLOSE_TASK_CREATION_MESSAGE + " "+"on 2022-11-25T18:30Z", responseString);
    }

    @Then("Verify the response code invalid value for reference number for the close Task end point input {string}")
    public void verifyTheResponseCodeInvalidValueForReferenceNumberForTheCloseTaskEndPointInput(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGE).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }

    @Then("Verify the response code invalid format for date & time for the close Task end point input {string}")
    public void verifyTheResponseCodeInvalidFormatForDateTimeForTheCloseTaskEndPointInput(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGE).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }

    @Then("Verify the response code invalid value for operator name for the close Task end point input {string}")
    public void verifyTheResponseCodeInvalidValueForOperatorNameForTheCloseTaskEndPointInput(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGE).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }

    @Then("Verify the response code invalid value for operatorRACFID for the close Task end point input {string}")
    public void verifyTheResponseCodeInvalidValueForOperatorRACFIDForTheCloseTaskEndPointInput(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGE).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }

    @Then("Verify the response code invalid value for application SequenceNumber for the close Task end point input {string}")
    public void verifyTheResponseCodeInvalidValueForApplicationSequenceNumberForTheCloseTaskEndPointInput(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGE).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }

    @Then("Verify the response code invalid value for stage Number for the close Task end point input {string}")
    public void verifyTheResponseCodeInvalidValueForStageNumberForTheCloseTaskEndPointInput(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGE).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }

    @Then("Verify the response code invalid value for taskId for the close Task end point input {string}")
    public void verifyTheResponseCodeInvalidValueForTaskIdForTheCloseTaskEndPointInput(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGE).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }

    @Then("Verify the response code invalid value for taskCode for the close Task end point input {string}")
    public void verifyTheResponseCodeInvalidValueForTaskCodeForTheCloseTaskEndPointInput(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGE).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }

    @Then("Validate the error code & message in the close task response if the RACF ID is invalid {string}")
    public void validateTheErrorCodeMessageInTheCloseTaskResponseIfTheRACFIDIsInvalid(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(NOT_FOUND, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGE).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }

    @Then("Validate the error code & message in the close task response if the RACF ID has no permission to close the task {string}")
    public void validateTheErrorCodeMessageInTheCloseTaskResponseIfTheRACFIDHasNoPermissionToCloseTheTask(String inputName) throws JsonProcessingException{
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(FORBIDDEN, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGE).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }

    @Then("Validate the error code & message in the close task response when the task is already closed {string}")
    public void validateTheErrorCodeMessageInTheCloseTaskResponseWhenTheTaskIsAlreadyClosed(String inputName) throws JsonProcessingException{
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(PRECONDITION_FAILED, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGE).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }
}
