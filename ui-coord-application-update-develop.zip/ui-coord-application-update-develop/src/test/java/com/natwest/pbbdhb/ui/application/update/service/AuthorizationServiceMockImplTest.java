package com.natwest.pbbdhb.ui.application.update.service;


import com.natwest.pbbdhb.ui.application.update.model.dto.response.userinformation.UserInformationResponse;
import com.natwest.pbbdhb.ui.application.update.service.auth.UserMockService;
import com.natwest.pbbdhb.ui.application.update.service.auth.impl.AuthorizationServiceMockImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AuthorizationServiceMockImplTest {

    @InjectMocks
    private AuthorizationServiceMockImpl service;

    @Mock
    private UserMockService userService;

    private UserInformationResponse userInfo;

    @BeforeEach
    public void setup() {
        userInfo = UserInformationResponse.builder()
                .isMCCUser(true)
                .isUWUser(true)
                .isMopsUser(false)
                .isUWLead(true)
                .isDocViewer(true)
                .isMopsDataEntry(false)
                .racfID("mockRacfId")
                .username("mockUsername")
                .build();
        Mockito.doReturn(userInfo).when(userService).getMockUser();
    }

    @Test
    void testMockAuthImpl() {
        Assertions.assertEquals(userInfo.getUsername(), service.getUsername());
        Assertions.assertEquals(userInfo.isMCCUser(), service.isMCCUser());
        Assertions.assertEquals(userInfo.isMopsUser(), service.isMopsUser());
        Assertions.assertEquals(userInfo.isUWUser(), service.isUWUser());
        Assertions.assertEquals(userInfo.isMopsDataEntry(), service.isMopsDataEntry());
        Assertions.assertEquals(userInfo.getRacfID(), service.getRacfId());
        Assertions.assertThrows(UnsupportedOperationException.class, () -> service.getUserPrincipal());
        Assertions.assertEquals(userInfo, service.getUserData());
        Assertions.assertFalse(service.isDevTestUser());
    }

    @Test
    void testIsUWUser() {
        userInfo.setUWUser(true);
        userInfo.setMCCUser(false);
        when(userService.getMockUser()).thenReturn(userInfo);
        Assertions.assertTrue(service.isUWUser());
    }

    @Test
    void testIsMCCUser() {
        userInfo.setUWUser(false);
        userInfo.setMCCUser(true);
        when(userService.getMockUser()).thenReturn(userInfo);
        Assertions.assertTrue(service.isMCCUser());
    }

    @Test
    void testIsMopsUser() {
        userInfo.setUWUser(false);
        userInfo.setMCCUser(false);
        userInfo.setMopsUser(true);
        when(userService.getMockUser()).thenReturn(userInfo);
        Assertions.assertTrue(service.isMopsUser());
    }

    @Test
    void testIsUWLeadUser() {
        userInfo.setUWUser(false);
        userInfo.setMCCUser(false);
        userInfo.setUWLead(true);
        when(userService.getMockUser()).thenReturn(userInfo);
        Assertions.assertTrue(service.isUWLead());
        Assertions.assertTrue(service.isUWUser());
    }

    @Test
    void testIsDocViewer() {
        userInfo.setUWUser(false);
        userInfo.setMCCUser(false);
        userInfo.setDocViewer(true);
        when(userService.getMockUser()).thenReturn(userInfo);
        Assertions.assertTrue(service.isDocViewer());
    }

    @Test
    void testIsMopsDataEntryUser() {
        userInfo.setUWUser(false);
        userInfo.setMCCUser(false);
        userInfo.setMopsDataEntry(true);
        when(userService.getMockUser()).thenReturn(userInfo);
        Assertions.assertTrue(service.isMopsDataEntry());
    }

    @Test
    void testIsMAUser(){
        userInfo.setMCCUser(false);
        userInfo.setUWUser(false);
        userInfo.setMopsUser(false);
        userInfo.setUWLead(false);
        userInfo.setDocViewer(false);
        userInfo.setMopsDataEntry(false);
        userInfo.setMAUser(true);
        when(userService.getMockUser()).thenReturn(userInfo);
        Assertions.assertTrue(service.isMAUser());
    }

    @Test
    void testIsCINUser(){
        userInfo.setMCCUser(false);
        userInfo.setUWUser(false);
        userInfo.setMopsUser(false);
        userInfo.setUWLead(false);
        userInfo.setDocViewer(false);
        userInfo.setMopsDataEntry(false);
        userInfo.setMAUser(false);
        userInfo.setCINUser(true);
        when(userService.getMockUser()).thenReturn(userInfo);
        Assertions.assertTrue(service.isCINUser());
    }


    @Test
    void testIsRBSIUser(){
        userInfo.setMCCUser(false);
        userInfo.setUWUser(false);
        userInfo.setMopsUser(false);
        userInfo.setUWLead(false);
        userInfo.setDocViewer(false);
        userInfo.setMopsDataEntry(false);
        userInfo.setMAUser(false);
        userInfo.setCINUser(false);
        userInfo.setRBSIUser(true);
        when(userService.getMockUser()).thenReturn(userInfo);
        Assertions.assertTrue(service.isRBSIUser());
    }

}