package com.natwest.pbbdhb.ui.application.update.cucumber.stepdefs;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.CucumberTestProperties;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.commons.lang.StringUtils;
import org.junit.jupiter.api.Assertions;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.ADD_TASK_INPUT_JSON;
import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.Params.*;

@Slf4j
public class AddTasksStepDefs {
    private JsonNode inputsAsJsonNode;
    private JsonNode responseJsonNode;
    private String responseString;
    private Response response;

    @Before
    public void init() throws IOException {
        inputsAsJsonNode = ApiTestUtil.getInputsAsJsonNode(ADD_TASK_INPUT_JSON);
    }
    @Given("all add Task Service endpoint exists")
    public void allAddTaskServiceEndpointExists() {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String path = inputsAsJsonNode.get(PATH).asText();
        Assertions.assertNotNull(path, "path is null");
    }
    @When("User sends request to add Task using input {string} and verify response code")
    public void userSendsRequestToAddTaskUsingInputAndVerifyResponseCode(String inputName) throws JsonProcessingException {
        String path = inputsAsJsonNode.get(PATH).asText();
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .accept(ContentType.JSON);
        JsonNode testInput = inputsAsJsonNode.get(inputName);
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(testInput, request, path);
        response = request
                .headers(CucumberTestProperties.getHeaders(testInput))
                .post(inputsAsJsonNode.get(PATH).asText());
        System.out.println("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }
    @Then("Verify reference number as a request input parameter which accepts Ten digit numeric number only for the add Task end point input {string}")
    public void verifyReferenceNumberAsARequestInputParameterWhichAcceptsTenDigitNumericNumberOnlyForTheAddTaskEndPointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_TASK_NOTE_CREATION_MESSAGE));
    }
    @Then("Verify applicationSequenceNumber as a request input parameter which accepts  numbers only for the add Task end point input {string}")
    public void verifyApplicationSequenceNumberAsARequestInputParameterWhichAcceptsNumbersOnlyForTheAddTaskEndPointInput(String inputName) {
        Assertions.assertTrue(responseString.contains(ADD_TASK_NOTE_CREATION_MESSAGE));
    }
    @Then("Verify Task Name as a request input parameter which should not be null for the add Task end point input {string}")
    public void verifyTaskNameAsARequestInputParameterWhichShouldNotBeNullForTheAddTaskEndPointInput(String inputName) {
        Assertions.assertTrue(responseString.contains(ADD_TASK_NOTE_CREATION_MESSAGE));
    }
    @Then("Verify Date as a request input parameter which accepts present or future date only in ISO standard for the add Task end point input {string}")
    public void verifyDateAsARequestInputParameterWhichAcceptsPresentOrFutureDateOnlyInISOStandardForTheAddTaskEndPointInput(String inputName) {
        Assertions.assertTrue(responseString.contains(ADD_TASK_NOTE_CREATION_MESSAGE));
    }
    @Then("Verify Stage number as a request input parameter which accepts numbers only for the add Task end point input {string}")
    public void verifyStageNumberAsARequestInputParameterWhichAcceptsNumbersOnlyForTheAddTaskEndPointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_TASK_NOTE_CREATION_MESSAGE));
    }
    @Then("Verify Operator Name as a request input parameter which accepts Letters only with space only for the add Task end point input {string}")
    public void verifyOperatorNameAsARequestInputParameterWhichAcceptsLettersOnlyWithSpaceOnlyForTheAddTaskEndPointInput(String inputName) {
        Assertions.assertTrue(responseString.contains(ADD_TASK_NOTE_CREATION_MESSAGE));
    }
    @Then("Verify operatorRACFID as a request input parameter which accepts Letters only without space only for the add Task end point input {string}")
    public void verifyOperatorRACFIDAsARequestInputParameterWhichAcceptsLettersOnlyWithoutSpaceOnlyForTheAddTaskEndPointInput(String inputName) {
        Assertions.assertTrue(responseString.contains(ADD_TASK_NOTE_CREATION_MESSAGE));
    }
    @Then("Verify Response code with message Task been added successfully in the output while request the valid entry of data for the add Task end point input {string}")
    public void verifyResponseCodeWithMessageTaskBeenAddedSuccessfullyInTheOutputWhileRequestTheValidEntryOfDataForTheAddTaskEndPointInput(String inputName) {
        Assertions.assertTrue(responseString.contains(ADD_TASK_NOTE_CREATION_MESSAGE));
    }
    @Then("Verify Application Update service response for the reference number having more than Ten digits for the add Task end point input {string}")
    public void verifyApplicationUpdateServiceResponseForTheReferenceNumberHavingMoreThanTenDigitsForTheAddTaskEndPointInput(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGE).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }
    @Then("Verify Application Update service response for the applicationSequenceNumber having alphabets for the add Task end point input {string}")
    public void verifyApplicationUpdateServiceResponseForTheApplicationSequenceNumberHavingAlphabetsForTheAddTaskEndPointInput(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGE).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }
    @Then("Verify Application Update service response for the Stage Number having alphabets for the add Task end point input {string}")
    public void verifyApplicationUpdateServiceResponseForTheStageNumberHavingAlphabetsForTheAddTaskEndPointInput(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGE).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }
    @Then("Verify Application Update service response for the Operator Name having number for the add Task end point input {string}")
    public void verifyApplicationUpdateServiceResponseForTheOperatorNameHavingNumberForTheAddTaskEndPointInput(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGE).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }
    @Then("Verify Application Update service response for the operatorRACFID having number for the add Task end point input {string}")
    public void verifyApplicationUpdateServiceResponseForTheOperatorRACFIDHavingNumberForTheAddTaskEndPointInput(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGE).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }
    @Then("Verify response for the invalid entry of date for the add Task end point input {string}")
    public void verifyResponseForTheInvalidEntryOfDateForTheAddTaskEndPointInput(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGE).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }
    @Then("Verify the response code invalid value for taskCode for the add Task end point input {string}")
    public void verifyTheResponseCodeInvalidValueForTaskCodeForTheAddTaskEndPointInput(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGE).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }
    @Then("Verify reference number as a request input parameter {int} digit number for the add task note point input {string}")
    public void verifyReferenceNumberAsARequestInputParameterDigitNumberForTheAddTaskNotePointInput(int arg0, String arg1) {
        Assertions.assertTrue(responseString.contains(ADD_TASK_NOTE_CREATION_MESSAGE));
    }
    @Then("Verify applicationSequenceNumber as a request input parameter number for the add task note point input {string}")
    public void verifyApplicationSequenceNumberAsARequestInputParameterNumberForTheAddTaskNotePointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_TASK_NOTE_CREATION_MESSAGE));
    }
    @Then("Verify document required having alpha numeric with special characters to max length of {int} as a request input parameter for the add task note point input {string}")
    public void verifyDocumentRequiredHavingAlphaNumericWithSpecialCharactersToMaxLengthOfAsARequestInputParameterForTheAddTaskNotePointInput(int arg0, String arg1) {
        Assertions.assertTrue(responseString.contains(ADD_TASK_NOTE_CREATION_MESSAGE));
    }
    @Then("Verify required for as a request input parameter number for the add task note point input {string}")
    public void verifyRequiredForAsARequestInputParameterNumberForTheAddTaskNotePointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_TASK_NOTE_CREATION_MESSAGE));
    }
    @Then("Verify from date as a request input parameter for the add task note point input {string}")
    public void verifyFromDateAsARequestInputParameterForTheAddTaskNotePointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_TASK_NOTE_CREATION_MESSAGE));
    }
    @Then("Verify to date as a request input parameter number for the add task note point input {string}")
    public void verifyToDateAsARequestInputParameterNumberForTheAddTaskNotePointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_TASK_NOTE_CREATION_MESSAGE));
    }
    @Then("Verify duration having alpha numeric with special characters of max {int} as a request input parameter for the add task note point input {string}")
    public void verifyDurationHavingAlphaNumericWithSpecialCharactersOfMaxAsARequestInputParameterForTheAddTaskNotePointInput(int arg0, String arg1) {
        Assertions.assertTrue(responseString.contains(ADD_TASK_NOTE_CREATION_MESSAGE));
    }
    @Then("Verify reason having alpha numeric with special characters of max {int} as a request input parameter number for the add task note point input {string}")
    public void verifyReasonHavingAlphaNumericWithSpecialCharactersOfMaxAsARequestInputParameterNumberForTheAddTaskNotePointInput(int arg0, String arg1) {
        Assertions.assertTrue(responseString.contains(ADD_TASK_NOTE_CREATION_MESSAGE));
    }
    @Then("Verify description as a request input parameter for the add task note point input {string}")
    public void verifyDescriptionAsARequestInputParameterForTheAddTaskNotePointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_TASK_NOTE_CREATION_MESSAGE));
    }
    @Then("Verify due date as a request input parameter number for the add task note point input {string}")
    public void verifyDueDateAsARequestInputParameterNumberForTheAddTaskNotePointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_TASK_NOTE_CREATION_MESSAGE));
    }
    @Then("Verify mandatory reason field only as a request input parameter for the add task note point input {string}")
    public void verifyMandatoryReasonFieldOnlyAsARequestInputParameterForTheAddTaskNotePointInput(String arg0) {
        Assertions.assertTrue(responseString.contains(ADD_TASK_NOTE_CREATION_MESSAGE));
    }
    @Then("Verify response for the invalid entry of from date for the add Task note end point input {string}")
    public void verifyResponseForTheInvalidEntryOfFromDateForTheAddTaskNoteEndPointInput(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGE).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }
    @Then("Verify response for the invalid entry of to date for the add Task note end point input {string}")
    public void verifyResponseForTheInvalidEntryOfToDateForTheAddTaskNoteEndPointInput(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGE).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }
    @Then("Verify response for the from date is invalid date format for the add Task note end point input {string}")
    public void verifyResponseForTheFromDateIsInvalidDateFormatForTheAddTaskNoteEndPointInput(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGE).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }
    @Then("Verify response for the to date is is invalid date format for the add Task note end point input {string}")
    public void verifyResponseForTheToDateIsIsInvalidDateFormatForTheAddTaskNoteEndPointInput(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGE).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }
    @Then("Verify response for the invalid entry of due date for the add Task note end point input {string}")
    public void verifyResponseForTheInvalidEntryOfDueDateForTheAddTaskNoteEndPointInput(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGE).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }
    @Then("Verify without mandatory reason field only as a request input parameter for the add task note point input {string}")
    public void verifyWithoutMandatoryReasonFieldOnlyAsARequestInputParameterForTheAddTaskNotePointInput(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGE).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }
    @Then("Verify response for the max length of more than {int} chars in duration for the add Task note end point input {string}")
    public void verifyResponseForTheMaxLengthOfMoreThanCharsInDurationForTheAddTaskNoteEndPointInput(int arg0, String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGE).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }
    @Then("Verify response for the max length more than {int} chars in reason for the add Task note end point input {string}")
    public void verifyResponseForTheMaxLengthMoreThanCharsInReasonForTheAddTaskNoteEndPointInput(int arg0, String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGE).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }
    @Then("Verify response for no values entered in reason,due date,from date and to date for the add Task note end point input {string}")
    public void verifyResponseForNoValuesEnteredInReasonDueDateFromDateAndToDateForTheAddTaskNoteEndPointInput(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        String[] errorMessage = inputs.get(ERROR_MESSAGE).asText().split(",");
        String responseError = "";
        for(int i=0;i<responseJsonNode.get(ERROR_MESSAGES).size();i++){
            responseError +=responseJsonNode.get(ERROR_MESSAGES).get(i);
        }
        for(String error:errorMessage){
            Assertions.assertTrue(responseError.contains(error));
        }
        Assertions.assertEquals(4, responseJsonNode.get(ERROR_MESSAGES).size());
     }
       @Then("Validate the error code & message in the add task response if the RACF ID is invalid {string}")
    public void validateTheErrorCodeMessageInTheAddTaskResponseIfTheRACFIDIsInvalid(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(NOT_FOUND, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGE).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }

    @Then("Validate the error code & message in the add task response if the RACF ID has no permission to create the task {string}")
    public void validateTheErrorCodeMessageInTheAddTaskResponseIfTheRACFIDHasNoPermissionToCreateTheTask(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(FORBIDDEN, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals(inputs.get(ERROR_MESSAGE).asText(), responseJsonNode.get(ERROR_MESSAGES).get(0).asText());
    }

    @Then("Validate the taskID in the add task response on successful addition of task {string}")
    public void validateTheTaskIDInTheAddTaskResponseOnSuccessfulAdditionOfTask(String inputName) {
        //Assertions.assertEquals(ADD_TASK_CREATION_MESSAGE, responseString);
        String lastElement = StringUtils.substringAfterLast(responseString, " ");
        List<String> listOfTaskIds = Arrays.asList(lastElement.split(","));
        listOfTaskIds.forEach(taskId ->
            Assertions.assertTrue(taskId.matches("\\d+"))
        );
    }
}