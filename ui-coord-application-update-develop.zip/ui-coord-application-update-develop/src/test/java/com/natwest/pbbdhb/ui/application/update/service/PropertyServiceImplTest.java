package com.natwest.pbbdhb.ui.application.update.service;

import com.natwest.pbbdhb.property.dto.PropertyDetailsDto;
import com.natwest.pbbdhb.ui.application.update.converter.JsonPatchHttpMessageConverter;
import com.natwest.pbbdhb.ui.application.update.mapper.PropertyDetailsDtoMapper;
import com.natwest.pbbdhb.ui.application.update.model.dto.exception.PreConditionFailedException;
import com.natwest.pbbdhb.ui.application.update.service.impl.PropertyServiceImpl;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import javax.json.Json;
import javax.json.JsonPatch;
import javax.json.JsonReader;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

import static com.natwest.pbbdhb.ui.application.update.util.TestConstants.CASE_ID;
import static com.natwest.pbbdhb.ui.application.update.util.TestConstants.NWB_BRAND;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.WARN)
public class PropertyServiceImplTest {

    @InjectMocks
    private PropertyServiceImpl service;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private JsonPatchHttpMessageConverter converter;

    @Mock
    private PropertyDetailsDtoMapper mapper;

    @Mock
    private JsonPatch jsonPatch;

    @AfterEach
    void verifyAfter() {
        verifyNoMoreInteractions(restTemplate);
    }

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        ReflectionTestUtils.setField(service, "propertyServiceParentEndpoint", "https://v1-msvc-property-dev.edi02-apps.dev-pcf.lb4.rbsgrp.net");
        ReflectionTestUtils.setField(service, "propertyInformationEndpoint", "/v1/properties/caseId");
    }

    @Test
    void testUpdatePropertyInformation() {
        PropertyDetailsDto request = PropertyDetailsDto.builder().caseId("caseId").build();
        when(restTemplate.exchange(any(), any(), any(), eq(PropertyDetailsDto.class)))
                .thenReturn(new ResponseEntity<>(Mockito.mock(PropertyDetailsDto.class), HttpStatus.OK));
        when(mapper.toPropertyDetailsDto(any())).thenReturn(Mockito.mock(PropertyDetailsDto.class));
        PropertyDetailsDto response = service.updatePropertyInformation(NWB_BRAND, "caseId", request);
        assertNotNull(response);
        verify(restTemplate).exchange(any(), any(), any(), eq(PropertyDetailsDto.class));
    }


    @Test
    void testUpdatePropertyInformationException() {
        PropertyDetailsDto request = PropertyDetailsDto.builder().caseId("caseId").build();
        when(restTemplate.exchange(any(), any(), any(), eq(PropertyDetailsDto.class)))
                .thenThrow(HttpClientErrorException.class);
        when(mapper.toPropertyDetailsDto(any())).thenReturn(Mockito.mock(PropertyDetailsDto.class));
        HttpClientErrorException exception = assertThrows(HttpClientErrorException.class,
                () -> service.updatePropertyInformation(NWB_BRAND, "caseId", request));
        verify(restTemplate).exchange(any(), any(), any(), eq(PropertyDetailsDto.class));
    }

    @Test
    void testPatchUpdatePropertyInformation() throws IOException {
        String validBody = "[{\"op\": \"replace\", \"path\": \"/whenBuilt\", \"value\": \"1995\" }]";
        JsonPatch jsonPatch = jsonStringToJsonPatch(validBody);
        when(restTemplate.exchange(any(), any(), any(), eq(PropertyDetailsDto.class)))
                .thenReturn(new ResponseEntity<>(Mockito.mock(PropertyDetailsDto.class), HttpStatus.OK));
        PropertyDetailsDto response = service.patchUpdatePropertyInformation(NWB_BRAND, "caseId", jsonPatch);
        assertNotNull(response);
        verify(restTemplate).exchange(any(), any(), any(), eq(PropertyDetailsDto.class));
    }

    @Test
    void testPatchUpdatePropertyInformationException() throws IOException {
        String validBody = "[{\"op\": \"replace\", \"path\": \"/whenBuilt\", \"value\": \"1995\" }]";
        JsonPatch jsonPatch = jsonStringToJsonPatch(validBody);
        when(restTemplate.exchange(any(), any(), any(), eq(PropertyDetailsDto.class)))
                .thenThrow(HttpClientErrorException.class);
        HttpClientErrorException exception = assertThrows(HttpClientErrorException.class,
                () -> service.patchUpdatePropertyInformation(NWB_BRAND, "caseId", jsonPatch));
        verify(restTemplate).exchange(any(), any(), any(), eq(PropertyDetailsDto.class));
    }

    @Test
    void testUpdatePropertyInformationPreConditionFailedException() {
        PropertyDetailsDto request = PropertyDetailsDto.builder().build();
        assertThrows(PreConditionFailedException.class,
                () -> service.updatePropertyInformation(NWB_BRAND, CASE_ID, request));
        verifyNoInteractions(restTemplate);
    }

    private JsonPatch jsonStringToJsonPatch(String jsonString) throws IOException {
        InputStream in = new ByteArrayInputStream(jsonString.getBytes());
        JsonReader reader = Json.createReader(in);
        return Json.createPatch(reader.readArray());
    }
}
