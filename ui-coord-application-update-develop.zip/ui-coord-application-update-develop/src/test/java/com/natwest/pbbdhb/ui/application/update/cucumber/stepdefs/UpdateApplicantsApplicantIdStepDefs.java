package com.natwest.pbbdhb.ui.application.update.cucumber.stepdefs;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants;
import com.natwest.pbbdhb.ui.application.update.cucumber.config.CucumberTestProperties;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;

import java.io.IOException;
import java.util.ArrayList;

import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.PUT_UPDATE_APPLICANTS_APPLICANT_ID_JSON;
import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.Params.*;
import static com.natwest.pbbdhb.ui.application.update.cucumber.config.ApiTestConstants.Params.ERROR_MESSAGES;

@Slf4j
public class UpdateApplicantsApplicantIdStepDefs {

    private JsonNode inputsAsJsonNode;
    private JsonNode responseJsonNode;
    private String responseString;
    private Response response;
    private String applicantVersion;

    @Before
    public void init() throws IOException {
        inputsAsJsonNode = ApiTestUtil.getInputsAsJsonNode(PUT_UPDATE_APPLICANTS_APPLICANT_ID_JSON);
    }

    @Given("UpdateApplicantsInformation Service applicant id endpoint exists")
    public void updateApplicantsInformationServiceEndpointExists() {
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        String path = inputsAsJsonNode.get(PATH).asText();
        Assertions.assertNotNull(path, "path is null");
    }

    private void validateBadRequest(String inputName) throws JsonProcessingException {
        JsonNode responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(BAD_REQUEST, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        validateResponseErrorContains(responseJsonNode, inputs.get(ERROR_MESSAGES));
    }

    private void validateNotFound(JsonNode responseJsonNode, String inputName) {
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertEquals("NOT_FOUND", responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode error_message_Array = responseJsonNode.get(ERROR_MESSAGE).get(0);
        Assertions.assertTrue(error_message_Array.asText().contains(inputs.get(ERROR_MESSAGE).asText()));
    }

    private void validateResponseErrorContains(JsonNode inputs, JsonNode itemSearched) {
        validateArrayContains(inputs, itemSearched, ERROR_MESSAGES);
    }

    private void validateArrayContains(JsonNode array, JsonNode itemSearched, String inputField) {
        ArrayList<String> predefined = new ObjectMapper().convertValue(array.get(inputField), ArrayList.class);
        Assertions.assertTrue(predefined.contains(itemSearched.asText()));
    }

    private void validatePreconditionFailed(String inputName) throws JsonProcessingException {
        JsonNode responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertEquals(PRECONDITION_FAILED, responseJsonNode.get(RESPONSE_STATUS).asText());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        String error = inputs.get(ERROR_MESSAGES).asText();
        Assertions.assertEquals(responseJsonNode.get(ERROR_MESSAGES).get(0).asText(),error);
    }

    @When("UpdateApplicantsInformation - User sends applicant id request to put applicant information using input {string} and verify response code")
    public void updateApplicantsInformationApplicantid(String inputName) throws JsonProcessingException {
        String path = inputsAsJsonNode.get(PATH).asText();
        RestAssured.baseURI = CucumberTestProperties.getBaseURI();
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .accept(ContentType.JSON);
        JsonNode testInput = inputsAsJsonNode.get(inputName);
        if(CucumberTestProperties.getTestEnvName().equals("UAT")){
            testInput = (inputsAsJsonNode.get(inputName+"UAT") != null ) ? inputsAsJsonNode.get(inputName+"UAT") : testInput;
        }
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(testInput);
        DocumentContext doc = JsonPath.parse(json);
        if(applicantVersion == null){
            applicantVersion = testInput.get(REQUEST_BODY).get(VERSION).asText();
        }
        doc.set("requestBody.version", applicantVersion);
        JsonNode updatedInput = new ObjectMapper().readTree(doc.jsonString());
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(updatedInput, request, path);
        response = request.headers(CucumberTestProperties.getHeaders(updatedInput)).put(inputsAsJsonNode.get(PATH).asText());
        System.out.println("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
    }

    @When("UpdateApplicantsInformation - User sends applicant id request to get applicant information using input {string} and verify response code")
    public void getApplicantsInformationApplicantid(String inputName) throws JsonProcessingException {
        String get_path = "/capie/applicants/{applicantId}";
        RestAssured.baseURI = CucumberTestProperties.getApplicationTrackingURI();
        RequestSpecification request = RestAssured.given()
                .log().all()
                .header(CONTENT_TYPE, CucumberTestProperties.getContentHeader())
                .header(IAM_CLAIMSETJWT, CucumberTestProperties.getJWTTokenUICoordAppTracking())
                .accept(ContentType.JSON);
        JsonNode testInput = inputsAsJsonNode.get(inputName);
        if(CucumberTestProperties.getTestEnvName().equals("UAT")){
            testInput = (inputsAsJsonNode.get(inputName+"UAT") != null ) ? inputsAsJsonNode.get(inputName+"UAT") : testInput;
        }
        Assertions.assertNotNull(testInput, ApiTestConstants.Errors.INPUTS_MISSING_FOR_SCENARIO);
        ApiTestUtil.createRequestForInputParams(testInput, request, get_path);
        response = request.headers(CucumberTestProperties.getHeaders(testInput,"AT")).get(get_path);
        System.out.println("response " + response);
        log.info(response.getHeaders().asList().toString());
        log.info(response.getBody().prettyPrint());
        Assertions.assertEquals(testInput.get(RESPONSE_CODE).asInt(), response.getStatusCode());
        Assertions.assertNotNull(response, "response is null");
        responseString = response.asString();
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        applicantVersion = responseJsonNode.get(VERSION).asText();
    }

    @Then("Verify applicant information in Put Applicants applicant ID response output for the input {string}")
    public void verifyApplicantsSuccessfulResponseApplicant1(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertNotNull(response, "response is null");
        Assertions.assertEquals(200, response.getStatusCode());
        if(StringUtils.equals(inputs.get("brand").asText(), "RBS")) {
            if (CucumberTestProperties.getTestEnvName().equals("UAT")) {
                Assert.assertEquals("633ac907b266424f0e45f8a2", responseJsonNode.get("applicantId").asText());
            } else {
                Assert.assertEquals("630dd8f53ec25a5cfadb9cb9", responseJsonNode.get("applicantId").asText());
            }
        } else {
            if (CucumberTestProperties.getTestEnvName().equals("UAT")) {
                Assert.assertEquals("633acac0b266424f0e45f8b8", responseJsonNode.get("applicantId").asText());
            } else {
                Assert.assertEquals("6305b908c16157390433c631", responseJsonNode.get("applicantId").asText());
            }
        }

        Assert.assertTrue(responseJsonNode.get("mainApplicant").booleanValue());

        JsonNode personalDetails = responseJsonNode.get("personalDetails");
        Assert.assertEquals("Deepak", personalDetails.get("firstNames").asText());
        Assert.assertEquals("Gupta", personalDetails.get("lastName").asText());
        Assert.assertEquals("deepak.gupta2@hcl.com", personalDetails.get("email").asText());
        Assert.assertEquals("Gupta", personalDetails.get("lastName").asText());

        JsonNode telephones = personalDetails.get("telephones");
        Assert.assertEquals("MOBILE", telephones.get(0).get("type").asText());
        Assert.assertEquals("012345628040", telephones.get(0).get("number").asText());
    }

    @Then("Verify error code 409 conflict for the UI Coord Application Update Applicants service response for the input {string}")
    public void verifyApplicantsConflictResponse(String arg0) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        Assertions.assertNotNull(response, "response is null");
        Assertions.assertEquals(409, response.getStatusCode());
    }

    @Then("Verify error code 404 Not Found for the UI Coord Application Update Applicants service response for the input {string}")
    public void verifyApplicantsNotFoundResponse(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.body().asString());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertNotNull(response, "response is null");
        Assertions.assertEquals(404, response.getStatusCode());
        JsonNode error_message_Array = responseJsonNode.get(ERRORS).get(0).get(MESSAGE);
        Assertions.assertTrue(error_message_Array.asText().contains(inputs.get(ERROR_MESSAGES).asText()));
    }

    @Then("Verify error code 400 bad request for the UI Coord Application Update Applicants service response for the input {string}")
    public void verifyApplicantsBadRequestResponse(String inputName) throws JsonProcessingException {
        validateBadRequest(inputName);
    }

    @Then("Verify error code 412 Precondition Failed for the UI Coord Application Update Applicants service response for the input {string}")
    public void verifyApplicantsPreconditionFailedResponse(String inputName) throws JsonProcessingException {
        validatePreconditionFailed(inputName);
    }

    @Then("Verify response code 206 Partial Success for the UI Coord Application Update Applicants service response for the input {string}")
    public void verifyApplicantsPartialSuccessResponse(String inputName) throws JsonProcessingException {
        responseJsonNode = new ObjectMapper().readTree(response.asString());
        JsonNode inputs = inputsAsJsonNode.get(inputName);
        Assertions.assertNotNull(response, "response is null");
        Assertions.assertEquals(200, response.getStatusCode());

        if(StringUtils.equals(inputs.get("brand").asText(), "RBS")) {
            if (CucumberTestProperties.getTestEnvName().equals("UAT")) {
                Assert.assertEquals("633ac907b266424f0e45f8a2", responseJsonNode.get("applicantId").asText());
            } else {
                Assert.assertEquals("630dd8f53ec25a5cfadb9cb9", responseJsonNode.get("applicantId").asText());
            }
        } else {
            if (CucumberTestProperties.getTestEnvName().equals("UAT")) {
                Assert.assertEquals("633acac0b266424f0e45f8b8", responseJsonNode.get("applicantId").asText());
            } else {
                Assert.assertEquals("6304e3d3c16157390433c5f0", responseJsonNode.get("applicantId").asText());
            }
        }
        //Assert.assertEquals("ID20220221100176521101", responseJsonNode.get("caseId").asText());
        Assert.assertTrue(responseJsonNode.get("mainApplicant").booleanValue());

        JsonNode personalDetails = responseJsonNode.get("personalDetails");
        Assert.assertEquals("Deepak", personalDetails.get("firstNames").asText());
        Assert.assertEquals("Gupta", personalDetails.get("lastName").asText());
        Assert.assertEquals("deepak.gupta2@hcl.com", personalDetails.get("email").asText());
        Assert.assertEquals("Gupta", personalDetails.get("lastName").asText());

        JsonNode telephones = personalDetails.get("telephones");
        Assert.assertEquals("MOBILE", telephones.get(0).get("type").asText());
        Assert.assertEquals("012345628040", telephones.get(0).get("number").asText());
    }
}
