package com.natwest.pbbdhb.ui.application.update.service.auth.impl;

import com.natwest.pbbdhb.ui.application.update.model.dto.exception.TokenExpiredException;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.userinformation.UserInformationResponse;
import com.natwest.pbbdhb.ui.application.update.service.auth.AuthorizationService;
import com.natwest.pbbdhb.ui.application.update.service.auth.UserMockService;
import com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants;
import com.rbs.dws.security.UserPrincipal;
import com.rbs.dws.security.UserPrincipalContext;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.StringJoiner;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.JWT_UTILITY;
import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.UTC_TIME_ZONE;

/**
 * Provides methods for Authorisation requests
 */
@Service("authorizationServiceImpl")
@RefreshScope
@Slf4j
@ConditionalOnExpression("!${ids.functional.user.mock:false} or '${hbo.env}' == 'prd'")
public class AuthorizationServiceImpl implements AuthorizationService {

    private static final String SEPARATOR = "_";
    protected static final String MEMBEROF_CLAIM = "clientstaff_wiam02_atm_memberof";
    protected static final String USER_FIRST_NAME = "clientstaff_wiam02_atm_firstname";
    protected static final String USER_LAST_NAME = "clientstaff_wiam02_atm_lastname";
    private static final String IS_VALID_USER_CHECK_DISABLED = "is Valid User check disabled";

    @Value("${ids.functional.user.check:false}")
    private boolean userCheck;

    @Value("${ids.functional.usergroups.mcc}")
    private String mccUserGroup;

    @Value("${ids.functional.usergroups.uw}")
    private String uwUserGroup;

    @Value("${ids.functional.usergroups.mops}")
    private String mopsUserGroup;

    @Value("${ids.functional.usergroups.uwLead}")
    private String uwLeadGroup;

    @Value("${ids.functional.usergroups.docViewer}")
    private String docViewerGroup;

    @Value("${ids.functional.usergroups.mopsDataEntry}")
    private String mopsDataEntryGroup;

    @Value("${ids.functional.usergroups.disassociateDocument}")
    private String disassociateDocumentGroup;

    @Value("${ids.functional.usergroups.pst}")
    private String pstGroup;

    @Value("${ids.functional.usergroups.ma}")
    private String maGroup;

    @Value("${ids.functional.usergroups.cin}")
    private String cinGroup;

    @Value("${ids.functional.usergroups.rbsi}")
    private String rbsiGroup;

    @Value("${ids.functional.user.mock:false}")
    private boolean isMockUserEnabled;

    @Value("${hbo.env}")
    private String currentProfile;

    @Value("${jwt.ms2ms-util}")
    private String jwtTokenUtilCN;

    @Autowired(required = false)
    private UserMockService userMockService;

    @Override
    public UserInformationResponse getUserData() {
        log.info("get user data method enters in AuthorizationServiceImpl class");

        if (isDevTestUser()) {
            return UserInformationResponse.builder()
                    .racfID(JWT_UTILITY)
                    .username(JWT_UTILITY)
                    .build();
        }

        UserPrincipal userPrincipal = getUserPrincipal();
        logUserDetails(userPrincipal);
        Date expiryDate = userPrincipal.getSessionExpiry();
        if (ZonedDateTime.now().isAfter(expiryDate.toInstant().atZone(ZoneId.of(UTC_TIME_ZONE)))) {
            throw new TokenExpiredException(ApplicationConstants.TOKEN_EXPIRED);
        }
        return UserInformationResponse.builder()
                .isMCCUser(isMCCUser())
                .isUWUser(isUWUser())
                .isMopsUser(isMopsUser())
                .isUWLead(isUWLead())
                .isDocViewer(isDocViewer())
                .isMopsDataEntry(isMopsDataEntry())
                .isDocumentDisassociate(isDisassociateDocument())
                .isPSTUser(isPSTUser())
                .isMAUser(isMAUser())
                .isCINUser(isCINUser())
                .isRBSIUser(isRBSIUser())
                .racfID(getRacfId())
                .username(getUsername())
                .userGroups(getUserGroups())
                .build();
    }

    private String[] getUserGroups() {
        log.info("get user groups method enters in AuthorizationServiceImpl class");

        UserPrincipal userPrincipal = getUserPrincipal();
        Object adGroupProperty = userPrincipal.getProperty(MEMBEROF_CLAIM);

        if (adGroupProperty != null && !adGroupProperty.toString().isEmpty()) {
            log.info("Actual group name {}", adGroupProperty);
            return adGroupProperty.toString().split(",");
        } else {
            log.debug("Actual group name is missing");
        }
        return null;
    }

    /**
     * Check if the user is part of the functional groups
     *
     * @return true for MCC Users
     */
    @Override
    public boolean isMCCUser() {
        if (!userCheck) {
            log.debug(IS_VALID_USER_CHECK_DISABLED);
            return true;
        }
        log.info("Checking isMCCUser");
        return hasGroup(mccUserGroup);
    }

    /**
     * Check if the user is part of the functional groups
     *
     * @return true for UW Users
     */
    @Override
    public boolean isUWUser() {
        if (!userCheck) {
            log.debug(IS_VALID_USER_CHECK_DISABLED);
            return true;
        }
        log.info("Checking isUWUser or isUWLead");
        return hasGroup(uwUserGroup) || hasGroup(uwLeadGroup);
    }

    /**
     * Check if the user is part of the functional groups
     *
     * @return true for UW Users
     */
    @Override
    public boolean isMopsUser() {
        if (!userCheck) {
            log.debug(IS_VALID_USER_CHECK_DISABLED);
            return true;
        }
        log.info("Checking isMOPSUser");
        return hasGroup(mopsUserGroup);
    }

    /**
     * To check if user is UWLead
     *
     * @return false as user group is yet to be created for UWLead role
     */
    @Override
    public boolean isUWLead() {
        if (!userCheck) {
            log.debug(IS_VALID_USER_CHECK_DISABLED);
            return true;
        }
        log.info("Checking isUWLeadUser");
        return hasGroup(uwLeadGroup);
    }

    /**
     * To check if user is Docs Viewer
     *
     * @return false as user group is yet to be created for UWLead role
     */
    @Override
    public boolean isDocViewer() {
        if (!userCheck) {
            log.debug(IS_VALID_USER_CHECK_DISABLED);
            return true;
        }
        log.info("Checking isDocViewer");
        return hasGroup(docViewerGroup);
    }

    /**
     * Check if the user is part of the functional groups
     *
     * @return true for UW Users
     */
    @Override
    public boolean isMopsDataEntry() {
        if (!userCheck) {
            log.debug(IS_VALID_USER_CHECK_DISABLED);
            return true;
        }
        log.info("Checking isMopsDataEntry");
        return hasGroup(mopsDataEntryGroup);
    }

    /**
     * Check if user has disassociate document permissions
     * @return
     */
    @Override
    public boolean isDisassociateDocument() {
        if (!userCheck) {
            log.debug(IS_VALID_USER_CHECK_DISABLED);
            return true;
        }
        log.info("Checking isDisassociateDocument");
        return hasGroup(disassociateDocumentGroup);
    }

    /**
     * Checks if user is member of PST Group
     * @return
     */
    @Override
    public boolean isPSTUser() {
        if (!userCheck) {
            log.debug(IS_VALID_USER_CHECK_DISABLED);
            return true;
        }
        log.info("Checking PSTUser");
        return hasGroup(pstGroup);
    }

    /**
     * Checks if user is member of MA Group
     * @return boolean
     */
    @Override
    public boolean isMAUser() {
        if (!userCheck) {
            log.debug(IS_VALID_USER_CHECK_DISABLED);
            return true;
        }
        log.info("Checking MAUser");
        return hasGroup(maGroup);
    }
    /**
     * Checks if user is member of CIN Exceptions Group
     * @return boolean
     */
    @Override
    public boolean isCINUser() {
        if (!userCheck) {
            log.debug(IS_VALID_USER_CHECK_DISABLED);
            return true;
        }
        log.info("Checking CINUser");
        return hasGroup(cinGroup);
    }


    /**
     * Checks if user is member of RBSI Group
     * @return boolean
     */
    @Override
    public boolean isRBSIUser() {
        if (!userCheck) {
            log.debug(IS_VALID_USER_CHECK_DISABLED);
            return true;
        }
        log.info("Checking RBSIUser");
        return hasGroup(rbsiGroup);
    }


    /**
     * Get user details from context
     *
     * @return UserPrincipal
     */
    @Override
    public UserPrincipal getUserPrincipal() {
        UserPrincipal userPrincipal = UserPrincipalContext.get();
        if (null == userPrincipal) {
            log.debug("No UserPrincipal found in UserPrincipalContext");
            throw new UsernameNotFoundException(ApplicationConstants.USER_PRINCIPAL_NOT_FOUND_SSO_NOT_ENABLED);
        }
        log.debug("Logged in UserPrincipal: {}", userPrincipal);
        return userPrincipal;
    }

    /**
     * @return true if User has one the given groups in memberof claim
     */
    private boolean hasAnyGroup(List<String> groups) {
        if (CollectionUtils.isEmpty(groups)) {
            return false;
        }

        boolean canAccess = false;
        UserPrincipal userPrincipal = getUserPrincipal();
        Object adGroupProperty = userPrincipal.getProperty(MEMBEROF_CLAIM);

        if (adGroupProperty != null && !adGroupProperty.toString().isEmpty()) {
            log.debug("Actual group name {}, expected groups {}", adGroupProperty, groups);
            String[] roles = adGroupProperty.toString().split(",");
            for (String role : roles) {
                if (groups.contains(role)) {
                    canAccess = true;
                    break;
                }
            }
        } else {
            log.debug("Actual group name is missing, expected groups {}", groups);
        }

        return canAccess;
    }

    /**
     * @return true if User has the given group in memberof claim
     */
    private boolean hasGroup(String group) {
        if (StringUtils.isEmpty(group)) {
            return false;
        }

        boolean canAccess = false;
        UserPrincipal userPrincipal = getUserPrincipal();
        Object adGroupProperty = userPrincipal.getProperty(MEMBEROF_CLAIM);

        if (adGroupProperty != null && !adGroupProperty.toString().isEmpty()) {
            log.debug("Actual group name {}, expected group {}", adGroupProperty, group);
            String[] roles = adGroupProperty.toString().split(",");
            for (String role : roles) {
                if (role.contains(group)) {
                    canAccess = true;
                    break;
                }
            }
        } else {
            log.debug("Actual group name is missing, expected group {}", group);
        }

        return canAccess;
    }

    /**
     * get userName from userPrincipal
     *
     * @return userName
     */
    @Override
    public String getUsername() {
        UserPrincipal userPrincipal = getUserPrincipal();
        String firstName = (String) userPrincipal.getProperty(USER_FIRST_NAME);

        String lastName = (String) userPrincipal.getProperty(USER_LAST_NAME);
        StringJoiner join = new StringJoiner(" ");
        join.add(firstName);
        join.add(lastName);
        return join.toString();
    }

    private String getUsername(UserPrincipal userPrincipal) {
        final String[] user = userPrincipal.getUserName().split(SEPARATOR);
        return user.length == 2 ? user[1] : userPrincipal.getUserName();
    }

    /**
     * get RacfId from userPrincipal
     *
     * @return userName
     */
    @Override
    public String getRacfId() {
        String username = getUsername(getUserPrincipal());
        if (Objects.nonNull(username)) {
            return username.replace("M01EUROPA_", "");
        }
        return username;
    }

    private void logUserDetails(UserPrincipal userPrincipal) {
        log.debug("****  UserPrincipal Contents ****");
        log.debug("* Username:             '{}'", userPrincipal.getUserName());
        log.debug("* Remote Address:       '{}'", userPrincipal.getRemoteAddress());
        log.debug("* Domain:               '{}'", userPrincipal.getDomain());
        log.debug("* Name:                 '{}'", userPrincipal.getName());
        log.debug("* Authentication Level: '{}'", userPrincipal.getAuthenticationLevel());
        log.debug("* Certificate:          '{}'", userPrincipal.getCertificate());
        log.debug("* Session Expiry:       '{}'", userPrincipal.getSessionExpiry());
        log.debug("* Token:                '{}'", userPrincipal.getToken());
        log.debug("* Properties:");
        userPrincipal.getPropertyKeys()
                .forEach(propertyName -> log.debug("* {}: '{}'", propertyName, userPrincipal.getProperty(propertyName)));
        log.debug("*********************************");
    }

    /**
     * To verify if util token is used to access the API
     *
     * @return true if valid util token is used and from non-prod env, otherwise false.
     */
    @Override
    public boolean isDevTestUser() {
        return !"prd".equalsIgnoreCase(currentProfile) && jwtTokenUtilCN.equalsIgnoreCase(getRacfId());
    }



}