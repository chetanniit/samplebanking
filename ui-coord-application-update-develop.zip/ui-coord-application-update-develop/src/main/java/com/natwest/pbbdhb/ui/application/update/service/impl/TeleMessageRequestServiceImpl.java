package com.natwest.pbbdhb.ui.application.update.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.ui.application.update.mapper.FlowManagerRequestMapper;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.AddTeleMessageRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.flowmanager.FlowManagerAddTeleMessageRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.SuccessResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.userinformation.UserInformationResponse;
import com.natwest.pbbdhb.ui.application.update.service.TeleMessageRequestService;
import com.natwest.pbbdhb.ui.application.update.service.auth.AuthorizationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.BRAND;

/**
 * Service to call addTeleMessageRequest API in flow manager
 */
@Service
@Slf4j
public class TeleMessageRequestServiceImpl implements TeleMessageRequestService {

    @Autowired
    @Qualifier("customSecureRestTemplate")
    private RestTemplate restTemplate;

    @Value("${msvc.flow-manager.parent.endpoint}")
    private String flowManagerParentEndpoint;

    @Value("${msvc.flow-manager.add-telemessage-request.endpoint}")
    private String addTelemessageRequestEndpoint;

    @Autowired
    private AuthorizationService authorizationService;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private FlowManagerRequestMapper flowManagerRequestMapper;

    private UriComponentsBuilder getUriComponentsBuilder(String endpoint, String referenceNumber) {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(endpoint);

        Map<String, Object> urlParams = new HashMap<>();
        urlParams.put("referenceNumber", referenceNumber);
        builder.uriVariables(urlParams);
        log.debug("URL : {} ", builder.toUriString());
        return builder;
    }

    /**
     * Method to add teleMessageRequest in packaging manager
     *
     * @param brand                 - brand
     * @param referenceNumber       - referenceNumber
     * @param addTeleMessageRequest - addTeleMessageRequest
     * @return SuccessResponse
     */
    @Override
    public SuccessResponse addTeleMessageRequest(String brand, String referenceNumber, AddTeleMessageRequest addTeleMessageRequest) {
        log.info("Entered into addTeleMessageRequest method for - brand: {}, referenceNumber: {}", brand, referenceNumber);
        UserInformationResponse userData = authorizationService.getUserData();
        FlowManagerAddTeleMessageRequest flowManagerAddTeleMessageRequest = flowManagerRequestMapper.toFlowManagerAddTeleMessageRequest(addTeleMessageRequest);
        Optional.ofNullable(userData).ifPresent(userInfo -> {
            flowManagerAddTeleMessageRequest.setUserFullName(userData.getUsername());
            flowManagerAddTeleMessageRequest.setUserRACFId(userData.getRacfID());
        });
        String endpoint = flowManagerParentEndpoint + addTelemessageRequestEndpoint;
        UriComponentsBuilder builder = getUriComponentsBuilder(endpoint, referenceNumber);
        HttpHeaders header = new HttpHeaders();
        header.add(BRAND, brand);
        HttpEntity<FlowManagerAddTeleMessageRequest> entity = new HttpEntity<>(flowManagerAddTeleMessageRequest, header);
        log.debug("header set for downstream call: {}, FlowManagerAddTeleMessageRequest :  {}", header, flowManagerAddTeleMessageRequest);
        ResponseEntity<String> responseEntity = restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.POST, entity, String.class);
        SuccessResponse successResponse = null;
        try {
            successResponse = objectMapper.readValue(responseEntity.getBody(), SuccessResponse.class);
        } catch (JsonProcessingException e) {
            log.error("Exception occurred while addTeleMessageResponse object conversion: {}", e.getMessage(), e);
        }
        return successResponse;
    }
}
