package com.natwest.pbbdhb.ui.application.update.model.dto.response.userinformation;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.Parameter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.hateoas.RepresentationModel;
import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.NotNull;

/**
 * This class is used as a response for user Authentication endPoint contains UserInformationResponse details
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Validated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserInformationResponse extends RepresentationModel<UserInformationResponse> {

    @JsonProperty("username")
    @Parameter(required = true)
    @NotNull
    private String username;

    @JsonProperty("isMCCUser")
    @Parameter(required = true)
    @NotNull
    private boolean isMCCUser;

    @JsonProperty("isUWUser")
    @Parameter(required = true)
    @NotNull
    private boolean isUWUser;

    @JsonProperty("isMopsUser")
    @Parameter(required = true)
    @NotNull
    private boolean isMopsUser;

    @JsonProperty("isUWLead")
    @Parameter(required = true)
    @NotNull
    private boolean isUWLead;

    @JsonProperty("isDocViewer")
    @Parameter(required = true)
    @NotNull
    private boolean isDocViewer;

    @JsonProperty("isMopsDataEntry")
    @Parameter(required = true)
    @NotNull
    private boolean isMopsDataEntry;


    @JsonProperty("isDocumentDisassociate")
    @Parameter(required = true)
    @NotNull
    private boolean isDocumentDisassociate;

    @JsonProperty("isPSTUser")
    @Parameter(required = true)
    @NotNull
    private boolean isPSTUser;

    @JsonProperty("isMAUser")
    @Parameter(required = true)
    @NotNull
    private boolean isMAUser;

    @JsonProperty("isCINUser")
    @Parameter(required = true)
    @NotNull
    private boolean isCINUser;

    @JsonProperty("isRBSIUser")
    @Parameter(required = true)
    @NotNull
    private boolean isRBSIUser;

    @JsonProperty("racfID")
    @Parameter(required = true)
    @NotNull
    private String racfID;

    @JsonIgnore
    @Parameter(required = true)
    @NotNull
    private String[] userGroups;
}
