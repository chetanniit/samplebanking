package com.natwest.pbbdhb.ui.application.update.model.dto.response.application;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Application source information object
 */
@Data
@Schema(description = "Source information update object")
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SourceInformationUpdateStatus {
    private String status;
}
