package com.natwest.pbbdhb.ui.application.update.model.dto.enums;

import lombok.AllArgsConstructor;

/**
 * enum class DocumentType contain values needed for downstream service(DocIn)
 **/
@AllArgsConstructor
public enum DocumentType {
    OTHER,
    EECOT,
    FMAMAF,
    SUITCP

}
