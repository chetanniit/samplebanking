package com.natwest.pbbdhb.ui.application.update.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.natwest.pbbdhb.adbo.dto.CaseDetailsDto;
import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.income.expense.model.domain.CaseStatusDto;
import com.natwest.pbbdhb.income.expense.model.expense.request.CaseExpenseDto;
import com.natwest.pbbdhb.income.expense.model.expense.response.ValidatedCaseExpenseDto;
import com.natwest.pbbdhb.income.expense.model.income.request.CaseIncomeDto;
import com.natwest.pbbdhb.income.expense.model.income.response.ValidatedCaseIncomeDto;
import com.natwest.pbbdhb.property.dto.PropertyDetailsDto;
import com.natwest.pbbdhb.applicant.dto.ApplicantDto;
import com.natwest.pbbdhb.ui.application.update.model.dto.capie.ManualKeyInCaseUpdateRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.document.DocumentUploadResponseDto;
import com.natwest.pbbdhb.ui.application.update.model.dto.notes.DocumentNotesRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.CloseTaskRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.DocumentReminder;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.FIStatusRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.NoteRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.TaskRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.AddTeleMessageRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.ApplicationInformationUpdateRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.CaseTransferRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.CaseUpdateCaseOwnerRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.UpdateCaseOwnerRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.document.DocumentRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.document.DocumentUploadRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.firequest.FIRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.AddDocumentResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.BasicPackagingDocumentResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.SuccessResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.application.ApplicationInformationUpdateResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.application.UpdatedCaseOwnerResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.application.CaseUpdatedCaseOwnerResponse;
import org.springframework.http.ResponseEntity;

import javax.json.JsonPatch;
import java.text.ParseException;

/**
 * This interface has the methods related to tasks and notes
 */
public interface ApplicationUpdateService {

    /**
     * @param brand       - Allowed values NWB/RBS
     * @param taskRequest - request object represents the task request
     * @return String
     * @throws ParseException - throws parse exception during date conversion
     */
    String addTask(String brand, TaskRequest taskRequest) throws ParseException;

    /**
     * @param brand       - Allowed values NWB/RBS
     * @param noteRequest - request object represents the note request
     * @return String
     * @throws ParseException - throws parse exception during date conversion
     */
    String addNote(String brand, NoteRequest noteRequest) throws ParseException;

    /**
     * @param brand   - Allowed values NWB/RBS
     * @param request - request object represents the close task request
     * @return String
     * @throws ParseException - throws parse exception during date conversion
     */
    String closeTask(String brand, CloseTaskRequest request) throws ParseException;

    /**
     * This method to add FI based on brand and FIRequest
     *
     * @param brand     - Allowed values NWB/RBS
     * @param referenceNumber - referenceNumber field
     * @param caseId          - String caseId
     * @param fIRequest - request object represents the FIRequest
     * @return AddDocumentResponse
     */
    ResponseEntity<AddDocumentResponse> addFI(String brand, String referenceNumber, String caseId, FIRequest fIRequest);

    /**
     * method is used for uploading document for the given mortgage/application id
     * @param brand           - brand could be NWB/RBS
     * @param caseId          -CaseId :type of applicationId
     * @param referenceNumber -type of applicationId
     * @param documentRequest - Document request object contains channel, application id and multipart
     * @return - DocumentUploadResponseDto
     * @throws JsonProcessingException - throws JsonProcessingException
     */
    DocumentUploadResponseDto uploadDocument(String brand, String caseId, String referenceNumber, DocumentRequest documentRequest) throws JsonProcessingException;

    /**
     * method is used for uploading document for the given mortgage/application id
     *
     * @param brand            - brand could be NWB/RBSs
     * @param documentReminder - Document reminder as input
     * @param referenceNumber  - String referenceNumber
     * @param caseId - String caseId
     * @return - String
     */
    ResponseEntity<SuccessResponse> sendReminder(String brand, DocumentReminder documentReminder, String referenceNumber, String caseId);

    /**
     * This method to update FI State based on brand and FIStatusRequest
     *
     * @param brand           - Allowed values NWB/RBS
     * @param fiStatusRequest - request object represents the FIStatusRequest
     * @param referenceNumber  - String referenceNumber
     * @param caseId - String caseId
     * @param firequestId - String requestId
     * @param state - state
     * @return String
     */
    ResponseEntity<SuccessResponse> updateFIState(String brand, FIStatusRequest fiStatusRequest, String referenceNumber, String caseId, String firequestId, String state);

    /**
     * This method is used to add the note
     *
     * @param brand   - supported brands NWB/RBS
     * @param referenceNumber - String referenceNumber
     * @param caseId - String caseId
     * @param request - request object
     * @return String - String response
     */
    ResponseEntity<SuccessResponse> addDocumentRequestNotes(String brand, String referenceNumber, String caseId, DocumentNotesRequest request);

    /**
     * Method to update application information in application collection
     *
     * @param brand - brand
     * @param caseApplicationDto - caseApplicationDto
     * @param caseId - String caseId
     * @return ApplicationInformationUpdateResponse
     */
    ResponseEntity<CaseApplicationDto> updateApplicationInformation(String brand, CaseApplicationDto caseApplicationDto, String caseId);


    /**
     * Method to update application information in application collection
     *
     * @param brand - brand
     * @param applicationInformationUpdateRequest - applicationInformationUpdateRequest
     * @param referenceNumber   - string referenceNumber
     * @param caseId - String caseId
     * @return ApplicationInformationUpdateResponse
     */
    ResponseEntity<ApplicationInformationUpdateResponse> updateApplicationInformation(String brand, ApplicationInformationUpdateRequest applicationInformationUpdateRequest, String referenceNumber, String caseId);

    /**
     * Method to update the property information for the given case id
     * @param brand - brand
     * @param caseId - case id String
     * @param request - request object
     * @return PropertyDetailsDto - response object
     */
    PropertyDetailsDto updatePropertyInformation(String brand, String caseId, PropertyDetailsDto request);

    /**
     * This method is used to update applicant information based on applicantId and caseId
     * @param brand - allowed values NWB/RBS
     * @param applicantId - String applicantId
     * @param caseId - String caseId
     * @param applicantDto - ApplicantDto object
     * @return - return ResponseEntity object
     */
    ResponseEntity<ApplicantDto> updateApplicants(String brand, String applicantId, String caseId, ApplicantDto applicantDto);

    /**
     * Method to update the case information for the given case id in CAPIE system
     *
     * @param brand     - brand
     * @param caseId    - caseId
     * @param jsonPatch - jsonPatch
     * @return CaseApplicationDto
     */
    CaseApplicationDto updateCaseInformation(String brand, String caseId, JsonPatch jsonPatch);


    /**
     * Method to patch update the property information for the given case id in CAPIE system
     *
     * @param brand     - brand
     * @param caseId    - caseId
     * @param jsonPatch - jsonPatch
     * @return PropertyDetailsDto
     */
    PropertyDetailsDto patchUpdatePropertyInformation(String brand, String caseId, JsonPatch jsonPatch);

    /**
     *  This method is used to update the applicant information in CAPIE system for the given fields
     *
     * @param brand - possible vales NWB/RBS
     * @param caseId - caseId String
     * @param applicantId - applicantId String
     * @param jsonPatch - jsonPatch request
     * @return ApplicantDto - ApplicantDto response
     */
    ApplicantDto patchApplicantUpdate(String brand, String caseId, String applicantId, JsonPatch jsonPatch);

    /**
     * This method is used to save and update income information based on caseId
     *
     * @param brand        - allowed values NWB/RBS
     * @param caseId  - String caseId
     * @param request - CaseIncomeDto object
     * @return - return ValidatedCaseIncomeDto object
     */
    ValidatedCaseIncomeDto saveAndValidateIncomeData(String brand, String caseId, CaseIncomeDto request);

    /**
     * This method is used to validate income information based on caseId
     *
     * @param brand        - allowed values NWB/RBS
     * @param caseId  - String caseId
     * @param request - CaseStatusDto object
     * @return - return ValidatedCaseIncomeDto object
     */
    ValidatedCaseIncomeDto markIncomeValidated(String brand, String caseId, CaseStatusDto request);

    /**
     * This method is used to save and update expense information based on caseId
     *
     * @param brand        - allowed values NWB/RBS
     * @param caseId  - String caseId
     * @param request - CaseExpenseDto object
     * @return - return ValidatedCaseExpenseDto object
     */
    ValidatedCaseExpenseDto saveAndValidateExpenseData(String brand, String caseId, CaseExpenseDto request);


    /**
     * This method is used to upload the document to docin-downstream system
     *
     * @param documentRequest - request
     * @return DocumentUploadResponseDto - response
     * @throws JsonProcessingException - exception object
     */
    DocumentUploadResponseDto uploadSingleDocument(DocumentUploadRequest documentRequest) throws JsonProcessingException;

    /**
     * This method is used to update the expense data validation status
     *
     * @param brand - possible values RBS/NWB
     * @param caseId - caseId String
     * @param request - input Object
     * @return ValidatedCaseExpenseDto - response
     */
    ValidatedCaseExpenseDto markExpenseValidated(String brand,String caseId, CaseStatusDto request);

    /**
     * Method to update application case owner in application collection
     *
     * @param brand - brand
     * @param request - UpdateCaseOwnerRequest request object
     * @return UpdatedCaseOwnerResponse response object
     */
    ResponseEntity<UpdatedCaseOwnerResponse> updateApplicationOwner(String brand, UpdateCaseOwnerRequest request);

    /**
     * Method to update application case owner in application collection
     *
     * @param brand - brand
     * @param request - CaseUpdateCaseOwnerRequest request object
     * @return CaseUpdatedCaseOwnerResponse response object
     */
    ResponseEntity<CaseUpdatedCaseOwnerResponse> updateApplicationOwner(String brand, CaseUpdateCaseOwnerRequest request);

    /**
     * Endpoint to update application detail for manual key in case
     *
     * @param brand                        - brand
     * @param caseId                       - caseId
     * @param dipId                        - dipId
     * @param manualKeyInCaseUpdateRequest - manualKeyInCaseUpdateRequest
     * @return SuccessResponse
     */
    SuccessResponse updateApplicationDataForManualKeyInCases(String brand, String caseId, String dipId,
                                                             ManualKeyInCaseUpdateRequest manualKeyInCaseUpdateRequest);

    /**
     * Method to add teleMessageRequest in packaging manager
     *
     * @param brand                 - brand
     * @param referenceNumber       - referenceNumber
     * @param addTeleMessageRequest - addTeleMessageRequest
     * @return SuccessResponse
     */
    SuccessResponse addTeleMessageRequest(String brand, String referenceNumber, AddTeleMessageRequest addTeleMessageRequest);

    /**
     * Method to update the adbo case information for the given case id in CAPIE system
     *
     * @param brand     - brand
     * @param caseId    - caseId
     * @param jsonPatch - jsonPatch
     * @return CaseDetailsDto
     */
    CaseDetailsDto updateADBOCaseInformation(String brand, String caseId, JsonPatch jsonPatch);

    /**
     * Method to retrieve basic packaging from requiredDocs API and store into PM
     *
     * @param brand                    - brand
     * @param caseId                   - caseId
     * @return BasicPackagingDocumentResponse object
     */
    ResponseEntity<BasicPackagingDocumentResponse> addBasicPackagingRequests(String brand, String caseId);

    /**
     * Method to move the case to referred state
     *
     * @param brand               - brand
     * @param caseTransferRequest - caseTransferRequest
     * @param caseId - caseId
     * @return SuccessResponse
     */
    SuccessResponse transferCase(String brand, CaseTransferRequest caseTransferRequest, String caseId);


    /**
     *
     * @param brand     - brand
     * @param caseId    - caseId
     * @param requestId
     * @param documentId
     * @return
     */
    SuccessResponse disassociateDocument(String brand, String caseId, String requestId, String documentId);

}
