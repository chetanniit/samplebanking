package com.natwest.pbbdhb.ui.application.update.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.natwest.pbbdhb.ui.application.update.model.dto.document.DocumentUploadResponseDto;
import com.natwest.pbbdhb.ui.application.update.model.dto.enums.ApplicationIdType;
import com.natwest.pbbdhb.ui.application.update.model.dto.enums.DocumentType;
import com.natwest.pbbdhb.ui.application.update.model.dto.exception.PreConditionFailedException;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.document.DocumentRequest;
import com.natwest.pbbdhb.ui.application.update.service.DocumentUploadService;
import com.natwest.pbbdhb.ui.application.update.util.ErrorConstant;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.util.Objects;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.*;

/**
 * implementation class for DocumentUploadService Interface
 */
@Service
@Slf4j
public class DocumentUploadServiceImpl implements DocumentUploadService {


    private final RestTemplate restTemplate;
    private final String docInServiceParentEndpoint;
    private final String docInServiceUploadEndpoint;
    private final String docInServicePreClassifiedEndpoint;
    private final boolean prefixValue;

    public DocumentUploadServiceImpl(@Qualifier("docUploadContentTypeSecureRestTemplate") RestTemplate restTemplate,
                                     @Value("${msvc.docin.service.parent.endpoint}") String docInServiceParentEndpoint,
                                     @Value("${msvc.docin.service.upload.endpoint}") String docInServiceUploadEndpoint,
                                     @Value("${msvc.docin.service.preclassified.endpoint}") String docInServicePreClassifiedEndpoint,
                                     @Value("${prefix.mock.value:false}") boolean prefixValue) {
        this.restTemplate = restTemplate;
        this.docInServiceParentEndpoint = docInServiceParentEndpoint;
        this.docInServiceUploadEndpoint = docInServiceUploadEndpoint;
        this.docInServicePreClassifiedEndpoint = docInServicePreClassifiedEndpoint;
        this.prefixValue = prefixValue;
    }

    /**
     * method is used for uploading document for the given mortgage/application id
     *
     * @param brand           - brand could be NWB/RBS
     * @param caseId          -caseId
     * @param referenceNumber -type of applicationId
     * @param documentRequest - Document request object contains channel, application id and multipart
     * @return - DocumentUploadResponseDto
     * @throws JsonProcessingException - throw JsonParsingException
     */
    @Override
    public DocumentUploadResponseDto uploadDocument(String brand, String caseId, String referenceNumber, DocumentRequest documentRequest) throws JsonProcessingException {
        log.info("inside uploadDocument method of DocumentUploadService");
        HttpHeaders headers = new HttpHeaders();
        headers.add("brand", brand.toUpperCase());
        preconditionCheck(documentRequest);


        MultiValueMap<String, Object> map = getMultiValueMap(caseId, referenceNumber, documentRequest);

        String endpoint = docInServiceParentEndpoint + docInServiceUploadEndpoint;

        if(StringUtils.isNotEmpty(documentRequest.getDocumentType())
                && !DocumentType.OTHER.name().equalsIgnoreCase(documentRequest.getDocumentType())){
            endpoint = docInServiceParentEndpoint + docInServicePreClassifiedEndpoint;
        }

        HttpEntity<MultiValueMap<String, Object>> httpEntity = new HttpEntity<>(map, headers);
        log.debug("DocIn service endPoint url {}, {}", endpoint, httpEntity);
        ResponseEntity<DocumentUploadResponseDto> responseEntity = restTemplate.exchange(endpoint, HttpMethod.POST, httpEntity, DocumentUploadResponseDto.class);
        documentRequest.getFiles().forEach(multipartFile -> multipartFile = null);
        documentRequest = null;
        return responseEntity.getBody();
    }

    private void preconditionCheck(DocumentRequest documentRequest) {
        if (StringUtils.isNotEmpty(documentRequest.getDocumentType())
                && !DocumentType.OTHER.name().equalsIgnoreCase(documentRequest.getDocumentType())
                && documentRequest.getFiles().size() > 1)
            throw new PreConditionFailedException(ErrorConstant.ERROR_CODE_412_FILE_SIZE_LIMIT_EXCEED);
    }

    @NotNull
    private MultiValueMap<String, Object> getMultiValueMap(String caseId, String referenceNumber, DocumentRequest documentRequest) {
        MultiValueMap<String, Object> map = new LinkedMultiValueMap<>();
        if (Objects.nonNull(caseId)) {
            map.add(APPLICATION_ID, prefixValue ? PREFIX + caseId : caseId);
            map.add(APPLICATION_ID_TYPE, ApplicationIdType.CASE_ID.name());
        } else {
            map.add(APPLICATION_ID, prefixValue ? PREFIX + referenceNumber : referenceNumber);
            map.add(APPLICATION_ID_TYPE, ApplicationIdType.MORTGAGE_REFERENCE_NUMBER.name());
        }

        map.add(CHANNEL_ID, documentRequest.getChannel().toString());
        map.add(APPLICANT_ID, documentRequest.getApplicantId());
        map.add(REQUEST_ID_TYPE, documentRequest.getRequestId());
        map.add(DOCUMENT_USER_CLASSIFICATION, documentRequest.getClassificationCode());
        if(StringUtils.isNotEmpty(documentRequest.getLoanPurpose())) {
            map.add(LOAN_PURPOSE, documentRequest.getLoanPurpose().toString());
        }

        if(StringUtils.isNotEmpty(documentRequest.getDocumentType())
                && !DocumentType.OTHER.name().equalsIgnoreCase(documentRequest.getDocumentType())){
            map.add(DOCUMENT_TYPE, documentRequest.getDocumentType());
            documentRequest.getFiles().forEach(file ->
                    map.add("file", file.getResource())
            );

        }else{
            documentRequest.getFiles().forEach(file ->
                    map.add("files", file.getResource())
            );
        }

        return map;
    }
}
