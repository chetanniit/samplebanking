package com.natwest.pbbdhb.ui.application.update.model.dto.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum UploadErrorType {
    CONTENT_TYPE(3),
    SERVER_ERROR(Integer.MAX_VALUE),
    FILE_TOO_BIG(2),
    FILE_EMPTY(1);

    private final int priority;
}
