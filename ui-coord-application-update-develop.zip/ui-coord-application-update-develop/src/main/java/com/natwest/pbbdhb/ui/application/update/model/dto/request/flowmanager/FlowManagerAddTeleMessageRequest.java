package com.natwest.pbbdhb.ui.application.update.model.dto.request.flowmanager;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FlowManagerAddTeleMessageRequest {

    private String documentIdentifier;
    private String category;
    private String callerInfo;
    private String callReason;
    private String dueDate;
    private String userFullName;
    private String userRACFId;
}
