package com.natwest.pbbdhb.ui.application.update.service.impl;

import com.natwest.pbbdhb.ui.application.update.mapper.GmsAPIStateMapper;
import com.natwest.pbbdhb.ui.application.update.model.dto.capie.GmsAPIStateRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.capie.ManualKeyInCaseUpdateRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.exception.ManualKeyInCaseUpdateException;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.SuccessResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.userinformation.UserInformationResponse;
import com.natwest.pbbdhb.ui.application.update.service.ManualKeyInCaseUpdateService;
import com.natwest.pbbdhb.ui.application.update.service.auth.AuthorizationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.HashMap;
import java.util.Map;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.BRAND;

/**
 * This service is used to call update application data API for manually key in cases
 */
@Service
@Slf4j
public class ManualKeyInCaseUpdateServiceImpl implements ManualKeyInCaseUpdateService {

    @Autowired
    @Qualifier("customSecureRestTemplate")
    private RestTemplate restTemplate;

    @Value("${msvc.hbo.gms.api.state.parent.endpoint}")
    private String msvcHboGmsApiStateParentEndpoint;

    @Value("${msvc.hbo.gms.api.state.manual.key.in.case.update.endpoint}")
    private String manualKeyInCaseUpdateEndpoint;

    @Value("${success.message.200-manual-key-in-case-update}")
    private String successMessage;

    @Autowired
    private AuthorizationService authorizationService;

    @Autowired
    private GmsAPIStateMapper gmsAPIStateMapper;


    /**
     * Endpoint to update application detail for manual key in case
     *
     * @param brand                        - brand
     * @param caseId                       - caseId
     * @param dipId                        - dipId
     * @param manualKeyInCaseUpdateRequest - manualKeyInCaseUpdateRequest
     * @return SuccessResponse
     */
    @Override
    public SuccessResponse updateApplicationDataForManualKeyInCases(String brand, String caseId, String dipId,
                                                                    ManualKeyInCaseUpdateRequest manualKeyInCaseUpdateRequest) {
        UserInformationResponse userData = authorizationService.getUserData();
        log.info("Entered into updateApplicationDataForManualKeyInCases method for - brand: {}, caseId: {}, " +
                "dipId: {} and manually keyed in by {} - {}", brand, caseId, dipId, userData.getUsername(), userData.getRacfID());
        String endpoint = msvcHboGmsApiStateParentEndpoint + manualKeyInCaseUpdateEndpoint;
        UriComponentsBuilder builder = getUriComponentsBuilder(endpoint, caseId, dipId);
        HttpHeaders header = new HttpHeaders();
        header.add(BRAND, brand);
        GmsAPIStateRequest gmsAPIStateRequest = gmsAPIStateMapper.toGmsAPIStateRequest(manualKeyInCaseUpdateRequest);
        HttpEntity<GmsAPIStateRequest> entity = new HttpEntity<>(gmsAPIStateRequest, header);
        log.debug("header set for downstream call: {}, gmsAPIStateRequest :  {}", header, gmsAPIStateRequest);
        try {
            restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.PATCH,
                    entity, String.class);
        } catch (HttpClientErrorException.BadRequest | HttpClientErrorException.NotFound | HttpClientErrorException.Conflict ex) {
            throw new ManualKeyInCaseUpdateException(ex.getResponseBodyAsString(), ex.getStatusCode());
        }
        return SuccessResponse.builder().successMessage(successMessage).build();
    }

    private UriComponentsBuilder getUriComponentsBuilder(String endpoint, String caseId, String dipId) {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(endpoint);

        Map<String, Object> urlParams = new HashMap<>();
        urlParams.put("caseId", caseId);
        urlParams.put("dipId", dipId);
        builder.uriVariables(urlParams);
        log.debug("URL : {} ", builder.toUriString());
        return builder;
    }
}
