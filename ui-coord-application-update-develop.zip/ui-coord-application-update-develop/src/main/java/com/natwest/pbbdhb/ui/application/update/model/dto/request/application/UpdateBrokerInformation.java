package com.natwest.pbbdhb.ui.application.update.model.dto.request.application;

import com.natwest.pbbdhb.ui.application.update.validator.format.EmailFormat;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.INVALID_BROKER_EMAIL_ID;


/**
 * Update broker information object
 */
@Data
@Schema(description = "Update broker information Object")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Validated
@Valid
public class UpdateBrokerInformation {

    @Valid
    @Parameter(description = "broker email")
    @EmailFormat(message = INVALID_BROKER_EMAIL_ID)
    private String emailAddress;

    @Valid
    @Parameter(description = "notificationRequired flag")
    private Boolean notificationRequired;
}
