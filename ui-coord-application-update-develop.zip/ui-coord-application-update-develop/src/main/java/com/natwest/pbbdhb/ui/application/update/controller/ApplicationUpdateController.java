package com.natwest.pbbdhb.ui.application.update.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.natwest.pbbdhb.ui.application.update.model.dto.document.DocumentUploadResponseDto;
import com.natwest.pbbdhb.ui.application.update.model.dto.document.GlobalErrorResponseDto;
import com.natwest.pbbdhb.ui.application.update.model.dto.exception.ErrorResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.notes.DocumentNotesRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.AddTeleMessageRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.DocumentReminder;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.FIStatusRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.ApplicationInformationUpdateRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.UpdateCaseOwnerRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.document.DocumentRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.firequest.FIRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.AddDocumentResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.SuccessResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.application.ApplicationInformationUpdateResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.application.UpdatedCaseOwnerResponse;
import com.natwest.pbbdhb.ui.application.update.service.ApplicationUpdateService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.*;

/**
 * This class has all endpoints related to creation and deletion of tasks and notes
 */
@PreAuthorize("@authorizationServiceImpl.isDevTestUser() || @authorizationServiceImpl.isUWUser()")
@RestController
@Tag(name = "Application Update API", description = "Application Update API")
@RequestMapping("/")
@AllArgsConstructor
@Validated
@Slf4j
public class ApplicationUpdateController {

    private final ApplicationUpdateService applicationUpdateService;

    /**
     * This endpoint is to update the application information in application collection
     *
     * @param brand           - brand
     * @param referenceNumber - String reference number
     * @param request         - ApplicationInformationUpdateRequest
     * @return ApplicationInformationUpdateResponse ResponseEntity object
     */
    @PreAuthorize("@authorizationServiceImpl.isDevTestUser() || @authorizationServiceImpl.isUWUser() || @authorizationServiceImpl.isMCCUser()")
    @Operation(summary = "Update Application Information", operationId = "updateApplicationInformation", tags = {"Application Update API"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "OK",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ApplicationInformationUpdateResponse.class))}),
                    @ApiResponse(responseCode = "206", description = "Partial Success",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ApplicationInformationUpdateResponse.class))}),
                    @ApiResponse(responseCode = "400", description = "Bad Request"),
                    @ApiResponse(responseCode = "401", description = "Not Authorised"),
                    @ApiResponse(responseCode = "403", description = "Forbidden"),
                    @ApiResponse(responseCode = "404", description = "No record found"),
                    @ApiResponse(responseCode = "409", description = "Conflict",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ApplicationInformationUpdateResponse.class))}),
                    @ApiResponse(responseCode = "412", description = "Precondition Failed"),
                    @ApiResponse(responseCode = "500", description = "Internal Server Error")
            })
    @PatchMapping(path = "/application/{referenceNumber:^(?:(?i)(?!case).)+}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ApplicationInformationUpdateResponse> updateApplicationInformation(
            @RequestHeader(value = "brand") @Valid @Pattern(regexp = VALID_BRANDS, message = INVALID_BRAND) String brand,
            @PathVariable(name = "referenceNumber") @Valid @Pattern(regexp = ALLOW_ONLY_NUMBERS_AND_MAX_OF_TEN_DIGITS, message =
                    INVALID_REFERENCE_NUMBER) String referenceNumber,
            @Valid @NotNull @RequestBody ApplicationInformationUpdateRequest request) {
        log.info("Inside updateApplicationInformation for referenceNumber:{}", referenceNumber);
        return applicationUpdateService.updateApplicationInformation(brand, request, referenceNumber, null);
    }

    /**
     * This endpoint will update FI state and FI documents information
     *
     * @param brand            - Brand
     * @param referenceNumber  - String reference number
     * @param firequestId      - String requestId
     * @param request          - FIRequest
     * @param validationErrors - Validation errors
     * @return String
     */
    @PreAuthorize("@authorizationServiceImpl.isDevTestUser() || @authorizationServiceImpl.isUWUser() " +
            "|| @authorizationServiceImpl.isMopsUser() || @authorizationServiceImpl.isPSTUser() " +
            "|| @authorizationServiceImpl.isMAUser()|| @authorizationServiceImpl.isCINUser()")
    @Operation(summary = "Update FI state", operationId = "updateFIState", tags = {"Application Update API"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "OK",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = SuccessResponse.class))}),
                    @ApiResponse(responseCode = "201", description = "Created",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = SuccessResponse.class))}),
                    @ApiResponse(responseCode = "400", description = "Bad Request"),
                    @ApiResponse(responseCode = "401", description = "Not Authorised"),
                    @ApiResponse(responseCode = "403", description = "Forbidden"),
                    @ApiResponse(responseCode = "404", description = "No record found"),
                    @ApiResponse(responseCode = "500", description = "Internal Server Error")
            })
    @PutMapping(path = "/application/{referenceNumber:^(?:(?i)(?!case).)+}/firequest/{firequestId}/fistate/{state}")
    public ResponseEntity<SuccessResponse> updateFIState(
            @RequestHeader(value = "brand") @Valid @Pattern(regexp = VALID_BRANDS, message = INVALID_BRAND) String brand,
            @PathVariable(name = "referenceNumber") @Valid @Pattern(regexp = ALLOW_ONLY_NUMBERS_AND_MAX_OF_TEN_DIGITS, message =
                    INVALID_REFERENCE_NUMBER) String referenceNumber,
            @PathVariable(name = "firequestId") @Valid @NotNull(message = INVALID_REQUEST_ID) @NotEmpty(message = INVALID_REQUEST_ID) String firequestId,
            @PathVariable(name = "state") @Valid @NotNull(message = INVALID_STATE) @NotEmpty(message = INVALID_STATE)
            @Parameter(schema = @Schema(type = "string", allowableValues = {"Open", "Draft", "Upload", "Review", "Error", "Closed", "PST_Review", "PST_Review_Complete", "MA_Review", "MA_Review_Complete"}))
            @Pattern(regexp = REGEXP_ALLOW_UPDATE_FI_STATE_VALUE, message = INVALID_STATE) String state,
            @Valid @RequestBody(required = false) FIStatusRequest request, BindingResult validationErrors) {
        log.info("updateFIState method entered in ApplicationUpdateController class with brand: {}", brand);
        log.info("updateFIState request complete: brand {}", brand);
        return applicationUpdateService.updateFIState(brand, request, referenceNumber, null, firequestId, state);
    }

    /**
     * This endpoint is used to add note
     *
     * @param brand           - supported brands - NWB/RBS
     * @param referenceNumber - reference number
     * @param request         - request object
     * @return String - String object
     */
    @PreAuthorize("@authorizationServiceImpl.isDevTestUser() || @authorizationServiceImpl.isUWUser() " +
            "|| @authorizationServiceImpl.isMCCUser() || @authorizationServiceImpl.isPSTUser() " +
            "|| @authorizationServiceImpl.isMAUser() || @authorizationServiceImpl.isCINUser()")
    @Operation(summary = "Add FI and Application Notes", operationId = "addDocumentRequestNotes", tags = {"Application Update API"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "OK",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = SuccessResponse.class))}),
                    @ApiResponse(responseCode = "400", description = "Bad Request"),
                    @ApiResponse(responseCode = "401", description = "Not Authorised"),
                    @ApiResponse(responseCode = "403", description = "Forbidden"),
                    @ApiResponse(responseCode = "404", description = "No record found"),
                    @ApiResponse(responseCode = "412", description = "Precondition Failed"),
                    @ApiResponse(responseCode = "500", description = "Internal Server Error")
            })
    @PostMapping(path = "/application/{referenceNumber:^(?:(?i)(?!case).)+}/note", produces = MediaType.APPLICATION_JSON_VALUE, consumes
            = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<SuccessResponse> addDocumentRequestNotes(
            @RequestHeader(value = "brand") @Valid @Pattern(regexp = VALID_BRANDS, message = INVALID_BRAND) String brand,
            @PathVariable(name = "referenceNumber") @Valid @Pattern(regexp = ALLOW_ONLY_NUMBERS_AND_MAX_OF_TEN_DIGITS, message =
                    INVALID_REFERENCE_NUMBER) String referenceNumber,
            @Valid @NotNull @RequestBody DocumentNotesRequest request) {
        log.info("addDocumentRequestNotes method enters in DocumentRequestNotesController class");
        return applicationUpdateService.addDocumentRequestNotes(brand, referenceNumber, null, request);
    }

    /**
     * This endpoint will take a Reminder for chasing a document as input and send the success message as response
     *
     * @param brand            - Brand
     * @param referenceNumber  - Reference number
     * @param request          - Reminder
     * @param validationErrors - Validation errors
     * @return String - String response
     */
    @PreAuthorize("@authorizationServiceImpl.isDevTestUser() || @authorizationServiceImpl.isUWUser() " +
            "|| @authorizationServiceImpl.isMCCUser() || @authorizationServiceImpl.isPSTUser() " +
            "|| @authorizationServiceImpl.isMAUser() || @authorizationServiceImpl.isCINUser()")
    @Operation(summary = "Send notifications", operationId = "sendReminder", tags = {"Application Update API"},
            responses = {
                    @ApiResponse(responseCode = "202", description = "Accepted",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = SuccessResponse.class))}),
                    @ApiResponse(responseCode = "400", description = "Bad Request",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "401", description = "Not Authorised",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "403", description = "Forbidden",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "No record found",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "412", description = "Precondition Failed",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "500", description = "Internal Server Error",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))})
            })
    @PostMapping(path = "/application/{referenceNumber:^(?:(?i)(?!case).)+}/notification", produces =
            MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<SuccessResponse> sendReminder(
            @RequestHeader(value = "brand") @Valid @Pattern(regexp = VALID_BRANDS, message = INVALID_BRAND) String brand,
            @PathVariable(name = "referenceNumber") @Valid @Pattern(regexp = ALLOW_ONLY_NUMBERS_AND_MAX_OF_TEN_DIGITS, message =
                    INVALID_REFERENCE_NUMBER) String referenceNumber,
            @Valid @RequestBody @NotNull DocumentReminder request, BindingResult validationErrors) {
        log.info("sendReminder method entered in ApplicationUpdateController class with brand: {}", brand);
        return applicationUpdateService.sendReminder(brand, request, referenceNumber, null);
    }

    /**
     * Endpoint to add FI by reference number
     *
     * @param brand            - brand
     * @param referenceNumber  - referenceNumber
     * @param request          - FiRequest
     * @param validationErrors - Validation Errors
     * @return AddDocumentResponse
     */
    @Operation(summary = "Request Further Information", operationId = "addFI", tags = {"Application Update API"},
            responses = {
                    @ApiResponse(responseCode = "201", description = "Created",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = AddDocumentResponse.class))}),
                    @ApiResponse(responseCode = "206", description = "Partial Content",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = AddDocumentResponse.class))}),
                    @ApiResponse(responseCode = "409", description = "Conflict",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = AddDocumentResponse.class))}),
                    @ApiResponse(responseCode = "400", description = "Bad Request",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "401", description = "Not Authorised",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "No record found",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "403", description = "Forbidden",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "500", description = "Internal Server Error",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))})
            })
    @PostMapping(path = "/application/{referenceNumber:^(?:(?i)(?!case).)+}/firequest")
    @PreAuthorize("@authorizationServiceImpl.isDevTestUser() || @authorizationServiceImpl.isUWUser() " +
            "|| @authorizationServiceImpl.isPSTUser() || @authorizationServiceImpl.isMAUser() || @authorizationServiceImpl.isCINUser()")
    public ResponseEntity<AddDocumentResponse> addFI(
            @RequestHeader(value = "brand") @Valid @Pattern(regexp = VALID_BRANDS, message = INVALID_BRAND) String brand,
            @PathVariable(name = "referenceNumber") @Valid @Pattern(regexp = ALLOW_ONLY_NUMBERS_AND_MAX_OF_TEN_DIGITS, message =
                    INVALID_REFERENCE_NUMBER) String referenceNumber,
            @Valid @RequestBody @NotNull FIRequest request, BindingResult validationErrors) {
        log.info("addFI method entered in ApplicationUpdateController class with brand: {}", brand);
        return applicationUpdateService.addFI(brand, referenceNumber, null, request);
    }

    /**
     * method is used for uploading document for the given mortgage/application id
     *
     * @param referenceNumber  - reference Number
     * @param brand            - brand could be NWB/RBS
     * @param documentRequest  - Document request object contains channel, application id and multipart
     * @param validationErrors - Validation errors
     * @return - DocumentUploadResponseDto
     * @throws JsonProcessingException - throw JsonParsingException
     */
    @PreAuthorize("@authorizationServiceImpl.isDevTestUser() || @authorizationServiceImpl.isUWUser() || @authorizationServiceImpl.isMopsUser()")
    @Operation(summary = "Upload application documents", operationId = "uploadDocument", tags = {"Application Update API"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "All uploads succeeded",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = DocumentUploadResponseDto.class))}),
                    @ApiResponse(responseCode = "207", description = "Some uploads succeeded",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = DocumentUploadResponseDto.class))}),
                    @ApiResponse(responseCode = "400", description = "Bad Request"),
                    @ApiResponse(responseCode = "412", description = "Precondition Failed"),
                    @ApiResponse(responseCode = "413", description = "The request payload is too large",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = GlobalErrorResponseDto.class))}),
                    @ApiResponse(responseCode = "415", description = "All uploads failed due to invalid file types",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = DocumentUploadResponseDto.class))})
            })
    @PostMapping(value = "/uploadDocument/{referenceNumber:^(?:(?i)(?!case).)+}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<DocumentUploadResponseDto> uploadDocument(
            @PathVariable(name = "referenceNumber") @Valid @NotNull(message = INVALID_REFERENCE_NUMBER) @NotEmpty(message =
                    INVALID_REFERENCE_NUMBER) @Size(min = 8, max = 17, message = INVALID_REFERENCE_NUMBER) String referenceNumber,
            @RequestHeader(value = "brand") @Valid @Pattern(regexp = DOC_UPLOAD_VALID_BRANDS, message = INVALID_BRAND) String brand,
            @Valid @ModelAttribute DocumentRequest documentRequest, BindingResult validationErrors) throws JsonProcessingException {
        log.info("Inside uploadDocument endpoint");
        DocumentUploadResponseDto documentUploadResponseDto = applicationUpdateService.uploadDocument(brand, null, referenceNumber,
                documentRequest);
        if (CollectionUtils.isNotEmpty(documentUploadResponseDto.getSuccessfulUploads()) && CollectionUtils.isNotEmpty(
                documentUploadResponseDto.getUnsuccessfulUploads())) {
            return new ResponseEntity<>(documentUploadResponseDto, HttpStatus.MULTI_STATUS);
        }
        return new ResponseEntity<>(documentUploadResponseDto, HttpStatus.OK);
    }

    /**
     * This endpoint is to update the application case owner by reference number in application collection
     *
     * @param brand           - brand
     * @param request         - case owner request object
     * @return UpdateApplicationCaseOwnerResponse ResponseEntity object
     */
    @PreAuthorize("@authorizationServiceImpl.isUWLead()")
    @Operation(summary = "Update Application Case Owner", operationId = "updateApplicationCaseOwner",
            description = "Update Case Owner for Mortgage Application based on reference number",
            tags = {"Application Update API"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "OK",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = UpdatedCaseOwnerResponse.class))}),
                    @ApiResponse(responseCode = "206", description = "Partial Success",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = UpdatedCaseOwnerResponse.class))}),
                    @ApiResponse(responseCode = "409", description = "Conflict",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = UpdatedCaseOwnerResponse.class))}),
                    @ApiResponse(responseCode = "413", description = "The request payload is too large",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "400", description = "Bad Request", content = {@Content()}),
                    @ApiResponse(responseCode = "401", description = "Not Authorised", content = {@Content()}),
                    @ApiResponse(responseCode = "403", description = "Forbidden", content = {@Content()}),
                    @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {@Content()})
            })
    @PatchMapping(path = "/application/caseOwner", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UpdatedCaseOwnerResponse> updateApplicationOwner(
                @RequestHeader(value = "brand") @Valid @Pattern(regexp = VALID_BRANDS, message = INVALID_BRAND) String brand,
                @Valid @NotNull @RequestBody UpdateCaseOwnerRequest request) {

        log.info("Inside updateApplicationCaseOwner: brand:{} ", brand);
        return applicationUpdateService.updateApplicationOwner(brand, request);
    }

    /**
     * This endpoint is used to teleMessage request
     *
     * @param brand                 - supported brands - NWB/RBS
     * @param referenceNumber       - reference number
     * @param addTeleMessageRequest - addTeleMessageRequest object
     * @return success message
     */
    @PreAuthorize("@authorizationServiceImpl.isDevTestUser() || @authorizationServiceImpl.isMCCUser()")
    @Operation(summary = "Add TeleMessage Request by ReferenceNumber",
            operationId = "AddTeleMessageRequestByReferenceNumber", tags = {"Application Update API"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "OK",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = SuccessResponse.class))}),
                    @ApiResponse(responseCode = "400", description = "Bad Request"),
                    @ApiResponse(responseCode = "401", description = "Not Authorised"),
                    @ApiResponse(responseCode = "403", description = "Forbidden"),
                    @ApiResponse(responseCode = "404", description = "No record found"),
                    @ApiResponse(responseCode = "412", description = "Precondition Failed"),
                    @ApiResponse(responseCode = "500", description = "Internal Server Error")
            })
    @PostMapping(path = "/application/{referenceNumber}/telemessage", produces = MediaType.APPLICATION_JSON_VALUE, consumes
            = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<SuccessResponse> addTeleMessageRequest(
            @RequestHeader(value = "brand") @Valid @Pattern(regexp = VALID_BRANDS, message = INVALID_BRAND) String brand,
            @PathVariable(name = "referenceNumber") @Valid @Pattern(regexp = ALLOW_ONLY_NUMBERS_AND_MAX_OF_TEN_DIGITS, message =
                    INVALID_REFERENCE_NUMBER) String referenceNumber,
            @Valid @NotNull @RequestBody AddTeleMessageRequest addTeleMessageRequest) {
        log.info("Entered into addTeleMessageRequest method for referenceNumber - {}", referenceNumber);
        SuccessResponse successResponse = applicationUpdateService.addTeleMessageRequest(brand, referenceNumber,
                addTeleMessageRequest);
        return ResponseEntity.status(HttpStatus.CREATED).body(successResponse);
    }

}
