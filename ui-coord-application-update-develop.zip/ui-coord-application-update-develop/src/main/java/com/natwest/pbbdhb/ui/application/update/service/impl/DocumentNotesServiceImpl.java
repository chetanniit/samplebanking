package com.natwest.pbbdhb.ui.application.update.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.ui.application.update.mapper.FlowManagerRequestMapper;
import com.natwest.pbbdhb.ui.application.update.model.dto.notes.DocumentNotesRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.flowmanager.FlowManagerDocumentNotesRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.SuccessResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.userinformation.UserInformationResponse;
import com.natwest.pbbdhb.ui.application.update.service.DocumentNotesService;
import com.natwest.pbbdhb.ui.application.update.service.auth.AuthorizationService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.*;

/**
 * This class is used perform notes service related opertions
 */
@Service
@Slf4j
public class DocumentNotesServiceImpl implements DocumentNotesService {

    @Value("${msvc.flow-manager.parent.endpoint}")
    private String flowManagerParentEndpoint;

    @Value("${msvc.flow-manager.add-note.endpoint}")
    private String flowManagerAddNoteEndpoint;

    @Value("${msvc.flow-manager.add-case-note.endpoint}")
    private String flowManagerAddCaseNoteEndpoint;

    @Value("${msvc.flow-manager.add-application-note.endpoint}")
    private String flowManagerAddApplicationNoteEndpoint;

    @Value("${msvc.flow-manager.add-case-application-note.endpoint}")
    private String flowManagerAddCaseApplicationNoteEndpoint;

    @Autowired
    @Qualifier("customSecureRestTemplate")
    private RestTemplate restTemplate;

    @Autowired
    private AuthorizationService authorizationService;

    @Autowired
    private FlowManagerRequestMapper flowManagerRequestMapper;

    @Autowired
    private ObjectMapper objectMapper;

    /**
     * This method is used to call downstream system to add the note
     *
     * @param brand   - supported brands NWB/RBS
     * @param referenceNumber -  String referenceNumber
     * @param caseId -  String caseId
     * @param request - request object
     * @return String - String response
     */
    @Override
    public ResponseEntity<SuccessResponse> addDocumentRequestNotes(String brand, String referenceNumber, String caseId, DocumentNotesRequest request) {
        log.info("addDocumentRequestNotes method entered in DocumentNotesServiceImpl class");
        SuccessResponse successResponse = null;
        UserInformationResponse userData = authorizationService.getUserData();
        FlowManagerDocumentNotesRequest flowManagerDocumentNotesRequest = flowManagerRequestMapper.toFlowManagerDocumentNotesRequest(request);
        Optional.ofNullable(userData).ifPresent(userInfo -> {
            flowManagerDocumentNotesRequest.setUserFullName(userData.getUsername());
            flowManagerDocumentNotesRequest.setUserRACFId(userData.getRacfID());
        });

        String endPoint = flowManagerParentEndpoint;
        Map<String, Object> urlParams = new HashMap<>();
        urlParams.put(REFERENCE_NUMBER, referenceNumber);
        if (StringUtils.isEmpty(request.getRequestId())) {
            if(StringUtils.isNotBlank(referenceNumber)) {
                flowManagerDocumentNotesRequest.setReferenceNumber(referenceNumber);
                urlParams.put(REFERENCE_NUMBER, referenceNumber);
                endPoint = endPoint + flowManagerAddApplicationNoteEndpoint;
            } else if(StringUtils.isNotBlank(caseId)){
                flowManagerDocumentNotesRequest.setCaseId(caseId);
                urlParams.put(CASE_ID, caseId);
                endPoint = endPoint + flowManagerAddCaseApplicationNoteEndpoint;
            }
        } else {
            if(StringUtils.isNotBlank(referenceNumber)) {
                flowManagerDocumentNotesRequest.setReferenceNumber(referenceNumber);
                urlParams.put(REFERENCE_NUMBER, referenceNumber);
                endPoint = endPoint + flowManagerAddNoteEndpoint;
            } else if(StringUtils.isNotBlank(caseId)){
                flowManagerDocumentNotesRequest.setCaseId(caseId);
                urlParams.put(CASE_ID, caseId);
                endPoint = endPoint + flowManagerAddCaseNoteEndpoint;
            }
            urlParams.put(REQUEST_ID, request.getRequestId());
            flowManagerDocumentNotesRequest.setRequestId(request.getRequestId());
        }


        URI builder = UriComponentsBuilder.fromUriString(endPoint).buildAndExpand(urlParams).toUri();
        HttpHeaders headers = new HttpHeaders();
        headers.add("brand", brand);

        HttpEntity<FlowManagerDocumentNotesRequest> httpEntity = new HttpEntity<>(flowManagerDocumentNotesRequest, headers);
        log.info("Flow Manager service addFI endPoint url {}, {}", endPoint, flowManagerDocumentNotesRequest);
        ResponseEntity<String> responseEntity = restTemplate.exchange(builder, HttpMethod.POST, httpEntity, String.class);
        try {
            successResponse = objectMapper.readValue(responseEntity.getBody(), SuccessResponse.class);
        } catch (JsonProcessingException e) {
            log.error("Exception occurred while response object conversion: {}", e.getMessage(), e);
        }
        return ResponseEntity.status(responseEntity.getStatusCode()).body(successResponse);

    }
}
