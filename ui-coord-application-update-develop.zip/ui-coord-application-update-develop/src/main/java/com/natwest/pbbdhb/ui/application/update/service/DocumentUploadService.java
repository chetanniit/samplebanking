package com.natwest.pbbdhb.ui.application.update.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.natwest.pbbdhb.ui.application.update.model.dto.document.DocumentUploadResponseDto;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.document.DocumentRequest;

/**
 * service is used by /uploadDocument endpoint and contains methods related to add new documents
 */
public interface DocumentUploadService {
    /**
     * method is used for uploading document for the given mortgage/application id
     * @param brand - brand could be NWB/RBS
     * @param caseId -CaseId :type of applicationId
     * @param referenceNumber -type of applicationId
     * @param documentRequest - Document request object contains channel, application id and multipart
     * @return - DocumentUploadResponseDto
     * @throws JsonProcessingException - throws JsonProcessingException object
     */
    DocumentUploadResponseDto uploadDocument(String brand, String caseId, String referenceNumber, DocumentRequest documentRequest) throws JsonProcessingException;

}
