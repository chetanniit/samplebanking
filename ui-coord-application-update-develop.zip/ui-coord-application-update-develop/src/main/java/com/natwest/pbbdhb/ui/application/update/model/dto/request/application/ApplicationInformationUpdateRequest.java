package com.natwest.pbbdhb.ui.application.update.model.dto.request.application;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import java.util.List;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.ALLOW_ONLY_ALPHABETS_PLUS_AND_MAX_OF_5_CHARACTERS;
import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.INVALID_POD_RATING;

/**
 * Application information Update Request
 */
@Data
@Schema(description = "Application Information Update Request Object")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Validated
@Valid
public class ApplicationInformationUpdateRequest {

    @Valid
    @Parameter(description = "Applicant Information To Update")
    private List<UpdateApplicantInformation> applicants;

    @Valid
    @Parameter(description = "Broker Information To Update")
    private UpdateBrokerInformation brokerInfo;

    @Valid
    @Parameter(description = "Source Information To Update")
    private UpdateSourceInformation sourceInfo;

    @Valid
    @Parameter(description = "pod rating")
    @Pattern(regexp = ALLOW_ONLY_ALPHABETS_PLUS_AND_MAX_OF_5_CHARACTERS, message = INVALID_POD_RATING)
    private String podRating;
}
