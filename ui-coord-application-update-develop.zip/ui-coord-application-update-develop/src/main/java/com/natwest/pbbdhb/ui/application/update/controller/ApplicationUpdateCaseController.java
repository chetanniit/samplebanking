package com.natwest.pbbdhb.ui.application.update.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.natwest.pbbdhb.ui.application.update.model.dto.document.DocumentUploadResponseDto;
import com.natwest.pbbdhb.ui.application.update.model.dto.document.GlobalErrorResponseDto;
import com.natwest.pbbdhb.ui.application.update.model.dto.exception.ErrorResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.notes.DocumentNotesRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.DocumentReminder;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.FIStatusRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.ApplicationInformationUpdateRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.CaseUpdateCaseOwnerRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.document.DocumentRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.firequest.FIRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.AddDocumentResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.BasicPackagingDocumentResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.SuccessResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.application.ApplicationInformationUpdateResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.application.CaseUpdatedCaseOwnerResponse;
import com.natwest.pbbdhb.ui.application.update.service.ApplicationUpdateService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.*;

/**
 * This class has all endpoints related to creation and deletion of tasks and notes
 */
@PreAuthorize("@authorizationServiceImpl.isDevTestUser() || @authorizationServiceImpl.isUWUser()")
@RestController
@Tag(name = "Application Update Case API", description = "Application Update Case API")
@RequestMapping("/")
@AllArgsConstructor
@Validated
@Slf4j
public class ApplicationUpdateCaseController {

    private final ApplicationUpdateService applicationUpdateService;

    /**
     * This endpoint is to update the application information in application collection
     *
     * @param brand   - brand
     * @param caseId  - String caseId
     * @param request - ApplicationInformationUpdateRequest
     * @return ApplicationInformationUpdateResponse ResponseEntity object
     */
    @PreAuthorize("@authorizationServiceImpl.isDevTestUser() || @authorizationServiceImpl.isUWUser() || @authorizationServiceImpl.isMCCUser()")
    @Operation(summary = "Update Application Information", operationId = "updateApplicationInformation", tags = {"Application Update Case API"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "OK",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ApplicationInformationUpdateResponse.class))}),
                    @ApiResponse(responseCode = "206", description = "Partial Success",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ApplicationInformationUpdateResponse.class))}),
                    @ApiResponse(responseCode = "400", description = "Bad Request"),
                    @ApiResponse(responseCode = "401", description = "Not Authorised"),
                    @ApiResponse(responseCode = "403", description = "Forbidden"),
                    @ApiResponse(responseCode = "404", description = "No record found"),
                    @ApiResponse(responseCode = "409", description = "Conflict",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ApplicationInformationUpdateResponse.class))}),
                    @ApiResponse(responseCode = "412", description = "Precondition Failed"),
                    @ApiResponse(responseCode = "500", description = "Internal Server Error")
            })
    @PatchMapping(path = "application/case/{caseId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ApplicationInformationUpdateResponse> updateApplicationInformation(@RequestHeader(value = "brand") @Valid @Pattern(regexp = VALID_BRANDS, message = INVALID_BRAND) String brand,
                                                                                             @PathVariable("caseId") @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_NUMBER_MAX_OF_THIRTY_SIX_CHAR, message = INVALID_CASE_ID) String caseId,
                                                                                             @Valid @NotNull @RequestBody ApplicationInformationUpdateRequest request) {
        log.info("Inside updateApplicationInformation for caseId:{}", caseId);
        return applicationUpdateService.updateApplicationInformation(brand, request, null, caseId);
    }

    /**
     * This endpoint will update FI state and FI documents information
     *
     * @param brand            - Brand
     * @param caseId           - String caseId
     * @param firequestId      - String requestId
     * @param state           - String status
     * @param request          - FIRequest
     * @param validationErrors - Validation errors
     * @return String
     */
    @PreAuthorize("@authorizationServiceImpl.isDevTestUser() || @authorizationServiceImpl.isUWUser() " +
            "|| @authorizationServiceImpl.isMopsUser() || @authorizationServiceImpl.isPSTUser() " +
            "|| @authorizationServiceImpl.isMAUser() || @authorizationServiceImpl.isCINUser()")
    @Operation(summary = "Update FI state", operationId = "updateFIState", tags = {"Application Update Case API"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "OK",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = SuccessResponse.class))}),
                    @ApiResponse(responseCode = "201", description = "Created",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = SuccessResponse.class))}),
                    @ApiResponse(responseCode = "400", description = "Bad Request"),
                    @ApiResponse(responseCode = "401", description = "Not Authorised"),
                    @ApiResponse(responseCode = "403", description = "Forbidden"),
                    @ApiResponse(responseCode = "404", description = "No record found"),
                    @ApiResponse(responseCode = "500", description = "Internal Server Error")
            })
    @PutMapping(path = "/application/case/{caseId}/firequest/{firequestId}/fistate/{state}")
    public ResponseEntity<SuccessResponse> updateFIState(
            @RequestHeader(value = "brand") @Valid @Pattern(regexp = VALID_BRANDS, message = INVALID_BRAND) String brand,
            @PathVariable("caseId") @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_NUMBER_MAX_OF_THIRTY_SIX_CHAR, message = INVALID_CASE_ID) String caseId,
            @PathVariable("firequestId") @Valid @NotNull(message = INVALID_REQUEST_ID) @NotEmpty(message = INVALID_REQUEST_ID) String firequestId,
            @PathVariable(name = "state") @Valid @NotNull(message = INVALID_STATE) @NotEmpty(message = INVALID_STATE)
            @Parameter(schema = @Schema(type = "string", allowableValues = {"Open", "Draft", "Upload", "Review", "Error", "Closed", "PST_Review", "PST_Review_Complete", "MA_Review", "MA_Review_Complete"}))
            @Pattern(regexp = REGEXP_ALLOW_UPDATE_FI_STATE_VALUE, message = INVALID_STATE) String state,
            @Valid @RequestBody(required = false) FIStatusRequest request, BindingResult validationErrors) {
        log.info("updateFIState method entered in ApplicationUpdateController class with brand: {}", brand);
        log.info("updateFIState request complete: brand {}", brand);
        return applicationUpdateService.updateFIState(brand, request, null, caseId, firequestId, state);
    }

    /**
     * This endpoint is used to add note
     *
     * @param brand   - supported brands - NWB/RBS
     * @param caseId  - String caseId
     * @param request - request object
     * @return String - String object
     */
    @PreAuthorize("@authorizationServiceImpl.isDevTestUser() || @authorizationServiceImpl.isUWUser() " +
            "|| @authorizationServiceImpl.isMCCUser() ||  @authorizationServiceImpl.isPSTUser() " +
            "|| @authorizationServiceImpl.isMAUser() || @authorizationServiceImpl.isCINUser()")
    @Operation(summary = "Add FI and Application Notes", operationId = "addDocumentRequestNotes", tags = {"Application Update Case API"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "OK",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = SuccessResponse.class))}),
                    @ApiResponse(responseCode = "201", description = "Created",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = SuccessResponse.class))}),
                    @ApiResponse(responseCode = "400", description = "Bad Request"),
                    @ApiResponse(responseCode = "401", description = "Not Authorised"),
                    @ApiResponse(responseCode = "403", description = "Forbidden"),
                    @ApiResponse(responseCode = "404", description = "No record found"),
                    @ApiResponse(responseCode = "412", description = "Precondition Failed"),
                    @ApiResponse(responseCode = "500", description = "Internal Server Error")
            })
    @PostMapping(path = "/application/case/{caseId}/note", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<SuccessResponse> addDocumentRequestNotes(@RequestHeader(value = "brand") @Valid @Pattern(regexp = VALID_BRANDS, message = INVALID_BRAND) String brand,
                                                                   @PathVariable("caseId") @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_NUMBER_MAX_OF_THIRTY_SIX_CHAR, message = INVALID_CASE_ID) String caseId,
                                                                   @Valid @NotNull @RequestBody DocumentNotesRequest request) {
        log.info("addDocumentRequestNotes method enters in DocumentRequestNotesController class");
        return applicationUpdateService.addDocumentRequestNotes(brand, null, caseId, request);
    }

    /**
     * This endpoint will take a Reminder for chasing a document as input and send the success message as response
     *
     * @param brand            - Brand
     * @param caseId           - CaseID
     * @param request          - Reminder
     * @param validationErrors - Validation errors
     * @return String - String response
     */
    @PreAuthorize("@authorizationServiceImpl.isDevTestUser() || @authorizationServiceImpl.isUWUser() " +
            "|| @authorizationServiceImpl.isMCCUser() || @authorizationServiceImpl.isPSTUser() " +
            "|| @authorizationServiceImpl.isMAUser() || @authorizationServiceImpl.isCINUser()")
    @Operation(summary = "Send notifications", operationId = "sendReminder", tags = {"Application Update Case API"},
            responses = {
                    @ApiResponse(responseCode = "202", description = "Accepted",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = SuccessResponse.class))}),
                    @ApiResponse(responseCode = "400", description = "Bad Request",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "401", description = "Not Authorised",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "403", description = "Forbidden",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "No record found",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "412", description = "Precondition Failed",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "500", description = "Internal Server Error",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))})
            })
    @PostMapping(path = "/application/case/{caseId}/notification", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<SuccessResponse> sendReminder(
            @RequestHeader(value = "brand") @Valid @Pattern(regexp = VALID_BRANDS, message = INVALID_BRAND) String brand,
            @PathVariable("caseId") @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_NUMBER_MAX_OF_THIRTY_SIX_CHAR, message = INVALID_CASE_ID) String caseId,
            @Valid @RequestBody @NotNull DocumentReminder request, BindingResult validationErrors) {
        log.info("Entered into sendReminder for brand: {}, caseId : {}", brand, caseId);
        return applicationUpdateService.sendReminder(brand, request, null, caseId);
    }

    /**
     * Endpoint to add FI by caseId
     *
     * @param brand            - brand
     * @param caseId           - caseId
     * @param request          - FiRequest
     * @param validationErrors - Validation errors
     * @return AddDocumentResponse
     */
    @Operation(summary = "Request Further Information", operationId = "addFI", tags = {"Application Update Case API"},
            responses = {
                    @ApiResponse(responseCode = "201", description = "Created",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = AddDocumentResponse.class))}),
                    @ApiResponse(responseCode = "206", description = "Partial Content",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = AddDocumentResponse.class))}),
                    @ApiResponse(responseCode = "409", description = "Conflict",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = AddDocumentResponse.class))}),
                    @ApiResponse(responseCode = "400", description = "Bad Request",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                            schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "401", description = "Not Authorised",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                            schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "No record found",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                            schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "403", description = "Forbidden",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                            schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "500", description = "Internal Server Error",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                            schema = @Schema(implementation = ErrorResponse.class))})
            })
    @PreAuthorize("@authorizationServiceImpl.isDevTestUser() || @authorizationServiceImpl.isUWUser() " +
            "|| @authorizationServiceImpl.isPSTUser() || @authorizationServiceImpl.isMAUser() || @authorizationServiceImpl.isCINUser()")
    @PostMapping(path = "/application/case/{caseId}/firequest")
    public ResponseEntity<AddDocumentResponse> addFI(
            @RequestHeader(value = "brand") @Valid @Pattern(regexp = VALID_BRANDS, message = INVALID_BRAND) String brand,
            @PathVariable("caseId") @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_NUMBER_MAX_OF_THIRTY_SIX_CHAR, message = INVALID_CASE_ID) String caseId,
            @Valid @RequestBody @NotNull FIRequest request, BindingResult validationErrors) {
        log.info("addFI method entered in ApplicationUpdateController class with brand: {}", brand);
        return applicationUpdateService.addFI(brand, null, caseId, request);
    }

    /**
     * method is used for uploading document for the given mortgage/application id
     *
     * @param brand            - brand could be NWB/RBS
     * @param caseId           -caseId
     * @param documentRequest  - Document request object contains channel, application id and multipart
     * @param validationErrors - Validation errors
     * @return - DocumentUploadResponseDto
     * @throws JsonProcessingException - throw JsonParsingException
     */
    @PreAuthorize("@authorizationServiceImpl.isDevTestUser() || @authorizationServiceImpl.isUWUser() || @authorizationServiceImpl.isMopsUser()")
    @Operation(summary = "Upload application documents with caseId", operationId = "uploadDocumentWithCaseId", tags = {"Application Update Case API"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "OK",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = DocumentUploadResponseDto.class))}),
                    @ApiResponse(responseCode = "207", description = "Some uploads succeeded",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = DocumentUploadResponseDto.class))}),
                    @ApiResponse(responseCode = "400", description = "Bad Request"),
                    @ApiResponse(responseCode = "412", description = "Precondition Failed"),
                    @ApiResponse(responseCode = "413", description = "The request payload is too large",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = GlobalErrorResponseDto.class))}),
                    @ApiResponse(responseCode = "415", description = "All uploads failed due to invalid file types",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = GlobalErrorResponseDto.class))}),
            })
    @PostMapping(value = "/uploadDocument/case/{caseId}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<DocumentUploadResponseDto> uploadDocumentWithCaseId(
            @PathVariable("caseId") @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_NUMBER_MAX_OF_THIRTY_SIX_CHAR, message = INVALID_CASE_ID) String caseId,
            @RequestHeader(value = "brand") @Valid @Pattern(regexp = DOC_UPLOAD_VALID_BRANDS, message = INVALID_BRAND) String brand,
            @Valid @ModelAttribute DocumentRequest documentRequest, BindingResult validationErrors) throws JsonProcessingException {
        log.info("Inside uploadDocument endpoint");
        DocumentUploadResponseDto documentUploadResponseDto = applicationUpdateService.uploadDocument(brand, caseId, null, documentRequest);
        if (CollectionUtils.isNotEmpty(documentUploadResponseDto.getSuccessfulUploads()) && CollectionUtils.isNotEmpty(documentUploadResponseDto.getUnsuccessfulUploads())) {
            return new ResponseEntity<>(documentUploadResponseDto, HttpStatus.MULTI_STATUS);
        }
        return new ResponseEntity<>(documentUploadResponseDto, HttpStatus.OK);
    }


    /**
     * This endpoint is to update the application case owner by reference number in application collection
     *
     * @param brand           - brand
     * @param request         - case owner request object
     * @return UpdateApplicationCaseOwnerResponse ResponseEntity object
     */
    @PreAuthorize("@authorizationServiceImpl.isUWLead()")
    @Operation(summary = "Update Application Case Owner", operationId = "updateApplicationCaseOwner",
            description = "Update Case Owner for Mortgage Application based on caseId",
            tags = {"Application Update Case API"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "OK",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = CaseUpdatedCaseOwnerResponse.class))}),
                    @ApiResponse(responseCode = "206", description = "Partial Success",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = CaseUpdatedCaseOwnerResponse.class))}),
                    @ApiResponse(responseCode = "409", description = "Conflict",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = CaseUpdatedCaseOwnerResponse.class))}),
                    @ApiResponse(responseCode = "413", description = "The request payload is too large",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "400", description = "Bad Request", content = {@Content()}),
                    @ApiResponse(responseCode = "401", description = "Not Authorised", content = {@Content()}),
                    @ApiResponse(responseCode = "403", description = "Forbidden", content = {@Content()}),
                    @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {@Content()})
            })
    @PatchMapping(path = "/application/case/caseOwner", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CaseUpdatedCaseOwnerResponse> updateApplicationOwner(
            @RequestHeader(value = "brand") @Valid @Pattern(regexp = VALID_BRANDS, message = INVALID_BRAND) String brand,
            @Valid @NotNull @RequestBody CaseUpdateCaseOwnerRequest request) {

        log.info("Inside updateApplicationCaseOwner: brand:{} ", brand);
        return applicationUpdateService.updateApplicationOwner(brand, request);
    }

    /**
     * API to retrieve basic packaging from requiredDocs API and store into PM
     *
     * @param brand                    - brand
     * @param caseId                   - caseId
     * @return BasicPackagingDocumentResponse object
     */
    @PreAuthorize("@authorizationServiceImpl.isDevTestUser() || @authorizationServiceImpl.isMopsDataEntry()")
    @Operation(summary = "Add basic packaging requests for a given caseId", operationId = "addBasicPackagingRequests",
            tags = {"Application Update Case API"},
            responses = {
                    @ApiResponse(responseCode = "201", description = "Created",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = BasicPackagingDocumentResponse.class))}),
                    @ApiResponse(responseCode = "400", description = "Bad Request",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "401", description = "Not Authorised",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "No record found",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "403", description = "Forbidden",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "412", description = "Precondition Failed",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "500", description = "Internal Server Error",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))})
            })
    @PostMapping(path = "/application/case/{caseId}/packaging")
    public ResponseEntity<BasicPackagingDocumentResponse> addBasicPackaging(
            @RequestHeader(value = "brand") @Valid @Pattern(regexp = VALID_BRANDS, message = INVALID_BRAND) String brand,
            @PathVariable("caseId") @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_NUMBER_MAX_OF_THIRTY_SIX_CHAR, message = INVALID_CASE_ID) String caseId) {
        log.info("addBasicPackaging: brand:{} case:{}", brand, caseId);
        return applicationUpdateService.addBasicPackagingRequests(brand, caseId);
    }

    @Operation( summary = "Disassociates a given document",
            tags = {"Application Update Case API"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "Success",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = SuccessResponse.class))}),
                    @ApiResponse(responseCode = "400", description = "Bad Request",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "401", description = "Not Authorised",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "Resource not found",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "412", description = "Precondition Failed",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "500", description = "Internal Server Error",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))})}

    )
    @PreAuthorize("@authorizationServiceImpl.isDevTestUser() || @authorizationServiceImpl.isUWUser() || @authorizationServiceImpl.isDisassociateDocument()")
    @PatchMapping(path ="/application/case/{caseId}/documentRequest/{requestId}/document/{documentId}/disassociate" , produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<SuccessResponse> disassociateDocument(@RequestHeader(value = "brand") @Valid @Pattern(regexp = VALID_BRANDS, message = INVALID_BRAND) String brand,
                                                                @PathVariable("caseId") @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_NUMBER_MAX_OF_THIRTY_SIX_CHAR, message = INVALID_CASE_ID) String caseId,
                                                                @PathVariable("requestId") @Valid @NotNull @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_NUMBER_MAX_OF_FIFTY_CHAR, message = INVALID_REQUEST_ID) String requestId,
                                                                @PathVariable("documentId") @Valid @NotNull @Pattern(regexp = ALLOW_MAX_50_CHAR, message = INVALID_DOCUMENT_ID) String documentId){

        log.info("Disassociate document with caseId={}, requestId={}, documentId={} ", caseId, requestId, documentId);
        return new ResponseEntity<>(applicationUpdateService.disassociateDocument(brand, caseId, requestId, documentId), HttpStatus.OK);

    }
}