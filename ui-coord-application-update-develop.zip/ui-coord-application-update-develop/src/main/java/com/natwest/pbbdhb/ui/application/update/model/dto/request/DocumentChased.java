package com.natwest.pbbdhb.ui.application.update.model.dto.request;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.*;

/**
 * DocumentChased class is used to contain chased document information
 * and validation for all the fields are captured here
 */
@Data
@Schema(description = "DocumentChased Object")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Validated
@Valid
public class DocumentChased {

    @Valid
    @Parameter(description = "Request ID")
    @NotNull(message = INVALID_REQUEST_ID)
    private String requestId;

    @Valid
    @Parameter(description = "isNotificationRequired")
    @NotNull(message = INVALID_APPLICANT_NOTIFICATION)
    private boolean applicantNotification;

    @Valid
    @Parameter(description = "isNotificationRequired")
    @NotNull(message = INVALID_BROKER_NOTIFICATION)
    private boolean brokerNotification;

}
