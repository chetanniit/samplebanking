package com.natwest.pbbdhb.ui.application.update.service.stp.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.flowmanager.FlowManagerCaseAllocationRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.flowmanager.FlowManagerCaseDeallocationRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.stp.ExceptionAllocationResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.stp.ExceptionDeallocationResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.userinformation.UserInformationResponse;
import com.natwest.pbbdhb.ui.application.update.service.auth.AuthorizationService;
import com.natwest.pbbdhb.ui.application.update.service.stp.CaseAllocationService;
import com.natwest.pbbdhb.ui.application.update.util.ErrorMessageConfigReader;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Objects;
import java.util.Optional;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.BRAND;
import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.EXCEPTION_ID;

@Service
@Slf4j
public class CaseAllocationServiceImpl implements CaseAllocationService {

    @Autowired
    private AuthorizationService authorizationService;

    @Autowired
    @Qualifier("iamJwtChainSecureRestTemplate")
    private RestTemplate restTemplate;

    @Value("${msvc.flow-manager.parent.endpoint}")
    private String flowManagerParentEndpoint;

    @Value("${msvc.flow-manager.case-allocation.endpoint}")
    private String flowManagerCaseAllocationEndpoint;

    @Value("${msvc.flow-manager.case-deallocation.endpoint}")
    private String flowManagerCaseDeallocationEndpoint;

    @Autowired
    private ErrorMessageConfigReader errorMessageConfigReader;


    @Autowired
    private ObjectMapper objectMapper;

    @Override
    public ResponseEntity<ExceptionAllocationResponse> allocateCase(String brand, String exceptionId) {
        log.info("CaseAllocationServiceImpl method enters");
        UserInformationResponse userData = authorizationService.getUserData();
        FlowManagerCaseAllocationRequest caseAllocationRequest = FlowManagerCaseAllocationRequest.builder().build();

        if (Objects.nonNull(userData)) {
            caseAllocationRequest.setUserFullName(userData.getUsername());
            caseAllocationRequest.setUserRACFId(userData.getRacfID());
            if (Objects.nonNull(userData.getUserGroups())) {
                caseAllocationRequest.setUserGroups(new ArrayList(Arrays.asList(userData.getUserGroups())));
            }
        }


        String endPoint = flowManagerParentEndpoint + flowManagerCaseAllocationEndpoint;
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(endPoint);
        if (StringUtils.isNotEmpty(exceptionId)) {
            builder.replaceQueryParam(EXCEPTION_ID, exceptionId);
        }

        HttpHeaders headers = new HttpHeaders();
        headers.add("brand", brand);

        HttpEntity<FlowManagerCaseAllocationRequest> httpEntity = new HttpEntity<>(caseAllocationRequest, headers);

        log.info("Flow Manager service caseAllocation endPoint url {}, caseAllocation path{}", endPoint, flowManagerCaseAllocationEndpoint);
        ResponseEntity<String> responseEntity = restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.PATCH, httpEntity, String.class);
        ExceptionAllocationResponse exceptionAllocationResponse = null;
        try {
            exceptionAllocationResponse = objectMapper.readValue(responseEntity.getBody(), ExceptionAllocationResponse.class);
        } catch (JsonProcessingException e) {
            log.error("Exception occurred while response object conversion: {}", e.getMessage(), e);
        }
        return ResponseEntity.status(responseEntity.getStatusCode()).body(exceptionAllocationResponse);
    }

    @Override
    public ResponseEntity<ExceptionDeallocationResponse> deallocateCase(String brand, String exceptionId) {
        log.info("deallocateCase method enters for brand: {} exception: {}", brand, exceptionId);
        UserInformationResponse userData = authorizationService.getUserData();
        FlowManagerCaseDeallocationRequest caseDeallocationRequest = FlowManagerCaseDeallocationRequest.builder().build();

        Optional.ofNullable(userData).ifPresent(userInfo -> {
            caseDeallocationRequest.setUserRACFId(userInfo.getRacfID());
            caseDeallocationRequest.setPSTUser(userInfo.isPSTUser());
        });

        String endPoint = flowManagerParentEndpoint + flowManagerCaseDeallocationEndpoint;
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(endPoint);
        if (StringUtils.isNotEmpty(exceptionId)) {
            builder.replaceQueryParam(EXCEPTION_ID, exceptionId);
        }

        HttpHeaders header = new HttpHeaders();
        header.add(BRAND, brand);

        HttpEntity<FlowManagerCaseDeallocationRequest> httpEntity = new HttpEntity<>(caseDeallocationRequest, header);

        log.debug("header set for downstream call: {}, FlowManagerCaseDeallocationRequest :  {}", header, caseDeallocationRequest);
        ResponseEntity<String> responseEntity = restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.PATCH, httpEntity, String.class);
        ExceptionDeallocationResponse exceptionDeallocationResponse = null;
        try {
            exceptionDeallocationResponse = objectMapper.readValue(responseEntity.getBody(), ExceptionDeallocationResponse.class);
        } catch (JsonProcessingException e) {
            log.error("Exception occurred while response object conversion: {}", e.getMessage(), e);
        }
        return ResponseEntity.status(responseEntity.getStatusCode()).body(exceptionDeallocationResponse);

    }
}
