package com.natwest.pbbdhb.ui.application.update.service.auth;

import com.natwest.pbbdhb.ui.application.update.model.dto.request.MockUsersRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.userinformation.UserInformationResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.PostConstruct;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * MockUserService helps to change the mock user group at run time and help validate the endpoint
 * permissions based on the user groups
 */
@RestController
@Tag(name = "Mock User Update Service", description = "Mock User Update Service")
@RequestMapping("/")
@ConditionalOnExpression("${ids.functional.user.mock:false} and '${hbo.env}' != 'prd'")
public class UserMockService {

    private static final String UPDATE_SUCCESSFUL = "Update Successful";
    // set to true since default user group is UW
    private boolean isMockUserUw = true;
    private boolean isMockUserMcc;
    private boolean isMockUserMops;
    private boolean isMockUserUwLead;
    private boolean isMockUserDocViewer;
    private boolean isMockUserDataEntry;
    private boolean isMockDocumentDisassociate;
    private boolean isMockPSTUser;
    private boolean isMockMAUser;
    private boolean isMockCINUser;
    private boolean isMockRBSIUser;

    private UserInformationResponse userInfo;

    @Value("${ids.functional.user.mock.racfid:mockRACFID}")
    private String mockRacfId;

    @Value("${ids.functional.user.mock.username:'fnMockUser lnMockUser'}")
    private String mockUsername;

    @Value("${ids.functional.usergroups.uw:'mockUWUser'}")
    private String uwUserGroup;
    @Value("${ids.functional.usergroups.mopsDataEntry:'mockDataEntryUser'}")
    private String mopsDataEntryUserGroup;
    @Value("${ids.functional.usergroups.mcc:'mockMCCUser'}")
    private String mccUserGroup;
    @Value("${ids.functional.usergroups.mops:'mockMopsUser'}")
    private String mopsUserGroup;
    @Value("${ids.functional.usergroups.disassociateDocument:'mockDisassociateDocumentUser'}")
    private String disassociateDocumentUserGroup;
    @Value("${ids.functional.usergroups.docViewer:'mockDocViewerUser'}")
    private String docViewerUserGroup;
    @Value("${ids.functional.usergroups.pst:'mockPSTUser'}")
    private String pstUserGroup;
    @Value("${ids.functional.usergroups.ma:'mockMAUser'}")
    private String maUserGroup;
    @Value("${ids.functional.usergroups.cin:'mockCINUser'}")
    private String cinUserGroup;
    @Value("${ids.functional.usergroups.rbsi:'mockRBSIUser'}")
    private String rbsiUserGroup;

    @PostConstruct
    private void setup() {
        userInfo = UserInformationResponse.builder()
                .isMCCUser(isMockUserMcc)
                .isUWUser(isMockUserUw)
                .isMopsUser(isMockUserMops)
                .isUWLead(isMockUserUwLead)
                .isDocViewer(isMockUserDocViewer)
                .isMopsDataEntry(isMockUserDataEntry)
                .isDocumentDisassociate(isMockDocumentDisassociate)
                .isPSTUser(isMockPSTUser)
                .isMAUser(isMockMAUser)
                .isCINUser(isMockCINUser)
                .isRBSIUser(isMockRBSIUser)
                .racfID(mockRacfId)
                .username(mockUsername)
                .userGroups(getUserGroups())
                .build();
    }

    @Operation(summary = "Set Multi group Mock User", operationId = "setMultiGroupMockUser", tags = {"Mock User Update Service"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "OK",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = String.class))})
            })
    @PostMapping(path = "/enableMockUsers", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> setMultiGroupMockUser(@Valid @NotNull @RequestBody MockUsersRequest mockUsersRequest) {
        isMockUserUw = mockUsersRequest.getIsUWUser();
        isMockUserMcc = mockUsersRequest.getIsMCCUser();
        isMockUserMops = mockUsersRequest.getIsMopsUser();
        isMockUserUwLead = mockUsersRequest.getIsUWLead();
        isMockUserDocViewer = mockUsersRequest.getIsDocViewer();
        isMockUserDataEntry = mockUsersRequest.getIsMopsDataEntry();
        isMockDocumentDisassociate = mockUsersRequest.getIsDisassociateDocument();
        isMockPSTUser = mockUsersRequest.getIsPSTUser();
        isMockMAUser = mockUsersRequest.getIsMAUser();
        isMockCINUser=mockUsersRequest.getIsCINUser();
        isMockRBSIUser=mockUsersRequest.getIsRBSIUser();
        Optional.ofNullable(mockUsersRequest.getRacfID()).ifPresent(s -> mockRacfId = s);
        Optional.ofNullable(mockUsersRequest.getUsername()).ifPresent(s -> mockUsername = s);
        return new ResponseEntity<>(UPDATE_SUCCESSFUL, HttpStatus.OK);
    }

    public UserInformationResponse getMockUser() {
        userInfo.setMCCUser(isMockUserMcc);
        userInfo.setMopsUser(isMockUserMops);
        userInfo.setUWUser(isMockUserUw);
        userInfo.setRacfID(mockRacfId);
        userInfo.setUsername(mockUsername);
        userInfo.setUWLead(isMockUserUwLead);
        userInfo.setDocViewer(isMockUserDocViewer);
        userInfo.setMopsDataEntry(isMockUserDataEntry);
        userInfo.setDocumentDisassociate(isMockDocumentDisassociate);
        userInfo.setPSTUser(isMockPSTUser);
        userInfo.setMAUser(isMockMAUser);
        userInfo.setCINUser(isMockCINUser);
        userInfo.setRBSIUser(isMockRBSIUser);
        userInfo.setUserGroups(getUserGroups());
        return userInfo;
    }

    private String[] getUserGroups() {
        List<String> userGroupsList = new ArrayList<>();
        if(isMockUserMcc) userGroupsList.add(mccUserGroup);
        if(isMockUserMops) userGroupsList.add(mopsUserGroup);
        if(isMockUserDocViewer) userGroupsList.add(docViewerUserGroup);
        if(isMockUserDataEntry) userGroupsList.add(mopsDataEntryUserGroup);
        if(isMockDocumentDisassociate) userGroupsList.add(disassociateDocumentUserGroup);
        if(isMockUserUw || isMockUserUwLead) userGroupsList.add(uwUserGroup);
        if(isMockPSTUser) userGroupsList.add(pstUserGroup);
        if(isMockMAUser) userGroupsList.add(maUserGroup);
        if(isMockCINUser) userGroupsList.add(cinUserGroup);
        if(isMockRBSIUser) userGroupsList.add(rbsiUserGroup);

        return userGroupsList.toArray(new String[0]);
    }

}