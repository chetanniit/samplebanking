package com.natwest.pbbdhb.ui.application.update.model.dto.request.flowmanager;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * FlowManagerCaseDeallocationRequest class is the request
 * for downstream case deallocation endpoint
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FlowManagerCaseDeallocationRequest {
    private String userRACFId;
    @JsonProperty(value = "isPSTUser", required = true)
    private boolean isPSTUser;
}
