package com.natwest.pbbdhb.ui.application.update.model.dto.request.firequest;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * FlowManagerDocument object used in create FI request
 */
@Data
@Schema(description = "Flow manager document object")
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FlowManagerDocument {

    private List<DocumentFor> requiredFor;
    private String taskCode;
    private String documentIdentifier;
    private String category;
    private List<String> purpose;
    private List<String> reRequestReason;
    private String dueDate;
    private String fromDate;
    private String toDate;
    private String count;
    private String frequency;
    private String otherInfo;
    private String fiType;
    @Builder.Default
    private String state = "Open";
    @Builder.Default
    private String requestType = "Further Information";
    private String additionalInfo;
    private String exceptionIdToResolve;

}