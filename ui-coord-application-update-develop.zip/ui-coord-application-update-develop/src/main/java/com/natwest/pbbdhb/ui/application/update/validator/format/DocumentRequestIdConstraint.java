package com.natwest.pbbdhb.ui.application.update.validator.format;


import com.natwest.pbbdhb.ui.application.update.validator.DocumentRequestIdValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.INVALID_REQUEST_ID;


/**
 * This interface is to validate document request ids
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD, ElementType.PARAMETER})
@Constraint(validatedBy = DocumentRequestIdValidator.class)
public @interface DocumentRequestIdConstraint {
    /**
     * return error message
     *
     * @return string
     */
    String message() default INVALID_REQUEST_ID;

    /**
     * return object
     *
     * @return Class
     */
    Class<?>[] groups() default {};

    /**
     * return object
     *
     * @return class
     */
    Class<? extends Payload>[] payload() default {};
}
