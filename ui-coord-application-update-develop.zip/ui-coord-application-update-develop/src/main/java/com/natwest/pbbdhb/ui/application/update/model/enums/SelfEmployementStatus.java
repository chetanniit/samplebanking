package com.natwest.pbbdhb.ui.application.update.model.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum SelfEmployementStatus {
    SOLE_TRADER,
    PARTNERSHIP,
    CONTRACTOR,
    LIMITED_COMPANY

}
