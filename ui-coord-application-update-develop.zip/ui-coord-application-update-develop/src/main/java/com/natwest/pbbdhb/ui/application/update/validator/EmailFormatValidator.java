package com.natwest.pbbdhb.ui.application.update.validator;


import com.natwest.pbbdhb.ui.application.update.validator.format.EmailFormat;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationUtil.isValidEmail;


/**
 * Validator to validate email format
 */
public class EmailFormatValidator implements ConstraintValidator<EmailFormat, String> {

    /**
     * method to validate email
     * @param email - input email
     * @param constraintValidatorContext - constraintValidatorContext
     * @return - boolean based on validation
     */
    @Override
    public boolean isValid(String email, ConstraintValidatorContext constraintValidatorContext) {
        return isValidEmail(email);
    }
}
