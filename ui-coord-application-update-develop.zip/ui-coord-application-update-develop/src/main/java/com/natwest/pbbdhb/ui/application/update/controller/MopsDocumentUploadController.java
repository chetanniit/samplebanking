package com.natwest.pbbdhb.ui.application.update.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.natwest.pbbdhb.ui.application.update.model.dto.document.DocumentUploadResponseDto;
import com.natwest.pbbdhb.ui.application.update.model.dto.document.GlobalErrorResponseDto;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.document.DocumentUploadRequest;
import com.natwest.pbbdhb.ui.application.update.service.ApplicationUpdateService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * This class handles the MOPS user document upload request
 *
 */
@PreAuthorize("@authorizationServiceImpl.isDevTestUser() || @authorizationServiceImpl.isMopsUser()")
@RestController
@Tag(name = "Application Update MOPS Document Upload API", description = "Application Update MOPS Document Upload API")
@RequestMapping("/")
@AllArgsConstructor
@Validated
@Slf4j
public class MopsDocumentUploadController {

    private final ApplicationUpdateService applicationUpdateService;

    /**
     * This method handles the MOPS user document upload request
     *
     * @param documentUploadRequest - input request object
     * @param validationErrors - validation errors
     * @return DocumentUploadResponseDto - response
     * @throws JsonProcessingException - exception object
     */
    @Operation(summary = "Upload application document", operationId = "uploadDocument", tags = {"Application Update MOPS Document Upload API"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "upload success",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = DocumentUploadResponseDto.class))}),
                    @ApiResponse(responseCode = "400", description = "Bad Request"),
                    @ApiResponse(responseCode = "413", description = "The request payload is too large",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = GlobalErrorResponseDto.class))}),
                    @ApiResponse(responseCode = "415", description = "Upload failed due to invalid file type",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = DocumentUploadResponseDto.class))})
            })
    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<DocumentUploadResponseDto> uploadSingleDocument(
            @Valid @ModelAttribute DocumentUploadRequest documentUploadRequest, BindingResult validationErrors) throws JsonProcessingException {
        log.info("uploadSingleDocument method enters in ApplicationUpdateController class");
        DocumentUploadResponseDto documentUploadResponseDto = applicationUpdateService.uploadSingleDocument(documentUploadRequest);
        if (CollectionUtils.isNotEmpty(documentUploadResponseDto.getSuccessfulUploads()) && CollectionUtils.isNotEmpty(
                documentUploadResponseDto.getUnsuccessfulUploads())) {
            return new ResponseEntity<>(documentUploadResponseDto, HttpStatus.MULTI_STATUS);
        }
        return new ResponseEntity<>(documentUploadResponseDto, HttpStatus.OK);
    }
}