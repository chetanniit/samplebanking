package com.natwest.pbbdhb.ui.application.update.service;


import com.natwest.pbbdhb.ui.application.update.model.dto.request.CloseTaskRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.TaskRequest;

import java.text.ParseException;

/**
 * This interface contains the methods related to tasks
 */
public interface TaskService {

    /**
     * @param brand - Allowed values NWB/RBS
     * @param taskRequest - request object represents the task request
     * @return String
     * @throws ParseException - throws parse exception during date conversion
     */
    String addTask(String brand, TaskRequest taskRequest) throws ParseException;

    /**
     * @param brand - Allowed values NWB/RBS
     * @param request - request object represents the close task request
     * @return String
     * @throws ParseException - throws parse exception during date conversion
     */
    String closeTask(String brand, CloseTaskRequest request) throws ParseException;
}
