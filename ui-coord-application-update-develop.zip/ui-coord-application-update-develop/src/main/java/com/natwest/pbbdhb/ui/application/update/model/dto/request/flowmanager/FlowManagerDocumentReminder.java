package com.natwest.pbbdhb.ui.application.update.model.dto.request.flowmanager;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * FlowManagerDocumentReminder class is the request
 * for downstream notification endpoint
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FlowManagerDocumentReminder {

    private String referenceNumber;
    private String caseId;
    private String userFullName;
    private String userRACFId;
    private List<String> requestIds;
}
