package com.natwest.pbbdhb.ui.application.update.events;

import lombok.Builder;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEvent;


/**
 * This class is used to represent ApplicantInfoUpdateEvent
 */
@Slf4j
@Getter
public class ApplicantInfoUpdateEvent extends ApplicationEvent{

    private static final long serialVersionUID = -4014063888186516680L;
    private final String emailAddress;
    private final String mobileNumber;
    private final String notificationRequired;
    private final String brand;
    private final String caseId;
    private final Boolean mainApplicant;

    /**
     * This constructor is used to build ApplicantInfoUpdateEvent object
     *
     * @param brand - String
     * @param caseId - String
     * @param emailAddress - String
     * @param mobileNumber - String
     * @param notificationRequired - String
     * @param mainApplicant - boolean
     */
    @Builder
    public ApplicantInfoUpdateEvent(String brand, String caseId, String emailAddress, String mobileNumber, String notificationRequired, Boolean mainApplicant) {
        super(brand);
        this.brand = brand;
        this.caseId = caseId;
        this.emailAddress = emailAddress;
        this.mobileNumber = mobileNumber;
        this.notificationRequired = notificationRequired;
        this.mainApplicant = mainApplicant;
    }
}
