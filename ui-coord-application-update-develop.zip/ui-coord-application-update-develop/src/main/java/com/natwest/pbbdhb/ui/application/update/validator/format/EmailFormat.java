package com.natwest.pbbdhb.ui.application.update.validator.format;


import com.natwest.pbbdhb.ui.application.update.validator.EmailFormatValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.INVALID_EMAIL_ID;


/**
 * Custom annotation to validate email format
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD, ElementType.PARAMETER})
@Constraint(validatedBy = EmailFormatValidator.class)
public @interface EmailFormat {

    /**
     * message to return when validation fails
     * @return error message
     */
    String message() default INVALID_EMAIL_ID;

    /**
     * groups
     * @return class
     */
    Class<?>[] groups() default {};

    /**
     * Payload
     * @return class
     */
    Class<? extends Payload>[] payload() default {};

}
