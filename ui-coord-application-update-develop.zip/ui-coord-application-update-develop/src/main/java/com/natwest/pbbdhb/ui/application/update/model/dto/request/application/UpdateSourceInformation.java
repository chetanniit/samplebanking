package com.natwest.pbbdhb.ui.application.update.model.dto.request.application;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.*;


/**
 * Update source information object
 */
@Data
@Schema(description = "Update source information Object")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Validated
@Valid
public class UpdateSourceInformation {

    @Valid
    @Parameter(description = "source racfId")
    @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_NUMBER_MAX_OF_TEN_DIGITS, message = INVALID_SOURCE_RACF_ID)
    private String racfId;

    @Valid
    @Parameter(description = "primary advisor racfId")
    @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_NUMBER_MAX_OF_TEN_DIGITS, message = INVALID_PRIMARY_ADVISOR_RACF_ID)
    private String primaryAdvisorRacfId;

    @Valid
    @Parameter(description = "applicationType")
    @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_UNDERSCORE_MAX_20, message = INVALID_APPLICATION_TYPE)
    private String applicationType;

    @Valid
    @Parameter(description = "advisor")
    @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_SPECIAL_CHAR_MAX_50, message = INVALID_ADVISOR)
    private String advisor;

    @Valid
    @Parameter(description = "lead advisor")
    @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_SPECIAL_CHAR_MAX_50, message = INVALID_LEAD_ADVISOR)
    private String leadAdvisor;

    @Valid
    @Parameter(description = "leadGenerator")
    @Pattern(regexp = ALLOW_ONLY_ALPHANUMERIC_AND_NO_SPECIAL_CHARACTER_MIN_6_MAX_12, message = INVALID_LEAD_GENERATOR)
    private String leadGenerator;

    @Valid
    @Parameter(description = "mortgageAdvised")
    private Boolean mortgageAdvised;
}