package com.natwest.pbbdhb.ui.application.update.util;


import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

/**
 * Property reader to read the properties from properties file
 *
 */
@ConfigurationProperties(prefix = "dbretry")
@Slf4j
@Data
@Component("dbUpdateRetryPropertiesReader")
@RefreshScope
public class DBUpdateRetryPropertiesReader {

    @Value("${count:1}")
    private int count;
    @Value("${waitdelay:1000}")
    private long waitDelay;

    /**
     * This method is used to print the retry configs
     *
     */
    @PostConstruct
    public void print() {
        log.info("async mongoDB update call retry properties are loaded with values :{}", this);
    }
}
