package com.natwest.pbbdhb.ui.application.update.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.ui.application.update.mapper.FlowManagerRequestMapper;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.DocumentReminder;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.flowmanager.FlowManagerDocumentReminder;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.SuccessResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.userinformation.UserInformationResponse;
import com.natwest.pbbdhb.ui.application.update.service.DocumentReminderService;
import com.natwest.pbbdhb.ui.application.update.service.auth.AuthorizationService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.*;


/**
 * Impl class of DocumentReminderService interface and contains the methods related to sendReminder endPoint
 */
@Service
@Slf4j
public class DocumentReminderServiceImpl implements DocumentReminderService {

    @Value("${msvc.flow-manager.parent.endpoint}")
    private String flowManagerParentEndpoint;

    @Value("${msvc.flow-manager.document-reminder.endpoint}")
    private String flowManagerReminderEndpoint;

    @Value("${msvc.flow-manager.case-document-reminder.endpoint}")
    private String flowManagerCaseReminderEndpoint;

    @Autowired
    @Qualifier("customSecureRestTemplate")
    private RestTemplate restTemplate;

    @Autowired
    private AuthorizationService authorizationService;

    @Autowired
    private FlowManagerRequestMapper flowManagerRequestMapper;

    @Autowired
    private ObjectMapper objectMapper;

    /**
     * This method is to add Further Information based on the brand and FIRequest
     *
     * @param brand            - could be NWB/RBS
     * @param documentReminder - Object which has the FIRequest details
     * @return String
     */
    @Override
    public ResponseEntity<SuccessResponse> sendReminder(String brand, DocumentReminder documentReminder, String referenceNumber,
                                                        String caseId) {
        log.info("Entered into sendReminder for brand - {}, referenceNumber - {}, caseId - {}, fiRequestIds - {}",
                brand, referenceNumber, caseId, documentReminder.getFiRequestIds());
        SuccessResponse successResponse = null;
        UserInformationResponse userData = authorizationService.getUserData();
        FlowManagerDocumentReminder flowManagerDocumentReminder = FlowManagerDocumentReminder.builder().build();
        flowManagerDocumentReminder.setRequestIds(documentReminder.getFiRequestIds());
        Optional.ofNullable(userData).ifPresent(userInfo -> {
            flowManagerDocumentReminder.setUserFullName(userData.getUsername());
            flowManagerDocumentReminder.setUserRACFId(userData.getRacfID());
        });
        Map<String, Object> urlParams = new HashMap<>();
        String endPoint = flowManagerParentEndpoint;
        if (StringUtils.isNotBlank(referenceNumber)) {
            flowManagerDocumentReminder.setReferenceNumber(referenceNumber);
            urlParams.put(REFERENCE_NUMBER, referenceNumber);
            endPoint = endPoint + flowManagerReminderEndpoint;
        } else if (StringUtils.isNotBlank(caseId)) {
            flowManagerDocumentReminder.setCaseId(caseId);
            urlParams.put(CASE_ID, caseId);
            endPoint = endPoint + flowManagerCaseReminderEndpoint;
        }

        URI builder = UriComponentsBuilder.fromUriString(endPoint).buildAndExpand(urlParams).toUri();
        HttpHeaders headers = new HttpHeaders();
        headers.add("brand", brand);

        HttpEntity<FlowManagerDocumentReminder> httpEntity = new HttpEntity<>(flowManagerDocumentReminder, headers);

        log.info("Flow Manager service sendReminder endPoint url {}", endPoint);
        ResponseEntity<String> responseEntity = restTemplate.exchange(builder, HttpMethod.POST, httpEntity, String.class);
        log.info("Response Received from Flow Manager service sendReminder endPoint is :" + responseEntity);
        try {
            successResponse = objectMapper.readValue(responseEntity.getBody(), SuccessResponse.class);
        } catch (JsonProcessingException e) {
            log.error("Exception occurred while response object conversion: {}", e.getMessage(), e);
        }
        return ResponseEntity.status(responseEntity.getStatusCode()).body(successResponse);
    }
}
