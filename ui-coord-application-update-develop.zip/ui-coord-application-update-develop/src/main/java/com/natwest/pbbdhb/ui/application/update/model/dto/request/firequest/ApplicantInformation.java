package com.natwest.pbbdhb.ui.application.update.model.dto.request.firequest;

import com.natwest.pbbdhb.ui.application.update.validator.format.EmailFormat;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.*;

/**
 * ApplicantInformation class is the request for /requestFI endpoint
 * and validation for all the fields are captured here
 */
@Data
@Schema(description = "Add Applicant Information Object")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Validated
@Valid
public class ApplicantInformation {

    @Valid
    @Parameter(description = "ApplicantID")
    @Pattern(regexp = ALLOW_ONLY_ALPHABETS_NUMBER_AND_SPACE_MAX_OF_TEN_CHAR, message = INVALID_ID)
    @NotNull(message = INVALID_ID)
    private String applicantId;

    @Valid
    @Parameter(description = "applicantTitle")
    @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_SPECIAL_CHAR_MAX_50, message = INVALID_TITLE)
    private String title;

    @Valid
    @Parameter(description = "applicantFirstName")
    @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_SPACE_MAX_OF_FIFTY_CHAR, message = INVALID_FIRST_NAME)
    private String firstName;

    @Valid
    @Parameter(description = "applicantLastName")
    @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_SPACE_MAX_OF_FIFTY_CHAR, message = INVALID_LAST_NAME)
    private String lastName;

    @Valid
    @Parameter(description = "email")
    @EmailFormat
    private String emailAddress;

    @Valid
    @Parameter(description = "phone")
    @Pattern(regexp = ALLOW_ONLY_NUMBERS_SPACE_AND_PLUS_MAX_OF_15_DIGITS, message = INVALID_MOBILE_NO)
    private String mobileNumber;

    @Valid
    @Parameter(description = "isNotificationRequired")
    @NotNull(message = INVALID_NOTIFICATION_REQUIRED)
    private boolean isNotificationRequired;
}
