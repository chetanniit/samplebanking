package com.natwest.pbbdhb.ui.application.update.service;

import com.natwest.pbbdhb.ui.application.update.model.dto.notes.DocumentNotesRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.SuccessResponse;
import org.springframework.http.ResponseEntity;

public interface DocumentNotesService {
    /**
     * This method is used to add the note
     *
     * @param brand   - supported brands NWB/RBS
     * @param referenceNumber - String referenceNumber
     * @param caseId - String caseId
     * @param request - request object
     * @return String - String response
     */
    ResponseEntity<SuccessResponse> addDocumentRequestNotes(String brand, String referenceNumber, String caseId, DocumentNotesRequest request);

}
