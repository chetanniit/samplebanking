package com.natwest.pbbdhb.ui.application.update.controller;

import com.natwest.pbbdhb.adbo.dto.CaseDetailsDto;
import com.natwest.pbbdhb.applicant.dto.ApplicantDto;
import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.income.expense.model.domain.CaseStatusDto;
import com.natwest.pbbdhb.income.expense.model.enums.CaseStatus;
import com.natwest.pbbdhb.income.expense.model.expense.request.CaseExpenseDto;
import com.natwest.pbbdhb.income.expense.model.expense.response.ValidatedCaseExpenseDto;
import com.natwest.pbbdhb.income.expense.model.income.request.CaseIncomeDto;
import com.natwest.pbbdhb.income.expense.model.income.response.ValidatedCaseIncomeDto;
import com.natwest.pbbdhb.property.dto.PropertyDetailsDto;
import com.natwest.pbbdhb.ui.application.update.model.dto.capie.ManualKeyInCaseUpdateRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.exception.ErrorResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.SuccessResponse;
import com.natwest.pbbdhb.ui.application.update.service.ApplicationUpdateService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.json.JsonPatch;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import static com.natwest.pbbdhb.ui.application.update.converter.JsonPatchHttpMessageConverter.JSON_PATCH;
import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.*;

/**
 * This class has all endpoints related to creation and deletion of tasks and notes
 */
@PreAuthorize("@authorizationServiceImpl.isDevTestUser() || @authorizationServiceImpl.isUWUser()")
@RestController
@Tag(name = "CAPIE Update API", description = "CAPIE Update API")
@RequestMapping("/")
@AllArgsConstructor
@Validated
@Slf4j
public class CapieUpdateController {

    private final ApplicationUpdateService applicationUpdateService;

    /**
     * This endpoint is to update the property information for the given case id
     *
     * @param brand   - brand
     * @param caseId  - String caseId
     * @param request - PropertyDetailsDto
     * @return PropertyDetailsDto ResponseEntity object
     */
    @Operation(summary = "Update Property Information", operationId = "updatePropertyInformation", tags = {"CAPIE Update API"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "Ok",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = PropertyDetailsDto.class))}),
                    @ApiResponse(responseCode = "400", description = "Bad Request"),
                    @ApiResponse(responseCode = "401", description = "Not Authorised"),
                    @ApiResponse(responseCode = "403", description = "Forbidden"),
                    @ApiResponse(responseCode = "404", description = "No record found"),
                    @ApiResponse(responseCode = "409", description = "Conflict",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = PropertyDetailsDto.class))}),
                    @ApiResponse(responseCode = "412", description = "Precondition Failed"),
                    @ApiResponse(responseCode = "500", description = "Internal Server Error")
            })
    @PutMapping(path = "/capie/case/{caseId}/property", produces = MediaType.APPLICATION_JSON_VALUE)
    public PropertyDetailsDto updatePropertyInformation(
            @RequestHeader(value = "brand") @Valid @Pattern(regexp = DOC_UPLOAD_VALID_BRANDS, message = INVALID_BRAND) String brand,
            @PathVariable("caseId") @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_NUMBER_MAX_OF_THIRTY_SIX_CHAR, message = INVALID_CASE_ID) String caseId,
            @Valid @RequestBody PropertyDetailsDto request) {
        log.info("updatePropertyInformation enters for the caseId:{}", caseId);
        return applicationUpdateService.updatePropertyInformation(brand, caseId, request);
    }

    /**
     * This endpoint will update applicant based on applicantid and caseId
     *
     * @param brand            - Brand
     * @param caseId           - CaseID
     * @param applicantId      - ApplicantId
     * @param request          - ApplicantDto object to update applicant information
     * @param validationErrors - Validation errors
     * @return ApplicantDto - ApplicantDto response
     */
    @Operation(summary = "update Applicant for Applicant Id and caseId", operationId = "updateApplicants", tags = {"CAPIE Update API"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "Ok",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ApplicantDto.class))}),
                    @ApiResponse(responseCode = "206", description = "Partial Success",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = String.class))}),
                    @ApiResponse(responseCode = "400", description = "Bad Request"),
                    @ApiResponse(responseCode = "401", description = "Not Authorised"),
                    @ApiResponse(responseCode = "403", description = "Forbidden"),
                    @ApiResponse(responseCode = "404", description = "No record found"),
                    @ApiResponse(responseCode = "412", description = "Precondition Failed"),
                    @ApiResponse(responseCode = "500", description = "Internal Server Error")
            })
    @PutMapping(path = "/capie/case/{caseId}/applicants/{applicantId}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ApplicantDto> updateApplicants(
            @RequestHeader(value = "brand") @Valid @Pattern(regexp = VALID_BRANDS, message = INVALID_BRAND) String brand,
            @PathVariable("caseId") @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_NUMBER_MAX_OF_THIRTY_SIX_CHAR, message = INVALID_CASE_ID) String caseId,
            @PathVariable("applicantId") @Valid @NotNull(message = INVALID_APPLICANT_ID) @NotEmpty(message = INVALID_APPLICANT_ID) String applicantId,
            @Valid @RequestBody @NotNull ApplicantDto request, BindingResult validationErrors) {
        log.info("updateApplicants method entered in ApplicationUpdateController class with brand: {}, caseId: {}, applicantId: {}", brand, caseId, applicantId);
        return applicationUpdateService.updateApplicants(brand, applicantId, caseId, request);
    }

    /**
     * This endpoint will update case information in CAPIE system by case id
     *
     * @param brand     - brand
     * @param caseId    - caseId
     * @param jsonPatch - jsonPatch
     * @return CaseApplicationDto
     */
    @Operation(summary = "Update case information by case id in CAPIE system", operationId = "updateCaseInformation", tags = {"CAPIE Update API"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "Success",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = CaseApplicationDto.class))}),
                    @ApiResponse(responseCode = "400", description = "Bad Request"),
                    @ApiResponse(responseCode = "401", description = "Not Authorised"),
                    @ApiResponse(responseCode = "403", description = "Forbidden"),
                    @ApiResponse(responseCode = "404", description = "No record found"),
                    @ApiResponse(responseCode = "412", description = "Precondition Failed"),
                    @ApiResponse(responseCode = "500", description = "Internal Server Error")
            })
    @PatchMapping(path = "/capie/case/{caseId}", consumes = JSON_PATCH, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CaseApplicationDto> updateCaseInformation(
            @RequestHeader(value = "brand") @Valid @Pattern(regexp = VALID_BRANDS, message = INVALID_BRAND) String brand,
            @PathVariable("caseId") @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_NUMBER_MAX_OF_THIRTY_SIX_CHAR, message = INVALID_CASE_ID) String caseId,
            @RequestBody JsonPatch jsonPatch) {
        log.info("updateCaseInformation method entered in ApplicationUpdateCaseController class with brand: {}, caseId: {}", brand, caseId);
        CaseApplicationDto caseApplicationDto = applicationUpdateService.updateCaseInformation(brand, caseId, jsonPatch);
        return new ResponseEntity<>(caseApplicationDto, HttpStatus.OK);
    }

    /**
     * This endpoint is to patch update the property information for the given case id in capie service
     *
     * @param brand     - brand
     * @param caseId    - caseId
     * @param jsonPatch - jsonPatch
     * @return PropertyDetailsDto
     */
    @Operation(summary = "Patch Update Property Information by case id in CAPIE system", operationId = "patchUpdatePropertyInformation", tags = {"CAPIE Update API"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "Success",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = PropertyDetailsDto.class))}),
                    @ApiResponse(responseCode = "400", description = "Bad Request"),
                    @ApiResponse(responseCode = "401", description = "Not Authorised"),
                    @ApiResponse(responseCode = "403", description = "Forbidden"),
                    @ApiResponse(responseCode = "404", description = "No record found"),
                    @ApiResponse(responseCode = "412", description = "Precondition Failed"),
                    @ApiResponse(responseCode = "500", description = "Internal Server Error")
            })
    @PatchMapping(path = "/capie/case/{caseId}/property", consumes = JSON_PATCH, produces = MediaType.APPLICATION_JSON_VALUE)
    public PropertyDetailsDto patchUpdatePropertyInformation(
            @RequestHeader(value = "brand") @Valid @Pattern(regexp = VALID_BRANDS, message = INVALID_BRAND) String brand,
            @PathVariable("caseId") @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_NUMBER_MAX_OF_THIRTY_SIX_CHAR, message = INVALID_CASE_ID) String caseId,
            @RequestBody JsonPatch jsonPatch) {
        log.info("patchUpdatePropertyInformation method entered in ApplicationUpdateCaseController class with brand: {}, caseId: {}", brand, caseId);
        return applicationUpdateService.patchUpdatePropertyInformation(brand, caseId, jsonPatch);
    }

    /**
     * This method is used to update Applicant information by applicant id in CAPIE system
     *
     * @param brand       - String
     * @param caseId      - String
     * @param applicantId - String
     * @param jsonPatch   - String
     * @return ApplicantDto - response
     */
    @Operation(summary = "update Applicant information by applicant id in CAPIE system", operationId = "patchUpdateApplicantInformation", tags = {"CAPIE Update API"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "Success",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ApplicantDto.class))}),
                    @ApiResponse(responseCode = "400", description = "Bad Request"),
                    @ApiResponse(responseCode = "401", description = "Not Authorised"),
                    @ApiResponse(responseCode = "403", description = "Forbidden"),
                    @ApiResponse(responseCode = "404", description = "No record found"),
                    @ApiResponse(responseCode = "412", description = "Precondition Failed"),
                    @ApiResponse(responseCode = "500", description = "Internal Server Error")
            })
    @PatchMapping(value = "/capie/case/{caseId}/applicants/{applicantId}", consumes = JSON_PATCH, produces = MediaType.APPLICATION_JSON_VALUE)
    public ApplicantDto patchUpdateApplicantInformation(@RequestHeader(value = "brand") @Valid @Pattern(regexp = VALID_BRANDS, message = INVALID_BRAND) String brand,
                                      @PathVariable("caseId") @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_NUMBER_MAX_OF_THIRTY_SIX_CHAR, message = INVALID_CASE_ID) String caseId,
                                      @PathVariable("applicantId") @Valid @NotNull(message = INVALID_APPLICANT_ID) @NotEmpty(message = INVALID_APPLICANT_ID) String applicantId,
                                      @RequestBody JsonPatch jsonPatch) {
        log.info("partialUpdate method enters in ApplicationUpdateController class with brand: {}, caseId: {}, applicantId: {}", brand, caseId, applicantId);
        return applicationUpdateService.patchApplicantUpdate(brand, caseId, applicantId, jsonPatch);
    }

    /**
     * This endpoint is to update the application information in application collection
     *
     * @param brand   - brand
     * @param caseId  - String caseId
     * @param request - ApplicationInformationUpdateRequest
     * @return ApplicationInformationUpdateResponse ResponseEntity object
     */
    @Operation(summary = "Update Application Information", operationId = "updateApplicationInformation", tags = {"CAPIE Update API"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "OK",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = CaseApplicationDto.class))}),
                    @ApiResponse(responseCode = "400", description = "Bad Request"),
                    @ApiResponse(responseCode = "401", description = "Not Authorised"),
                    @ApiResponse(responseCode = "403", description = "Forbidden"),
                    @ApiResponse(responseCode = "409", description = "Conflict",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = CaseApplicationDto.class))}),
                    @ApiResponse(responseCode = "404", description = "No record found"),
                    @ApiResponse(responseCode = "412", description = "Precondition Failed"),
                    @ApiResponse(responseCode = "500", description = "Internal Server Error")
            })
    @PutMapping(path = "capie/case/{caseId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CaseApplicationDto> updateApplicationInformation(@RequestHeader(value = "brand") @Valid @Pattern(regexp = VALID_BRANDS, message = INVALID_BRAND) String brand,
                                                                                             @PathVariable("caseId") @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_NUMBER_MAX_OF_THIRTY_SIX_CHAR, message = INVALID_CASE_ID) String caseId,
                                                                                             @Valid @NotNull @RequestBody CaseApplicationDto request) {
        log.info("Inside updateApplicationInformation for caseId:{}", caseId);
        return applicationUpdateService.updateApplicationInformation(brand, request, caseId);
    }

    /**
     * This endpoint will save and update income data in CAPIE system by case id
     *
     * @param brand            - Brand
     * @param caseId           - String caseId
     * @param request          - CaseIncomeDto
     * @param validationErrors - Validation errors
     * @return ValidatedCaseIncomeDto
     */
    @Operation(summary = "update and save income data in capie system", operationId = "UpdateIncome", tags = {"CAPIE Update API"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "income data saved successfully",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ValidatedCaseIncomeDto.class))}),
                    @ApiResponse(responseCode = "207", description = "income data saved with validation failures",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ValidatedCaseIncomeDto.class))}),
                    @ApiResponse(responseCode = "400", description = "Bad Request"),
                    @ApiResponse(responseCode = "401", description = "Not Authorised"),
                    @ApiResponse(responseCode = "403", description = "Forbidden"),
                    @ApiResponse(responseCode = "404", description = "No record found"),
                    @ApiResponse(responseCode = "422", description = "Unprocessable Entity"),
                    @ApiResponse(responseCode = "409", description = "Conflict"),
                    @ApiResponse(responseCode = "500", description = "Internal Server Error")
            })
    @PutMapping(path = "/capie/case/{caseId}/income", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ValidatedCaseIncomeDto> saveAndValidateIncomeData(
            @RequestHeader(value = "brand") @Valid @Pattern(regexp = VALID_BRANDS, message = INVALID_BRAND) String brand,
            @PathVariable("caseId") @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_NUMBER_MAX_OF_THIRTY_SIX_CHAR, message = INVALID_CASE_ID) String caseId,
                @RequestBody @Valid CaseIncomeDto request, BindingResult validationErrors) {
        log.info("saveAndValidateIncomeData method entered in ApplicationUpdateController class with brand: {} and caseId: {}", brand, caseId);
        ValidatedCaseIncomeDto validatedCaseIncomeDto = applicationUpdateService.saveAndValidateIncomeData(brand, caseId, request);
        return new ResponseEntity<>(validatedCaseIncomeDto, HttpStatus.OK);
    }

    /**
     * This endpoint will save and update expense data in CAPIE system by case id
     *
     * @param brand            - Brand
     * @param caseId           - String caseId
     * @param request          - CaseExpenseDto
     * @param validationErrors - Validation errors
     * @return ValidatedCaseExpenseDto
     */
    @Operation(summary = "update and save expense data in capie system", operationId = "UpdateExpense", tags = {"CAPIE Update API"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "income data saved successfully",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ValidatedCaseExpenseDto.class))}),
                    @ApiResponse(responseCode = "207", description = "income data saved with validation failures",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ValidatedCaseExpenseDto.class))}),
                    @ApiResponse(responseCode = "400", description = "Bad Request"),
                    @ApiResponse(responseCode = "401", description = "Not Authorised"),
                    @ApiResponse(responseCode = "403", description = "Forbidden"),
                    @ApiResponse(responseCode = "404", description = "No record found"),
                    @ApiResponse(responseCode = "422", description = "Unprocessable Entity"),
                    @ApiResponse(responseCode = "409", description = "Conflict"),
                    @ApiResponse(responseCode = "500", description = "Internal Server Error")
            })
    @PutMapping(path = "/capie/case/{caseId}/expense", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ValidatedCaseExpenseDto> saveAndValidateExpenseData(
            @RequestHeader(value = "brand") @Valid @Pattern(regexp = VALID_BRANDS, message = INVALID_BRAND) String brand,
            @PathVariable("caseId") @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_NUMBER_MAX_OF_THIRTY_SIX_CHAR, message = INVALID_CASE_ID) String caseId,
            @RequestBody @Valid CaseExpenseDto request, BindingResult validationErrors) {
        log.info("saveAndValidateExpenseData method entered in ApplicationUpdateController class with brand: {} and caseId: {}", brand, caseId);
        ValidatedCaseExpenseDto validatedCaseIncomeDto = applicationUpdateService.saveAndValidateExpenseData(brand, caseId, request);
        return new ResponseEntity<>(validatedCaseIncomeDto, HttpStatus.OK);
    }

    /**
     * This method is used to update the expense data validation status
     *
     * @param brand - possible values RBS/NWB
     * @param caseId - caseId String
     * @param request - input Object
     * @return ValidatedCaseExpenseDto - response
     */
    @Operation(summary = "update expense validation status in CAPIE system", operationId = "Update Expense Validation Status", tags = {"CAPIE Update API"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "validated expense data based on caseId",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ValidatedCaseExpenseDto.class))}),
                    @ApiResponse(responseCode = "400", description = "Bad Request"),
                    @ApiResponse(responseCode = "401", description = "Not Authorised"),
                    @ApiResponse(responseCode = "403", description = "Forbidden"),
                    @ApiResponse(responseCode = "404", description = "Resource not found"),
                    @ApiResponse(responseCode = "422", description = "Unprocessable Entity"),
                    @ApiResponse(responseCode = "409", description = "Conflict"),
                    @ApiResponse(responseCode = "500", description = "Internal Server Error")
            })
    @PatchMapping(value = "/capie/case/{caseId}/expense", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ValidatedCaseExpenseDto> markExpenseValidated(@RequestHeader(value = "brand") @Valid @Pattern(regexp = VALID_BRANDS, message = INVALID_BRAND) String brand,
                                                                     @PathVariable("caseId") @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_NUMBER_MAX_OF_THIRTY_SIX_CHAR, message = INVALID_CASE_ID) String caseId,
                                                                     @Valid @RequestBody CaseStatusDto request){
        log.info("markExpenseValidated method entered for caseId: {}", caseId);
        ValidatedCaseExpenseDto validatedData = applicationUpdateService.markExpenseValidated(brand,caseId, request);
        if (validatedData.getStatus() != CaseStatus.VALIDATED) {
            log.info("Unable to mark expense data validated with validation errors for caseId: {}", caseId);
            return ResponseEntity.badRequest().body(validatedData);
        }
        return ResponseEntity.ok(validatedData);

    }

    /**
     * This method is used to update the income data validation status
     *
     * @param brand - possible values RBS/NWB
     * @param caseId - caseId String
     * @param request - input Object
     * @param validationErrors - Validation errors
     * @return ValidatedCaseIncomeDto - response
     */
    @Operation(summary = "Validate data in the Database ", operationId = "patch Income", description = "Returns income Response with validation result")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "validated income data based on caseId", content = @Content(schema = @Schema(implementation = ValidatedCaseIncomeDto.class))),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(examples = {})),
            @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content(examples = {})),
            @ApiResponse(responseCode = "403", description = "Forbidden", content = @Content(examples = {})),
            @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content(examples = {})),
            @ApiResponse(responseCode = "409", description = "Conflict", content = @Content(examples = {})),
            @ApiResponse(responseCode = "422", description = "Unprocessable Entity", content = @Content(examples = {})),
            @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content(examples = {}))})
    @PatchMapping(path = "/capie/case/{caseId}/income", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ValidatedCaseIncomeDto> markIncomeValidated(
            @RequestHeader(value = "brand") @Valid @Pattern(regexp = VALID_BRANDS, message = INVALID_BRAND) String brand,
            @PathVariable("caseId") @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_NUMBER_MAX_OF_THIRTY_SIX_CHAR, message = INVALID_CASE_ID) String caseId,
            @Valid @RequestBody CaseStatusDto request, BindingResult validationErrors) {

        log.info("markIncomeValidated method entered in ApplicationUpdateController class with brand: {} and caseId: {}", brand, caseId);
        ValidatedCaseIncomeDto validatedData = applicationUpdateService.markIncomeValidated(brand, caseId, request);
        log.info("Income data successfully marked validated for caseId: {}", caseId);
        return ResponseEntity.ok(validatedData);
    }

    /**
     * Endpoint to update application detail for manual key in case
     *
     * @param brand                        - brand
     * @param caseId                       - caseId
     * @param dipId                        - dipId
     * @param manualKeyInCaseUpdateRequest - manualKeyInCaseUpdateRequest
     * @param validationErrors             - validationErrors
     * @return SuccessResponse
     */
    @PreAuthorize("@authorizationServiceImpl.isDevTestUser() || @authorizationServiceImpl.isMopsDataEntry()")
    @Operation(summary = "Update application detail for manual key in case", operationId = "Update application details for manual key in case",
            tags = {"CAPIE Update API"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "success",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = SuccessResponse.class))}),
                    @ApiResponse(responseCode = "400", description = "Bad Request",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "401", description = "Not Authorised",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "403", description = "Forbidden",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "No record found",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "500", description = "Internal Server Error",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))})
            })
    @PatchMapping(path = "/capie/case/{caseId}/dataentry/{dipId}", produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<SuccessResponse> updateApplicationDataForManualKeyInCase(
            @RequestHeader(value = "brand") @Valid @Pattern(regexp = VALID_BRANDS, message = INVALID_BRAND) String brand,
            @PathVariable("caseId") @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_NUMBER_MAX_OF_THIRTY_SIX_CHAR, message = INVALID_CASE_ID) String caseId,
            @PathVariable("dipId") @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_NUMBER_MAX_OF_THIRTY_SIX_CHAR, message = INVALID_DIP_ID) String dipId,
            @Valid @RequestBody ManualKeyInCaseUpdateRequest manualKeyInCaseUpdateRequest, BindingResult validationErrors) {
        log.info("Entered into updateApplicationDataForManualKeyInCase method with brand: {} and caseId: {} and dipId: {}", brand, caseId, dipId);
        SuccessResponse successResponse = applicationUpdateService.updateApplicationDataForManualKeyInCases(brand, caseId, dipId, manualKeyInCaseUpdateRequest);
        log.info("ManualKeyInCaseUpdateRequest completed for caseId: {} and dipId: {}", caseId, dipId);
        return ResponseEntity.ok(successResponse);
    }

    /**
     * This endpoint will update adbo case information in CAPIE system by case id
     *
     * @param brand     - brand
     * @param caseId    - caseId
     * @param jsonPatch - jsonPatch
     * @return CaseDetailsDto
     */
    @Operation(summary = "Update case adbo information by case id in CAPIE system", operationId = "updateCaseInformation", tags = {"CAPIE Update API"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "Success",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = CaseApplicationDto.class))}),
                    @ApiResponse(responseCode = "400", description = "Bad Request"),
                    @ApiResponse(responseCode = "401", description = "Not Authorised"),
                    @ApiResponse(responseCode = "403", description = "Forbidden"),
                    @ApiResponse(responseCode = "404", description = "No record found"),
                    @ApiResponse(responseCode = "412", description = "Precondition Failed"),
                    @ApiResponse(responseCode = "500", description = "Internal Server Error")
            })
    @PatchMapping(path = "/capie/case-adbo/{caseId}", consumes = JSON_PATCH, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CaseDetailsDto> updateADBOCaseInformation(
            @RequestHeader(value = "brand") @Valid @Pattern(regexp = VALID_BRANDS, message = INVALID_BRAND) String brand,
            @PathVariable("caseId") @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_NUMBER_MAX_OF_THIRTY_SIX_CHAR, message = INVALID_CASE_ID) String caseId,
            @RequestBody JsonPatch jsonPatch) {
        log.info("updateADBOCaseInformation method entered in ApplicationUpdateCaseController class with brand: {}, caseId: {}", brand, caseId);
        CaseDetailsDto caseDetailsDto = applicationUpdateService.updateADBOCaseInformation(brand, caseId, jsonPatch);
        return new ResponseEntity<>(caseDetailsDto, HttpStatus.OK);
    }

}