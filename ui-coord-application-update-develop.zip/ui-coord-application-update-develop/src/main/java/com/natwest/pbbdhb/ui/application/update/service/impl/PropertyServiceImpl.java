package com.natwest.pbbdhb.ui.application.update.service.impl;

import com.natwest.pbbdhb.property.dto.PropertyDetailsDto;
import com.natwest.pbbdhb.ui.application.update.mapper.PropertyDetailsDtoMapper;
import com.natwest.pbbdhb.ui.application.update.model.dto.exception.PreConditionFailedException;
import com.natwest.pbbdhb.ui.application.update.service.PropertyService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonPatch;
import javax.json.JsonPatchBuilder;
import javax.json.JsonValue;
import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.CASE_ID;
import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.WHEN_BUILT;
import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.WHEN_BUILT_FORMAT;
import static com.natwest.pbbdhb.ui.application.update.util.ApplicationUtil.getHeader;
import static com.natwest.pbbdhb.ui.application.update.util.ApplicationUtil.getUriComponentsBuilder;
import static com.natwest.pbbdhb.ui.application.update.util.ErrorConstant.ERROR_CODE_412_CASEID_NOT_VALID;

/**
 * This class is used to perform property related operations
 */
@Slf4j
@Service
public class PropertyServiceImpl implements PropertyService {

    @Autowired
    @Qualifier("customSecureRestTemplate")
    private RestTemplate restTemplate;

    @Value("${msvc.property-service.parent.endpoint:}")
    private String propertyServiceParentEndpoint;

    @Value("${msvc.property-service.get.property.info.endpoint:}")
    private String propertyInformationEndpoint;

    @Autowired
    private PropertyDetailsDtoMapper mapper;

    /**
     * Method to update the property information for the given case id
     *
     * @param brand   - brand
     * @param caseId  - case id String
     * @param request - request object
     * @return PropertyDetailsDto - response object
     */
    @Override
    public PropertyDetailsDto updatePropertyInformation(String brand, String caseId, PropertyDetailsDto request) {
        log.info("updatePropertyInformation method enters in PropertyServiceImpl class");
        log.info("brand:{}, caseId:{}", brand, caseId);
        validateCaseId(caseId, request);
        request = mapper.toPropertyDetailsDto(request);
        String endPoint = propertyServiceParentEndpoint + propertyInformationEndpoint;
        Map<String, Object> urlParams = new HashMap<>();
        urlParams.put(CASE_ID, caseId);
        HttpHeaders headers = new HttpHeaders();
        headers.add("brand", brand);

        HttpEntity<PropertyDetailsDto> httpEntity = new HttpEntity<>(request, headers);
        URI builder = UriComponentsBuilder.fromUriString(endPoint).buildAndExpand(urlParams).toUri();
        ResponseEntity<PropertyDetailsDto> response = restTemplate.exchange(builder, HttpMethod.PUT, httpEntity, PropertyDetailsDto.class);
        return response.getBody();
    }

    /**
     * Method to patch update the property information for the given case id in capie service
     *
     * @param brand   - brand
     * @param caseId  - case id String
     * @param jsonPatch - jsonPatch object
     * @return PropertyDetailsDto - response object
     */
    @Override
    public PropertyDetailsDto patchUpdatePropertyInformation(String brand, String caseId, JsonPatch jsonPatch) {
        log.info("patchUpdatePropertyInformation method entered in PropertyServiceImpl class brand: {}, caseId: {} ", brand, caseId);

        boolean whenBuiltFieldPresent = jsonPatch.toJsonArray().stream().anyMatch(jsonValue -> StringUtils.isNotBlank(jsonValue.asJsonObject().getString("path")) && WHEN_BUILT.equalsIgnoreCase(jsonValue.asJsonObject().getString("path")));
        if (whenBuiltFieldPresent) {
            JsonArray jsonArray = jsonPatch.toJsonArray();
            String whenBuilt = null;
            JsonPatchBuilder builder = Json.createPatchBuilder(jsonArray);
            for (JsonValue jsonValue : jsonArray) {
                if (StringUtils.isNotBlank(jsonValue.asJsonObject().getString("path")) && WHEN_BUILT.equalsIgnoreCase(jsonValue.asJsonObject().getString("path"))) {
                    whenBuilt = String.format(WHEN_BUILT_FORMAT, jsonValue.asJsonObject().getString("value"));
                }
            }
            jsonPatch = builder.replace(WHEN_BUILT, whenBuilt)
                    .build();
        }

        ResponseEntity<PropertyDetailsDto> response;
        String endpoint = propertyServiceParentEndpoint + propertyInformationEndpoint;
        UriComponentsBuilder builder = getUriComponentsBuilder(caseId, endpoint);
        response = getApiResponse(brand, builder, jsonPatch);
        return response.getBody();
    }


    private ResponseEntity<PropertyDetailsDto> getApiResponse(String brand, UriComponentsBuilder builder, JsonPatch jsonPatch) {
        return restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.PATCH, getHeader(jsonPatch, brand), PropertyDetailsDto.class);
    }

    private void validateCaseId(String caseId, PropertyDetailsDto request) {
        log.info("validateCaseId method enters in PropertyServiceImpl class");
        if(!StringUtils.equals(caseId, request.getCaseId())){
            throw new PreConditionFailedException(ERROR_CODE_412_CASEID_NOT_VALID);
        }
    }
}