package com.natwest.pbbdhb.ui.application.update.model.dto.response.application;

import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.ApplicationCaseOwner;
import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 * Update Case Owner API response Object
 */
@Data
@Builder
public class UpdatedCaseOwnerResponse {
    private String message;
    private int responseCode;
    private List<ApplicationCaseOwner> failedRequests;
}


