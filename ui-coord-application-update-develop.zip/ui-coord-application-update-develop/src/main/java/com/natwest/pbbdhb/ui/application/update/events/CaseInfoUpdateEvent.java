package com.natwest.pbbdhb.ui.application.update.events;

import com.natwest.pbbdhb.ui.application.update.model.dto.event.UpdateAppInfoEventRequest;
import lombok.Builder;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEvent;


/**
 * This class is used to represent CaseInfoUpdateEvent
 */
@Slf4j
@Getter
public class CaseInfoUpdateEvent extends ApplicationEvent {

    private final String brand;
    private final UpdateAppInfoEventRequest updateAppInfoEventRequest;

    /**
     * This constructor is used to build CaseInfoUpdateEvent object
     *
     * @param brand                     - brand
     * @param updateAppInfoEventRequest - updateAppInfoEventRequest
     */
    @Builder
    public CaseInfoUpdateEvent(String brand, UpdateAppInfoEventRequest updateAppInfoEventRequest) {
        super(brand);
        this.brand = brand;
        this.updateAppInfoEventRequest = updateAppInfoEventRequest;
    }
}
