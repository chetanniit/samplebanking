package com.natwest.pbbdhb.ui.application.update.validator.format;

import com.natwest.pbbdhb.ui.application.update.validator.ArrayLengthValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.INVALID_INPUT;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD, ElementType.PARAMETER})
@Constraint(validatedBy = ArrayLengthValidator.class)
public @interface ArrayLengthConstraint {

    /**
     * Method to set the error message when error occurs. It defaults to "Please provide a valid
     * user"
     *
     * @return error message
     */
    String message() default INVALID_INPUT;

    /**
     * Method to pass the value for "required" which is being used by the validator to perform some
     * checks. It defaults to false.
     *
     * @return true or false
     */
    boolean required() default false;

    /**
     * Method to get the default
     *
     * @return Class
     */
    Class<?>[] groups() default {};

    /**
     * Method to get the payload
     *
     * @return Class
     */
    Class<? extends Payload>[] payload() default {};
}
