/*
 * Natwest (C)2023
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */
package com.natwest.pbbdhb.ui.application.update.validator;

import com.natwest.pbbdhb.ui.application.update.validator.format.CommonConstraint;
import org.apache.commons.lang3.StringUtils;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.Objects;
import java.util.regex.Pattern;

/**
 * This class validates the input value against the given regex pattern
 */
public class CommonFormatValidator implements ConstraintValidator<CommonConstraint, String> {

    private boolean isRequired;
    private String regex;

    @Override
    public void initialize(CommonConstraint commonConstraint) {
        this.isRequired = commonConstraint.required();
        this.regex = commonConstraint.regex();
    }

    @Override
    public boolean isValid(String content, ConstraintValidatorContext constraintValidatorContext) {
        if (isRequired && StringUtils.isEmpty(content)) {
            return false;
        }
        return Objects.isNull(content)
                || (StringUtils.isNotBlank(content)
                && StringUtils.isNotEmpty(content)
                && Pattern.compile(regex).matcher(content).matches());
    }
}
