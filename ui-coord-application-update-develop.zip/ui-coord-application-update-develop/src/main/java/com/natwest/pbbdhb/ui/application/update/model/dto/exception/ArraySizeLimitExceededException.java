package com.natwest.pbbdhb.ui.application.update.model.dto.exception;

/**
 * Class to throw the exception when array size limit exceed in request object of update application owner
 */
public class ArraySizeLimitExceededException extends RuntimeException{
    private static final long serialVersionUID = 1L;

    /**
     * This method is used to construct the object based on argument passed
     *
     * @param message - exception message
     */
    public ArraySizeLimitExceededException(String message) {
        super(message);
    }
}
