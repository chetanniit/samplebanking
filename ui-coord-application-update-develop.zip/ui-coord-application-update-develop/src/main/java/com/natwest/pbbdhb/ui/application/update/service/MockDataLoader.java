package com.natwest.pbbdhb.ui.application.update.service;

import com.opencsv.CSVReader;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * This class is used to read the data from csv file
 */
@Component
public class MockDataLoader {


    @Value("${gms.mock.data}")
    private Resource gmsMockData;

    private final List<String> invalidReferenceNumber;

    private final List<String> notValidUser;

    private final List<String> notAuthorizedUser;

    private final List<String> closedTask;

    private final List<String> applicationId;

    private final List<String> unprocessedEntity;

    /**
     * Constructor method for this class to initialize the variables
     */
    public MockDataLoader() {
        notValidUser = new ArrayList<>();
        notAuthorizedUser = new ArrayList<>();
        closedTask = new ArrayList<>();
        invalidReferenceNumber = new ArrayList<>();
        applicationId = new ArrayList<>();
        unprocessedEntity = new ArrayList<>();
    }

    /**
     * This method is to get all the invalidReferenceNumber
     *
     * @return List of invalid reference numbers
     */
    public List<String> getInvalidReferenceNumber() {
        return invalidReferenceNumber;
    }

    /**
     * This method is to get all the closedTask
     *
     * @return List of closed tasks
     */
    public List<String> getClosedTask() {
        return closedTask;
    }

    /**
     * This method is to get all the notAuthorizedUser
     *
     * @return List of all unAuthorized users
     */
    public List<String> getNotAuthorizedUser() {
        return notAuthorizedUser;
    }

    /**
     * This method is to get all the notValidUser
     *
     * @return list of invalid users
     */
    public List<String> getNotValidUser() {
        return notValidUser;
    }

    /**
     * This method is to get all the invalid applicationId
     *
     * @return list of invalid users
     */
    public List<String> getInvalidApplicationId() {
        return applicationId;
    }

    /**
     * This method is to get all the unprocessed Entity
     *
     * @return list of unprocessed Entity
     */
    public List<String> getUnprocessedEntity() {
        return unprocessedEntity;
    }

    @PostConstruct
    void init() throws IOException {
        initMockData(gmsMockData.getFile(), invalidReferenceNumber, notValidUser, notAuthorizedUser, closedTask, applicationId,
                unprocessedEntity);
    }

    private void initMockData(File file, List<String> invalidReferenceNumber, List<String> notValidUser, List<String> notAuthorizedUser,
                              List<String> closedTask, List<String> applicationId, List<String> unprocessedEntity) throws IOException {
        try (CSVReader csvReader = new CSVReader(new FileReader(file))) {
            csvReader.readNext(); // skip the header
            String[] values;
            while ((values = csvReader.readNext()) != null) {
                invalidReferenceNumber.add(values[0]);
                notValidUser.add(values[1]);
                notAuthorizedUser.add(values[2]);
                closedTask.add(values[3]);
                applicationId.add(values[4]);
                unprocessedEntity.add(values[5]);
            }
        }
    }

}
