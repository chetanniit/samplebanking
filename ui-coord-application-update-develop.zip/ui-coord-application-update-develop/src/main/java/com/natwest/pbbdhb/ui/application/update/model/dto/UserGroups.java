package com.natwest.pbbdhb.ui.application.update.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserGroups {

    private Boolean isPSTUser;
}
