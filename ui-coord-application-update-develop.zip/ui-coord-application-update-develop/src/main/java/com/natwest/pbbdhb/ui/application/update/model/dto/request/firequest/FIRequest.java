package com.natwest.pbbdhb.ui.application.update.model.dto.request.firequest;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.INVALID_DOCUMENT;

/**
 * FIRequest class is the request for /requestFI endpoint
 * and validation for all the fields are captured here
 */
@Data
@Schema(description = "Add Task Object")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Validated
@Valid
public class FIRequest {

    @Valid
    @Parameter(required = true, description = "Documents List")
    @NotNull(message = INVALID_DOCUMENT)
    @NotEmpty(message = INVALID_DOCUMENT)
    private List<Document> documentRequests;

}
