package com.natwest.pbbdhb.ui.application.update.model.dto.request.flowmanager;

import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.UpdateApplicantInformation;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.UpdateBrokerInformation;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.UpdateSourceInformation;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;


/**
 * FlowManagerApplicationInformationUpdateRequest class is the request
 * for downstream update application endpoint
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FlowManagerApplicationInformationUpdateRequest {

    private String caseId;
    private String referenceNumber;
    private List<UpdateApplicantInformation> applicants;
    private UpdateBrokerInformation brokerInfo;
    private UpdateSourceInformation sourceInfo;
    private String userFullName;
    private String userRACFId;
    private String podRating;
}
