package com.natwest.pbbdhb.ui.application.update.model.dto.request.document;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.CHANNEL_BRANCH;
import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.CHANNEL_INTERMEDIARY;

@Getter
@Schema(description = "MOPS document upload supported channels")
public enum Channel {
    FOCUS(CHANNEL_INTERMEDIARY),
    VDOCS(CHANNEL_BRANCH);

    private final String downStreamChannel;

    Channel(String downStreamChannel) {
        this.downStreamChannel = downStreamChannel;
    }
}
