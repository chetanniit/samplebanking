package com.natwest.pbbdhb.ui.application.update.model.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum PermanentIndicator {
    PERMANENT,
    TEMPORARY,
    OTHER,
    CONTRACT

}
