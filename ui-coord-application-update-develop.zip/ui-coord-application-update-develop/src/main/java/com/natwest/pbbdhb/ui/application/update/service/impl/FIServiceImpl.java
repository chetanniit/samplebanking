package com.natwest.pbbdhb.ui.application.update.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.ui.application.update.mapper.FlowManagerRequestMapper;
import com.natwest.pbbdhb.ui.application.update.model.dto.FlowManagerAddDocumentResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.UserGroups;
import com.natwest.pbbdhb.ui.application.update.model.dto.enums.DocumentStatus;
import com.natwest.pbbdhb.ui.application.update.model.dto.exception.PreConditionFailedException;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.AddNoteRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.FIStatusRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.firequest.FIRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.flowmanager.FlowManagerAddNoteRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.flowmanager.FlowManagerDisassociateDocumentRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.flowmanager.FlowManagerFIRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.flowmanager.FlowManagerFIStatusRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.AddDocumentResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.SuccessResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.userinformation.UserInformationResponse;
import com.natwest.pbbdhb.ui.application.update.service.FIService;
import com.natwest.pbbdhb.ui.application.update.service.auth.AuthorizationService;
import com.natwest.pbbdhb.ui.application.update.util.ErrorConstant;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.*;

/**
 * Impl class of FIService interface and contains the methods related to requestFI endPoint
 */
@Service
@Slf4j
public class FIServiceImpl implements FIService {

    @Value("${msvc.flow-manager.parent.endpoint}")
    private String flowManagerParentEndpoint;

    @Value("${msvc.flow-manager.add-document.endpoint}")
    private String flowManagerApplicantEndpoint;

    @Value("${msvc.flow-manager.add-case-document.endpoint}")
    private String flowManagerCaseApplicantEndpoint;

    @Value("${msvc.flow-manager.update-doc-status.endpoint}")
    private String flowManagerDocStatusEndpoint;

    @Value("${msvc.flow-manager.update-case-doc-status.endpoint}")
    private String flowManagerCaseDocStatusEndpoint;

    @Value("${msvc.flow-manager.add-note.endpoint}")
    private String flowManagerAddNoteEndpoint;

    @Value("${msvc.flow-manager.add-case-note.endpoint}")
    private String flowManagerAddCaseNoteEndpoint;

    @Value("${msvc.flow-manager.disassociate-document.endpoint}")
    private String flowManagerDisassociateEndpoint;


    @Autowired
    @Qualifier("customSecureRestTemplate")
    private RestTemplate restTemplate;

    @Autowired
    private AuthorizationService authorizationService;

    @Autowired
    private FlowManagerRequestMapper flowManagerRequestMapper;

    @Autowired
    private ObjectMapper objectMapper;


    /**
     * This method is to add Further Information based on the brand and FIRequest
     * @param brand - Allowed values NWB/RBS
     * @param referenceNumber - referenceNumber field
     * @param fiRequest - request object represents the FIRequest
     * @return AddDocumentResponse
     */
    @Override
    public ResponseEntity<AddDocumentResponse> addFI(String brand, String referenceNumber, String caseId, FIRequest fiRequest) {
        log.info("addFI method entered in FiServiceImpl class");
        log.info("Calling Flow Manager service addFI endPoint with Request  : " + fiRequest);
        if(CollectionUtils.isNotEmpty(fiRequest.getDocumentRequests())){
            fiRequest.getDocumentRequests().forEach( documentRequest -> {
                if(Objects.isNull(documentRequest.getDocumentIdentifier())){
                    documentRequest.setDocumentIdentifier(FI_DOCUMENT_IDENTIFIER);
                }
            });
        }
        AddDocumentResponse addDocumentResponse = null;
        UserInformationResponse userData = authorizationService.getUserData();


        FlowManagerFIRequest flowManagerFIRequest = flowManagerRequestMapper.toFlowManagerFIRequest(fiRequest);
        flowManagerFIRequest.setReferenceNumber(referenceNumber);
        Optional.ofNullable(userData).ifPresent(userInfo -> {
            flowManagerFIRequest.setUserFullName(userData.getUsername());
            flowManagerFIRequest.setUserRACFId(userData.getRacfID());
            UserGroups userGroups = new UserGroups();
            userGroups.setIsPSTUser(userData.isPSTUser());
            flowManagerFIRequest.setUserGroups(userGroups);
        });
        HttpHeaders headers = new HttpHeaders();
        headers.add("brand", brand);


        String endPoint = flowManagerParentEndpoint;
        Map<String, Object> urlParams = new HashMap<>();
        if(StringUtils.isNotBlank(referenceNumber)) {
            flowManagerFIRequest.setReferenceNumber(referenceNumber);
            urlParams.put(REFERENCE_NUMBER, referenceNumber);
            endPoint = endPoint + flowManagerApplicantEndpoint;
        } else if(StringUtils.isNotBlank(caseId)){
            flowManagerFIRequest.setCaseId(caseId);
            urlParams.put(CASE_ID, caseId);
            endPoint = endPoint + flowManagerCaseApplicantEndpoint;
        }
        URI builder = UriComponentsBuilder.fromUriString(endPoint).buildAndExpand(urlParams).toUri();

        HttpEntity<FlowManagerFIRequest> httpEntity = new HttpEntity<>(flowManagerFIRequest, headers);

        log.info("Flow Manager service addFI endPoint url {}", endPoint);
        ResponseEntity<FlowManagerAddDocumentResponse> response = null;
        try {
            response = restTemplate.exchange(builder, HttpMethod.POST, httpEntity, FlowManagerAddDocumentResponse.class);
        } catch (HttpClientErrorException.Conflict ex) {
            log.error("Conflict occurred during raise FI - ", ex);
            FlowManagerAddDocumentResponse flowManagerAddDocumentResponse = getFlowManagerAddDocumentResponse(ex.getResponseBodyAsString());
            response = ResponseEntity.status(ex.getStatusCode()).body(flowManagerAddDocumentResponse);
        }
        addDocumentResponse = flowManagerRequestMapper.toAddDocumentResponse(response.getBody());
        return ResponseEntity.status(response.getStatusCode()).body(addDocumentResponse);
    }

    private FlowManagerAddDocumentResponse getFlowManagerAddDocumentResponse(String response) {
        FlowManagerAddDocumentResponse flowManagerAddDocumentResponse = FlowManagerAddDocumentResponse.builder().build();
        try {
            flowManagerAddDocumentResponse = objectMapper.readValue(response, FlowManagerAddDocumentResponse.class);
        } catch (JsonMappingException e) {
            log.error("JsonMappingException exception occurred while converting FlowManagerAddDocumentResponse: ", e);
        } catch (JsonProcessingException e) {
            log.error("JsonProcessingException exception occurred while converting FlowManagerAddDocumentResponse: ", e);
        }
        return flowManagerAddDocumentResponse;
    }

    /**
     * This method is to update the FI State based on the brand and FIStatusRequest
     *
     * @param brand       - could be NWB/RBS
     * @param fiStatusRequest - Object which has the FIStatusRequest details
     * @param state - state
     * @return String
     */
    @Override
    public ResponseEntity<SuccessResponse> updateFIState(String brand, FIStatusRequest fiStatusRequest, String referenceNumber, String caseId, String firequestId, String state) {
        log.info("updateFIStatus method entered in FiServiceImpl class");

        closeFiValidation(fiStatusRequest, state);

        HttpHeaders headers = new HttpHeaders();
        headers.add("brand", brand);

        if(Objects.nonNull(fiStatusRequest) && StringUtils.isNotEmpty(fiStatusRequest.getNote())){
            makeAddNoteCall(headers,fiStatusRequest, referenceNumber, caseId, firequestId);
        }
        return makeUpdateFIStatusCall(headers, state, referenceNumber, caseId, firequestId, fiStatusRequest);
    }

    private void closeFiValidation(FIStatusRequest fiStatusRequest, String state) {
        if(Objects.nonNull(fiStatusRequest) &&DocumentStatus.CLOSED.name().equalsIgnoreCase(state)){
            String errorMsg = null;
            if(Objects.nonNull(fiStatusRequest.getCustomerResponse())){
                errorMsg = ErrorConstant.ERROR_CODE_412_CUSTOMER_RESPONSE;
            }
            if(CollectionUtils.isNotEmpty(fiStatusRequest.getDocumentInfo()) &&
                    fiStatusRequest.getDocumentInfo().stream().anyMatch(documentInfo -> Objects.nonNull(documentInfo.getOriginalFileName()))){
                errorMsg = (Objects.nonNull(errorMsg))? ErrorConstant.ERROR_CODE_412_CUSTOMER_RESPONSE_ORIGINAL_FILE_NAME: ErrorConstant.ERROR_CODE_412_ORIGINAL_FILE_NAME;
            }
            if(Objects.nonNull(errorMsg)){
                throw new PreConditionFailedException(errorMsg);
            }
        }
    }

    /**
     * Method to make REST API call to update FI state and FI documents information
     * @param headers - headers
     * @param state - state
     * @param referenceNumber - referenceNumber
     * @param caseId - caseId
     * @param firequestId - firequestId
     * @return success message
     */
    private ResponseEntity<SuccessResponse> makeUpdateFIStatusCall(HttpHeaders headers, String state, String referenceNumber, String caseId, String firequestId, FIStatusRequest fiStatusRequest) {
        log.info("makeUpdateFIStatusCall method is enters in FiServiceImpl class");
        SuccessResponse successResponse = null;
        UserInformationResponse userData = authorizationService.getUserData();
        FlowManagerFIStatusRequest flowManagerFIStatusRequest = FlowManagerFIStatusRequest.builder()
                .requestId(firequestId)
                .state(state)
                .customerResponse(Optional.ofNullable(fiStatusRequest).map(FIStatusRequest::getCustomerResponse).orElse(null))
                .documentInfo(Optional.ofNullable(fiStatusRequest)
                        .map(docRequest -> flowManagerRequestMapper.toFlowManagerDocumentInfo(docRequest.getDocumentInfo())).orElse(null))
                .build();

        Optional.ofNullable(userData).ifPresent(userInfo -> {
            flowManagerFIStatusRequest.setUpdatedByFullName(userData.getUsername());
            flowManagerFIStatusRequest.setUpdatedByRACFID(userData.getRacfID());
        });

        String endPoint = flowManagerParentEndpoint ;
        Map<String, Object> urlParams = new HashMap<>();
        if(StringUtils.isNotBlank(referenceNumber)) {
            flowManagerFIStatusRequest.setReferenceNumber(referenceNumber);
            urlParams.put(REFERENCE_NUMBER, referenceNumber);
            endPoint = endPoint + flowManagerDocStatusEndpoint;
        } else if(StringUtils.isNotBlank(caseId)){
            flowManagerFIStatusRequest.setCaseId(caseId);
            urlParams.put(CASE_ID, caseId);
            endPoint = endPoint + flowManagerCaseDocStatusEndpoint;
        }

        HttpEntity<FlowManagerFIStatusRequest> httpEntity = new HttpEntity<>(flowManagerFIStatusRequest, headers);
        urlParams.put(REQUEST_ID, firequestId);
        URI builder = UriComponentsBuilder.fromUriString(endPoint).buildAndExpand(urlParams).toUri();
        ResponseEntity<String> responseEntity = restTemplate.exchange(builder, HttpMethod.PUT, httpEntity, String.class);
        try {
            successResponse = objectMapper.readValue(responseEntity.getBody(), SuccessResponse.class);
        } catch (JsonProcessingException e) {
            log.error("Exception occurred while response object conversion: {}", e.getMessage(), e);
        }
        return ResponseEntity.status(responseEntity.getStatusCode()).body(successResponse);
    }

    /**
     * This method is used to make call to add Note enpoint
     *
     * @param headers - headers object
     * @param fiStatusRequest - fiStatusRequest object
     * @return String
     */
    private ResponseEntity<String> makeAddNoteCall(HttpHeaders headers,FIStatusRequest fiStatusRequest, String referenceNumber, String caseId, String firequestId){
        log.info("makeAddNoteCall method is enters in FiServiceImpl class");
        AddNoteRequest addNoteRequest = getAddNoteRequest(fiStatusRequest,referenceNumber, firequestId);

        UserInformationResponse userData = authorizationService.getUserData();

        FlowManagerAddNoteRequest flowManagerAddNoteRequest = flowManagerRequestMapper.toFlowManagerAddNoteRequest(addNoteRequest);

        flowManagerAddNoteRequest.setRequestId(firequestId);

        Optional.ofNullable(userData).ifPresent(userInfo -> {
            flowManagerAddNoteRequest.setUserFullName(userData.getUsername());
            flowManagerAddNoteRequest.setUserRACFId(userData.getRacfID());
        });


        String noteEndPoint = flowManagerParentEndpoint;

        Map<String, Object> urlParams = new HashMap<>();
        if(StringUtils.isNotBlank(referenceNumber)) {
            flowManagerAddNoteRequest.setReferenceNumber(referenceNumber);
            urlParams.put(REFERENCE_NUMBER, referenceNumber);
            noteEndPoint = noteEndPoint + flowManagerAddNoteEndpoint;
        } else if(StringUtils.isNotBlank(caseId)){
            flowManagerAddNoteRequest.setCaseId(caseId);
            urlParams.put(CASE_ID, caseId);
            noteEndPoint = noteEndPoint + flowManagerAddCaseNoteEndpoint;
        }

        urlParams.put(REQUEST_ID, firequestId);
        URI builder = UriComponentsBuilder.fromUriString(noteEndPoint).buildAndExpand(urlParams).toUri();

        HttpEntity<FlowManagerAddNoteRequest> httpNoteEntity = new HttpEntity<>(flowManagerAddNoteRequest, headers);
        return restTemplate.exchange(builder, HttpMethod.POST, httpNoteEntity, String.class);
    }

    /**
     * This method is used to populate add note request
     *
     * @param fiStatusRequest - fiStatusRequest object
     * @return AddNoteRequest - AddNoteRequest object
     */
    private AddNoteRequest getAddNoteRequest(FIStatusRequest fiStatusRequest, String referenceNumber, String firequestId) {
        return AddNoteRequest.builder()
                .referenceNumber(referenceNumber)
                .requestID(firequestId)
                .note(fiStatusRequest.getNote())
                .build();
    }

    public SuccessResponse  disassociateDocument(String brand, String caseId, String requestId, String documentId){
        log.info("makeUpdateFIStatusCall method is enters in FiServiceImpl class");
        SuccessResponse successResponse = null;
        UserInformationResponse userData = authorizationService.getUserData();
        FlowManagerDisassociateDocumentRequest disassociateDocumentRequest = FlowManagerDisassociateDocumentRequest.builder()
                .documentId(documentId)
                .caseId(caseId)
                .requestId(requestId)
                .build();

        Optional.ofNullable(userData).ifPresent(userInfo -> {
            disassociateDocumentRequest.setUpdatedByFullName(userData.getUsername());
            disassociateDocumentRequest.setUpdatedByRACFID(userData.getRacfID());
        });

        String endPoint = flowManagerParentEndpoint ;
        Map<String, Object> urlParams = new HashMap<>();

        HttpHeaders headers = new HttpHeaders();
        headers.add("brand", brand);

       if(StringUtils.isNotBlank(caseId)){
            urlParams.put(CASE_ID, caseId);
            endPoint = endPoint + flowManagerDisassociateEndpoint;
        }

        HttpEntity<FlowManagerDisassociateDocumentRequest> httpEntity = new HttpEntity<>(disassociateDocumentRequest, headers);
        urlParams.put(REQUEST_ID, requestId);
        URI builder = UriComponentsBuilder.fromUriString(endPoint).buildAndExpand(urlParams).toUri();
        ResponseEntity<String> responseEntity = restTemplate.exchange(builder, HttpMethod.PATCH, httpEntity, String.class);
        try {
            successResponse = objectMapper.readValue(responseEntity.getBody(), SuccessResponse.class);
        } catch (JsonProcessingException e) {
            log.error("Exception occurred while response object conversion: {}", e.getMessage(), e);
        }
        return successResponse;
    }

}
