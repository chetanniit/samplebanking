package com.natwest.pbbdhb.ui.application.update.model.dto.capie;

import com.natwest.pbbdhb.ui.application.update.validator.format.DateConstraint;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.*;

@Data
@Schema(description = "Manual Key In Applicant Detail")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Validated
@Valid
public class ManualKeyInApplicantDetail {
    @Valid
    @Schema(example = "111111")
    @Parameter(required = true, description = "cin")
    @Size(max = 20, message = INVALID_CIN)
    @NotBlank(message = INVALID_CIN)
    private String cin;

    @Valid
    @Schema(example = "222222")
    @Parameter(required = true, description = "client id")
    @NotNull(message = INVALID_CLIENT_ID)
    private Integer clientId;

    @Valid
    @Schema(example = "John")
    @Parameter(required = true, description = "applicant first name")
    @Size(max = 15, message = INVALID_FIRST_NAMES)
    @NotBlank(message = INVALID_FIRST_NAMES)
    private String firstNames;

    @Valid
    @Schema(example = "David")
    @Parameter(description = "applicant middle name")
    @Size(min=1, max = 25, message = INVALID_MIDDLE_NAMES)
    private String middleNames;

    @Valid
    @Schema(example = "Marney")
    @Parameter(required = true, description = "applicant last name")
    @Size(max = 30, message = INVALID_MANUAL_KEY_IN_APPLICANT_LAST_NAME)
    @NotBlank(message = INVALID_MANUAL_KEY_IN_APPLICANT_LAST_NAME)
    private String lastName;

    @Valid
    @Schema(type = "String", description = "applicant date of birth", example = "2000-12-30")
    @DateConstraint(message = INVALID_DATE_OF_BIRTH)
    @NotBlank(message = INVALID_DATE_OF_BIRTH)
    private String dateOfBirth;
}
