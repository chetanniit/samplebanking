package com.natwest.pbbdhb.ui.application.update.service.impl;

import com.natwest.pbbdhb.ui.application.update.mapper.FlowManagerRequestMapper;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.flowmanager.FlowManagerAddBasicPackagingRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.BasicPackagingDocumentResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.FlowManagerBasicPackagingDocumentResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.userinformation.UserInformationResponse;
import com.natwest.pbbdhb.ui.application.update.service.BasicPackagingService;
import com.natwest.pbbdhb.ui.application.update.service.auth.AuthorizationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.HashMap;
import java.util.Map;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.BRAND;

/**
 * Implementation class for BasicPackagingService
 */
@Service
@Slf4j
public class BasicPackagingServiceImpl implements BasicPackagingService {

    @Value("${msvc.flow-manager.parent.endpoint}")
    private String flowManagerParentEndpoint;

    @Value("${msvc.flow-manager.add-basic-packaging.endpoint}")
    private String flowManagerAddBasicPackagingEndpoint;

    @Autowired
    @Qualifier("customSecureRestTemplate")
    private RestTemplate restTemplate;

    @Autowired
    private AuthorizationService authorizationService;

    @Autowired
    private FlowManagerRequestMapper flowManagerRequestMapper;

    /**
     * Method to retrieve basic packaging from requiredDocs API and store into PM
     *
     * @param brand  - brand
     * @param caseId - caseId
     * @return BasicPackagingDocumentResponse object
     */
    @Override
    public ResponseEntity<BasicPackagingDocumentResponse> addBasicPackagingRequests(String brand, String caseId) {
        log.info("Entered into addBasicPackagingRequests for brand : {}, caseId : {}", brand, caseId);
        UserInformationResponse userData = authorizationService.getUserData();
        log.info("Basic packaging for caseId - {}, requestedBy - {}, {}", caseId, userData.getUsername(), userData.getRacfID());
        FlowManagerAddBasicPackagingRequest flowManagerAddBasicPackagingRequest = FlowManagerAddBasicPackagingRequest
                .builder().userFullName(userData.getUsername()).userRACFId(userData.getRacfID()).build();
        String endPoint = flowManagerParentEndpoint + flowManagerAddBasicPackagingEndpoint;
        UriComponentsBuilder builder = getUriComponentsBuilder(endPoint, caseId);
        HttpHeaders headers = new HttpHeaders();
        headers.add(BRAND, brand);
        HttpEntity<FlowManagerAddBasicPackagingRequest> httpEntity = new HttpEntity<>(flowManagerAddBasicPackagingRequest, headers);
        log.debug("header set for downstream call: {}, FlowManagerAddBasicPackagingRequest :  {}", headers, flowManagerAddBasicPackagingRequest);
        ResponseEntity<FlowManagerBasicPackagingDocumentResponse> responseEntity = restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.POST, httpEntity, FlowManagerBasicPackagingDocumentResponse.class);
        BasicPackagingDocumentResponse basicPackagingDocumentResponse = flowManagerRequestMapper.toBasicPackagingDocumentResponse(responseEntity.getBody());
        return ResponseEntity.status(responseEntity.getStatusCode()).body(basicPackagingDocumentResponse);
    }

    private UriComponentsBuilder getUriComponentsBuilder(String endpoint, String caseId) {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(endpoint);
        Map<String, Object> urlParams = new HashMap<>();
        urlParams.put("caseId", caseId);
        builder.uriVariables(urlParams);
        log.debug("URL : {} ", builder.toUriString());
        return builder;
    }
}
