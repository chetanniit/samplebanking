package com.natwest.pbbdhb.ui.application.update.events.handlers;

import com.natwest.pbbdhb.ui.application.update.events.CaseInfoUpdateEvent;
import com.natwest.pbbdhb.ui.application.update.model.dto.event.UpdateAppInfoEventRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.ApplicationInformationUpdateRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.UpdateBrokerInformation;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.UpdateSourceInformation;
import com.natwest.pbbdhb.ui.application.update.service.ApplicationUpdateService;
import com.natwest.pbbdhb.ui.application.update.util.DBUpdateRetryPropertiesReader;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.core.annotation.Order;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Component;

/**
 * This class is used to handle ApplicantInfoUpdateEvent
 */
@Component
@AllArgsConstructor
@Slf4j
@EnableAsync
@EnableRetry
public class CaseInfoUpdateEventListener {

    @Autowired
    private final ApplicationUpdateService applicationUpdateService;

    @Autowired
    private final DBUpdateRetryPropertiesReader dbUpdateRetryPropertiesReader;

    /**
     * This method is used to handle UpdateAppInfoEventRequest
     *
     * @param caseInfoUpdateEvent - object
     */
    @EventListener
    @Order(0)
    @Async
    @Retryable(value = RuntimeException.class, maxAttemptsExpression = "#{@dbUpdateRetryPropertiesReader.getCount()}", backoff = @Backoff(delayExpression = "#{@dbUpdateRetryPropertiesReader.getWaitDelay()}"))
    public void onUpdateAppInfoEventRequest(CaseInfoUpdateEvent caseInfoUpdateEvent) {
        log.info("onUpdateAppInfoEventRequest listener method enters in CaseInfoUpdateEventListener class");
        ApplicationInformationUpdateRequest request = ApplicationInformationUpdateRequest.builder()
                .sourceInfo(getUpdatedSourceInfo(caseInfoUpdateEvent.getUpdateAppInfoEventRequest()))
                .brokerInfo(getUpdatedBrokerInfo(caseInfoUpdateEvent.getUpdateAppInfoEventRequest()))
                .build();

        applicationUpdateService.updateApplicationInformation(caseInfoUpdateEvent.getBrand(), request,
                null, caseInfoUpdateEvent.getUpdateAppInfoEventRequest().getCaseId());
    }

    /**
     * This method is used to construct UpdateSourceInformation object
     *
     * @param updateAppInfoEventRequest - input
     * @return UpdateSourceInformation - response
     */
    private UpdateSourceInformation getUpdatedSourceInfo(UpdateAppInfoEventRequest updateAppInfoEventRequest) {
        log.info("getUpdatedCaseInfo method enters in CaseInfoUpdateEventListener class");
        return UpdateSourceInformation.builder()
                .racfId(updateAppInfoEventRequest.getRacfId())
                .primaryAdvisorRacfId(updateAppInfoEventRequest.getPrimaryAdvisorRacfId())
                .applicationType(updateAppInfoEventRequest.getApplicationType())
                .advisor(updateAppInfoEventRequest.getAdvisor())
                .leadAdvisor(updateAppInfoEventRequest.getLeadAdvisor())
                .leadGenerator(updateAppInfoEventRequest.getLeadGenerator())
                .build();
    }

    /**
     * This method is used to construct updateAppInfoEventRequest object
     *
     * @param updateAppInfoEventRequest - input
     * @return UpdateBrokerInformation - response
     */
    private UpdateBrokerInformation getUpdatedBrokerInfo(UpdateAppInfoEventRequest updateAppInfoEventRequest) {
        log.info("getUpdatedBrokerInfo method enters in CaseInfoUpdateEventListener class");
        return UpdateBrokerInformation.builder()
                .emailAddress(updateAppInfoEventRequest.getBrokerEmail())
                .build();
    }

    /**
     * This method is used to handle retry failure
     *
     * @param e - exception object input
     * @param caseInfoUpdateEvent - input
     */
    @Recover
    public void updateAppInfoEventRecover(RuntimeException e,CaseInfoUpdateEvent caseInfoUpdateEvent){
        log.info("updateAppInfoEventRecover method enters in CaseInfoUpdateEventListener class");
        String logMessage = String.format("All the retries are exhausted for this event: %s with exception : %s",
                caseInfoUpdateEvent.getUpdateAppInfoEventRequest(),e.getMessage());
        log.error(logMessage);
    }
}
