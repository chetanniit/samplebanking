package com.natwest.pbbdhb.ui.application.update.service.impl;

import com.natwest.pbbdhb.ui.application.update.model.dto.exception.ClosedTaskException;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.CloseTaskRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.TaskRequest;
import com.natwest.pbbdhb.ui.application.update.service.MockDataLoader;
import com.natwest.pbbdhb.ui.application.update.service.TaskService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.validation.constraints.NotNull;
import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.util.TimeZone;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.*;
import static com.natwest.pbbdhb.ui.application.update.util.ApplicationUtil.parseDateTime;
import static com.natwest.pbbdhb.ui.application.update.util.ApplicationUtil.throwUpdateFailureException;
import static com.natwest.pbbdhb.ui.application.update.util.ErrorConstant.ERROR_CODE_412_NOT_ELIGIBLE_TO_CLOSE;


/**
 * This class is to methods to create and close task
 */
@Service
@Slf4j
@AllArgsConstructor
public class TaskServiceImpl implements TaskService {

    private final MockDataLoader mockDataLoader;

    /**
     * This method is to create task based on the brand and TaskRequest
     *
     * @param brand       - could be NWB/RBS
     * @param taskRequest - Object which has the task details
     * @return String
     * @throws ParseException - throws parse exception during date conversion
     *                        This method is to create task based ont he brand and TaskRequest
     */
    @Override
    public String addTask(String brand, @NotNull TaskRequest taskRequest) throws ParseException {
        log.info("addTask method entered in TaskServiceImpl class");
        /*Logic to get the application sequence number and add a new task to the
        table using GMS AIS service will be implemented once the services are available.
        Now returning Success message as response*/
        throwUpdateFailureException(taskRequest.getReferenceNumber(), taskRequest.getOperatorRacfId(), mockDataLoader);
        Date taskDate = parseDateTime(taskRequest.getDate());
        DateFormat format = new SimpleDateFormat(DATE_TIME_FORMAT);
        format.setTimeZone(TimeZone.getTimeZone(UK_TIME_ZONE));

        return MessageFormat.format(TASK_CREATED_MSG, format.format(taskDate), (new Random().nextInt(000122222222)));
    }

    /**
     * This method is to close task based on the brand and CloseTaskRequest
     *
     * @param brand   - Allowed values NWB/RBS
     * @param request - request object represents close task request
     * @return String - message
     * @throws ParseException - throws parse exception during date conversion
     */
    @Override
    public String closeTask(String brand, CloseTaskRequest request) throws ParseException {
        log.info("closeTask method entered in TaskServiceImpl class");
        throwUpdateFailureException(request.getReferenceNumber(), request.getOperatorRacfId(), mockDataLoader);
        throwClosedTaskException(request.getTaskId());
        Date taskDate = parseDateTime(request.getDate());
        DateFormat format = new SimpleDateFormat(DATE_TIME_FORMAT);
        format.setTimeZone(TimeZone.getTimeZone(UK_TIME_ZONE));
        return TASK_CLOSED_MSG + format.format(taskDate);
    }

    private void throwClosedTaskException(String taskId) {
        if (mockDataLoader.getClosedTask().contains(taskId)) {
            throw new ClosedTaskException(ERROR_CODE_412_NOT_ELIGIBLE_TO_CLOSE);
        }
    }

}
