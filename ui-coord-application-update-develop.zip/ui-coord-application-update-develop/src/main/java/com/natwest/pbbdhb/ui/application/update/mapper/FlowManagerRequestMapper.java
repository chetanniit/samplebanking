package com.natwest.pbbdhb.ui.application.update.mapper;

import com.natwest.pbbdhb.ui.application.update.model.dto.FlowManagerAddDocumentResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.FlowManagerDocumentRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.notes.DocumentNotesRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.AddNoteRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.DocumentReminder;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.FIStatusRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.FlowManagerDocumentInfo;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.DocumentInfo;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.AddTeleMessageRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.ApplicationInformationUpdateRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.firequest.Document;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.firequest.FIRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.firequest.FlowManagerDocument;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.flowmanager.*;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.AddDocumentResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.DocumentRequestResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.BasicPackagingDocumentResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.FlowManagerBasicPackagingDocumentResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.FlowManagerDocumentDetail;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.DocumentDetail;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.DOCUMENT_INFO_DATE_TIME;
import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.UTC_TIME_ZONE;
import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.SPACE_DELIMITER;

/**
 * Mapper to convert coord update request to flow manager request
 */
@Mapper(config = MappingConfig.class)
public interface FlowManagerRequestMapper {

    /**
     * Mapper to convert DocumentNotesRequest to FlowManagerDocumentNotesRequest
     *
     * @param documentNotesRequest - DocumentNotesRequest
     * @return - FlowManagerDocumentNotesRequest
     */
    FlowManagerDocumentNotesRequest toFlowManagerDocumentNotesRequest(DocumentNotesRequest documentNotesRequest);

    /**
     * Mapper to convert FIRequest to FlowManagerFIRequest
     *
     * @param fiRequest - FIRequest
     * @return - FlowManagerFIRequest
     */
    FlowManagerFIRequest toFlowManagerFIRequest(FIRequest fiRequest);

    /**
     * Method to convert list of Document to list of FlowManagerDocument
     *
     * @param documents - list of Document
     * @return list of FlowManagerDocument
     */
    List<FlowManagerDocument> toFlowManagerDocument(List<Document> documents);

    /**
     * Method to convert Document to FlowManagerDocument
     *
     * @param document - Document
     * @return FlowManagerDocument
     */
    @Mapping(target = "count", expression = "java(getCount(document))")
    @Mapping(target = "frequency", expression = "java(getFrequency(document))")
    FlowManagerDocument toFlowManagerDocument(Document document);

    /**
     * Mapper to convert DocumentReminder to FlowManagerDocumentReminder
     *
     * @param documentReminder - DocumentReminder
     * @return - FlowManagerDocumentReminder
     */
    FlowManagerDocumentReminder toFlowManagerDocumentReminder(DocumentReminder documentReminder);

    /**
     * Mapper to convert AddNoteRequest to FlowManagerAddNoteRequest
     *
     * @param addNoteRequest - AddNoteRequest
     * @return - FlowManagerAddNoteRequest
     */
    FlowManagerAddNoteRequest toFlowManagerAddNoteRequest(AddNoteRequest addNoteRequest);

    /**
     * Mapper to convert ApplicationInformationUpdateRequest to FlowManagerApplicationInformationUpdateRequest
     *
     * @param applicationInformationUpdateRequest - ApplicationInformationUpdateRequest
     * @return - FlowManagerApplicationInformationUpdateRequest
     */
    FlowManagerApplicationInformationUpdateRequest toFlowManagerApplicationInformationUpdateRequest(ApplicationInformationUpdateRequest applicationInformationUpdateRequest);

    /**
     * Mapper to convert FIStatusRequest to FlowManagerFIStatusRequest
     *
     * @param fiStatusRequest - fiStatusRequest
     * @return FlowManagerFIStatusRequest
     */
    FlowManagerFIStatusRequest toFlowManagerFIStatusRequest(FIStatusRequest fiStatusRequest);

    /**
     * Mapper to convert DocumentInfo to FlowManagerDocumentInfo
     *
     * @param documentInfo - documentInfo
     * @return FlowManagerDocumentInfo
     */
    @Mapping(target = "dateTime", expression = "java(getDateTime())")
    FlowManagerDocumentInfo toFlowManagerDocumentInfo(DocumentInfo documentInfo);

    /**
     * Mapper to convert list of DocumentInfo to list of FlowManagerDocumentInfo
     *
     * @param documentInfo list of documentInfo
     * @return list of FlowManagerDocumentInfo
     */
    List<FlowManagerDocumentInfo> toFlowManagerDocumentInfo(List<DocumentInfo> documentInfo);

    /**
     * To convert FlowManagerAddDocumentResponse to AddDocumentResponse
     *
     * @param flowManagerAddDocumentResponse - flowManagerAddDocumentResponse
     * @return AddDocumentResponse
     */
    AddDocumentResponse toAddDocumentResponse(FlowManagerAddDocumentResponse flowManagerAddDocumentResponse);

    /**
     * To convert list of FlowManagerDocumentRequest to list of DocumentRequest
     *
     * @param flowManagerDocumentRequests list of flowManagerDocumentRequests
     * @return list of DocumentRequest
     */
    List<DocumentRequestResponse> toDocumentRequest(List<FlowManagerDocumentRequest> flowManagerDocumentRequests);

    /**
     * To convert FlowManagerDocumentRequest to DocumentRequest
     *
     * @param flowManagerDocumentRequest - flowManagerDocumentRequests
     * @return DocumentRequest
     */
    @Mapping(target = "timePeriod", expression = "java(getTimePeriod(flowManagerDocumentRequest))")
    DocumentRequestResponse toDocumentRequest(FlowManagerDocumentRequest flowManagerDocumentRequest);

    /**
     * Method to convert FlowManagerBasicPackagingDocumentResponse to BasicPackagingDocumentResponse
     *
     * @param flowManagerBasicPackagingDocumentResponse - flowManagerBasicPackagingDocumentResponse
     * @return BasicPackagingDocumentResponse
     */
    BasicPackagingDocumentResponse toBasicPackagingDocumentResponse(FlowManagerBasicPackagingDocumentResponse flowManagerBasicPackagingDocumentResponse);

    /**
     * Method to convert list of FlowManagerDocumentDetail to list of DocumentDetail
     *
     * @param flowManagerDocumentDetails - flowManagerDocumentDetails
     * @return list of DocumentDetail
     */
    List<DocumentDetail> toDocumentDetail(List<FlowManagerDocumentDetail> flowManagerDocumentDetails);

    /**
     * Method to convert FlowManagerDocumentDetail to DocumentDetail
     *
     * @param flowManagerDocumentDetail - flowManagerDocumentDetail
     * @return DocumentDetail
     */
    @Mapping(target = "timePeriod", expression = "java(getTimePeriod(flowManagerDocumentDetail))")
    DocumentDetail toDocumentDetail(FlowManagerDocumentDetail flowManagerDocumentDetail);

    /**
     * Method to convert from AddTeleMessageRequest to FlowManagerAddTeleMessageRequest
     *
     * @param teleMessageRequest - teleMessageRequest
     * @return FlowManagerAddTeleMessageRequest
     */
    FlowManagerAddTeleMessageRequest toFlowManagerAddTeleMessageRequest(AddTeleMessageRequest teleMessageRequest);

    default String getDateTime() {
        LocalDateTime dateTime = LocalDateTime.now(ZoneId.of(UTC_TIME_ZONE));
        return DateTimeFormatter.ofPattern(DOCUMENT_INFO_DATE_TIME).format(dateTime);
    }

    /**
     * Method to get count from time period
     *
     * @param document - document
     * @return count
     */
    default String getCount(Document document) {
        String[] splitTimePeriod = Optional.ofNullable(document).map(Document::getTimePeriod)
                .map(timePeriod -> timePeriod.split(SPACE_DELIMITER)).
                        orElse(null);
        if (Objects.isNull(splitTimePeriod)) {
            return null;
        }
        return splitTimePeriod.length > 1 ? splitTimePeriod[0] : "0";
    }

    /**
     * Method to get frequency from time period
     *
     * @param document - document
     * @return frequency
     */
    default String getFrequency(Document document) {
        String[] splitTimePeriod = Optional.ofNullable(document).map(Document::getTimePeriod)
                .map(timePeriod -> timePeriod.split(SPACE_DELIMITER)).
                        orElse(null);
        if (Objects.isNull(splitTimePeriod)) {
            return null;
        }
        return splitTimePeriod.length > 1 ? splitTimePeriod[1] : splitTimePeriod[0];
    }

    /**
     * Method to calculate time period based on count and frequency
     *
     * @param flowManagerDocumentRequest - flowManagerDocumentRequest
     * @return time period
     */
    default String getTimePeriod(FlowManagerDocumentRequest flowManagerDocumentRequest) {
        if (Objects.isNull(flowManagerDocumentRequest.getCount()) || "0".equalsIgnoreCase(flowManagerDocumentRequest.getCount())) {
            return flowManagerDocumentRequest.getFrequency();
        } else {
            return flowManagerDocumentRequest.getCount() + SPACE_DELIMITER + flowManagerDocumentRequest.getFrequency();
        }
    }

    /**
     * Method to calculate time period based on count and frequency
     *
     * @param flowManagerDocumentDetail - flowManagerDocumentDetail
     * @return time period
     */
    default String getTimePeriod(FlowManagerDocumentDetail flowManagerDocumentDetail) {
        if (Objects.isNull(flowManagerDocumentDetail.getCount()) || "0".equalsIgnoreCase(flowManagerDocumentDetail.getCount())) {
            return flowManagerDocumentDetail.getFrequency();
        } else {
            return flowManagerDocumentDetail.getCount() + SPACE_DELIMITER + flowManagerDocumentDetail.getFrequency();
        }
    }

}