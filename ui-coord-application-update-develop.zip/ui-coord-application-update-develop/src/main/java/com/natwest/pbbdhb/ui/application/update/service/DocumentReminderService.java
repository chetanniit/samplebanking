package com.natwest.pbbdhb.ui.application.update.service;

import com.natwest.pbbdhb.ui.application.update.model.dto.request.DocumentReminder;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.SuccessResponse;
import org.springframework.http.ResponseEntity;

/**
 * This interface contains the methods related to sendReminder endPoint
 */
public interface DocumentReminderService {

    /**
     * This method is to request a document reminder to be sent
     * @param brand - Allowed values NWB/RBS
     * @param reminderRequest - request object represents the Document request
     * @param referenceNumber - String referenceNumber
     * @param caseID - String caseId
     * @return String
     */
    ResponseEntity<SuccessResponse> sendReminder(String brand, DocumentReminder reminderRequest, String referenceNumber, String caseID);

}
