package com.natwest.pbbdhb.ui.application.update.model.dto.request.flowmanager;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * DisassociateDocumentRequest class is the request for disassociating a docment from a bucket/requestid
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString
public class FlowManagerDisassociateDocumentRequest {


    private String documentId;

    private String caseId;

    private String requestId;

    private String updatedByFullName;

    private String updatedByRACFID;


}
