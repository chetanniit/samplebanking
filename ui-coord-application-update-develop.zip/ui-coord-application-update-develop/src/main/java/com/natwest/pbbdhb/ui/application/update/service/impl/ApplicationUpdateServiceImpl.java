package com.natwest.pbbdhb.ui.application.update.service.impl;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.natwest.pbbdhb.adbo.dto.CaseDetailsDto;
import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.commondictionaries.enums.applicant.TelephoneType;
import com.natwest.pbbdhb.income.expense.model.domain.CaseStatusDto;
import com.natwest.pbbdhb.income.expense.model.expense.request.CaseExpenseDto;
import com.natwest.pbbdhb.income.expense.model.expense.response.ValidatedCaseExpenseDto;
import com.natwest.pbbdhb.income.expense.model.income.request.CaseIncomeDto;
import com.natwest.pbbdhb.income.expense.model.income.response.ValidatedCaseIncomeDto;
import com.natwest.pbbdhb.property.dto.PropertyDetailsDto;
import com.natwest.pbbdhb.applicant.dto.ApplicantDto;
import com.natwest.pbbdhb.applicant.dto.PersonTelephoneDto;
import com.natwest.pbbdhb.ui.application.update.events.ApplicantInfoUpdateEvent;
import com.natwest.pbbdhb.ui.application.update.model.dto.capie.ManualKeyInCaseUpdateRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.document.DocumentUploadResponseDto;
import com.natwest.pbbdhb.ui.application.update.model.dto.exception.PreConditionFailedException;
import com.natwest.pbbdhb.ui.application.update.model.dto.notes.DocumentNotesRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.CloseTaskRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.DocumentReminder;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.FIStatusRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.NoteRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.TaskRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.AddTeleMessageRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.ApplicationInformationUpdateRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.CaseTransferRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.CaseUpdateCaseOwnerRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.UpdateCaseOwnerRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.document.DocumentRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.document.DocumentUploadRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.firequest.FIRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.AddDocumentResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.BasicPackagingDocumentResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.SuccessResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.application.ApplicationInformationUpdateResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.application.CaseUpdatedCaseOwnerResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.application.UpdatedCaseOwnerResponse;
import com.natwest.pbbdhb.ui.application.update.service.*;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.json.JsonPatch;
import java.text.ParseException;
import java.util.Objects;

import static com.natwest.pbbdhb.ui.application.update.util.ErrorConstant.ERROR_CODE_412_CASEID_NOT_VALID;

/**
 * This class is an implementation class of ApplicationUpdateService
 */
@Service
@AllArgsConstructor
@Slf4j
public class ApplicationUpdateServiceImpl implements ApplicationUpdateService {
    private final TaskService taskService;
    private final NoteService noteService;
    private final FIService fiService;
    private final DocumentUploadService documentUploadService;
    private final DocumentReminderService documentReminderService;
    private final DocumentNotesService documentNotesService;
    private final ApplicationService applicationService;
    private final PropertyService propertyService;
    private final ApplicantService applicantService;
    private final CaseService caseService;
    private final IncomeExpenseService incomeExpenseService;
    private final ApplicationEventPublisher eventPublisher;
    private final MopsDocumentUploadService mopsDocumentUploadService;
    private final ManualKeyInCaseUpdateService manualKeyInCaseUpdateService;
    private final TeleMessageRequestService teleMessageRequestService;
    private final ADBOCaseService adboCaseService;
    private final BasicPackagingService basicPackagingService;
    private final StpOutcomeService stpOutcomeService;

    /**
     * This method will call taskService.addTask to create task based on brand and TaskRequest
     *
     * @param brand       - Allowed values NWB/RBS
     * @param taskRequest - TaskRequest as input
     * @return String
     * @throws ParseException - throws parse exception during date conversion
     */
    @Override
    public String addTask(String brand, TaskRequest taskRequest) throws ParseException {
        log.info("addTask method entered in ApplicationUpdateServiceImpl class");
        return taskService.addTask(brand, taskRequest);
    }

    /**
     * This method will call noteService.addNote to create note based on NoteRequest
     *
     * @param brand       Allowed values NWB/RBS
     * @param noteRequest - Represent NoteRequest object
     * @return String
     * @throws ParseException throws parse exception during date conversion
     */
    @Override
    public String addNote(String brand, NoteRequest noteRequest) throws ParseException {
        log.info("addNote method entered in ApplicationUpdateServiceImpl class");
        return noteService.addNote(brand, noteRequest);
    }

    /**
     * This method will call taskService.closeTask to close task based on CloseTaskRequest
     *
     * @param brand   - Allowed values NWB/RBS
     * @param request - request object represents close task request
     * @return String
     * @throws ParseException - throws parse exception during date conversion
     */
    @Override
    public String closeTask(String brand, CloseTaskRequest request) throws ParseException {
        log.info("closeTask method entered in ApplicationUpdateServiceImpl class");
        return taskService.closeTask(brand, request);
    }

    /**
     * This method to add FI based on brand and FIRequest
     *
     * @param brand     - Allowed values NWB/RBS
     * @param referenceNumber - referenceNumber field
     * @param caseId - caseId field
     * @param fIRequest - request object represents the FIRequest
     * @return AddDocumentResponse
     */
    @Override
    public ResponseEntity<AddDocumentResponse> addFI(String brand, String referenceNumber, String caseId, FIRequest fIRequest) {
        log.info("addFI method entered in ApplicationUpdateServiceImpl class");
        return fiService.addFI(brand, referenceNumber, caseId, fIRequest);
    }

    /**
     * method is used for uploading document for the given mortgage/application id
     *
     * @param brand           - brand could be NWB/RBSs
     * @param caseId          -CaseId :type of applicationId
     * @param referenceNumber -referenceNumber :type of applicationId
     * @param documentRequest - Document request object contains channel, application id and multipart
     * @return - DocumentUploadResponseDto
     */
    @Override
    public DocumentUploadResponseDto uploadDocument(String brand,String caseId, String referenceNumber, DocumentRequest documentRequest) throws JsonProcessingException {
        return documentUploadService.uploadDocument(brand,caseId, referenceNumber, documentRequest);
    }

    /**
     * method is used for uploading document for the given mortgage/application id
     *
     * @param brand            - brand could be NWB/RBSs
     * @param documentReminder - Document reminder as input
     * @param referenceNumber  - String referenceNumber
     * @param caseId - String caseId
     * @return - String
     */
    @Override
    public ResponseEntity<SuccessResponse> sendReminder(String brand, DocumentReminder documentReminder, String referenceNumber, String caseId) {
        return documentReminderService.sendReminder(brand, documentReminder, referenceNumber, caseId);
    }

    /**
     * This method to update FI State based on brand and FIStatusRequest
     *
     * @param brand           - Allowed values NWB/RBS
     * @param fiStatusRequest - request object represents the FIStatusRequest
     * @param referenceNumber  - String referenceNumber
     * @param caseId - String caseId
     * @param firequestId - String requestId
     * @param state - String state
     * @return String
     */
    @Override
    public ResponseEntity<SuccessResponse> updateFIState(String brand, FIStatusRequest fiStatusRequest, String referenceNumber, String caseId, String firequestId, String state) {
        log.info("updateFIState method entered in ApplicationUpdateServiceImpl class");
        return fiService.updateFIState(brand, fiStatusRequest, referenceNumber, caseId, firequestId, state);
    }

    /**
     * This method is used to add the note
     *
     * @param brand   - supported brands NWB/RBS
     * @param referenceNumber - String referenceNumber
     * @param caseId - String caseId
     * @param request - request object
     * @return String - String response
     */
    @Override
    public ResponseEntity<SuccessResponse> addDocumentRequestNotes(String brand, String referenceNumber, String caseId, DocumentNotesRequest request) {
        return documentNotesService.addDocumentRequestNotes(brand, referenceNumber, caseId, request);
    }

    /**
     * Method to update application information in application collection
     *
     * @param brand              - brand
     * @param caseApplicationDto - caseApplicationDto
     * @param caseId             - String caseId
     * @return ApplicationInformationUpdateResponse
     */
    @Override
    public ResponseEntity<CaseApplicationDto> updateApplicationInformation(String brand, CaseApplicationDto caseApplicationDto, String caseId) {
        return caseService.updateCase(brand,caseApplicationDto,caseId);
    }

    /**
     * Method to update application information in application collection
     *
     * @param brand - brand
     * @param applicationInformationUpdateRequest - applicationInformationUpdateRequest
     * @param referenceNumber   - string referenceNumber
     * @param caseId - String caseId
     * @return ApplicationInformationUpdateResponse
     */
    @Override
    public ResponseEntity<ApplicationInformationUpdateResponse> updateApplicationInformation(String brand, ApplicationInformationUpdateRequest applicationInformationUpdateRequest, String referenceNumber, String caseId) {
        return applicationService.updateApplicationInformation(brand, applicationInformationUpdateRequest, referenceNumber, caseId);
    }

    /**
     * Method to update the property information for the given case id
     *
     * @param brand   - brand
     * @param caseId  - case id String
     * @param request - request object
     * @return PropertyDetailsDto - response object
     */
    @Override
    public PropertyDetailsDto updatePropertyInformation(String brand, String caseId, PropertyDetailsDto request) {
        return propertyService.updatePropertyInformation(brand, caseId, request);
    }

    /**
     * This method is used to update applicant information based on applicantId and caseId
     *
     * @param brand        - allowed values NWB/RBS
     * @param applicantId  - String applicantId
     * @param caseId       - String caseId
     * @param applicantDto - ApplicantDto object
     * @return - return ResponseEntity object
     */
    @Override
    public ResponseEntity<ApplicantDto> updateApplicants(String brand, String applicantId, String caseId, ApplicantDto applicantDto) {
        validateCaseId(caseId, applicantDto);
        ResponseEntity<ApplicantDto> applicantDtoResponseEntity = applicantService.updateApplicants(brand, applicantId, applicantDto);
        if(HttpStatus.OK.value() == applicantDtoResponseEntity.getStatusCodeValue() && Objects.nonNull(applicantDto.getPersonalDetails())){

            ApplicantInfoUpdateEvent event = getApplicantInfoUpdateEvent(brand, applicantDto);

            eventPublisher.publishEvent(event);
        }
        return applicantDtoResponseEntity;
    }

    /**
     * Method to update the case information for the given case id in CAPIE system
     *
     * @param brand     - brand
     * @param caseId    - caseId
     * @param jsonPatch - jsonPatch
     * @return CaseApplicationDto
     */
    @Override
    public CaseApplicationDto updateCaseInformation(String brand, String caseId, JsonPatch jsonPatch) {
        return caseService.updateCaseInformation(brand, caseId, jsonPatch);
    }

    /**
     * Method to patch update the property information for the given case id in CAPIE system
     *
     * @param brand     - brand
     * @param caseId    - caseId
     * @param jsonPatch - jsonPatch
     * @return PropertyDetailsDto
     */
    @Override
    public PropertyDetailsDto patchUpdatePropertyInformation(String brand, String caseId, JsonPatch jsonPatch) {
        return propertyService.patchUpdatePropertyInformation(brand, caseId, jsonPatch);
    }

    private String getMobileNumber(ApplicantDto applicantDto) {
        if(Objects.isNull(applicantDto.getPersonalDetails().getTelephones())){
            return null;
        }
        return applicantDto.getPersonalDetails().getTelephones().stream()
                    .filter(personTelephoneDto -> StringUtils.equals(personTelephoneDto.getType(), TelephoneType.MOBILE.name()))
                    .map(PersonTelephoneDto::getNumber)
                    .findFirst().orElse(null);
    }

    private void validateCaseId(String caseId, ApplicantDto applicantDto){
        if(!StringUtils.equals(caseId, applicantDto.getCaseId())){
            throw new PreConditionFailedException(ERROR_CODE_412_CASEID_NOT_VALID);
        }
    }

    /**
     *  This method is used to update the applicant information in CAPIE system for the given fields
     *
     * @param brand - possible vales NWB/RBS
     * @param caseId - caseId String
     * @param applicantId - applicantId String
     * @param jsonPatch - jsonPatch request
     * @return ApplicantDto - ApplicantDto response
     */
    @Override
    public ApplicantDto patchApplicantUpdate(String brand, String caseId, String applicantId, JsonPatch jsonPatch) {
        return applicantService.patchApplicantUpdate(brand,caseId,applicantId,jsonPatch);
    }

    /**
     * This method is used to save and update income information based on caseId
     *
     * @param brand   - allowed values NWB/RBS
     * @param caseId  - String caseId
     * @param request - CaseIncomeDto object
     * @return - return ValidatedCaseIncomeDto object
     */
    @Override
    public ValidatedCaseIncomeDto saveAndValidateIncomeData(String brand, String caseId, CaseIncomeDto request) {
        return incomeExpenseService.saveAndValidateIncomeData(brand, caseId, request);
    }

    /**
     * This method is used to validate income information based on caseId
     *
     * @param brand   - allowed values NWB/RBS
     * @param caseId  - String caseId
     * @param request - CaseStatusDto object
     * @return - return ValidatedCaseIncomeDto object
     */
    @Override
    public ValidatedCaseIncomeDto markIncomeValidated(String brand, String caseId, CaseStatusDto request) {
        return incomeExpenseService.markIncomeValidated(brand, caseId, request);
    }

    /**
     * This method is used to save and update expense information based on caseId
     *
     * @param brand   - allowed values NWB/RBS
     * @param caseId  - String caseId
     * @param request - CaseExpenseDto object
     * @return - return ValidatedCaseExpenseDto object
     */
    @Override
    public ValidatedCaseExpenseDto saveAndValidateExpenseData(String brand, String caseId, CaseExpenseDto request) {
        return incomeExpenseService.saveAndValidateExpenseData(brand, caseId, request);
    }

    /**
     * This method is used to upload the document to docin-downstream system
     *
     * @param documentRequest - request
     * @return DocumentUploadResponseDto - response
     */
    @Override
    public DocumentUploadResponseDto uploadSingleDocument(DocumentUploadRequest documentRequest) throws JsonProcessingException {
        return mopsDocumentUploadService.uploadSingleDocument(documentRequest);
    }

    /**
     * This method is used to update the expense data validation status
     *
     * @param brand - possible values RBS/NWB
     * @param caseId - caseId String
     * @param request - input Object
     * @return ValidatedCaseExpenseDto - response
     */
    @Override
    public ValidatedCaseExpenseDto markExpenseValidated(String brand,String caseId, CaseStatusDto request) {
        return incomeExpenseService.markExpenseValidated(brand,caseId,request);
    }

    /**
     * Method to update application case owner in application collection
     *
     * @param brand - brand
     * @param request - UpdateCaseOwnerByReferenceNumber request object
     * @return UpdateApplicationCaseOwnerResponseByReferenceNum response object
     */
    @Override
    public ResponseEntity<UpdatedCaseOwnerResponse> updateApplicationOwner(String brand, UpdateCaseOwnerRequest request) {
        return applicationService.updateApplicationOwner(brand,request);
    }

    @Override
    public ResponseEntity<CaseUpdatedCaseOwnerResponse> updateApplicationOwner(String brand, CaseUpdateCaseOwnerRequest request) {
        return applicationService.updateApplicationOwner(brand,request);
    }

    /**
     * Endpoint to update application detail for manual key in case
     *
     * @param brand                        - brand
     * @param caseId                       - caseId
     * @param dipId                        - dipId
     * @param manualKeyInCaseUpdateRequest - manualKeyInCaseUpdateRequest
     * @return SuccessResponse
     */
    @Override
    public SuccessResponse updateApplicationDataForManualKeyInCases(String brand, String caseId, String dipId,
                                                                    ManualKeyInCaseUpdateRequest manualKeyInCaseUpdateRequest) {
        return manualKeyInCaseUpdateService.updateApplicationDataForManualKeyInCases(brand, caseId, dipId, manualKeyInCaseUpdateRequest);
    }

    /**
     * Method to add teleMessageRequest in packaging manager
     *
     * @param brand                 - brand
     * @param referenceNumber       - referenceNumber
     * @param addTeleMessageRequest - addTeleMessageRequest
     * @return SuccessResponse
     */
    @Override
    public SuccessResponse addTeleMessageRequest(String brand, String referenceNumber, AddTeleMessageRequest addTeleMessageRequest) {
        return teleMessageRequestService.addTeleMessageRequest(brand, referenceNumber, addTeleMessageRequest);
    }

    @Override
    public CaseDetailsDto updateADBOCaseInformation(String brand, String caseId, JsonPatch jsonPatch) {
        return adboCaseService.updateADBOCaseInformation(brand, caseId, jsonPatch);
    }

    /**
     * Method to retrieve basic packaging from requiredDocs API and store into PM
     *
     * @param brand                    - brand
     * @param caseId                   - caseId
     * @return BasicPackagingDocumentResponse object
     */
    @Override
    public ResponseEntity<BasicPackagingDocumentResponse> addBasicPackagingRequests(String brand, String caseId) {
        return basicPackagingService.addBasicPackagingRequests(brand, caseId);
    }

    /**
     * Method to move the case to referred state
     *
     * @param brand               - brand
     * @param caseTransferRequest - caseTransferRequest
     * @param caseId - caseId
     * @return SuccessResponse
     */
    @Override
    public SuccessResponse transferCase(String brand, CaseTransferRequest caseTransferRequest, String caseId) {
        return stpOutcomeService.transferCase(brand, caseTransferRequest, caseId);
    }

    @Override
    public SuccessResponse disassociateDocument(String brand, String caseId, String requestId, String documentId) {
        return fiService.disassociateDocument(brand, caseId, requestId, documentId);
    }

    /**
     * @param brand
     * @param applicantDto
     * @return
     */
    private ApplicantInfoUpdateEvent getApplicantInfoUpdateEvent(String brand, ApplicantDto applicantDto) {
        return ApplicantInfoUpdateEvent
                .builder()
                .emailAddress(StringUtils.isNotBlank(applicantDto.getPersonalDetails().getEmail()) ? applicantDto.getPersonalDetails().getEmail() : null)
                .mobileNumber(getMobileNumber(applicantDto))
                .brand(brand)
                .caseId(applicantDto.getCaseId())
                .mainApplicant(applicantDto.getMainApplicant())
                .build();
    }

}
