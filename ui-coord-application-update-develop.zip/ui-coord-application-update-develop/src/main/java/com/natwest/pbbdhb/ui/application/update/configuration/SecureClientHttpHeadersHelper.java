package com.natwest.pbbdhb.ui.application.update.configuration;

import com.rbs.dws.security.utils.HttpHeadersHelper;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

public class SecureClientHttpHeadersHelper extends HttpHeadersHelper {

    @Override
    public void setMediaType(HttpHeaders httpHeaders, MediaType mediaType) {
        // Override to avoid setting default value
    }
}