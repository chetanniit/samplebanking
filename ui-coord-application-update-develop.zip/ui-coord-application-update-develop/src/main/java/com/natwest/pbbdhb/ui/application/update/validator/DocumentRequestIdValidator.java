package com.natwest.pbbdhb.ui.application.update.validator;


import com.natwest.pbbdhb.ui.application.update.validator.format.DocumentRequestIdConstraint;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Value;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.List;
import java.util.regex.Pattern;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.ALLOW_ONLY_ALPHABETS_AND_NUMBER_MAX_OF_FIFTY_CHAR;


/**
 * This class is to validate document request ids
 */
@Slf4j
public class DocumentRequestIdValidator implements ConstraintValidator<DocumentRequestIdConstraint, List<String>> {

    @Value("${notification.documentRequests.limit}")
    private Integer notificationDocumentRequestIdsLimit;

    @Override
    public boolean isValid(List<String> documentRequestIds, ConstraintValidatorContext context) {
        return CollectionUtils.isNotEmpty(documentRequestIds)
                && documentRequestIds.size() <= notificationDocumentRequestIdsLimit
                && documentRequestIds.stream().allMatch(id -> Pattern.compile(ALLOW_ONLY_ALPHABETS_AND_NUMBER_MAX_OF_FIFTY_CHAR).matcher(id).matches());
    }
}
