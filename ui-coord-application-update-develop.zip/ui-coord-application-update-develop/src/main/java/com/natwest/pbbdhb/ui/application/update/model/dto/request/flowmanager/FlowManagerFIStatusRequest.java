package com.natwest.pbbdhb.ui.application.update.model.dto.request.flowmanager;

import com.natwest.pbbdhb.ui.application.update.model.dto.request.FlowManagerDocumentInfo;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * FlowManagerFIStatusRequest class is the request
 * for downstream documentStatus endpoint
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FlowManagerFIStatusRequest {

    private String referenceNumber;
    private String caseId;
    private String updatedByFullName;
    private String updatedByRACFID;
    private String requestId;
    private String state;
    private String note;
    private List<FlowManagerDocumentInfo> documentInfo;
    private String customerResponse;

}
