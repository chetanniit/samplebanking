package com.natwest.pbbdhb.ui.application.update.model.dto.request;

import com.natwest.pbbdhb.ui.application.update.validator.format.DocumentRequestIdConstraint;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import java.util.List;

/**
 * Request object for send notification API
 */
@Data
@Schema(description = "Document Reminder Request Object")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Validated
@Valid
public class DocumentReminder {
    @Valid
    @Parameter(required = true, description = "request Ids")
    @DocumentRequestIdConstraint
    private List<String> fiRequestIds;
}
