package com.natwest.pbbdhb.ui.application.update.controller;

import com.natwest.pbbdhb.ui.application.update.model.dto.request.CloseTaskRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.TaskRequest;
import com.natwest.pbbdhb.ui.application.update.service.ApplicationUpdateService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.text.ParseException;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.INVALID_BRAND;
import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.VALID_BRANDS;

/**
 * This class has all endpoints related to creation and deletion of tasks and notes
 */
@PreAuthorize("@authorizationServiceImpl.isDevTestUser() || @authorizationServiceImpl.isUWUser()")
@RestController
@Tag(name = "Application Update GMS API", description = "Application Update GMS API")
@RequestMapping("/")
@AllArgsConstructor
@Validated
@Slf4j
public class ApplicationUpdateGMSController {

    private final ApplicationUpdateService applicationUpdateService;


    /**
     * This endpoint will take TaskRequest as input to create task and send the success message as response
     *
     * @param brand            - Brand
     * @param request          - Task request
     * @param validationErrors - Validation errors
     * @return String
     * @throws ParseException - throws parse exception during date conversion
     */
    @Operation(summary = "Add Task", operationId = "addTasks", tags = {"Application Update GMS API"},
            responses = {
                    @ApiResponse(responseCode = "201", description = "Created",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = String.class))}),
                    @ApiResponse(responseCode = "400", description = "Bad Request"),
                    @ApiResponse(responseCode = "401", description = "Not Authorised"),
                    @ApiResponse(responseCode = "403", description = "Forbidden"),
                    @ApiResponse(responseCode = "404", description = "No record found"),
                    @ApiResponse(responseCode = "500", description = "Internal Server Error")
            })
    @PostMapping(path = "/addTask")
    public ResponseEntity<String> addTasks(
            @RequestHeader(value = "brand") @Valid @Pattern(regexp = VALID_BRANDS, message = INVALID_BRAND) String brand,
            @Valid @RequestBody @NotNull TaskRequest request, BindingResult validationErrors) throws ParseException {
        log.info("addTasks method entered in ApplicationUpdateController class with brand: {}", brand);
        String response = applicationUpdateService.addTask(brand, request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    /**
     * This endpoint will take CloseTaskRequest as input to close task and send the success message as response
     *
     * @param brand            - allowed values NWB/RBS
     * @param request          - request object is used to frame the close task request
     * @param validationErrors - this object will hold the validation errors if any on the client request
     * @return String - response object returned to client
     * @throws ParseException - throws parse exception during date conversion
     */
    @Operation(summary = "save update data in Database", operationId = "closeTask", tags = {"Application Update GMS API"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "Ok",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = String.class))}),
                    @ApiResponse(responseCode = "400", description = "Bad Request"),
                    @ApiResponse(responseCode = "401", description = "Not Authorised"),
                    @ApiResponse(responseCode = "403", description = "Forbidden"),
                    @ApiResponse(responseCode = "404", description = "No record found"),
                    @ApiResponse(responseCode = "412", description = "Precondition Failed"),
                    @ApiResponse(responseCode = "500", description = "Internal Server Error")
            })
    @PutMapping(path = "/closeTask")
    public String closeTask(
            @RequestHeader("brand") @Valid @Pattern(regexp = VALID_BRANDS, message = INVALID_BRAND) String brand,
            @Valid @RequestBody @NotNull CloseTaskRequest request, BindingResult validationErrors) throws ParseException {
        log.info("closeTask method entered in ApplicationUpdateController class with brand : {}", brand);
        return applicationUpdateService.closeTask(brand, request);
    }
}
