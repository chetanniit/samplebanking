package com.natwest.pbbdhb.ui.application.update.service.impl;

import com.natwest.pbbdhb.adbo.dto.CaseDetailsDto;
import com.natwest.pbbdhb.ui.application.update.model.dto.exception.ResourceNotFoundException;
import com.natwest.pbbdhb.ui.application.update.service.ADBOCaseService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import javax.json.JsonPatch;
import java.util.HashMap;
import java.util.Map;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationUtil.getHeader;
import static com.natwest.pbbdhb.ui.application.update.util.ErrorConstant.ERROR_CODE_404_RECORD_NOT_FOUND;

/**
 * This service is used to call the case endPoints of CAPIE service
 */
@Service
@Slf4j
public class ADBOCaseServiceImpl implements ADBOCaseService {

    @Autowired
    @Qualifier("customSecureRestTemplate")
    private RestTemplate restTemplate;

    @Value("${msvc.adbo.case.parent.endpoint:}")
    private String msvcADBOCaseParentEndpoint;

    @Value("${msvc.adbo.case.cases.endpoint:}")
    private String msvcPatchADBOCaseEndpoint;


    /**
     * Method to update the adbo case information for the given case id in CAPIE system
     *
     * @param brand     - brand
     * @param caseId    - caseId
     * @param jsonPatch - jsonPatch
     * @return CaseDetailsDto
     */
    @Override
    public CaseDetailsDto updateADBOCaseInformation(String brand, String caseId, JsonPatch jsonPatch) {
        log.debug("updateAdboCaseInformation method entered in CaseServiceImpl class brand: {}, caseId: {} ", brand, caseId);
        String endpoint = msvcADBOCaseParentEndpoint + msvcPatchADBOCaseEndpoint;
        UriComponentsBuilder builder = getUriComponentsBuilder(caseId, endpoint);
        ResponseEntity<CaseDetailsDto> response = null;
        try {
            response = getApiResponse(brand, builder, jsonPatch);
        }catch (HttpClientErrorException ex){
            if(HttpStatus.NOT_FOUND.value() == ex.getRawStatusCode()){
                throw new ResourceNotFoundException(ERROR_CODE_404_RECORD_NOT_FOUND);
            }
            throw ex;
        }
        return response.getBody();
    }

    private UriComponentsBuilder getUriComponentsBuilder(String caseId, String endpoint) {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(endpoint);

        Map<String, Object> urlParams = new HashMap<>();
        urlParams.put("caseId", caseId);
        builder.uriVariables(urlParams);
        log.debug("URL : {} ", builder.toUriString());
        return builder;
    }

    private ResponseEntity<CaseDetailsDto> getApiResponse(String brand, UriComponentsBuilder builder, JsonPatch jsonPatch) {
        return restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.PATCH, getHeader(jsonPatch, brand), CaseDetailsDto.class);
    }

}
