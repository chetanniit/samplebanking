package com.natwest.pbbdhb.ui.application.update.service.auth;

import com.natwest.pbbdhb.ui.application.update.model.dto.response.userinformation.UserInformationResponse;
import com.rbs.dws.security.UserPrincipal;

/**
 * Interface definition for AuthorizationService implementations
 */
public interface AuthorizationService {

    UserInformationResponse getUserData();

    String getUsername();

    boolean isMCCUser();

    boolean isUWUser();

    /**
     * To check if user is Mops User
     *
     * @return returns true if Mops User
     */
    boolean isMopsUser();

    /**
     * To check if user is UWLead
     *
     * @return returns true if UWLead
     */
    boolean isUWLead();

    /**
     * To check if user is document viewer
     *
     * @return returns true if document viewer
     */
    boolean isDocViewer();

    /**
     * To check if user is Mops Data Entry
     *
     * @return returns true if Mops Data Entry
     */
    boolean isMopsDataEntry();

    String getRacfId();

    UserPrincipal getUserPrincipal();

    /**
     * To verify if util token is used to access the API
     *
     * @return true if valid util token is used and from non-prod env, otherwise false.
     */
    boolean isDevTestUser();


    /**
     * Check if user has disassociate document permissions
     * @return
     */
    boolean isDisassociateDocument();

    /**
     * Checks if user is member of PST Group
     * @return true if user belongs to PST Group
     */
    boolean isPSTUser();

    /**
     * Checks if user is member of MA Group
     * @return true if user belongs to MA Group
     */
    boolean isMAUser();

    /**
     * Checks if user is member of CIN exceptions Group
     * @return true if user belongs to CIN exceptions Group
     */
    boolean isCINUser();


    /**
     * Checks if user is member of RBSI  Group
     * @return true if user belongs to RBSI Group
     */
    boolean isRBSIUser();
}
