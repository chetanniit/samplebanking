package com.natwest.pbbdhb.ui.application.update.controller;

import com.natwest.pbbdhb.ui.application.update.model.dto.response.userinformation.UserInformationResponse;
import com.natwest.pbbdhb.ui.application.update.service.auth.AuthorizationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationUtil.populateHATEOASLink;

@RestController
@Tag(name = "Get user details API", description = "Get user details API")
@RequestMapping("/")
@Slf4j
@Validated
@AllArgsConstructor
public class UserDetailsController {

    private final AuthorizationService authService;

    @Operation(summary = "Get user search", operationId = "getUserDetails", tags = {"Get user details API"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "Ok",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = UserInformationResponse.class))}),
                    @ApiResponse(responseCode = "403", description = "Token missing or expired"),
                    @ApiResponse(responseCode = "500", description = "Internal Server Error")

            })
    @GetMapping(path = "/getUserDetails", produces = "application/json")
    public UserInformationResponse getUserDetails() {

        log.info("getUserDetails method in UserDetailsController enters");

        UserInformationResponse searchResponse = authService.getUserData();

        populateHATEOASLink(searchResponse);

        return searchResponse;
    }
}