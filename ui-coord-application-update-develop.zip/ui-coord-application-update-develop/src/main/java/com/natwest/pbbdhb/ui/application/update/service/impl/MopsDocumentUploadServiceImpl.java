package com.natwest.pbbdhb.ui.application.update.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.natwest.pbbdhb.ui.application.update.model.dto.document.DocumentUploadResponseDto;
import com.natwest.pbbdhb.ui.application.update.model.dto.enums.ApplicationIdType;
import com.natwest.pbbdhb.ui.application.update.model.dto.enums.DocumentType;
import com.natwest.pbbdhb.ui.application.update.model.dto.exception.PreConditionFailedException;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.document.DocumentUploadRequest;
import com.natwest.pbbdhb.ui.application.update.service.MopsDocumentUploadService;
import com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants;
import com.natwest.pbbdhb.ui.application.update.util.ErrorConstant;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.util.List;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.*;

/**
 * implementation class for MopsDocumentUploadService Interface
 */
@Service
@Slf4j
public class MopsDocumentUploadServiceImpl implements MopsDocumentUploadService {

    private final RestTemplate restTemplate;
    private final String docInServiceParentEndpoint;
    private final String docInServiceUploadEndpoint;
    private final String docInServicePreClassifiedEndpoint;
    private final boolean prefixValue;
    private final List<String> rbsStartDigits;
    private final List<String> nwbStartDigits;

    /**
     * This constructor is used to initialize the object with parameters
     *
     * @param restTemplate - restTemplate object
     * @param docInServiceParentEndpoint - parent endpoint
     * @param docInServiceUploadEndpoint - upload endpoint
     * @param prefixValue - boolean input
     * @param rbsStartDigits - String input
     * @param nwbStartDigits - String input
     */
    public MopsDocumentUploadServiceImpl(@Qualifier("docUploadContentTypeSecureRestTemplate") RestTemplate restTemplate,
                                         @Value("${msvc.docin.service.parent.endpoint}") String docInServiceParentEndpoint,
                                         @Value("${msvc.docin.service.upload.endpoint}") String docInServiceUploadEndpoint,
                                         @Value("${msvc.docin.service.preclassified.endpoint}") String docInServicePreClassifiedEndpoint,
                                         @Value("${prefix.mock.value:false}") boolean prefixValue,
                                         @Value("#{'${reference.number.start.digits.rbs:2}'.split(',')}") List<String> rbsStartDigits,
                                         @Value("#{'${reference.number.start.digits.nwb:3,7,8,9}'.split(',')}") List<String> nwbStartDigits) {
        this.restTemplate = restTemplate;
        this.docInServiceParentEndpoint = docInServiceParentEndpoint;
        this.docInServiceUploadEndpoint = docInServiceUploadEndpoint;
        this.docInServicePreClassifiedEndpoint = docInServicePreClassifiedEndpoint;
        this.prefixValue = prefixValue;
        this.rbsStartDigits = rbsStartDigits;
        this.nwbStartDigits = nwbStartDigits;
    }

    /**
     * This method is used to upload the document to docin-downstream system
     *
     * @param documentUploadRequest - request
     * @return DocumentUploadResponseDto - response
     */
    @Override
    public DocumentUploadResponseDto uploadSingleDocument(DocumentUploadRequest documentUploadRequest) throws JsonProcessingException {
        log.info("uploadSingleDocument method enters in DocumentUploadServiceImpl class");
        String fileNameWithExtension = documentUploadRequest.getFile().getOriginalFilename();
        String fileName = FilenameUtils.removeExtension(fileNameWithExtension);
        log.info("documentUploadRequest with fileName:{} fileNameWithExt:{}", fileName, fileNameWithExtension);

        preconditionCheck(fileName);
        String brand = StringUtils.EMPTY;
        if (rbsStartDigits.contains(String.valueOf(fileName.charAt(0)))) {
            brand = ApplicationConstants.BRAND_RBS;
        } else if (nwbStartDigits.contains(String.valueOf(fileName.charAt(0)))) {
            brand = ApplicationConstants.BRAND_NWB;
        }
        if (StringUtils.isBlank(brand))
            throw new PreConditionFailedException(ErrorConstant.ERROR_CODE_412_FILE_NAME_NOT_VALID);

        String referenceNumber = fileName.substring(0, 8);
        HttpHeaders headers = new HttpHeaders();
        headers.add("brand", brand.toUpperCase());
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);

        MultiValueMap<String, Object> map = getMultiValueMap(documentUploadRequest, referenceNumber);

        String endpoint = docInServiceParentEndpoint + docInServiceUploadEndpoint;

        if(StringUtils.isNotEmpty(documentUploadRequest.getDocumentType())
                && !DocumentType.OTHER.name().equalsIgnoreCase(documentUploadRequest.getDocumentType())){
            endpoint = docInServiceParentEndpoint + docInServicePreClassifiedEndpoint;
        }

        HttpEntity<MultiValueMap<String, Object>> httpEntity = new HttpEntity<>(map, headers);
        log.debug("DocIn service endPoint url {}, {}", endpoint, httpEntity);
        ResponseEntity<DocumentUploadResponseDto> responseEntity = restTemplate.exchange(endpoint, HttpMethod.POST, httpEntity, DocumentUploadResponseDto.class);;
        documentUploadRequest = null;
        return responseEntity.getBody();
    }

    @NotNull
    private MultiValueMap<String, Object> getMultiValueMap(DocumentUploadRequest documentUploadRequest, String referenceNumber) {
        MultiValueMap<String, Object> map = new LinkedMultiValueMap<>();
        map.add(APPLICATION_ID, prefixValue ? PREFIX + referenceNumber : referenceNumber);
        map.add(APPLICATION_ID_TYPE, ApplicationIdType.MORTGAGE_REFERENCE_NUMBER.name());
        map.add(CHANNEL_ID, StringUtils.upperCase(documentUploadRequest.getChannel().getDownStreamChannel()));
        if(StringUtils.isNotEmpty(documentUploadRequest.getDocumentType())
                && !DocumentType.OTHER.name().equalsIgnoreCase(documentUploadRequest.getDocumentType())) {
            map.add(DOCUMENT_TYPE, documentUploadRequest.getDocumentType());
            map.add("file", documentUploadRequest.getFile().getResource());
        } else {
            map.add("files", documentUploadRequest.getFile().getResource());
        }
        return map;
    }

    @NotNull
    private void preconditionCheck(String fileName) {
        if (StringUtils.isBlank(fileName) || (StringUtils.isNotBlank(fileName) && fileName.length() < 8))
            throw new PreConditionFailedException(ErrorConstant.ERROR_CODE_412_FILE_NAME_NOT_VALID);

        boolean isAllDigits = fileName.substring(0, 8).chars().allMatch(Character::isDigit);

        if (!isAllDigits)
            throw new PreConditionFailedException(ErrorConstant.ERROR_CODE_412_FILE_NAME_NOT_VALID);
    }
}
