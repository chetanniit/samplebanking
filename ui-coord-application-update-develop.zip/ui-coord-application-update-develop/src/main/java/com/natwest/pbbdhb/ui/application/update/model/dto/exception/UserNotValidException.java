package com.natwest.pbbdhb.ui.application.update.model.dto.exception;

/**
 * Class to map the details when UserNotValidException occurs
 */
public class UserNotValidException extends RuntimeException {

    private static final long serialVersionUID = 3363757489999379517L;
    /**
     * Constructor to set the value for message
     * @param message - Error message
     */
    public UserNotValidException(String message) {
        super(message);
    }
}
