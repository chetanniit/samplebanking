package com.natwest.pbbdhb.ui.application.update.configuration;

import com.rbs.dws.security.UserPrincipalProvider;
import com.rbs.dws.security.iam.MicroserviceIssuer;
import com.rbs.dws.transport.claimSource.ClaimsSourceFactory;
import com.rbs.dws.transport.config.HttpConfig;
import com.rbs.dws.transport.config.IamJwtChainConfig;
import com.rbs.dws.transport.jwtchain.JwkProvider;
import com.rbs.dws.transport.rest.IamJwtChainSecureClientHttpRequestFactory;
import com.rbs.dws.transport.rest.SecureClientHttpRequestFactory;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.client.HttpClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.client.RestTemplate;

@Configuration
@Getter
@Validated
@Slf4j
public class DocUploadSecureClientConfig {

    @Bean(name = "docUploadContentTypeSecureRestTemplate")
    public RestTemplate iamJwtChainSecureRestTemplate(
            @Qualifier("secureHttpClient") HttpClient httpClient,
            HttpConfig httpConfig,
            @Qualifier("cascadingUserPrincipalProvider") UserPrincipalProvider principalProvider,
            JwkProvider jwkProvider,
            IamJwtChainConfig iamJwtChainConfig,
            MicroserviceIssuer microserviceIssuer,
            ClaimsSourceFactory claimsSourceFactory,
            @Autowired RestTemplateBuilder restTemplateBuilder) {
        SecureClientHttpRequestFactory iamJwtChainSecureClientHttpRequestFactory =
                getIamJwtChainSecureClientHttpRequestFactory(httpClient,
                        httpConfig,
                        principalProvider,
                        jwkProvider,
                        iamJwtChainConfig,
                        microserviceIssuer,
                        claimsSourceFactory);

        return restTemplateBuilder.requestFactory(() -> iamJwtChainSecureClientHttpRequestFactory).setBufferRequestBody(false).build();
    }

    private SecureClientHttpRequestFactory getIamJwtChainSecureClientHttpRequestFactory(
            HttpClient httpClient,
            HttpConfig httpConfig,
            UserPrincipalProvider principalProvider,
            JwkProvider jwkProvider,
            IamJwtChainConfig iamJwtChainConfig,
            MicroserviceIssuer microserviceIssuer,
            ClaimsSourceFactory claimsSourceFactory) {
        return new IamJwtChainSecureClientHttpRequestFactory(
                httpClient,
                httpConfig,
                principalProvider,
                jwkProvider,
                iamJwtChainConfig,
                microserviceIssuer,
                new SecureClientHttpHeadersHelper(),
                claimsSourceFactory
        );
    }
}
