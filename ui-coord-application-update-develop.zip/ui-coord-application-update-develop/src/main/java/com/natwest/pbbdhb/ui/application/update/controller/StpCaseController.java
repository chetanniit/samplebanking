package com.natwest.pbbdhb.ui.application.update.controller;

import com.natwest.pbbdhb.ui.application.update.model.dto.exception.ErrorResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.CaseTransferRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.SuccessResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.stp.ExceptionAllocationResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.stp.ExceptionDeallocationResponse;
import com.natwest.pbbdhb.ui.application.update.service.ApplicationUpdateService;
import com.natwest.pbbdhb.ui.application.update.service.stp.CaseAllocationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.*;

@RestController
@Tag(name = "STP Update API", description = "STP Update API")
@RequestMapping("/")
@AllArgsConstructor
@Validated
@Slf4j
public class StpCaseController {
    private final CaseAllocationService caseAllocationService;
    private final ApplicationUpdateService applicationUpdateService;

    /**
     * This endpoint is to allocate case for the requested user
     *
     * @param brand   - brand
     * @param exceptionId - String
     * @return ExceptionAllocationResponse ResponseEntity object
     */
    @PreAuthorize("@authorizationServiceImpl.isDevTestUser() || @authorizationServiceImpl.isUWUser() " +
            "|| @authorizationServiceImpl.isPSTUser() || @authorizationServiceImpl.isMAUser() || @authorizationServiceImpl.isCINUser()")
    @Operation(summary = "Allocate case api", operationId = "updateApplicationCaseOwner",
            description = "Allocate case for the requested user",
            tags = {"STP Update API"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "OK",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ExceptionAllocationResponse.class))}),
                    @ApiResponse(responseCode = "400", description = "Bad Request", content = {@Content()}),
                    @ApiResponse(responseCode = "401", description = "Not Authorised", content = {@Content()}),
                    @ApiResponse(responseCode = "403", description = "Forbidden", content = {@Content()}),
                    @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {@Content()})
            })
    @PatchMapping(path = "stp/exception/assign", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ExceptionAllocationResponse> allocateCase(
            @RequestHeader(value = "brand") @Valid @Pattern(regexp = VALID_BRANDS, message = INVALID_BRAND) String brand,
            @RequestParam(name = "exceptionId", required = false) @Pattern(regexp = ALLOW_ONLY_UUID_MAX_OF_THIRTY_SIX_CHAR, message = INVALID_EXCEPTION_ID) String exceptionId) {

        log.info("allocateCase method enters: brand:{} ", brand);
        return caseAllocationService.allocateCase(brand, exceptionId);
    }



    /**
     * This endpoint is to unAssign exception for the requested user
     *
     * @param brand   - brand
     * @param exceptionId - String
     * @return ExceptionDeAllocationResponse ResponseEntity object
     */
    @PreAuthorize("@authorizationServiceImpl.isDevTestUser() || @authorizationServiceImpl.isUWUser() " +
            "|| @authorizationServiceImpl.isPSTUser() || @authorizationServiceImpl.isMAUser() || @authorizationServiceImpl.isCINUser()")
    @Operation(summary = "Deallocate case api", operationId = "deallocate case",
            description = "DeAllocate case for the requested user",
            tags = {"STP Update API"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "OK",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ExceptionDeallocationResponse.class))}),
                    @ApiResponse(responseCode = "400", description = "Bad Request", content = {@Content()}),
                    @ApiResponse(responseCode = "401", description = "Not Authorised", content = {@Content()}),
                    @ApiResponse(responseCode = "403", description = "Forbidden", content = {@Content()}),
                    @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {@Content()})
            })
    @PatchMapping(path = "stp/exception/unassign", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ExceptionDeallocationResponse> deAllocateCase(
            @RequestHeader(value = "brand") @Valid @Pattern(regexp = VALID_BRANDS, message = INVALID_BRAND) String brand,
            @RequestParam(name = "exceptionId") @Pattern(regexp = ALLOW_ONLY_UUID_MAX_OF_THIRTY_SIX_CHAR, message = INVALID_EXCEPTION_ID) String exceptionId) {

        log.info("deAllocateCase method enters: brand:{} exceptionId:{} ", brand, exceptionId);
        return caseAllocationService.deallocateCase(brand, exceptionId);
    }

    /**
     * This endpoint is to move the case to referred state
     *
     * @param brand               - brand
     * @param caseId              - caseId
     * @param caseTransferRequest - caseTransferRequest
     * @return SuccessResponse
     */
    @PreAuthorize("@authorizationServiceImpl.isDevTestUser() || @authorizationServiceImpl.isUWUser() " +
            "|| @authorizationServiceImpl.isPSTUser() || @authorizationServiceImpl.isMAUser() || @authorizationServiceImpl.isCINUser()")
    @Operation(summary = "Case Transfer API", operationId = "transferCase", tags = {"STP Update API"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "Success",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = SuccessResponse.class))}),
                    @ApiResponse(responseCode = "400", description = "Bad Request",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "401", description = "Not Authorised",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "Resource not found",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "412", description = "Precondition Failed",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "500", description = "Internal Server Error",
                            content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))})
            })
    @PatchMapping(path = "/case/{caseId}/caseTransfer", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<SuccessResponse> transferCase(
            @RequestHeader(value = "brand") @Valid @Pattern(regexp = VALID_BRANDS, message = INVALID_BRAND) String brand,
            @PathVariable("caseId") @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_NUMBER_MAX_OF_THIRTY_SIX_CHAR, message = INVALID_CASE_ID) String caseId,
            @RequestBody(required = false) @Valid CaseTransferRequest caseTransferRequest) {
        log.info("caseTransfer: brand: {}, caseId: {}", brand, caseId);
        return new ResponseEntity<>(applicationUpdateService.transferCase(brand, caseTransferRequest, caseId), HttpStatus.OK);
    }
}
