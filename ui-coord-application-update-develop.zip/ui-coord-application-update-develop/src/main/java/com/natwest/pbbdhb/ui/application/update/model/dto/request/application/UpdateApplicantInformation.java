package com.natwest.pbbdhb.ui.application.update.model.dto.request.application;

import com.natwest.pbbdhb.ui.application.update.validator.format.EmailFormat;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.*;

/**
 * Update Applicant Information Object
 */
@Data
@Schema(description = "Update applicant information Object")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Validated
@Valid
public class UpdateApplicantInformation {
    @Valid
    @Parameter(description = "applicant email")
    @EmailFormat(message = INVALID_APPLICANT_EMAIL_ID)
    private String emailAddress;

    @Valid
    @Parameter(description = "applicant mobile number")
    @Pattern(regexp = ALLOW_ONLY_NUMBERS_SPACE_AND_PLUS_MAX_OF_15_DIGITS, message = INVALID_APPLICANT_MOBILE_NO)
    private String mobileNumber;

    @Valid
    @Parameter(required = true, description = "mainApplicant flag")
    @NotNull(message = INVALID_MAIN_APPLICANT)
    private Boolean mainApplicant;

    @Valid
    @Parameter(description = "notificationRequired flag")
    private Boolean notificationRequired;
}