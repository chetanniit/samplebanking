package com.natwest.pbbdhb.ui.application.update.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.natwest.pbbdhb.ui.application.update.model.dto.document.DocumentUploadResponseDto;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.document.DocumentUploadRequest;

/**
 * service is used by /upload endpoint and contains methods related to add new documents
 */
public interface MopsDocumentUploadService {

    /**
     * This method is used to upload the document to docin-downstream system
     *
     * @param documentRequest - request
     * @return DocumentUploadResponseDto - response
     */
    DocumentUploadResponseDto uploadSingleDocument(DocumentUploadRequest documentRequest) throws JsonProcessingException;
}
