package com.natwest.pbbdhb.ui.application.update.model.dto.request.application;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.*;

/**
 * Application Case Owner information object
 */
@Data
@Schema(description = "Application Case Owner information object")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Validated
@Valid
public class ApplicationCaseOwner {

    @Valid
    @Parameter(description = "Reference Number")
    @Pattern(regexp = ALLOW_ONLY_NUMBERS_AND_MAX_OF_TEN_DIGITS, message = INVALID_REFERENCE_NUMBER)
    @NotNull(message = INVALID_REFERENCE_NUMBER)
    private String referenceNumber;

    @Valid
    @Parameter(description = "case owner")
    @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_NUMBERS_MAX_OF_TWENTY_CHAR, message = INVALID_CASE_OWNER)
    @NotNull(message = INVALID_CASE_OWNER)
    private String caseOwner;
}
