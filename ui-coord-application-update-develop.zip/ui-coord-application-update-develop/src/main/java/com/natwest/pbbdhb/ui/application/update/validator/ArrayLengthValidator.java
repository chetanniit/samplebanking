package com.natwest.pbbdhb.ui.application.update.validator;

import com.natwest.pbbdhb.ui.application.update.validator.format.ArrayLengthConstraint;
import org.apache.commons.collections.CollectionUtils;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class ArrayLengthValidator implements ConstraintValidator<ArrayLengthConstraint, List<String>> {

    @Override
    public boolean isValid(List<String> value, ConstraintValidatorContext context) {
        if(CollectionUtils.isNotEmpty(value)){
            AtomicInteger size = new AtomicInteger();
            value.forEach(s -> {
                size.addAndGet(s.length());
            });
            if(size.get()>100){
                return false;
            }
        }
        return true;
    }
}
