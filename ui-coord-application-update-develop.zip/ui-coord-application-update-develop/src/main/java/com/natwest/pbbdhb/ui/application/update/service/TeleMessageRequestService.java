package com.natwest.pbbdhb.ui.application.update.service;

import com.natwest.pbbdhb.ui.application.update.model.dto.request.AddTeleMessageRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.SuccessResponse;

/**
 * Service class to raise TeleMessageRequest
 */
public interface TeleMessageRequestService {

    /**
     * Method to add teleMessageRequest in packaging manager
     *
     * @param brand                 - brand
     * @param referenceNumber       - referenceNumber
     * @param addTeleMessageRequest - addTeleMessageRequest
     * @return SuccessResponse
     */
    SuccessResponse addTeleMessageRequest(String brand, String referenceNumber, AddTeleMessageRequest addTeleMessageRequest);
}
