package com.natwest.pbbdhb.ui.application.update.service;


import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.ApplicationInformationUpdateRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.CaseUpdateCaseOwnerRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.UpdateCaseOwnerRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.application.ApplicationInformationUpdateResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.application.CaseUpdatedCaseOwnerResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.application.UpdatedCaseOwnerResponse;
import org.springframework.http.ResponseEntity;

/**
 * This class has method to update the application collection
 */
public interface ApplicationService {

    /**
     * Method to update application information in application collection
     *
     * @param brand                               - brand
     * @param applicationInformationUpdateRequest - applicationInformationUpdateRequest
     * @param referenceNumber                     - String referenceNumber
     * @param caseId                              - String caseId
     * @return ApplicationInformationUpdateResponse
     */
    ResponseEntity<ApplicationInformationUpdateResponse> updateApplicationInformation(String brand, ApplicationInformationUpdateRequest applicationInformationUpdateRequest, String referenceNumber, String caseId);

    /**
     * Method to update application case owner by reference number in application collection
     * @param brand - brand
     * @param request - UpdateCaseOwnerRequest
     * @return UpdatedCaseOwnerResponse
     */

    ResponseEntity<UpdatedCaseOwnerResponse> updateApplicationOwner(String brand, UpdateCaseOwnerRequest request);

    /**
     * Method to update application case owner by reference number in application collection
     * @param brand - brand
     * @param request - CaseUpdateCaseOwnerRequest
     * @return CaseUpdatedCaseOwnerResponse
     */

    ResponseEntity<CaseUpdatedCaseOwnerResponse> updateApplicationOwner(String brand, CaseUpdateCaseOwnerRequest request);
}
