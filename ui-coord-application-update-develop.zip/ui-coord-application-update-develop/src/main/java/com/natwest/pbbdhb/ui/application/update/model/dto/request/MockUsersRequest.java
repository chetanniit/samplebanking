package com.natwest.pbbdhb.ui.application.update.model.dto.request;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

/**
 * This class is used for enable multi mock users request
 */
@Data
@Schema(description = "Enable Mock Users")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Validated
@Valid
public class MockUsersRequest {

    @Parameter(required = true, description = "MCCUser")
    @NotNull(message = "MCCUser")
    private Boolean isMCCUser;

    @Parameter(required = true, description = "MopsUser")
    @NotNull(message = "MopsUser")
    private Boolean isMopsUser;

    @Parameter(required = true, description = "UWUser")
    @NotNull(message = "UWUser")
    private Boolean isUWUser;

    @Parameter(required = true, description = "UWLead")
    @NotNull(message = "UWLead")
    private Boolean isUWLead;

    @Parameter(required = true, description = "DocViewer")
    @NotNull(message = "DocViewer")
    private Boolean isDocViewer;

    @Parameter(required = true, description = "MopsDataEntry")
    @NotNull(message = "MopsDataEntry")
    private Boolean isMopsDataEntry;

    @Parameter(required = true, description = "isDisassociateDocument")
    @NotNull(message = "isDisassociateDocument")
    private Boolean isDisassociateDocument;

    @Parameter(required = true, description = "PSTUser")
    @NotNull(message = "PSTUser")
    private Boolean isPSTUser;

    @Parameter(required = true, description = "MAUser")
    @NotNull(message = "MAUser")
    private Boolean isMAUser;

    @Parameter(required = true, description = "CINUser")
    @NotNull(message = "CINUser")
    private Boolean isCINUser;

    @Parameter(required = true, description = "RBSIUser")
    @NotNull(message = "RBSIUser")
    private Boolean isRBSIUser;

    @Parameter(description = "racfID")
    private String racfID;

    @Parameter(description = "username")
    private String username;
}
