package com.natwest.pbbdhb.ui.application.update.model.dto.request;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.*;

/**
 * AddNoteRequest class is the request for downstream /AddNote endpoint
 * and validation for all the fields are captured here
 */
@Data
@Schema(description = "Add NOte Object")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Validated
@Valid
public class AddNoteRequest {
    @Valid
    @Parameter(required = true, description = "Reference Number")
    @Pattern(regexp = ALLOW_ONLY_NUMBERS_AND_MAX_OF_TEN_DIGITS, message = INVALID_REFERENCE_NUMBER)
    private String referenceNumber;

    @Valid
    @Parameter(required = true, description = "Sequence Number")
    @Pattern(regexp = ALLOW_ONLY_NUMBERS_AND_MAX_OF_TWO_DIGITS, message = INVALID_SEQUENCE_ID)
    private String sequenceNumber;

    @Valid
    @Parameter(required = true, description = "request ID")
    @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_NUMBERS_MAX_OF_FIFTY_CHAR, message = INVALID_REQUEST_ID)
    @NotNull(message = INVALID_REQUEST_ID)
    private String requestID;

    @Valid
    @Parameter(description = "note")
    @Pattern(regexp = ALLOW_MAX_4000_CHAR, message = INVALID_NOTE)
    private String note;

}
