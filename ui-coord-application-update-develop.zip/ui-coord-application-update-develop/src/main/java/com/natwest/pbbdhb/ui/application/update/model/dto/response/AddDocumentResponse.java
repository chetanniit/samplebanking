package com.natwest.pbbdhb.ui.application.update.model.dto.response;

import lombok.*;

import java.util.List;

/**
 * Response object for request FI API
 */
@Data
@Builder
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@NoArgsConstructor(access = AccessLevel.PUBLIC)
public class AddDocumentResponse {
    private String message;
    private int responseCode;
    private List<DocumentRequestResponse> duplicateRequests;
}
