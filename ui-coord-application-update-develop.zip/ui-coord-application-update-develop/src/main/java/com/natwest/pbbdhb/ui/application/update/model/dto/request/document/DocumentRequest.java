package com.natwest.pbbdhb.ui.application.update.model.dto.request.document;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.ALLOW_ONLY_ALPHABETS_AND_NUMBERS_MAX_OF_EIGHT_CHAR;
import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.ALLOW_ONLY_ALPHABETS_AND_NUMBERS_MAX_OF_FIFTY_CHAR;
import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.INVALID_APPLICANT_ID;
import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.INVALID_CHANNEL;
import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.INVALID_CLASSIFICATION_CODE;
import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.INVALID_DOCUMENT_TYPE;
import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.INVALID_DOC_UPLOAD;
import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.INVALID_LOAN_PURPOSE;
import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.INVALID_REQUEST_ID;
import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.REGEXP_ALLOW_DOC_TYPE_VALUE;
import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.REGEXP_ALLOW_LOAN_PURPOSE_VALUE;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.springframework.validation.annotation.Validated;
import org.springframework.web.multipart.MultipartFile;

import com.natwest.pbbdhb.commondictionaries.enums.cases.LoanPurpose;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Schema(description = "Document request object")
@AllArgsConstructor
@NoArgsConstructor
@Validated
@Builder
public class DocumentRequest {

    @Valid
    @NotNull(message = INVALID_CHANNEL)
    @Parameter(description = "Channel")
    private DocUploadChannelEnum channel;

    @Valid
    @Parameter(description = "Request Id")
    @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_NUMBERS_MAX_OF_FIFTY_CHAR, message = INVALID_REQUEST_ID)
    private String requestId;

    @Valid
    @Parameter(description = "Applicant id for uploaded documents.")
    @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_NUMBERS_MAX_OF_FIFTY_CHAR, message = INVALID_APPLICANT_ID)
    private String applicantId;

    @Valid
    @Parameter(description = "Classification Code")
    @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_NUMBERS_MAX_OF_EIGHT_CHAR, message = INVALID_CLASSIFICATION_CODE)
    private String classificationCode;

    @Valid
    @NotNull(message = INVALID_DOC_UPLOAD)
    @Parameter(description = "Documents to be uploaded")
    private List<MultipartFile> files;

    @Valid
    @NotNull(message = INVALID_DOCUMENT_TYPE)
    @Parameter(description = "DocumentType")
    @Pattern(regexp = REGEXP_ALLOW_DOC_TYPE_VALUE, message = INVALID_DOCUMENT_TYPE)
    @Schema(type = "String", defaultValue = "OTHER", allowableValues = {"OTHER", "EECOT", "FMAMAF", "SUITCP", "EKYC", "VALREP"})
    private String documentType;

    @Valid
    @Parameter(description = "Loan Purpose")
    @Schema(implementation = LoanPurpose.class)
    @Pattern(regexp = REGEXP_ALLOW_LOAN_PURPOSE_VALUE, message = INVALID_LOAN_PURPOSE)
    private String loanPurpose;

}
