package com.natwest.pbbdhb.ui.application.update.model.dto.response.application;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Application Information Update Response Object
 */
@Data
@Schema(description = "Application information update response object")
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ApplicationInformationResponse {
    private CaseUpdateStatus caseUpdateStatus;
    private List<ApplicantInformationUpdateStatus> applicants;
    private BrokerInformationUpdateStatus brokerInfo;
    private SourceInformationUpdateStatus sourceInfo;
}
