package com.natwest.pbbdhb.ui.application.update.validator;

import com.natwest.pbbdhb.ui.application.update.validator.format.ValidateEnum;
import org.apache.commons.lang3.StringUtils;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class EnumValidator implements ConstraintValidator<ValidateEnum, CharSequence> {
    private List<String> acceptedValues;

    private void customMessageForValidation(ConstraintValidatorContext constraintContext, String message) {
        constraintContext.buildConstraintViolationWithTemplate(message).addConstraintViolation();
    }

    @Override
    public void initialize(ValidateEnum enums) {
        acceptedValues = Stream.of(enums.enumClass()
                        .getEnumConstants())
                .map(Enum::name)
                .collect(Collectors.toList());
    }


    public boolean isValid(CharSequence value, ConstraintValidatorContext context) {
        context.disableDefaultConstraintViolation();
        if (value == null || StringUtils.isBlank(value)) {
            return true;
        }
        if (!acceptedValues.contains(value.toString())) {
            customMessageForValidation(context, context.getDefaultConstraintMessageTemplate());
            return false;
        }
        return true;
    }
}
