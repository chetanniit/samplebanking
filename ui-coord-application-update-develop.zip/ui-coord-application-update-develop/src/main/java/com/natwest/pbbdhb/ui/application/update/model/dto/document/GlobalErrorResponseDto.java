package com.natwest.pbbdhb.ui.application.update.model.dto.document;

import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Builder
@Value
@Jacksonized
public class GlobalErrorResponseDto {
    String message;
}

