package com.natwest.pbbdhb.ui.application.update.model.dto.capie;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Object used in request FI API response from flow manager
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class GmsAPIStateRequest {

    private String mortgageRefNo;

    private String applSeq;

    private List<ManualKeyInApplicantDetail> applicants;

    private String applicationType;
}
