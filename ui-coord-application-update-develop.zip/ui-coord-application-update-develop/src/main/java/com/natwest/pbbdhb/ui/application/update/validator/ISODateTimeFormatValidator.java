package com.natwest.pbbdhb.ui.application.update.validator;


import com.natwest.pbbdhb.ui.application.update.validator.format.ISODateTimeConstraint;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationUtil.isValidISODateTime;


/**
 * This class is to validate DateTime format
 */
public class ISODateTimeFormatValidator implements ConstraintValidator<ISODateTimeConstraint, String> {


    /**
     * @param dateStr - date string as input
     * @param context - ConstraintValidatorContext as input
     * @return boolean
     * This method is to validate ISO dateTime format
     */
    @Override
    public boolean isValid(String dateStr, ConstraintValidatorContext context) {

        return isValidISODateTime(dateStr);
    }
}
