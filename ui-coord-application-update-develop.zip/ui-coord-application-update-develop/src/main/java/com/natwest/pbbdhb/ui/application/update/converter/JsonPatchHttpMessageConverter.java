package com.natwest.pbbdhb.ui.application.update.converter;

import org.jetbrains.annotations.NotNull;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.HttpOutputMessage;
import org.springframework.http.MediaType;
import org.springframework.http.converter.AbstractHttpMessageConverter;
import org.springframework.http.converter.HttpMessageNotWritableException;
import org.springframework.stereotype.Component;

import javax.json.Json;
import javax.json.JsonPatch;
import javax.json.JsonReader;
import javax.json.JsonWriter;
import java.io.IOException;

@Component
public class JsonPatchHttpMessageConverter extends AbstractHttpMessageConverter<JsonPatch> {

    public static final String JSON_PATCH = "application/json-patch+json";

    public JsonPatchHttpMessageConverter() {
        super(MediaType.valueOf(JSON_PATCH));
    }

    @Override
    protected boolean supports(@NotNull Class<?> clazz) {
        return JsonPatch.class.isAssignableFrom(clazz);
    }

    @NotNull
    @Override
    protected JsonPatch readInternal(
            @NotNull Class<? extends JsonPatch> clazz, @NotNull HttpInputMessage inputMessage)
            throws IOException {
        try (JsonReader reader = Json.createReader(inputMessage.getBody())) {
            return Json.createPatch(reader.readArray());
        }
    }

    @Override
    protected void writeInternal(@NotNull JsonPatch jsonPatch, @NotNull HttpOutputMessage outputMessage) {
        try (JsonWriter writer = Json.createWriter(outputMessage.getBody())) {
            writer.write(jsonPatch.toJsonArray());
        } catch (Exception e) {
            throw new HttpMessageNotWritableException(e.getMessage(), e);
        }
    }
}
