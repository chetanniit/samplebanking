package com.natwest.pbbdhb.ui.application.update.model.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * BasicPackagingDocumentResponse object for addBasicPackaging API
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FlowManagerBasicPackagingDocumentResponse {

    private List<FlowManagerDocumentDetail> documents;

}
