package com.natwest.pbbdhb.ui.application.update.model.dto.request;

import com.natwest.pbbdhb.ui.application.update.validator.format.DateConstraint;
import com.natwest.pbbdhb.ui.application.update.validator.format.DateFormatConstraint;
import com.natwest.pbbdhb.ui.application.update.validator.format.DateTimeConstraint;
import com.natwest.pbbdhb.ui.application.update.validator.format.NoteConstraint;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.*;

/**
 * TaskRequest class is the request for /addTask endpoint
 * and validation for all the fields are captured here
 */
@Data
@Schema(description = "Add Task Object")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Validated
@Valid
@NoteConstraint
public class TaskRequest {

    @Valid
    @Schema(required = true, type = "String", description = "Task Id")
    @Pattern(regexp = ALLOW_ONLY_NUMBERS_AND_MAX_OF_TEN_DIGITS, message = INVALID_REFERENCE_NUMBER)
    @NotNull(message = INVALID_REFERENCE_NUMBER)
    private String referenceNumber;

    @Valid
    @Schema(required = true, type = "String", description = "Task Id")
    @Pattern(regexp = ALLOW_ONLY_NUMBERS_AND_MAX_OF_TWO_DIGITS, message = INVALID_SEQUENCE_ID)
    @NotNull(message = INVALID_SEQUENCE_ID)
    private String applicationSequenceNumber;

    @Valid
    @Schema(required = true, type = "String", description = "Task code")
    @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_NUMBER_MAX_OF_FIVE_DIGITS, message = INVALID_TASK_CODE)
    @NotNull(message = INVALID_TASK_CODE)
    private String taskCode;


    @Valid
    @Schema(required = true, type = "String", description = "Task Name")
    @NotNull(message = INVALID_TASK_NAME)
    @Pattern(regexp = ALLOW_MAX_FIFTY_CHARACTERS, message = INVALID_TASK_NAME)
    private String taskName;

    @Valid
    @Schema(type = "String", description = "Date")
    @DateTimeConstraint
    private String date;

    @Valid
    @Schema(type = "String", description = "Stage number")
    @Pattern(regexp = ALLOW_ONLY_NUMBERS_AND_MAX_OF_TWO_DIGITS, message = INVALID_STAGE_NUMBER)
    private String stageNumber;

    @Valid
    @Schema(required = true, type = "String", description = "Operator name")
    @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_SPACE_MAX_OF_FIFTY_CHAR, message = INVALID_OPERATOR_NAME)
    @NotNull(message = INVALID_OPERATOR_NAME)
    private String operatorName;

    @Valid
    @Schema(required = true, type = "String", description = "Operator RACFId")
    @Pattern(regexp = ALLOW_ONLY_ALPHABETS, message = INVALID_OPERATOR_RACFID)
    @NotNull(message = INVALID_OPERATOR_RACFID)
    private String operatorRacfId;

    @Valid
    @Schema(type = "String", description = "Document Required")
    @Pattern(regexp = ALLOW_MAX_50_CHAR, message = INVALID_DOCUMENT_REQUIRED)
    private String documentRequired;

    @Valid
    @Schema(type = "String", description = "Required For")
    @Pattern(regexp = ALLOW_MAX_FIFTY_CHARACTERS, message = INVALID_REQUIRED_FOR)
    private String requiredFor;

    @Valid
    @Schema(type = "String", description = "From Date")
    @DateConstraint(message = INVALID_FROM_DATE)
    private String fromDate;

    @Valid
    @Schema(type = "String", description = "To Date")
    @DateConstraint(message = INVALID_TO_DATE)
    private String toDate;

    @Valid
    @Schema(type = "String", description = "Duration")
    @Pattern(regexp = ALLOW_MAX_50_CHAR, message = INVALID_DURATION)
    private String duration;

    @Valid
    @Schema(type = "String", description = "Reason")
    @Pattern(regexp = ALLOW_MAX_250_CHAR, message = INVALID_REASON)
    private String reason;

    @Valid
    @Schema(type = "String", description = "Description")
    @Pattern(regexp = ALLOW_MAX_FIFTY_CHARACTERS, message = INVALID_DESCRIPTION)
    private String description;

    @Valid
    @Schema(type = "String", description = "Due Date")
    @DateFormatConstraint(message = INVALID_DUE_DATE)
    private String dueDate;

}
