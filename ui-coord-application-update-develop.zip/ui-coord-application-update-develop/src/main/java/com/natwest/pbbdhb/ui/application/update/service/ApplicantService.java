package com.natwest.pbbdhb.ui.application.update.service;

import com.natwest.pbbdhb.applicant.dto.ApplicantDto;
import org.springframework.http.ResponseEntity;

import javax.json.JsonPatch;

/**
 * this service is used to call the applicants endPoint of CAPIE service
 */
public interface ApplicantService {

    /**
     * This method is used to update applicant information based on applicantId
     * @param brand - allowed values NWB/RBS
     * @param applicantId - String applicantId
     * @param applicantDto - ApplicantDto applicantDto object
     * @return - return ResponseEntity object
     */
    ResponseEntity<ApplicantDto> updateApplicants(String brand, String applicantId, ApplicantDto applicantDto);

    /**
     *  This method is used to update the applicant information in CAPIE system for the given fields
     *
     * @param brand - possible vales NWB/RBS
     * @param caseId - caseId String
     * @param applicantId - applicantId String
     * @param jsonPatch - jsonPatch request
     * @return ApplicantDto - ApplicantDto response
     */
    ApplicantDto patchApplicantUpdate(String brand, String caseId, String applicantId, JsonPatch jsonPatch);
}
