package com.natwest.pbbdhb.ui.application.update.model.dto.request.firequest;

import com.natwest.pbbdhb.ui.application.update.validator.format.EmailFormat;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.*;

/**
 * BrokerInformation class is the request for /requestFI endpoint
 * and validation for all the fields are captured here
 */
@Data
@Schema(description = "Add Source Object")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Validated
@Valid
public class BrokerInformation {

    @Valid
    @Parameter(description = "brokerName")
    @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_SPACE_MAX_OF_FIFTY_CHAR, message = INVALID_BROKER_NAME)
    private String fullName;

    @Valid
    @Parameter(description = "firmName")
    @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_SPECIAL_CHAR_MAX_OF_320_CHARACTERS, message = INVALID_FIRM_NAME)
    private String firmName;

    @Valid
    @Parameter(description = "email")
    @EmailFormat
    private String emailAddress;

    @Valid
    @Parameter(description = "isNotificationRequired")
    @NotNull(message = INVALID_NOTIFICATION_REQUIRED)
    private boolean isNotificationRequired;

    @Valid
    @Parameter(description = "phone")
    @Pattern(regexp = ALLOW_ONLY_NUMBERS_SPACE_AND_PLUS_MAX_OF_15_DIGITS, message = INVALID_MOBILE_NO)
    private String mobileNumber;
}
