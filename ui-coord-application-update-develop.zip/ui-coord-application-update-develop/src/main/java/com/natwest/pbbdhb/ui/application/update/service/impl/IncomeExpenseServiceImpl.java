package com.natwest.pbbdhb.ui.application.update.service.impl;

import com.natwest.pbbdhb.income.expense.model.domain.CaseStatusDto;
import com.natwest.pbbdhb.income.expense.model.expense.request.CaseExpenseDto;
import com.natwest.pbbdhb.income.expense.model.expense.response.ValidatedCaseExpenseDto;
import com.natwest.pbbdhb.income.expense.model.income.request.CaseIncomeDto;
import com.natwest.pbbdhb.income.expense.model.income.response.ValidatedCaseIncomeDto;
import com.natwest.pbbdhb.ui.application.update.service.IncomeExpenseService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.*;
import static com.natwest.pbbdhb.ui.application.update.util.ApplicationUtil.getUriComponentsBuilder;

/**
 * This service is used to call the Income and Expense service endPoint of CAPIE service
 */
@Slf4j
@Service
public class IncomeExpenseServiceImpl implements IncomeExpenseService {

    @Autowired
    @Qualifier("customSecureRestTemplate")
    private RestTemplate restTemplate;

    @Value("${msvc.income-expense.parent.endpoint:}")
    private String msvcIncomeExpenseParentEndpoint;

    @Value("${msvc.income-expense.income.endpoint:}")
    private String incomeEndPoint;

    @Value("${msvc.income-expense.expense.endpoint:}")
    private String expenseEndPoint;

    public static final String HEADER_SET_FOR_DOWNSTREAM_CALL = "header set for downstream call: {}";

    /**
     * This method is used to save and update income information based on caseId
     *
     * @param brand        - allowed values NWB/RBS
     * @param caseId  - String caseId
     * @param request - CaseIncomeDto object
     * @return - return ValidatedCaseIncomeDto object
     */
    @Override
    public ValidatedCaseIncomeDto saveAndValidateIncomeData(String brand, String caseId, CaseIncomeDto request) {
        log.debug("saveAndValidateIncomeData method entered in IncomeExpenseServiceImpl class brand: {}, caseId: {} ", brand, caseId);
        String endpoint = msvcIncomeExpenseParentEndpoint + incomeEndPoint;
        UriComponentsBuilder builder = getUriComponentsBuilder(caseId, endpoint);
        ResponseEntity<ValidatedCaseIncomeDto> response = getApiResponse(brand, builder, request);
        log.info("response from income service endPoint {}", response.getStatusCode());
        return response.getBody();
    }

    /**
     * This method is used to call income patch end point to validate income information based on caseId
     *
     * @param brand   - allowed values NWB/RBS
     * @param caseId  - String caseId
     * @param request - CaseIncomeDto object
     * @return - return ValidatedCaseIncomeDto object
     */
    @Override
    public ValidatedCaseIncomeDto markIncomeValidated(String brand, String caseId, CaseStatusDto request) {
        log.debug("markIncomeValidated method entered in IncomeExpenseServiceImpl class brand: {}, caseId: {} ", brand, caseId);
        String endpoint = msvcIncomeExpenseParentEndpoint + incomeEndPoint;
        UriComponentsBuilder builder = getUriComponentsBuilder(caseId, endpoint);
        ResponseEntity<ValidatedCaseIncomeDto> response = getIncomeApiResponse(brand, builder, request);
        log.info("response from income service endPoint {}", response.getStatusCode());
        return response.getBody();
    }

    /**
     * This method is used to save and update expense information based on caseId
     *
     * @param brand        - allowed values NWB/RBS
     * @param caseId  - String caseId
     * @param request - CaseExpenseDto object
     * @return - return ValidatedCaseExpenseDto object
     */
    @Override
    public ValidatedCaseExpenseDto saveAndValidateExpenseData(String brand, String caseId, CaseExpenseDto request) {
        log.debug("saveAndValidateExpenseData method entered in IncomeExpenseServiceImpl class brand: {}, caseId: {} ", brand, caseId);
        String endpoint = msvcIncomeExpenseParentEndpoint + expenseEndPoint;
        UriComponentsBuilder builder = getUriComponentsBuilder(caseId, endpoint);
        ResponseEntity<ValidatedCaseExpenseDto> response = getApiResponse(brand, builder, request);
        log.info("response from expense service endPoint {}", response.getStatusCode());
        return response.getBody();
    }

    /**
     * This method is used to update the expense data validation status
     *
     * @param brand - possible values RBS/NWB
     * @param caseId - caseId String
     * @param request - input Object
     * @return ValidatedCaseExpenseDto - response
     */
    @Override
    public ValidatedCaseExpenseDto markExpenseValidated(String brand,String caseId, CaseStatusDto request) {
        log.debug("markExpenseValidated method entered in IncomeExpenseServiceImpl class for the caseId:{}, brand:{}",caseId,brand);
        String endpoint = msvcIncomeExpenseParentEndpoint + expenseEndPoint;
        UriComponentsBuilder builder = getUriComponentsBuilder(caseId, endpoint);
        ResponseEntity<ValidatedCaseExpenseDto> response = getApiResponse(brand, builder, request);
        log.info("response:{}",response);
        return response.getBody();
    }

    private ResponseEntity<ValidatedCaseIncomeDto> getApiResponse(String brand, UriComponentsBuilder builder, CaseIncomeDto request) {
        return restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.PUT, getHeader(request, brand), ValidatedCaseIncomeDto.class);
    }

    private ResponseEntity<ValidatedCaseExpenseDto> getApiResponse(String brand, UriComponentsBuilder builder, CaseExpenseDto request) {
        return restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.PUT, getHeader(request, brand), ValidatedCaseExpenseDto.class);
    }

    private ResponseEntity<ValidatedCaseIncomeDto> getIncomeApiResponse(String brand, UriComponentsBuilder builder, CaseStatusDto request) {
        return restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.PATCH, getHeader(request, brand), ValidatedCaseIncomeDto.class);
    }

    private HttpEntity<CaseIncomeDto> getHeader(CaseIncomeDto request, String brand) {
        HttpHeaders header = new HttpHeaders();
        header.add(CONTENT_TYPE, APPLICATION_JSON);
        header.add(BRAND, brand);
        HttpEntity<CaseIncomeDto> entity = new HttpEntity<>(request, header);
        log.info(HEADER_SET_FOR_DOWNSTREAM_CALL, header);
        return entity;
    }

    private HttpEntity<CaseExpenseDto> getHeader(CaseExpenseDto request, String brand) {
        HttpHeaders header = new HttpHeaders();
        header.add(CONTENT_TYPE, APPLICATION_JSON);
        header.add(BRAND, brand);
        HttpEntity<CaseExpenseDto> entity = new HttpEntity<>(request, header);
        log.info(HEADER_SET_FOR_DOWNSTREAM_CALL, header);
        return entity;
    }

    /**
     *  This method is used to return api call response
     *
     * @param brand - possible values RBS/NWB
     * @param builder - request object
     * @param request - request object
     * @return ValidatedCaseExpenseDto - response object
     */
    private ResponseEntity<ValidatedCaseExpenseDto> getApiResponse(String brand, UriComponentsBuilder builder, CaseStatusDto request) {
        return restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.PATCH, getHeader(request, brand), ValidatedCaseExpenseDto.class);
    }

    /**
     * method to get http header
     *
     * @param request - request object
     * @param brand - String brand
     * @return - HttpEntity
     */
    public static HttpEntity<CaseStatusDto> getHeader(CaseStatusDto request, String brand) {
        HttpHeaders header = new HttpHeaders();
        header.add(CONTENT_TYPE, APPLICATION_JSON);
        header.add(BRAND, brand);
        HttpEntity<CaseStatusDto> entity = new HttpEntity<>(request, header);
        log.info(HEADER_SET_FOR_DOWNSTREAM_CALL, header);
        return entity;
    }
}
