package com.natwest.pbbdhb.ui.application.update.model.dto.request.incomerequest;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.ui.application.update.model.enums.PayslipFrequency;
import com.natwest.pbbdhb.ui.application.update.validator.format.ValidateEnum;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import java.math.BigDecimal;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.INVALID_PAYSLIP_AMOUNT;
import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.INVALID_PAYSLIP_FREQUENCY;


@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@Validated
public class PaySlipRequest {

    @ValidateEnum(enumClass = PayslipFrequency.class, message = INVALID_PAYSLIP_FREQUENCY)
    @Schema(example = "WEEKLY")
    private String payslipFrequency;

    @Digits(integer = 15, fraction = 2, message = INVALID_PAYSLIP_AMOUNT)
    @Min(0)
    private BigDecimal payslipAmount ;
}
