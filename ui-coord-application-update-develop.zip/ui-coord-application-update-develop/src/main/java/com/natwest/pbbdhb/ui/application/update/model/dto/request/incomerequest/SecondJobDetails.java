package com.natwest.pbbdhb.ui.application.update.model.dto.request.incomerequest;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.natwest.pbbdhb.ui.application.update.model.enums.EmployementStatus;
import com.natwest.pbbdhb.ui.application.update.model.enums.EmployerStatus;
import com.natwest.pbbdhb.ui.application.update.model.enums.IncomeDecreaseFiveYears;
import com.natwest.pbbdhb.ui.application.update.model.enums.SelfEmployementStatus;
import com.natwest.pbbdhb.ui.application.update.validator.format.ValidateEnum;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.Past;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.*;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@Validated
public class SecondJobDetails {

	@Schema(example = "EMPLOYED")
	@ValidateEnum(enumClass = EmployementStatus.class, message = INVALID_EMPLOYMENT_STATUS)
	private String employmentStatus;

	@Past(message = INVALID_START_DATE)
	@Schema(example = "19-12-1990")
	@JsonFormat(pattern = "dd-MM-yyyy")
	@JsonDeserialize(using = LocalDateDeserializer.class)
	@JsonSerialize(using = LocalDateSerializer.class)
	private LocalDate employmentStartDate;

	@Past(message = INVALID_BUSINESS_ESTABLISHMENT_DATE)
	@JsonFormat(pattern = "dd-MM-yyyy")
	@JsonDeserialize(using = LocalDateDeserializer.class)
	@JsonSerialize(using = LocalDateSerializer.class)
	private LocalDate businessEstablishmentDate;

	@ValidateEnum(enumClass = EmployerStatus.class, message = INVALID_EMPLOYER_STATUS)
	private String employerStatus;

	@ValidateEnum(enumClass = IncomeDecreaseFiveYears.class, message = INVALID_INCOME_DECREASE_IN_5_YEARS)
	private String incomeDecreaseInFiveYrs;

	@Digits(integer = 15, fraction = 2, message = INVALID_ANNUAL_GROSS_INCOME_ALLOWS_MAX_15_DIGIT)
	@Min(0)
	private BigDecimal annualGrossIncome;

	@Valid
	private List<PaySlipRequest> paySlip = new ArrayList<>();

	@ValidateEnum(enumClass = SelfEmployementStatus.class, message = INVALID_SELF_EMPLOYMENT_STATUS)
	private String selfEmploymentStatus;

	@Digits(integer = 9, fraction = 0, message = INVALID_YEAR_ONE_REPORT)
	@Min(0)
	private BigDecimal yearOneProfit;

	@Digits(integer = 9, fraction = 0, message = INVALID_YEAR_TWO_REPORT)
	@Min(0)
	private BigDecimal yearTwoProfit;

	@Digits(integer = 9, fraction = 0, message = INVALID_YEAR_ONE_TURN_OVER)
	@Min(0)
	private BigDecimal yearOneTurnover;

	@Digits(integer = 9, fraction = 0, message = INVALID_YEAR_TWO_TURN_OVER)
	@Min(0)
	private BigDecimal yearTwoTurnover;

	@Digits(integer = 9, fraction = 0, message = INVALID_YEAR_ONE_DIRECTORY_SALARY)
	@Min(0)
	private BigDecimal yearOneDirectorSalary;

	@Digits(integer = 9, fraction = 0, message = INVALID_YEAR_TWO_DIRECTORY_SALARY)
	@Min(0)
	private BigDecimal yearTwoDirectorSalary;

	@Digits(integer = 9, fraction = 0, message = INVALID_YEAR_ONE_DIVIDENDS)
	@Min(0)
	private BigDecimal yearOneDividends;

	@Digits(integer = 9, fraction = 0, message = INVALID_YEAR_TWO_DIVIDENDS)
	@Min(0)
	private BigDecimal yearTwoDividends;

}
