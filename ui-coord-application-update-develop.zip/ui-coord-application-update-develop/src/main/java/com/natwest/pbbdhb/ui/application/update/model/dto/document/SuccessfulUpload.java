package com.natwest.pbbdhb.ui.application.update.model.dto.document;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.Parameter;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;
import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.NotNull;

@Builder
@Jacksonized
@Value
@Validated
public class SuccessfulUpload {

    @JsonProperty("originalFileName")
    @Parameter(required = true)
    @NotNull
    String originalFileName;

    @JsonProperty("documentId")
    @Parameter(required = true)
    @NotNull
    String documentId;
}
