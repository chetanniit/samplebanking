package com.natwest.pbbdhb.ui.application.update.service.auth.impl;

import com.natwest.pbbdhb.ui.application.update.model.dto.response.userinformation.UserInformationResponse;
import com.natwest.pbbdhb.ui.application.update.service.auth.AuthorizationService;
import com.natwest.pbbdhb.ui.application.update.service.auth.UserMockService;
import com.rbs.dws.security.UserPrincipal;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.stereotype.Service;

@Service("authorizationServiceImpl")
@Slf4j
@ConditionalOnExpression("${ids.functional.user.mock:false} and '${hbo.env}' != 'prd'")
public class AuthorizationServiceMockImpl implements AuthorizationService {

    @Autowired
    private UserMockService userMockService;

    @Override
    public UserInformationResponse getUserData() {
        return userMockService.getMockUser();
    }

    @Override
    public String getUsername() {
        return userMockService.getMockUser().getUsername();
    }

    @Override
    public boolean isMCCUser() {
        return userMockService.getMockUser().isMCCUser();
    }

    @Override
    public boolean isUWUser() {
        return userMockService.getMockUser().isUWUser() ||
                userMockService.getMockUser().isUWLead();
    }

    @Override
    public boolean isMopsUser() {
        return userMockService.getMockUser().isMopsUser();
    }

    @Override
    public boolean isUWLead() {
        return userMockService.getMockUser().isUWLead();
    }

    @Override
    public boolean isDocViewer() {
        return userMockService.getMockUser().isDocViewer();
    }

    @Override
    public boolean isMopsDataEntry() {
        return userMockService.getMockUser().isMopsDataEntry();
    }

    @Override
    public String getRacfId() {
        return userMockService.getMockUser().getRacfID();
    }

    @Override
    public UserPrincipal getUserPrincipal() {
        throw new UnsupportedOperationException();
    }

    /**
     * @return false as it is a mock implementation
     */
    @Override
    public boolean isDevTestUser() {
        return false;
    }

    @Override
    public boolean isDisassociateDocument() {return userMockService.getMockUser().isDocumentDisassociate();}

    @Override
    public boolean isPSTUser() {
        return userMockService.getMockUser().isPSTUser();
    }

    @Override
    public boolean isMAUser() {
        return userMockService.getMockUser().isMAUser();
    }

    @Override
    public boolean isCINUser() {
        return userMockService.getMockUser().isCINUser();
    }


    @Override
    public boolean isRBSIUser() { return userMockService.getMockUser().isRBSIUser(); }
}
