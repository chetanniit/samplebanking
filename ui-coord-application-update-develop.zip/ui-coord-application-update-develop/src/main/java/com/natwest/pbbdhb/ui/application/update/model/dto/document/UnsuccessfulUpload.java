package com.natwest.pbbdhb.ui.application.update.model.dto.document;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.natwest.pbbdhb.ui.application.update.model.dto.enums.UploadErrorType;
import io.swagger.v3.oas.annotations.Parameter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;
import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.NotNull;

@Builder
@Value
@AllArgsConstructor
@Jacksonized
@Validated
public class UnsuccessfulUpload {

    @JsonProperty("originalFileName")
    @Parameter(required = true)
    @NotNull
    String originalFileName;

    @JsonProperty("errorMessage")
    @Parameter(required = true)
    @NotNull
    String errorMessage;

    @JsonProperty("errorType")
    @Parameter(required = true)
    @NotNull
    UploadErrorType errorType;
}
