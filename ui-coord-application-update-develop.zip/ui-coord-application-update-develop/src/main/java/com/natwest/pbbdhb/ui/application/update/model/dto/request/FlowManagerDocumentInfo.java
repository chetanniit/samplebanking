package com.natwest.pbbdhb.ui.application.update.model.dto.request;

import lombok.*;

/**
 * DocumentInfo object used in update document state API
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString
public class FlowManagerDocumentInfo {
    private String documentId;
    private String documentStatus;
    private String originalFileName;
    private String dateTime;
}