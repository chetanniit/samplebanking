package com.natwest.pbbdhb.ui.application.update.model.dto.request;

import com.natwest.pbbdhb.ui.application.update.model.dto.enums.DocumentStatus;
import com.natwest.pbbdhb.ui.application.update.validator.format.ValidateEnum;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.*;

/**
 * DocumentInfo object used in update document state API
 */
@Data
@Schema(description = "Update Document Request")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Validated
@Valid
@ToString
public class DocumentInfo {

    @Valid
    @Parameter(description = "document Id")
    @NotNull(message = INVALID_DOCUMENT_ID)
    private String documentId;

    @Valid
    @Parameter(required = true, description = "document status")
    @ValidateEnum(enumClass = DocumentStatus.class, message = INVALID_DOCUMENT_STATUS)
    @NotNull(message = INVALID_DOCUMENT_STATUS)
    @Schema(example = "UPLOAD_SUCCESS")
    private String documentStatus;

    @Parameter(description = "original Filename")
    private String originalFileName;
}