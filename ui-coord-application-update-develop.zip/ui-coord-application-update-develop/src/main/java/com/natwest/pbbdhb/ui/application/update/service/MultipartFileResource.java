package com.natwest.pbbdhb.ui.application.update.service;

import org.springframework.core.io.ByteArrayResource;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Objects;

public class MultipartFileResource extends ByteArrayResource {

    private String filename;

    public MultipartFileResource(MultipartFile multipartFile) throws IOException {
        super(multipartFile.getBytes());
        this.filename = multipartFile.getOriginalFilename();
    }

    @Override
    public String getFilename() {
        return this.filename;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }

        MultipartFileResource that = (MultipartFileResource) o;

        return Objects.equals(filename, that.filename);
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + (filename != null ? filename.hashCode() : 0);
        return result;
    }
}
