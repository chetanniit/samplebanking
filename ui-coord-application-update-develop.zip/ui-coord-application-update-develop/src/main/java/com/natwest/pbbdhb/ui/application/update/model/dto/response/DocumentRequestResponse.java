package com.natwest.pbbdhb.ui.application.update.model.dto.response;

import com.natwest.pbbdhb.ui.application.update.model.dto.request.firequest.DocumentFor;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Object used in request FI API response object
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DocumentRequestResponse {
    private List<DocumentFor> requiredFor;
    private String documentIdentifier;
    private String category;
    private List<String> reRequestReason;
    private List<String> purpose;
    private String dueDate;
    private String fromDate;
    private String toDate;
    private String timePeriod;
}
