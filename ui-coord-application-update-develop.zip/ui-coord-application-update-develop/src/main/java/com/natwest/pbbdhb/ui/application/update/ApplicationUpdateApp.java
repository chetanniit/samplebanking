package com.natwest.pbbdhb.ui.application.update;

import com.natwest.pbbdhb.ui.application.update.util.ErrorMessageConfigReader;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.mongo.MongoDataAutoConfiguration;
import org.springframework.boot.autoconfigure.mongo.MongoAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Startup of ApplicationUpdateApp
 */
@SpringBootApplication(scanBasePackageClasses = {ApplicationUpdateApp.class}, exclude = {
        MongoAutoConfiguration.class,
        MongoDataAutoConfiguration.class
})
@EnableScheduling
@EnableConfigurationProperties(ErrorMessageConfigReader.class)
public class ApplicationUpdateApp {
    /**
     * Main method of ApplicationUpdateApp
     * @param args - arguments
     */
    public static void main(String[] args) {
        SpringApplication.run(ApplicationUpdateApp.class, args);
    }
}
