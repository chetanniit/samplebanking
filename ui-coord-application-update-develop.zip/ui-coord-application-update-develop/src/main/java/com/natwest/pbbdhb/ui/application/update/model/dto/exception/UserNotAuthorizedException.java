package com.natwest.pbbdhb.ui.application.update.model.dto.exception;

/**
 * Class to map the details when UserNotAuthorizedException occurs
 */
public class UserNotAuthorizedException extends RuntimeException {

    private static final long serialVersionUID = 3884872493108915116L;
    /**
     * Constructor to set the value for message
     * @param message - Error message
     */
    public UserNotAuthorizedException(String message) {
        super(message);
    }
}
