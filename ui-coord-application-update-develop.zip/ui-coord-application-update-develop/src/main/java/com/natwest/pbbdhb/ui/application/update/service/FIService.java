package com.natwest.pbbdhb.ui.application.update.service;

import com.natwest.pbbdhb.ui.application.update.model.dto.request.FIStatusRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.firequest.FIRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.AddDocumentResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.SuccessResponse;
import org.springframework.http.ResponseEntity;

/**
 * This interface contains the methods related to requestFI endPoint
 */
public interface FIService {

    /**
     * This method is to add Further Information based on the brand and FIRequest
     * @param brand - Allowed values NWB/RBS
     * @param referenceNumber - referenceNumber field
     * @param caseID          - string caseId
     * @param fiRequest - request object represents the FIRequest
     * @return AddDocumentResponse
     */
    ResponseEntity<AddDocumentResponse> addFI(String brand, String referenceNumber, String caseID, FIRequest fiRequest);

    /**
     * This method is to update the FI State based on the brand and FIStatusRequest
     * @param brand - Allowed values NWB/RBS
     * @param fiStatusRequest - request object represents the FIStatusRequest
     * @param referenceNumber - String referenceNumber
     * @param caseID - String caseID
     * @param firequestId - String requestId
     * @param state - state
     * @return String
     */
    ResponseEntity<SuccessResponse> updateFIState(String brand, FIStatusRequest fiStatusRequest, String referenceNumber, String caseID, String firequestId, String state);


    /**
     *
     * @param brand
     * @param caseId
     * @param requestId
     * @param documentId
     * @return
     */
    SuccessResponse  disassociateDocument(String brand, String caseId, String requestId, String documentId);
}
