package com.natwest.pbbdhb.ui.application.update.model.dto.request.flowmanager;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Request object for flow manager addBasicPackaging API
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FlowManagerAddBasicPackagingRequest {
    private String userFullName;
    private String userRACFId;
}
