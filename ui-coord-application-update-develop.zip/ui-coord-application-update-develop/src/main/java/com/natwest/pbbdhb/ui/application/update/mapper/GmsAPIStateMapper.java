package com.natwest.pbbdhb.ui.application.update.mapper;


import com.natwest.pbbdhb.commondictionaries.enums.cases.LoanPurpose;
import com.natwest.pbbdhb.ui.application.update.model.dto.capie.GmsAPIStateRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.capie.ManualKeyInCaseUpdateRequest;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.APPLICATION_TYPE_FMA;

/**
 * Mapper to convert coord update request to gms api state request
 */
@Mapper(config = MappingConfig.class)
public interface GmsAPIStateMapper {

    @Mapping(target = "applicationType", expression = "java(getApplicationType(manualKeyInCaseUpdateRequest))")
    GmsAPIStateRequest toGmsAPIStateRequest(ManualKeyInCaseUpdateRequest manualKeyInCaseUpdateRequest);

    default String getApplicationType(ManualKeyInCaseUpdateRequest manualKeyInCaseUpdateRequest) {
        return LoanPurpose.ADDITIONAL_BORROWING.name().equalsIgnoreCase(manualKeyInCaseUpdateRequest.getLoanPurpose()) ? LoanPurpose.ADDITIONAL_BORROWING.name() : APPLICATION_TYPE_FMA;
    }
}
