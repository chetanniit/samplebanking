package com.natwest.pbbdhb.ui.application.update.mapper;

import com.natwest.pbbdhb.property.dto.PropertyDetailsDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.util.function.Function;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.WHEN_BUILT_FORMAT;
import static java.lang.String.format;
import static java.util.Optional.ofNullable;

@Mapper(config = MappingConfig.class)
public interface PropertyDetailsDtoMapper {

    /**
     * This method is used to map propertyDetailsDto to propertyDetailsDto
     * @param propertyDetailsDto - input
     * @return PropertyDetailsDto - output
     */
    @Mapping(target = "whenBuilt", source = "propertyDetailsDto", qualifiedByName = "getWhenBuilt")
    PropertyDetailsDto toPropertyDetailsDto(PropertyDetailsDto propertyDetailsDto);

    /**
     * This method is used to return whenbuilt field value with YYYY-MM-DD format
     * @param propertyDetailsDto - input
     * @return String - output
     */
    @Named("getWhenBuilt")
    static String getWhenBuilt(PropertyDetailsDto propertyDetailsDto) {

        Function<String, String> propertyWhenBuiltYearCapieFormatter = (String) -> format(WHEN_BUILT_FORMAT, String);
        return  ofNullable(propertyDetailsDto.getWhenBuilt())
                .map(propertyWhenBuiltYearCapieFormatter)
                .orElse(null);
    }
}
