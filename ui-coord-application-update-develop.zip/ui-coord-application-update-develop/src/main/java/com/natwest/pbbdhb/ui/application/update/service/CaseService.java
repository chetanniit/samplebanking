package com.natwest.pbbdhb.ui.application.update.service;

import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;

import javax.json.JsonPatch;


import org.springframework.http.ResponseEntity;

/**
 * This service is used to call the case endPoints of CAPIE service
 */
public interface CaseService {
    /**
     * Method to update the case information for the given case id in CAPIE system
     *
     * @param brand     - brand
     * @param caseId    - caseId
     * @param jsonPatch - jsonPatch
     * @return CaseApplicationDto
     */
    CaseApplicationDto updateCaseInformation(String brand, String caseId, JsonPatch jsonPatch);

    /**
     * This method is used to update applicant information based on applicantId
     * @param brand - allowed values NWB/RBS
     * @param caseId - String caseId
     * @param caseApplicationDto - CaseApplicationDto object
     * @return - return ResponseEntity object
     */
    ResponseEntity<CaseApplicationDto> updateCase(String brand, CaseApplicationDto caseApplicationDto, String caseId);

}
