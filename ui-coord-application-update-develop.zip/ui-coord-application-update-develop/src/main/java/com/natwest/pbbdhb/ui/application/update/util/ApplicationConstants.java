package com.natwest.pbbdhb.ui.application.update.util;

/**
 * This class is to create constants that are used across the service
 */
public class ApplicationConstants {


    public static final String CONTENT_TYPE = "Content-Type";
    public static final String APPLICATION_JSON = "application/json";
    public static final String DWS_CORRELATION_ID = "dws-correlation-id";
    public static final String DWS_REQUEST_CORRELATION_ID = "dws-request-correlation-id";

    public static final String VALID_BRANDS = "(RBS|NWB|NWI|UBNI|rbs|nwb|nwi|ubni)";
    public static final String ALLOW_ONLY_NUMBERS_AND_MAX_OF_TEN_DIGITS = "\\d{1,10}";
    public static final String ALLOW_ONLY_ALPHABETS = "^([A-Za-z]){1,10}$";
    public static final String ALLOW_ONLY_ALPHABETS_AND_SPACE_MAX_OF_FIFTY_CHAR = "^([A-Za-z\\s]){1,50}$";
    public static final String ALLOW_ONLY_ALPHABETS_AND_NUMBER_MAX_OF_FIVE_DIGITS = "^([A-Za-z0-9]){1,5}$";
    public static final String ALLOW_ONLY_NUMBERS_AND_MAX_OF_TWO_DIGITS = "^\\d{1,2}$";
    public static final String ALLOW_ONLY_ALPHABETS_NUMBER_AND_SPACE_MAX_OF_FIFTY_CHAR = "^([A-Za-z0-9\\s]){1,50}$";
    public static final String ALLOW_ONLY_ALPHABETS_AND_NUMBERS_MAX_OF_FIFTY_CHAR = "^([A-Za-z0-9]){1,50}$";
    public static final String ALLOW_ONLY_ALPHABETS_NUMBER_AND_SPACE_MAX_OF_TEN_CHAR = "^([A-Za-z0-9\\s]){1,10}$";
    public static final String ALLOW_ONLY_ALPHABETS_AND_MAX_OF_10_DIGITS = "^([A-Za-z]){1,10}$";
    public static final String ALLOW_ONLY_ALPHABETS_AND_SPACE = "^([A-Za-z\\s]){1,50}$";
    public static final String ALLOW_ONLY_ALPHABETS_AND_NUMBER = "^([A-Za-z0-9]){1,5}$";
    public static final String ALLOW_MAX_100_CHAR = "^.{0,100}$";
    public static final String ALLOW_MAX_4000_CHAR = "^.{0,4000}$";
    public static final String ALLOW_ONLY_ALPHABETS_AND_NUMBER_MAX_OF_TEN_DIGITS = "^([A-Za-z0-9]){1,10}$";
    public static final String ALLOW_ONLY_ALPHABETS_AND_SPECIAL_CHAR_MAX_50 = "^([A-Za-z0-9/]*){1,50}$";
    public static final String ALLOW_ONLY_ALPHABETS_PLUS_AND_MAX_OF_5_CHARACTERS = "^([A-Za-z+]){1,5}$";
    public static final String ALLOW_ONLY_ALPHABETS_AND_NUMBERS_MAX_OF_EIGHT_CHAR = "^([A-Za-z0-9]){1,8}$";
    public static final String ALLOW_ONLY_ALPHABETS_AND_NUMBERS_MAX_OF_TWENTY_CHAR = "^([A-Za-z0-9]){1,20}$";

    public static final String DATE_TIME_PATTERN = "^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}\\+\\d{2}:\\d{2}$";
    public static final String ISO_DATE_TIME_PATTERN = "^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}.\\d{3}$";
    public static final String DATE_PATTERN = "^\\d{4}-\\d{2}-\\d{2}$";
    public static final String ALLOW_MAX_50_CHAR = "^.{0,50}$";
    public static final String ALLOW_MAX_250_CHAR = "^.{5,250}$";
    public static final String ALLOW_0_TO_250_CHAR = "^.{0,250}$";
    public static final String ALLOW_ONLY_ALPHABETS_AND_SPECIAL_CHAR_MAX_OF_320_CHARACTERS = "^([ A-Za-z0-9_@&£$€¥#().,:;\"!+/'ë-]){1,320}$";
    public static final String EMAIL_PATTERN = "^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$";
    public static final String ALLOW_ONLY_NUMBERS_SPACE_AND_PLUS_MAX_OF_15_DIGITS = "^[1-9\\+]{1}[0-9\\s]{3,14}$";
    public static final String ALLOW_ONLY_ALPHANUMERIC_AND_NO_SPECIAL_CHARACTER_MIN_6_MAX_12 = "^([a-zA-Z0-9]){6,12}$";
    public static final String ALLOW_ONLY_ALPHABETS_AND_UNDERSCORE_MAX_20 = "^[a-zA-Z_]{0,20}$";
    public static final String ALLOW_MAX_FIFTY_CHARACTERS = "^.{0,50}$";
    public static final String ALLOW_ONLY_ALPHANUMERIC_MIN_MAX_3_CHAR = "^[a-zA-Z0-9]{3,3}$";

    public static final String DOC_UPLOAD_VALID_BRANDS = "(RBS|NWB|rbs|nwb)";
    public static final String ALLOWED_VALUES_FOR_CHANNEL = "INTERNET,BRANCH,INTERMEDIARY,internet,branch,intermediary";
    public static final String BROKER_FOCUS = "BROKER_FOCUS";
    public static final String BROKER = "BROKER";

    public static final String CHANNEL_ID = "channelId";
    public static final String APPLICATION_ID = "applicationId";
    public static final String APPLICANT_ID = "applicantId";
    public static final String REFERENCE_NUMBER = "referenceNumber";
    public static final String CASE_ID = "caseId";
    public static final String EXCEPTION_ID = "exceptionId";
    public static final String REQUEST_ID = "requestId";

    public static final String DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mmXXX";
    public static final String DATE_FORMAT_YYYY_MM_DD = "yyyy-MM-dd";
    public static final String UK_TIME_ZONE = "Europe/London";

    public static final String BRAND = "brand";

    public static final String INVALID_INPUT = "input";
    public static final String INVALID_REFERENCE_NUMBER = "reference number";

    public static final String INVALID_SEQUENCE_ID = "sequence id";
    public static final String INVALID_TASK_NAME = "task name";
    public static final String INVALID_OPERATOR_NAME = "operator name";
    public static final String INVALID_OPERATOR_RACFID = "operator racfId";
    public static final String INVALID_TASK_CODE = "task code";
    public static final String INVALID_STAGE_NUMBER = "stage number";
    public static final String INVALID_BRAND = "brand name";
    public static final String INVALID_TASK_ID = "task id";
    public static final String MISSING_BRAND = "Missing request header 'brand'";
    public static final String INVALID_NOTE = "note";
    public static final String INVALID_MORTGAGE_REFERENCE_NUMBER = "mortgageRefNo";
    public static final String INVALID_APPLICATION_SEQUENCE_NUMBER = "applSeq";
    public static final String INVALID_FIRST_NAMES = "firstNames";
    public static final String INVALID_MIDDLE_NAMES = "middleNames";
    public static final String INVALID_MANUAL_KEY_IN_APPLICANT_LAST_NAME = "lastName";
    public static final String INVALID_DATE_OF_BIRTH = "dateOfBirth";
    public static final String INVALID_APPLICANTS = "applicants";
    public static final String INVALID_CLIENT_ID = "clientId";

    public static final String INVALID_DATE_TIME = "date and time";
    public static final String INVALID_DATE = "date";

    public static final String INVALID_DESCRIPTION = "Description";
    public static final String INVALID_DUE_DATE = "Due Date";
    public static final String INVALID_DOCUMENT_REQUIRED = "doc required";
    public static final String INVALID_FROM_DATE = "From Date";
    public static final String INVALID_TO_DATE = "To Date";
    public static final String INVALID_DURATION = "Duration";
    public static final String INVALID_REASON = "reason";
    public static final String INVALID_FIRST_NAME = "First Name";
    public static final String INVALID_LAST_NAME = "Last Name";
    public static final String INVALID_TITLE = "Title";
    public static final String INVALID_ID = "Applicant ID";
    public static final String INVALID_CHANNEL = "Channel";
    public static final String INVALID_FIRM_NAME = "Firm Name";
    public static final String INVALID_BROKER_NAME = "broker full name";
    public static final String INVALID_EMAIL_ID = "email id";
    public static final String INVALID_MOBILE_NO = "mobile no";
    public static final String INVALID_CASE_ID = "case Id";
    public static final String INVALID_EXCEPTION_ID="exception id";
    public static final String INVALID_DIP_ID = "dip Id";
    public static final String INVALID_DOCUMENT_IDENTIFIER = "document identifier";
    public static final String INVALID_CATEGORY = "category";
    public static final String INVALID_TIME_PERIOD = "time period";
    public static final String INVALID_OTHER_INFO = "other Info";
    public static final String INVALID_DOCUMENT = "document field";
    public static final String INVALID_NOTIFICATION_REQUIRED = "isNotificationRequired field";
    public static final String INVALID_REQUIRED_FOR = "requiredFor field";
    public static final String INVALID_REQUEST_ID = "request Id";
    public static final String INVALID_APPLICANT_NOTIFICATION = "isApplicantNotification field";
    public static final String INVALID_BROKER_NOTIFICATION = "isBrokerNotification field";

    public static final String INVALID_UPDATED_BY_FULLNAME = "updatedByFullName";
    public static final String INVALID_UPDATED_BY_RACFID = "updatedByRACFID";
    public static final String ALLOW_ONLY_ALPHABETS_AND_NUMBER_MAX_OF_FIFTY_CHAR = "^([A-Za-z0-9]){1,50}$";
    public static final String ALLOW_ONLY_ALPHABETS_AND_NUMBER_MAX_OF_THIRTY_SIX_CHAR = "^([A-Za-z0-9]){1,36}$";
    public static final String ALLOW_ONLY_UUID_MAX_OF_THIRTY_SIX_CHAR="^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$";
    public static final String REGEXP_ALLOW_UPDATE_STATUS_VALUE = "(Received|Error)";
    public static final String REGEXP_ALLOW_UPDATE_FI_STATUS_VALUE = "(CLOSED|PARTIALLY CLOSED|RECEIVED|REVIEWED|REMOVED|UPLOAD_SUCCESS|UPLOAD_FAILURE)";
    public static final String REGEXP_ALLOW_UPDATE_FI_STATE_VALUE = "(Open|Draft|Upload|Review|Error|Closed|PST_Review|PST_Review_Complete|MA_Review|MA_Review_Complete)";
    public static final String INVALID_STATUS = "status";
    public static final String INVALID_STATE = "state";
    public static final String ALLOW_UPDATE_STATUS_VALUE = "Received, Error";
    public static final String ALLOW_UPDATE_FI_STATUS_VALUE = "CLOSED,PARTIALLY CLOSED,RECEIVED,REVIEWED,REMOVED,UPLOAD_SUCCESS,UPLOAD_FAILURE";
    public static final String REQUESTED = "Requested";
    public static final String NOTIFICATION_REQUIRED_FIELD="notificationRequired";

    public static final String INVALID_CIN = "Cin";
    public static final String INVALID_APPLICANT_ID = "Applicant Id";
    public static final String INVALID_CLASSIFICATION_CODE = "classification code";
    public static final String INVALID_EMPLOYMENT_STATUS = "Employment Status";
    public static final String INVALID_EMPLOYER_STATUS = "Employer Status";
    public static final String INVALID_OCCUPATION_TYPE = "Occupation Type";
    public static final String INVALID_CONTRACT_PAYEFLAG = "Contract Payee Flag";
    public static final String INVALID_PERMANENT_INDICATOR = "Permanent Indicator";
    public static final String INVALID_INCOME_DECREASEIN5YRS = "Income Decrease In Five Years";
    public static final String INVALID_ANNUAL_GROSS_INCOME = "Annual Gross Income";
    public static final String INVALID_SELF_EMPLOYMENT_STATUS = "Self Employment Status";
    public static final String INVALID_BUSINESS_ESTABLISHMENT_DATE = "Business Establishment Date";
    public static final String INVALID_YEAR_ONE_REPORT = "Year One Profit";
    public static final String INVALID_YEAR_TWO_REPORT = "Year Two Profit";
    public static final String INVALID_YEAR_ONE_TURN_OVER = "Year One Turnover";
    public static final String INVALID_YEAR_TWO_TURN_OVER = "Year Two Turnover";
    public static final String INVALID_YEAR_ONE_DIRECTORY_SALARY = "Year One Director Salary";
    public static final String INVALID_YEAR_TWO_DIRECTORY_SALARY = "Year Two Director Salary";
    public static final String INVALID_EMPLOYMENT_START_DATE = "Employment Start Date";
    public static final String INVALID_YEAR_ONE_DIVIDENDS = "Year One Dividends";
    public static final String INVALID_YEAR_TWO_DIVIDENDS = "Year Two Dividends";
    public static final String INVALID_SOURCE_OF_INCOME = "Source Of Income";
    public static final String INVALID_OTHER_BENEFIT_INCOME = "Other Benefit Income Free Text";
    public static final String INVALID_OTHER_SOURCE_OF_INCOME = "Other Source Of Income Free Text";
    public static final String INVALID_BENEFIT_INCOME_OPTION = "Benefit Income Option";
    public static final String INVALID_OTHER_INCOME_FREQUENCY = "Other Income Frequency";
    public static final String INVALID_OTHER_INCOME_AMOUNT = "Other Income Amount";
    public static final String INVALID_PAYSLIP_FREQUENCY = "Payslip Frequency";
    public static final String INVALID_PAYSLIP_AMOUNT = "Payslip Amount";
    public static final String INVALID_START_DATE = "Employment Start Date";
    public static final String INVALID_INCOME_DECREASE_IN_5_YEARS = "Income Decrease in Five Years";
    public static final String INVALID_ANNUAL_GROSS_INCOME_ALLOWS_MAX_15_DIGIT = "Annual Gross Income";
    public static final String INVALID_VALUATION_RECEIVED = "Valuation received value";
    public static final String INVALID_VALUATION = "Valuation details";
    public static final String INVALID_VALUATION_TYPE = "Valuation type";
    public static final String INVALID_VALUATION_DATE = "Valuation date";
    public static final String INVALID_VALUATION_AMOUNT = "Valuation amount";
    public static final String INVALID_POD_RATING = "podRating";

    public static final String TASK_CREATED_MSG = "Task has been added successfully on {0} and Task Id is {1}";
    public static final String TASK_CLOSED_MSG = "Task has been closed successfully on ";

    public static final String CSP_VALUE = "default-src 'none'; script-src 'self'; connect-src 'self'; img-src 'self' data: http://www.w3.org/; font-src 'self'; style-src 'self' 'unsafe-inline';base-uri 'self';form-action 'self'";
    public static final String NO_CACHE = "no-cache";
    public static final String REQUEST_REMINDER_RESPONSE = "Reminder has been sent successfully for RequestID ";
    public static final String FI_STATUS_UPDATE_RESPONSE = "FI Status updated successfully";

    public static final String UNSUCCESSFUL_UPLOADS = "unsuccessfulUploads";

    public static final String TOKEN_EXPIRED = "token expired : please supply a valid authentication token";
    public static final String UTC_TIME_ZONE = "UTC";
    public static final String USER_PRINCIPAL_NOT_FOUND_SSO_NOT_ENABLED = "UserPrincipal not found. SSO not enabled";

    public static final String BUSINESS_ESTABLISHMENT_DATE = "businessEstablishmentDate";
    public static final String EMPLOYMENT_START_DATE = "employmentStartDate";
    public static final String RECEIVED = "received";
    public static final String AMOUNT = "amount";
    public static final String VALUATION= "valuation";
    public static final String PROPERTY_DETAILS= "PropertyDetails";
    public static final String VALUATION_TYPE= "valuation.type";
    public static final String VALUATION_DATE= "valuation.date";
    public static final String VALUATION_AMOUNT = "valuation.amount";

    public static final String NOT_FOUND_REQUESTED_ROUTE = "404 Not Found: Requested route";

    public static final String INVALID_BROKER_EMAIL_ID = "broker email id";
    public static final String INVALID_BROKER_MOBILE_NO = "broker mobile number";
    public static final String INVALID_APPLICANT_EMAIL_ID = "applicant email id";
    public static final String INVALID_APPLICANT_MOBILE_NO = "applicant mobile number";
    public static final String INVALID_MAIN_APPLICANT = "mainApplicant field";
    public static final String MAIN_APPLICANT = "mainApplicant";

    public static final String SUCCESS = "Success";
    public static final String FAILURE = "Failure";
    public static final String PREFIX = "111";
    public static final String INVALID_DOC_UPLOAD = "document";
    public static final String INVALID_DOCUMENT_TYPE = "document type";
    public static final String INVALID_LOAN_PURPOSE = "loan purpose";
    public static final String APPLICATION_ID_TYPE = "applicationIdType";
    public static final String REQUEST_ID_TYPE = "requestTypeId";
    public static final String DOCUMENT_USER_CLASSIFICATION = "documentUserClassification";
    public static final String LOAN_PURPOSE = "loanPurpose";

    public static final String INVALID_SOURCE_NAME = "source name";
    public static final String INVALID_SOURCE_RACF_ID = "source racfId";
    public static final String INVALID_SOURCE_EMAIL_ID = "source email id";
    public static final String INVALID_PRIMARY_ADVISOR_RACF_ID = "primary advisor racfId";
    public static final String INVALID_ADVISOR = "advisor";
    public static final String INVALID_LEAD_ADVISOR = "lead advisor";
    public static final String INVALID_PRIMARY = "primary field";
    public static final String PRIMARY = "primary";
    public static final String MORTGAGE_ADVISED = "mortgageAdvised";
    public static final String INVALID_MORTGAGE_ADVISED = "mortgageAdvised field";
    public static final String WHEN_BUILT = "/whenBuilt";
    public static final String WHEN_BUILT_FORMAT = "%s-01-01";
    public static final String BRAND_RBS = "RBS";
    public static final String BRAND_NWB = "NWB";
    public static final String CHANNEL_INTERMEDIARY = "INTERMEDIARY";
    public static final String CHANNEL_BRANCH = "BRANCH";
    public static final String FI_DOCUMENT_IDENTIFIER = "FI";

    public static final String INVALID_DOCUMENT_ID = "document id";
    public static final String INVALID_DOCUMENT_STATUS = "document status";
    public static final String INVALID_CLASSIFICATION = "classification";
    public static final String REGEXP_ALLOW_DOCUMENT_CLASSIFICATION_VALUE = "(INCOME|EXPENDITURE|UNCLASSIFIED|EXCEPTION)";
    public static final String INVALID_ORIGINAL_NAME = "original file name";
    public static final String INVALID_DATETIME = "date time";

    public static final String JWT_UTILITY = "jwtutility";
    public static final String DOCUMENT_INFO_DATE_TIME = "yyyy-MM-dd'T'HH:mm:ss.SSS";
    public static final String SPACE_DELIMITER = " ";
    public static final String INVALID_LEAD_GENERATOR = "lead generator";
    public static final String INVALID_APPLICATION_TYPE = "applicationType";
    public static final String INVALID_PURPOSE= "purpose";
    public static final String INVALID_REREQUEST_REASON= "reRequestReason";
    public static final String INVALID_FI_TYPE = "Fi Type";
    public static final String REGEXP_ALLOWED_FI_TYPE_VALUE = "(Document|Text)";
    public static final String INVALID_CUSTOMER_RESPONSE = "response";
    public static final String NO_REFERRER = "no-referrer";
    public static final String X_XSS_PROTECTION_VALUE = "0";
    public static final String INVALID_APPLICATION_CASEOWNER = "application owner";
    public static final String INVALID_CASE_OWNER = "caseOwner";
    public static final String DOCUMENT_TYPE = "documentType";
    public static final String REGEXP_ALLOW_DOC_TYPE_VALUE = "(OTHER|EECOT|FMAMAF|SUITCP|EKYC|VALREP)";
    public static final String REGEXP_ALLOW_LOAN_PURPOSE_VALUE = "(ADDITIONAL_BORROWING|HOUSE_PURCHASE|REMORTGAGE)";
    public static final String INVALID_CALLER_INFO = "caller info";
    public static final String INVALID_CALL_REASON = "call reason";

    public static final String INVALID_ADDITIONAL_INFO = "additionalInfo";
    public static final String APPLICATION_TYPE_FMA = "FMA";

    private ApplicationConstants() {
    }
}
