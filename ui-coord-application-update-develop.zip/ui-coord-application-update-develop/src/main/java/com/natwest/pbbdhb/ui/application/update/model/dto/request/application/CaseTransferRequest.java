package com.natwest.pbbdhb.ui.application.update.model.dto.request.application;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import javax.validation.constraints.Size;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.*;


/**
 * CaseTransfer API Request
 */
@Data
@Schema(description = "CaseTransfer Request Object")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Validated
@Valid
public class CaseTransferRequest {
    @Valid
    @Parameter(description = "note")
    @Size(min = 1, max = 3500, message = INVALID_NOTE)
    private String note;
}