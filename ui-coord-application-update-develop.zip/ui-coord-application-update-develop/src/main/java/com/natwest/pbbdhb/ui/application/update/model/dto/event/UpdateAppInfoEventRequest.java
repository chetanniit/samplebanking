package com.natwest.pbbdhb.ui.application.update.model.dto.event;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * UpdateAppInfoEventRequest object used for CaseInfoUpdateEvent listener
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UpdateAppInfoEventRequest {
    private String brand;
    private String caseId;
    private String racfId;
    private String primaryAdvisorRacfId;
    private String applicationType;
    private String advisor;
    private String leadAdvisor;
    private String leadGenerator;
    private String brokerEmail;
}
