package com.natwest.pbbdhb.ui.application.update.service;

import com.natwest.pbbdhb.income.expense.model.domain.CaseStatusDto;
import com.natwest.pbbdhb.income.expense.model.expense.request.CaseExpenseDto;
import com.natwest.pbbdhb.income.expense.model.expense.response.ValidatedCaseExpenseDto;
import com.natwest.pbbdhb.income.expense.model.income.request.CaseIncomeDto;
import com.natwest.pbbdhb.income.expense.model.income.response.ValidatedCaseIncomeDto;

import javax.json.JsonPatch;

/**
 * This service is used to call the Income and Expense service endPoint of CAPIE service
 */
public interface IncomeExpenseService {

    /**
     * This method is used to save and update income information based on caseId
     *
     * @param brand        - allowed values NWB/RBS
     * @param caseId  - String caseId
     * @param request - CaseIncomeDto object
     * @return - return ValidatedCaseIncomeDto object
     */
    ValidatedCaseIncomeDto saveAndValidateIncomeData(String brand, String caseId, CaseIncomeDto request);

    /**
     * This method is used to call income patch end point to validate income information based on caseId
     *
     * @param brand        - allowed values NWB/RBS
     * @param caseId  - String caseId
     * @param request - CaseIncomeDto object
     * @return - return ValidatedCaseIncomeDto object
     */
    ValidatedCaseIncomeDto markIncomeValidated(String brand, String caseId, CaseStatusDto request);

    /**
     * This method is used to save and update expense information based on caseId
     *
     * @param brand        - allowed values NWB/RBS
     * @param caseId  - String caseId
     * @param request - CaseExpenseDto object
     * @return - return ValidatedCaseExpenseDto object
     */
    ValidatedCaseExpenseDto saveAndValidateExpenseData(String brand, String caseId, CaseExpenseDto request);

    /**
     * This method is used to update the expense data validation status
     *
     * @param brand - possible values RBS/NWB
     * @param caseId - caseId String
     * @param request - input Object
     * @return ValidatedCaseExpenseDto - response
     */
    ValidatedCaseExpenseDto markExpenseValidated(String brand,String caseId, CaseStatusDto request);
}
