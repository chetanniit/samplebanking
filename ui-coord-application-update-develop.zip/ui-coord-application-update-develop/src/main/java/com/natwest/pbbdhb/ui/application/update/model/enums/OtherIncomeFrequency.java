package com.natwest.pbbdhb.ui.application.update.model.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum OtherIncomeFrequency {
    WEEKLY,
    FORTNIGHTLY,
    MONTHLY,
    FOUR_WEEKLY,
    QUARTERLY,
    HALF_YEAR,
    ANNUALLY

}
