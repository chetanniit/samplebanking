package com.natwest.pbbdhb.ui.application.update.validator.format;


import com.natwest.pbbdhb.ui.application.update.validator.ISODateTimeFormatValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.INVALID_DATE_TIME;


/**
 * This interface is to validate DateTime format
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD, ElementType.PARAMETER})
@Constraint(validatedBy = ISODateTimeFormatValidator.class)
public @interface ISODateTimeConstraint {

    /**
     * return error message
     *
     * @return String
     */
    String message() default INVALID_DATE_TIME;

    /**
     * return boolean
     *
     * @return boolean
     */
    boolean required() default false;

    /**
     * return object
     *
     * @return Class
     */
    Class<?>[] groups() default {};

    /**
     * return object
     *
     * @return class
     */
    Class<? extends Payload>[] payload() default {};
}
