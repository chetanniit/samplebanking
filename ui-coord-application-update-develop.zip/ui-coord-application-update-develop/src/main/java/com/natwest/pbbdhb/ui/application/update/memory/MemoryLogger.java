package com.natwest.pbbdhb.ui.application.update.memory;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * Util to log VM memory
 */
@ConditionalOnExpression("${log.memory.enabled:false}")
@Slf4j
@Component
public class MemoryLogger {

    private static final int MEGABYTES = 10241024;

    /**
     * logs the memory based on cron
     */
    @Scheduled(cron = "${log.memory.heap.cron.expression:* * 0/1 * * ?}")
    public void printMemory() {
        long totalMemory = Runtime.getRuntime().totalMemory() / MEGABYTES;
        long freeMemory = Runtime.getRuntime().freeMemory() / MEGABYTES;
        long usedMemory = totalMemory - freeMemory;
        long maxMemory = Runtime.getRuntime().maxMemory() / MEGABYTES;
        log.info("total: {}, free: {}, used: {}, max: {}", totalMemory, freeMemory, usedMemory, maxMemory);
    }

}
