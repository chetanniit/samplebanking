package com.natwest.pbbdhb.ui.application.update.model.dto.request;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import javax.validation.constraints.Size;

import java.util.List;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.INVALID_CUSTOMER_RESPONSE;
import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.INVALID_NOTE;

/**
 * FIStatusRequest class is the request for /updateFIState endpoint
 * and validation for all the fields are captured here
 */
@Data
@Schema(description = "update FI Status Object")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Validated
@Valid
public class FIStatusRequest {


    @Valid
    @Parameter(description = "note")
    @Size(min = 1, max = 4000, message = INVALID_NOTE)
    private String note;

    @Valid
    @Parameter(description = "Document Info")
    private List<DocumentInfo> documentInfo;

    @Valid
    @Parameter(description = "customerResponse")
    @Size(min = 1, max = 1000, message = INVALID_CUSTOMER_RESPONSE)
    private String customerResponse;
}
