package com.natwest.pbbdhb.ui.application.update.model.dto.request.firequest;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.ALLOW_ONLY_ALPHABETS_NUMBER_AND_SPACE_MAX_OF_FIFTY_CHAR;
import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.INVALID_ID;

/**
 * DocumentFor class is the used as request for /requestFI endpoint
 * and validation for all the fields are captured here
 */
@Data
@Schema(description = "Add DocumentFor Object")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Validated
@Valid
public class DocumentFor {

    @Valid
    @Parameter(description = "ApplicantID")
    @Pattern(regexp = ALLOW_ONLY_ALPHABETS_NUMBER_AND_SPACE_MAX_OF_FIFTY_CHAR, message = INVALID_ID)
    @NotNull(message = INVALID_ID)
    private String applicantId;
}
