package com.natwest.pbbdhb.ui.application.update.model.dto.request.flowmanager;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * FlowManagerDocumentNotesRequest class is the request
 * for downstream document notes endpoint
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FlowManagerDocumentNotesRequest {

    private String referenceNumber;
    private String caseId;
    private String userFullName;
    private String userRACFId;
    private String requestId;
    private String note;
    private boolean skipPrefix;
}
