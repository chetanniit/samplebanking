package com.natwest.pbbdhb.ui.application.update.model.dto.exception;

/**
 * Class to map the details when ClosedTaskException occurs
 */
public class ClosedTaskException extends RuntimeException {

    private static final long serialVersionUID = 4720769207559339746L;
    /**
     * Constructor to set the value for message
     * @param message - Error message
     */
    public ClosedTaskException(String message) {
        super(message);
    }
}
