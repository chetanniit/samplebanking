package com.natwest.pbbdhb.ui.application.update.util;

import com.natwest.pbbdhb.ui.application.update.controller.UserDetailsController;
import com.natwest.pbbdhb.ui.application.update.model.dto.exception.ResourceNotFoundException;
import com.natwest.pbbdhb.ui.application.update.model.dto.exception.UserNotAuthorizedException;
import com.natwest.pbbdhb.ui.application.update.model.dto.exception.UserNotValidException;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.TaskRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.userinformation.UserInformationResponse;
import com.natwest.pbbdhb.ui.application.update.service.MockDataLoader;
import lombok.extern.slf4j.Slf4j;
import org.springframework.hateoas.Link;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.util.UriComponentsBuilder;

import javax.json.JsonPatch;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Stream;

import static com.natwest.pbbdhb.ui.application.update.converter.JsonPatchHttpMessageConverter.JSON_PATCH;
import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.*;
import static com.natwest.pbbdhb.ui.application.update.util.ErrorConstant.*;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

/**
 * This class contains common methods used across service
 */
@Slf4j
@Component
public class ApplicationUtil {

    private static final String EXCEPTION_WHILE_FORMATTING_THE_DATE = "Exception while formatting the date: {}";

    private ApplicationUtil() {
    }

    /**
     * This method is to parse date in the format yyyy-MM-dd
     *
     * @param dateStr - Date string as input
     * @return Date
     * @throws ParseException - Date parse exception
     */
    public static Date parseDate(String dateStr) throws ParseException {
        if (Objects.isNull(dateStr)) {
            return null;
        }
        DateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT_YYYY_MM_DD);
        return dateFormat.parse(dateStr);
    }

    /**
     * This method is to parse the date string to dateTime format
     *
     * @param dateStr - Date string as input
     * @return Date
     * @throws ParseException - Date parse exception
     */
    public static Date parseDateTime(String dateStr) throws ParseException {
        DateFormat dateTimeFormat = new SimpleDateFormat(DATE_TIME_FORMAT);
        dateTimeFormat.setTimeZone(TimeZone.getTimeZone(UK_TIME_ZONE));
        if (dateStr == null || dateStr.isEmpty()) {
            Date date = new Date();
            return dateTimeFormat.parse(dateTimeFormat.format(date));
        } else {
            return dateTimeFormat.parse(dateStr);
        }
    }


    /**
     * This method is to validate date format and the given date is not in the past
     *
     * @param dateStr - Date string
     * @return boolean
     */
    public static boolean isValidDateTime(String dateStr) {
        if (Objects.isNull(dateStr)) {
            return true;
        }

        DateFormat sdf = new SimpleDateFormat(DATE_TIME_FORMAT);
        sdf.setLenient(false);
        boolean isAfter = false;

        try {
            DateTimeFormatter dateFormatter = new DateTimeFormatterBuilder().parseCaseInsensitive()
                    .appendPattern(ApplicationConstants.DATE_TIME_FORMAT)
                    .toFormatter();
            LocalDate localDate = LocalDate.parse(dateStr, dateFormatter);
            LocalDate today = LocalDate.now(ZoneId.of(UK_TIME_ZONE));
            isAfter = (localDate.isAfter(today) || localDate.isEqual(today));
        } catch (DateTimeParseException e) {
            log.error("Exception while formatting the date : ", e);
            return false;
        }
        return (Pattern.compile(DATE_TIME_PATTERN).matcher(dateStr).matches()) && isAfter;
    }

    /**
     * This method is to validate date format
     * @param dateStr - dateStr
     * @return true if valid, otherwise false
     */
    public static boolean isValidISODateTime(String dateStr) {
        if (Objects.isNull(dateStr)) {
            return true;
        }
        DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
        try {
            LocalDateTime.parse(dateStr, formatter);
        } catch (DateTimeParseException e) {
            log.error(EXCEPTION_WHILE_FORMATTING_THE_DATE, dateStr, e);
            return false;
        }
        return (Pattern.compile(ISO_DATE_TIME_PATTERN).matcher(dateStr).matches());
    }

    /**
     * /**
     * This method is to validate date format and the given date is not in the past
     *
     * @param dateStr - date as string
     * @return boolean
     */
    public static boolean isValidDateInFuture(String dateStr) {
        if (Objects.isNull(dateStr)) {
            return true;
        }
        DateFormat sdf = new SimpleDateFormat(DATE_FORMAT_YYYY_MM_DD);
        sdf.setLenient(false);
        boolean isAfter = false;

        try {
            DateTimeFormatter dateFormatter = new DateTimeFormatterBuilder().parseCaseInsensitive()
                    .appendPattern(DATE_FORMAT_YYYY_MM_DD)
                    .toFormatter();
            LocalDate localDate = LocalDate.parse(dateStr, dateFormatter);
            LocalDate today = LocalDate.now(ZoneId.of(UK_TIME_ZONE));
            isAfter = (localDate.isAfter(today) || localDate.isEqual(today));
        } catch (DateTimeParseException ex) {
            log.error("Exception while formatting the date :{}", ex);
            return false;
        }
        return (Pattern.compile(DATE_PATTERN).matcher(dateStr).matches()) && isAfter;
    }

    /**
     * This method is to mock and throw exception for create/close task and add note.
     * This will be removed once the actual service is available
     *
     * @param referenceNumber - reference number
     * @param racfId          - operator racfId
     * @param mockDataLoader  - MockDataLoader
     */
    public static void throwUpdateFailureException(String referenceNumber, String racfId, MockDataLoader mockDataLoader) {
        if (mockDataLoader.getInvalidReferenceNumber().contains(referenceNumber)) {
            throw new ResourceNotFoundException(ERROR_CODE_404_RECORD_NOT_FOUND);
        } else if (mockDataLoader.getNotValidUser().contains(racfId)) {
            throw new UserNotValidException(ERROR_CODE_404_USER_NOT_VALID);
        } else if (mockDataLoader.getNotAuthorizedUser().contains(racfId)) {
            throw new UserNotAuthorizedException(ERROR_CODE_403_USER_NOT_AUTHORISED);
        }
    }

    /**
     * This method is to validate given date format
     *
     * @param dateStr - date as string
     * @return boolean
     */
    public static boolean isValidDate(String dateStr) {
        if (Objects.isNull(dateStr)) {
            return true;
        }
        DateFormat sdf = new SimpleDateFormat(DATE_FORMAT_YYYY_MM_DD);
        sdf.setLenient(false);
        try {
            sdf.parse(dateStr);
        } catch (ParseException ex) {
            log.error("Exception while formatting the date :{}", ex);
            return false;
        }
        return (Pattern.compile(DATE_PATTERN).matcher(dateStr).matches());
    }

    /**
     * This method is to validate Reason to create note is available
     *
     * @param taskRequest - Task request as input
     * @return boolean
     */
    public static boolean validateTaskNoteRequest(TaskRequest taskRequest) {
        boolean noteReasonRequired = false;
        boolean noteRequestAvailable = (Stream.of(taskRequest.getDescription(), taskRequest.getDocumentRequired(),
                        taskRequest.getDueDate(), taskRequest.getDuration(), taskRequest.getFromDate(),
                        taskRequest.getToDate(), taskRequest.getRequiredFor())
                .anyMatch(Objects::nonNull));

        if ((taskRequest.getReason() != null) || (!noteRequestAvailable && taskRequest.getReason() == null))
            noteReasonRequired = true;
        log.info("noteRequestAvailable : {}, noteReasonRequired : {}", noteRequestAvailable, noteReasonRequired);
        return noteReasonRequired;
    }

    /**
     * method to check email validation
     *
     * @param email - input email
     * @return - boolean
     */
    public static boolean isValidEmail(String email) {
        return Objects.isNull(email) || (Pattern.compile(EMAIL_PATTERN).matcher(email).matches() && email.length() <= 320);
    }

    public static File convert(MultipartFile file) throws IOException {
        File convertedFile = new File(file.getOriginalFilename());
        boolean isNewFileCreated = convertedFile.createNewFile();
        if (!isNewFileCreated) {
            log.error("New file creation failed");
        }
        try (FileOutputStream fos = new FileOutputStream(convertedFile)) {
            fos.write(file.getBytes());
        }
        return convertedFile;
    }

    public static void populateHATEOASLink(UserInformationResponse applicationDetailsResponse) {
        if (Objects.nonNull(applicationDetailsResponse) && applicationDetailsResponse.getLinks().isEmpty()) {
            UriComponentsBuilder link = linkTo(methodOn(UserDetailsController.class)
                    .getUserDetails())
                    .toUriComponentsBuilder();
            applicationDetailsResponse.add(Link.of(link.build().toUriString()).withSelfRel());
        }
    }

    /**
     * method to construct UriComponentsBuilder
     *
     * @param caseId - String caseId
     * @param endpoint - String endpoint
     * @return - UriComponentsBuilder object
     */
    public static UriComponentsBuilder getUriComponentsBuilder(String caseId, String endpoint) {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(endpoint);

        Map<String, Object> urlParams = new HashMap<>();
        urlParams.put("caseId", caseId);
        builder.uriVariables(urlParams);
        log.debug("URL : {} ", builder.toUriString());
        return builder;
    }

    /**
     * method to get http header
     *
     * @param jsonPatch - JsonPatch object
     * @param brand - String brand
     * @return - HttpEntity
     */
    public static HttpEntity<JsonPatch> getHeader(JsonPatch jsonPatch, String brand) {
        HttpHeaders header = new HttpHeaders();
        header.add(CONTENT_TYPE, JSON_PATCH);
        header.add(BRAND, brand);
        HttpEntity<JsonPatch> entity = new HttpEntity<>(jsonPatch, header);
        log.info("header set for downstream call: {}", header);
        return entity;
    }

}
