package com.natwest.pbbdhb.ui.application.update.configuration;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.util.List;

@Configuration
public class WebConfiguration {

    @Value("${cors.allowed-origin-patterns:*.rbsgrp.net,*.banksvcs.net}")
    private List<String> allowedOriginPatterns;

    @Value("${cors.allowed-origins:}")
    private List<String> allowedOrigins;

    @Value("${cors.allowed-methods:}")
    private List<String> allowedMethods;

    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                CorsRegistration corsRegistration = registry.addMapping("/**");
                if (CollectionUtils.isNotEmpty(allowedOriginPatterns)) {
                    String[] patterns = allowedOriginPatterns.toArray(new String[0]);
                    corsRegistration.allowedOriginPatterns(patterns);
                }
                if (CollectionUtils.isNotEmpty(allowedOrigins)) {
                    String[] origins = allowedOrigins.toArray(new String[0]);
                    corsRegistration.allowedOrigins(origins);
                }
                if (CollectionUtils.isNotEmpty(allowedMethods)) {
                    String[] methods = allowedMethods.toArray(new String[0]);
                    corsRegistration.allowedMethods(methods);
                }
            }
        };

    }
}

