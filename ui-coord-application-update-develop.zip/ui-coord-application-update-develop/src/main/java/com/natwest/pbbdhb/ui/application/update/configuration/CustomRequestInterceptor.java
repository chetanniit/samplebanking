package com.natwest.pbbdhb.ui.application.update.configuration;

import java.io.IOException;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CustomRequestInterceptor implements ClientHttpRequestInterceptor {

    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution)
            throws IOException {
        ClientHttpResponse response = execution.execute(request, body);
        
        log.info("content length : "+request.getHeaders().getContentLength());
        
        if (response.getHeaders().containsKey(HttpHeaders.TRANSFER_ENCODING))
            response.getHeaders().remove(HttpHeaders.TRANSFER_ENCODING);
        
        return response;
    }

}
