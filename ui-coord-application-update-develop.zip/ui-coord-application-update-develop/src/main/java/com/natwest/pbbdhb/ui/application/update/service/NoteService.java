package com.natwest.pbbdhb.ui.application.update.service;

import com.natwest.pbbdhb.ui.application.update.model.dto.request.NoteRequest;

import java.text.ParseException;

/**
 * service is used by /addNote endpoint and contains methods related to task note
 */
public interface NoteService {
    /**
     * method is used for adding Note for a particular task
     * @param brand - brand could be NWB/RBS
     * @param noteRequest - Note request
     * @return - String
     * @throws ParseException - throws parse exception during date conversion
     */
    String addNote(String brand, NoteRequest noteRequest) throws ParseException;
}
