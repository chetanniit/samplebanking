package com.natwest.pbbdhb.ui.application.update.service;

import com.natwest.pbbdhb.ui.application.update.model.dto.response.BasicPackagingDocumentResponse;
import org.springframework.http.ResponseEntity;

/**
 * Methods related to basic packaging API
 */
public interface BasicPackagingService {

    /**
     * Method to retrieve basic packaging from requiredDocs API and store into PM
     *
     * @param brand  - brand
     * @param caseId - caseId
     * @return BasicPackagingDocumentResponse object
     */
    ResponseEntity<BasicPackagingDocumentResponse> addBasicPackagingRequests(String brand, String caseId);
}
