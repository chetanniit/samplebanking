package com.natwest.pbbdhb.ui.application.update.model.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum EmployementStatus {
    EMPLOYED,
    SELF_EMPLOYED,
    CONTRACTOR,
    HOMEMAKER,
    RETIRED,
    STUDENT,
    NOT_IN_EMPLOYMENT

}
