package com.natwest.pbbdhb.ui.application.update.model.dto.request.document;

import com.natwest.pbbdhb.ui.application.update.model.dto.enums.DocumentType;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.*;

@Data
@Schema(description = "Document upload request")
@AllArgsConstructor
@NoArgsConstructor
@Validated
@Builder
public class DocumentUploadRequest {

    @Valid
    @NotNull(message = INVALID_DOC_UPLOAD)
    @Parameter(description = "Document to be upload")
    private MultipartFile file;

    @Valid
    @NotNull(message = INVALID_CHANNEL)
    @Schema(implementation = Channel.class)
    private Channel Channel;

    @Valid
    @NotNull(message = INVALID_DOCUMENT_TYPE)
    @Parameter(description = "DocumentType")
    @Pattern(regexp = REGEXP_ALLOW_DOC_TYPE_VALUE, message = INVALID_DOCUMENT_TYPE)
    @Schema(type = "String", defaultValue = "OTHER", allowableValues = {"OTHER", "EECOT", "FMAMAF", "SUITCP", "EKYC", "VALREP"})
    private String documentType;
}
