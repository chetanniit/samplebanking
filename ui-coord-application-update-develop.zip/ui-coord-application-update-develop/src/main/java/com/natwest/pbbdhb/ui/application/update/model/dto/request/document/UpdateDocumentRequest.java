package com.natwest.pbbdhb.ui.application.update.model.dto.request.document;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.*;

/**
 * UpdateDocumentRequest class is the request for /updateDocumentStatus endpoint
 * and validation for all the fields are captured here
 */
@Data
@Schema(description = "Update Document Request")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Validated
@Valid
public class UpdateDocumentRequest {

    @Valid
    @Parameter(required = true, description = "Reference Number")
    @Pattern(regexp = ALLOW_ONLY_NUMBERS_AND_MAX_OF_TEN_DIGITS, message = INVALID_REFERENCE_NUMBER)
    @NotNull(message = INVALID_REFERENCE_NUMBER)
    private String referenceNumber;

    @Valid
    @Parameter(required = true, description = "Sequence Number")
    @Pattern(regexp = ALLOW_ONLY_NUMBERS_AND_MAX_OF_TWO_DIGITS, message = INVALID_SEQUENCE_ID)
    @NotNull(message = INVALID_SEQUENCE_ID)
    private String sequenceNumber;

    @Valid
    @Parameter(required = true, description = "updatedBy FullName")
    @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_SPACE_MAX_OF_FIFTY_CHAR, message = INVALID_UPDATED_BY_FULLNAME)
    @NotNull(message = INVALID_UPDATED_BY_FULLNAME)
    private String updatedByFullName;

    @Valid
    @Parameter(required = true, description = "updatedBy RACFId")
    @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_MAX_OF_10_DIGITS, message = INVALID_UPDATED_BY_RACFID)
    @NotNull(message = INVALID_UPDATED_BY_RACFID)
    private String updatedByRACFID;

    @Valid
    @Parameter(required = true, description = "request ID")
    @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_NUMBER_MAX_OF_FIFTY_CHAR, message = INVALID_REQUEST_ID)
    private String requestId;

    @Valid
    @Pattern(regexp = REGEXP_ALLOW_UPDATE_STATUS_VALUE, message = INVALID_STATUS)
    @Parameter(required = true, description = "status", schema = @Schema(type = "string", defaultValue = "Requested", allowableValues = {"Received", "Error"}))
    private String status;
}
