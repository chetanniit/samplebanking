package com.natwest.pbbdhb.ui.application.update.model.dto.request.incomerequest;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.natwest.pbbdhb.ui.application.update.model.enums.BenefitIncomeOption;
import com.natwest.pbbdhb.ui.application.update.model.enums.OtherIncomeFrequency;
import com.natwest.pbbdhb.ui.application.update.model.enums.SourceOfIncome;
import com.natwest.pbbdhb.ui.application.update.validator.format.ValidateEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;
import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import java.math.BigDecimal;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.*;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@Validated
public class OtherIncomeDetails {

    @ValidateEnum(enumClass = SourceOfIncome.class, message = INVALID_SOURCE_OF_INCOME)
    @NotBlank(message = INVALID_SOURCE_OF_INCOME)
    private String sourceOfIncome;

    @Length(max = 200,message = INVALID_OTHER_SOURCE_OF_INCOME)
    private String otherSourceOfIncomeFreeText;

    @ValidateEnum(enumClass = BenefitIncomeOption.class, message = INVALID_BENEFIT_INCOME_OPTION)
    private String benefitIncomeOption;

    @Length(max = 200, message = INVALID_OTHER_BENEFIT_INCOME)
    private String otherBenefitIncomeFreeText;

    @ValidateEnum(enumClass = OtherIncomeFrequency.class, message = INVALID_OTHER_INCOME_FREQUENCY)
    private String otherIncomeFrequency;

    @Digits(integer = 15, fraction = 2, message = INVALID_OTHER_INCOME_AMOUNT)
    @Min(0)
    private BigDecimal otherIncomeAmount;
}
