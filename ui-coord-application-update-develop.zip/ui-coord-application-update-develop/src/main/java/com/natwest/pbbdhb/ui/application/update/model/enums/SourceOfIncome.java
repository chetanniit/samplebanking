package com.natwest.pbbdhb.ui.application.update.model.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum SourceOfIncome {
    PENSION_STATE,
    OVERTIME_GUARANTEED,
    OVERTIME_REGULAR,
    BONUS_DISCRETIONARY,
    BONUS_GUARANTEED,
    SHIFT_ALLOWANCE_REGULAR,
    CAR_ALLOWANCE,
    CHILD_MAINTENANCE,
    SECOND_JOB,
    RENTAL_INCOME,
    COMMISSION_REGULAR,
    BENEFIT_INCOME,
    OTHER

}
