package com.natwest.pbbdhb.ui.application.update.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.datatype.jsr353.JSR353Module;
import com.natwest.pbbdhb.applicant.dto.ApplicantDto;
import com.natwest.pbbdhb.applicant.dto.PersonTelephoneDto;
import com.natwest.pbbdhb.commondictionaries.enums.applicant.TelephoneType;
import com.natwest.pbbdhb.ui.application.update.events.ApplicantInfoUpdateEvent;
import com.natwest.pbbdhb.ui.application.update.service.ApplicantService;
import lombok.extern.slf4j.Slf4j;
import lombok.var;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import javax.json.JsonArray;
import javax.json.JsonPatch;
import javax.json.JsonStructure;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Collections;

import static com.natwest.pbbdhb.ui.application.update.converter.JsonPatchHttpMessageConverter.JSON_PATCH;
import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.APPLICATION_JSON;
import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.BRAND;
import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.CONTENT_TYPE;

/**
 * This service is used to call the applicants endPoint of CAPIE service
 */
@Service
@Slf4j
public class ApplicantServiceImpl implements ApplicantService {

    @Autowired
    @Qualifier("customSecureRestTemplate")
    private RestTemplate restTemplate;

    @Autowired
    private ApplicationEventPublisher eventPublisher;


    @Autowired
    private ObjectMapper jsr353Mapper;

    @Value("${msvc.applicant.parent.endpoint:}")
    private String msvcApplicantParentEndpoint;

    @Value("${msvc.applicant.applicants.endpoint:}")
    private String msvcApplicantApplicantsEndpoint;

    @Value("${msvc.applicant.applicants.patch.endpoint:}")
    private String msvcApplicantApplicantsPatchEndpoint;

    @Value("#{'${applicant.info.update.allowed.fields:}'.split(',')}")
    private List<String> applicantInfoUpdateAllowedFields;


    /**
     * This method is used to update applicant information based on applicantId
     *
     * @param brand        - allowed values NWB/RBS
     * @param applicantId  - String applicantId
     * @param applicantDto - ApplicantDto applicantDto object
     * @return - return ApplicantDto object
     */
    @Override
    public ResponseEntity<ApplicantDto> updateApplicants(String brand, String applicantId, ApplicantDto applicantDto) {
        log.debug("getApplicants method entered in ApplicantServiceImpl class brand: {}, applicantId: {} ", brand, applicantId);
        ResponseEntity<ApplicantDto> response;
        String endpoint = msvcApplicantParentEndpoint + msvcApplicantApplicantsEndpoint;
        UriComponentsBuilder builder = getUriComponentsBuilder(applicantId, endpoint);
        response = getApiResponse(brand, builder, applicantDto);
        return response;
    }

    private UriComponentsBuilder getUriComponentsBuilder(String applicantId, String endpoint) {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(endpoint);

        Map<String, Object> urlParams = new HashMap<>();
        urlParams.put("applicantId", applicantId);
        builder.uriVariables(urlParams);
        log.debug("URL : {} ", builder.toUriString());
        return builder;
    }

    private ResponseEntity<ApplicantDto> getApiResponse(String brand, UriComponentsBuilder builder, ApplicantDto applicantDto) {
        return restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.PUT, getHeader(applicantDto, brand), ApplicantDto.class);
    }

    private HttpEntity<ApplicantDto> getHeader(ApplicantDto applicantDto, String brand) {
        HttpHeaders header = new HttpHeaders();
        header.add(CONTENT_TYPE, APPLICATION_JSON);
        header.add(BRAND, brand);
        HttpEntity<ApplicantDto> entity = new HttpEntity<>(applicantDto, header);
        log.info("header set for downstream call: {}", header);
        return entity;
    }

    /**
     * This method is use to update partial applicant information by making call to patch endpoint of msvc-applicant service
     *
     * @param brand       - Possible values NWB/RBS
     * @param caseId      - caseId String
     * @param applicantId - applicantId String
     * @param jsonPatch   - jsonPatch request
     * @return ApplicantDto - response
     */
    @Override
    public ApplicantDto patchApplicantUpdate(String brand, String caseId, String applicantId, JsonPatch jsonPatch) {
        log.info("patchApplicantUpdate method enters in ApplicantServiceImpl class");
        String endpoint = msvcApplicantParentEndpoint + msvcApplicantApplicantsPatchEndpoint;
        UriComponentsBuilder builder = getUriComponentsBuilder(applicantId, endpoint);
        ResponseEntity<ApplicantDto> response = getPatchApplicantApiResponse(brand, builder, jsonPatch);
        if (response.getStatusCode().equals(HttpStatus.OK) && isDbUpdateNeeded(jsonPatch, applicantInfoUpdateAllowedFields))
            doApplicantInfoUpdate(brand, jsonPatch, response.getBody());
        return response.getBody();
    }

    /**
     * This method is used to make call to msvc-applicant service
     *
     * @param brand     - Possible values NWB/RBS
     * @param builder   - builder object
     * @param jsonPatch - jsonPatch request
     * @return ApplicantDto - response
     */
    private ResponseEntity<ApplicantDto> getPatchApplicantApiResponse(String brand, UriComponentsBuilder builder, JsonPatch jsonPatch) {
        log.info("getPatchApplicantApiResponse method enters in ApplicantServiceImpl class");
        return restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.PATCH, getHeaderForPatchRequest(jsonPatch, brand), ApplicantDto.class);
    }

    /**
     * This method is used to construct header for the request
     *
     * @param jsonPatch - request
     * @param brand     - possible values RBS/NWB
     * @return HttpEntity - response
     */
    private HttpEntity<JsonPatch> getHeaderForPatchRequest(JsonPatch jsonPatch, String brand) {
        log.info("getHeaderForPatchRequest method enters in ApplicantServiceImpl class");
        HttpHeaders header = new HttpHeaders();
        header.add(CONTENT_TYPE, JSON_PATCH);
        header.add(BRAND, brand);
        header.setContentType(MediaType.valueOf(JSON_PATCH));
        HttpEntity<JsonPatch> entity = new HttpEntity<>(jsonPatch, header);
        log.info("header set for downstream call: {}", header);
        return entity;
    }

    /**
     * This method is used to publish ApplicantInfoUpdateEvent
     *
     * @param brand        - possible values NWB/RBS
     * @param jsonPatch    - jsonPatch object input
     * @param applicantDto - applicantDto object input
     */
    private void doApplicantInfoUpdate(String brand, JsonPatch jsonPatch, ApplicantDto applicantDto) {
        log.info("doApplicantInfoUpdate method enters in ApplicantServiceImpl class");
        jsr353Mapper.registerModule(new JSR353Module());
        jsr353Mapper.registerModule(new JavaTimeModule());
        var requestJson = jsr353Mapper.convertValue(applicantDto, JsonStructure.class);
        var updatedJson = jsonPatch.apply(requestJson);
        applicantDto = jsr353Mapper.convertValue(updatedJson, ApplicantDto.class);

        ApplicantInfoUpdateEvent event = ApplicantInfoUpdateEvent
                .builder()
                .emailAddress(StringUtils.isNotBlank(applicantDto.getPersonalDetails().getEmail()) ? applicantDto.getPersonalDetails().getEmail() : null)
                .mobileNumber(getMobileNumber(applicantDto.getPersonalDetails().getTelephones()))
                .brand(brand)
                .caseId(applicantDto.getCaseId())
                .mainApplicant(applicantDto.getMainApplicant())
                .build();

        eventPublisher.publishEvent(event);
    }

    private String getMobileNumber(List<PersonTelephoneDto> personTelephoneDtoList) {
        return Optional.ofNullable(personTelephoneDtoList).orElseGet(Collections::emptyList).stream()
                .filter(telephoneDto -> TelephoneType.MOBILE.name().equalsIgnoreCase(telephoneDto.getType()))
                .findFirst().map(PersonTelephoneDto::getNumber).orElse(null);
    }

    /**
     * This method is used to decide the DB update
     *
     * @param jsonPatch                        - jsonPatch object
     * @param applicantInfoUpdateAllowedFields - applicantInfoUpdateAllowedFields object
     * @return boolean
     */
    public boolean isDbUpdateNeeded(JsonPatch jsonPatch, List<String> applicantInfoUpdateAllowedFields) {
        log.info("isDbUpdateNeeded method enters in ApplicantServiceImpl class");
        JsonArray jsonArray = jsonPatch.toJsonArray();
        boolean result = false;
        for (javax.json.JsonValue jsonValue : jsonArray) {
            String path = jsonValue.asJsonObject().get("path").toString().replace("\"", "");
            if (path.contains("telephones")) {
                result = true;
            } else {
                result = applicantInfoUpdateAllowedFields.contains(path);
            }
            if (result)
                break;
        }
        return result;
    }
}
