package com.natwest.pbbdhb.ui.application.update.service.impl;

import com.natwest.pbbdhb.ui.application.update.model.dto.exception.ClosedTaskException;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.NoteRequest;
import com.natwest.pbbdhb.ui.application.update.service.MockDataLoader;
import com.natwest.pbbdhb.ui.application.update.service.NoteService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.validation.constraints.NotNull;
import java.text.ParseException;
import java.util.Date;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationUtil.*;
import static com.natwest.pbbdhb.ui.application.update.util.ErrorConstant.ERROR_CODE_412_ACTION_NOT_ALLOWED;

/**
 * implementation class for NoteService Interface
 */
@Service
@AllArgsConstructor
@Slf4j
public class NoteServiceImpl implements NoteService {

    private final MockDataLoader mockDataLoader;

    /**
     * This method is to create note based on the brand and NoteRequest
     * @param brand       - brand could be NWB/RBS
     * @param noteRequest - Note request
     * @return string
     * @throws ParseException - throws parse exception during date conversion
     */
    @Override
    public String addNote(String brand, @NotNull NoteRequest noteRequest) throws ParseException {
        log.info("addNote method entered in NoteServiceImpl class");
        /*Logic to get the application sequence number and add a new note to the
        table using GMS AIS service will be implemented once the services are available.
        Now returning only String as a response*/
        throwUpdateFailureException(noteRequest.getReferenceNumber(), noteRequest.getOperatorRacfId(),mockDataLoader);
        throwClosedTaskException(noteRequest.getTaskID());
        Date date = parseDateTime(noteRequest.getDate());
        Date dueDate = parseDate(noteRequest.getDueDate());
        return "Note added into the database \n Date: " + date + "\n Due Date: " + dueDate;
    }

    private void throwClosedTaskException(String taskId){
        if(mockDataLoader.getClosedTask().contains(taskId)){
            throw new ClosedTaskException(ERROR_CODE_412_ACTION_NOT_ALLOWED);
        }
    }
}
