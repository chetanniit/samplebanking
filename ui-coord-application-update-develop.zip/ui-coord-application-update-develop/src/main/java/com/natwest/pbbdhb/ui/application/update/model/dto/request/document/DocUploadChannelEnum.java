package com.natwest.pbbdhb.ui.application.update.model.dto.request.document;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * Channels allowed for doc upload
 */
@Schema(name = "channel", enumAsRef = true, defaultValue = "BRANCH")
public enum DocUploadChannelEnum {
    INTERNET,
    BRANCH,
    INTERMEDIARY,
    INTERMEDIARY_BROKER_API,
    INTERMEDIARY_NAPOLI
}
