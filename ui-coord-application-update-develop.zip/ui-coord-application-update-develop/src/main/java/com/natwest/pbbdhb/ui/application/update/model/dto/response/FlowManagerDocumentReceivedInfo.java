package com.natwest.pbbdhb.ui.application.update.model.dto.response;

import lombok.*;

/**
 * This class will have Document Received information
 */
@Data
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@NoArgsConstructor(access = AccessLevel.PUBLIC)
@Builder
public class FlowManagerDocumentReceivedInfo {

    private String documentId;

    private String documentStatus;

    private String dateTime;

    private String classification;

    private String originalFileName;

    private String errorMessage;

}
