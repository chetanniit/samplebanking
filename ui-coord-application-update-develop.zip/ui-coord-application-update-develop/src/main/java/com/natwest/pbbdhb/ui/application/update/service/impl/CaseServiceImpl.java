package com.natwest.pbbdhb.ui.application.update.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.cases.dto.BrokerDto;
import com.natwest.pbbdhb.cases.dto.CaseApplicationDto;
import com.natwest.pbbdhb.ui.application.update.model.dto.exception.PreConditionFailedException;
import com.natwest.pbbdhb.ui.application.update.service.CaseService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.datatype.jsr353.JSR353Module;
import com.natwest.pbbdhb.cases.dto.MortgageAdvisorDto;
import com.natwest.pbbdhb.cases.dto.MortgageDto;
import com.natwest.pbbdhb.ui.application.update.events.CaseInfoUpdateEvent;
import com.natwest.pbbdhb.ui.application.update.model.dto.event.UpdateAppInfoEventRequest;
import lombok.var;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.HashMap;
import java.util.Map;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.*;

import javax.json.JsonArray;
import javax.json.JsonPatch;
import javax.json.JsonStructure;
import java.util.List;
import java.util.Optional;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationUtil.getHeader;
import static com.natwest.pbbdhb.ui.application.update.util.ErrorConstant.ERROR_CODE_412_CASEID_NOT_VALID;

/**
 * This service is used to call the case endPoints of CAPIE service
 */
@Service
@Slf4j
public class CaseServiceImpl implements CaseService {

    @Autowired
    @Qualifier("customSecureRestTemplate")
    private RestTemplate restTemplate;

    @Autowired
    private ObjectMapper jsr353Mapper;

    @Autowired
    private ApplicationEventPublisher eventPublisher;

    @Value("${msvc.case.parent.endpoint:}")
    private String msvcCaseParentEndpoint;

    @Value("${msvc.case.cases.endpoint:}")
    private String msvcCaseCasesEndpoint;

    @Value("#{'${case.info.update.allowed.fields:}'.split(',')}")
    private List<String> caseInfoUpdateAllowedFields;


    /**
     * This method is used to update applicant information based on applicantId
     *
     * @param brand              - allowed values NWB/RBS
     * @param caseApplicationDto - CaseApplicationDto object
     * @param caseId             - String caseId
     * @return - return ResponseEntity object
     */
    @Override
    public ResponseEntity<CaseApplicationDto> updateCase(String brand, CaseApplicationDto caseApplicationDto, String caseId) {
        validateCaseId(caseId, caseApplicationDto);
        ResponseEntity<CaseApplicationDto> caseUpdateResponse = updateCapieeCase(brand,caseApplicationDto,caseId);

        if (HttpStatus.OK.value() == caseUpdateResponse.getStatusCodeValue()) {

            UpdateAppInfoEventRequest updateAppInfoEventRequest = getUpdateAppInfoEventRequest(brand, caseApplicationDto);

            CaseInfoUpdateEvent event = CaseInfoUpdateEvent.builder().brand(brand).updateAppInfoEventRequest(updateAppInfoEventRequest).build();
            eventPublisher.publishEvent(event);
        }
        return caseUpdateResponse;

    }

    private void validateCaseId(String caseId, CaseApplicationDto caseApplicationDto) {
        log.info("validateCaseId method enters in CaseServiceImpl class");
        if(!StringUtils.equals(caseId, caseApplicationDto.getCaseId())){
            throw new PreConditionFailedException(ERROR_CODE_412_CASEID_NOT_VALID);
        }
    }

    private UpdateAppInfoEventRequest getUpdateAppInfoEventRequest(String brand, CaseApplicationDto caseApplicationDto) {
        return UpdateAppInfoEventRequest
                .builder()
                .brand(brand)
                .caseId(caseApplicationDto.getCaseId())
                .racfId(Optional.ofNullable(caseApplicationDto.getRacfId()).orElse(null))
                .primaryAdvisorRacfId(Optional.ofNullable(caseApplicationDto.getPrimaryAdvisorRacfId()).orElse(null))
                .applicationType(Optional.ofNullable(caseApplicationDto.getApplicationType()).orElse(null))
                .advisor(Optional.ofNullable(caseApplicationDto.getMortgage()).map(MortgageDto::getMortgageAdvisor)
                        .map(MortgageAdvisorDto::getAdvisor).orElse(null))
                .leadAdvisor(Optional.ofNullable(caseApplicationDto.getMortgage()).map(MortgageDto::getMortgageAdvisor)
                        .map(MortgageAdvisorDto::getLeadAdvisor).orElse(null))
                .leadGenerator(Optional.ofNullable(caseApplicationDto.getMortgage()).map(MortgageDto::getMortgageAdvisor)
                        .map(MortgageAdvisorDto::getLeadGenerator).orElse(null))
                .brokerEmail(Optional.ofNullable(caseApplicationDto.getBroker()).map(BrokerDto::getBrokerEmail).orElse(null))
                .build();
    }

    private ResponseEntity<CaseApplicationDto> updateCapieeCase(String brand, CaseApplicationDto caseApplicationDto, String caseId) {
        log.debug("update case method entered in CaseServiceImpl class brand: {}, caseId: {} ", brand, caseId);
        ResponseEntity<CaseApplicationDto> response;
        String endpoint = msvcCaseParentEndpoint + msvcCaseCasesEndpoint;
        log.info("Endpoint: {}", endpoint);
        UriComponentsBuilder builder = getUriComponentsBuilder(caseId, endpoint);
        response = getApiResponse(brand, builder, caseApplicationDto);
        return response;
    }

    private UriComponentsBuilder getUriComponentsBuilder(String caseId, String endpoint) {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(endpoint);

        Map<String, Object> urlParams = new HashMap<>();
        urlParams.put("caseId", caseId);
        builder.uriVariables(urlParams);
        log.debug("URL : {} ", builder.toUriString());
        return builder;
    }

    private ResponseEntity<CaseApplicationDto> getApiResponse(String brand, UriComponentsBuilder builder, CaseApplicationDto caseApplicationDto) {
         ResponseEntity<CaseApplicationDto> response = restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.PUT, getHeaderForCaseUpdate(caseApplicationDto, brand), CaseApplicationDto.class);
            log.info(" response : {}",response.getBody());
        return response;
    }

    private HttpEntity<CaseApplicationDto> getHeaderForCaseUpdate(CaseApplicationDto caseApplicationDto, String brand) {
        HttpHeaders header = new HttpHeaders();
        header.add(BRAND, brand);
        HttpEntity<CaseApplicationDto> entity = new HttpEntity<>(caseApplicationDto, header);
        log.info("header set for downstream call: {}, CaseApplicationDto :  {}", header,caseApplicationDto);
        return entity;
    }




    /**
     * Method to update the case information for the given case id in CAPIE system
     *
     * @param brand     - brand
     * @param caseId    - caseId
     * @param jsonPatch - jsonPatch
     * @return CaseApplicationDto
     */
    @Override
    public CaseApplicationDto updateCaseInformation(String brand, String caseId, JsonPatch jsonPatch) {
        log.debug("updateCaseInformation method entered in CaseServiceImpl class brand: {}, caseId: {} ", brand, caseId);
        String endpoint = msvcCaseParentEndpoint + msvcCaseCasesEndpoint;
        UriComponentsBuilder builder = getUriComponentsBuilder(caseId, endpoint);
        ResponseEntity<CaseApplicationDto> response = getApiResponse(brand, builder, jsonPatch);
        if (response.getStatusCode().equals(HttpStatus.OK) && isDbUpdateNeeded(jsonPatch, caseInfoUpdateAllowedFields))
            doCaseInfoUpdate(brand, jsonPatch, response.getBody());
        return response.getBody();
    }

    private boolean isDbUpdateNeeded(JsonPatch jsonPatch, List<String> caseInfoUpdateAllowedFields) {
        log.info("isDbUpdateNeeded method enters in CaseServiceImpl class");
        JsonArray jsonArray = jsonPatch.toJsonArray();
        boolean result = false;
        for (javax.json.JsonValue jsonValue : jsonArray) {
            String path = jsonValue.asJsonObject().get("path").toString().replace("\"", "");
            result = caseInfoUpdateAllowedFields.contains(path);
            if (result)
                break;
        }
        return result;
    }

    private ResponseEntity<CaseApplicationDto> getApiResponse(String brand, UriComponentsBuilder builder, JsonPatch jsonPatch) {
        return restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.PATCH, getHeader(jsonPatch, brand), CaseApplicationDto.class);
    }

    private void doCaseInfoUpdate(String brand, JsonPatch jsonPatch, CaseApplicationDto caseApplicationDto) {
        log.info("doCaseInfoUpdate method enters in CaseServiceImpl class");
        jsr353Mapper.registerModule(new JSR353Module());
        jsr353Mapper.registerModule(new JavaTimeModule());
        var requestJson = jsr353Mapper.convertValue(caseApplicationDto, JsonStructure.class);
        var updatedJson = jsonPatch.apply(requestJson);
        caseApplicationDto = jsr353Mapper.convertValue(updatedJson, CaseApplicationDto.class);

        UpdateAppInfoEventRequest updateAppInfoEventRequest = getUpdateAppInfoEventRequest(brand, caseApplicationDto);

        CaseInfoUpdateEvent event = CaseInfoUpdateEvent.builder().brand(brand).updateAppInfoEventRequest(updateAppInfoEventRequest).build();
        eventPublisher.publishEvent(event);
    }
}
