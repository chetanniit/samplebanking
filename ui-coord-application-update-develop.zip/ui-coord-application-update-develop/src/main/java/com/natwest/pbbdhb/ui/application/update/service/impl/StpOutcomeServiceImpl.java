package com.natwest.pbbdhb.ui.application.update.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.CaseTransferRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.flowmanager.FlowManagerCaseTransferRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.SuccessResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.userinformation.UserInformationResponse;
import com.natwest.pbbdhb.ui.application.update.service.StpOutcomeService;
import com.natwest.pbbdhb.ui.application.update.service.auth.AuthorizationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.BRAND;

/**
 * Implementation class for StpOutcomeService
 */
@Service
@Slf4j
public class StpOutcomeServiceImpl implements StpOutcomeService {

    @Value("${msvc.flow-manager.parent.endpoint}")
    private String flowManagerParentEndpoint;

    @Value("${msvc.flow-manager.stp.case-transfer.endpoint}")
    private String flowManagerStpCaseTransferEndpoint;

    @Autowired
    @Qualifier("iamJwtChainSecureRestTemplate")
    private RestTemplate restTemplate;

    @Autowired
    private AuthorizationService authorizationService;

    @Autowired
    private ObjectMapper objectMapper;

    /**
     * Method to move the case to referred state
     *
     * @param brand               - brand
     * @param caseTransferRequest - caseTransferRequest
     * @param caseId - caseId
     * @return SuccessResponse
     */
    @Override
    public SuccessResponse transferCase(String brand, CaseTransferRequest caseTransferRequest, String caseId) {
        log.info("Entered into transferCase for brand : {}, caseId : {}", brand, caseId);
        UserInformationResponse userData = authorizationService.getUserData();
        log.info("STP case transfer for caseId - {}, referredBy - {}, {}", caseId,
                userData.getUsername(), userData.getRacfID());
        FlowManagerCaseTransferRequest flowManagerCaseTransferRequest = FlowManagerCaseTransferRequest
                .builder().userFullName(userData.getUsername()).userRACFId(userData.getRacfID())
                .caseId(caseId)
                .note(Optional.ofNullable(caseTransferRequest).map(CaseTransferRequest::getNote).orElse(null))
                .build();
        String endpoint = flowManagerParentEndpoint + flowManagerStpCaseTransferEndpoint;
        UriComponentsBuilder builder = getUriComponentsBuilder(endpoint, caseId);
        HttpHeaders headers = new HttpHeaders();
        headers.add(BRAND, brand);
        HttpEntity<FlowManagerCaseTransferRequest> httpEntity = new HttpEntity<>(flowManagerCaseTransferRequest, headers);
        log.debug("header set for downstream call: {}, FlowManagerCaseTransferRequest :  {}", headers, flowManagerCaseTransferRequest);
        ResponseEntity<String> responseEntity = restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.PATCH, httpEntity, String.class);
        SuccessResponse successResponse = null;
        try {
            successResponse = objectMapper.readValue(responseEntity.getBody(), SuccessResponse.class);
        } catch (JsonProcessingException e) {
            log.error("Exception occurred while transferCase object conversion: {}", e.getMessage(), e);
        }
        return successResponse;
    }

    private UriComponentsBuilder getUriComponentsBuilder(String endpoint, String caseId) {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(endpoint);
        Map<String, Object> urlParams = new HashMap<>();
        urlParams.put("caseId", caseId);
        builder.uriVariables(urlParams);
        log.debug("URL : {} ", builder.toUriString());
        return builder;
    }
}
