package com.natwest.pbbdhb.ui.application.update.model.dto.request.firequest;

import com.natwest.pbbdhb.ui.application.update.validator.format.ArrayLengthConstraint;
import com.natwest.pbbdhb.ui.application.update.validator.format.DateConstraint;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.util.List;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.*;

/**
 * Document class is the used as request for /requestFI endpoint
 * and validation for all the fields are captured here
 */
@Data
@Schema(description = "Add Document Object")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Validated
@Valid
public class Document {

    @Valid
    @Parameter(description = "Required For")
    private List<DocumentFor> requiredFor;

    @Valid
    @Parameter(description = "Document Identifier")
    @Size(min = 2, max = 10, message = INVALID_DOCUMENT_IDENTIFIER)
    @NotNull(message = INVALID_DOCUMENT_IDENTIFIER)
    private String documentIdentifier;

    @Valid
    @Parameter(description = "Re-Request Reason")
    @ArrayLengthConstraint(message = INVALID_REREQUEST_REASON)
    private List<String> reRequestReason;

    @Valid
    @Parameter(description = "Due Date")
    @DateConstraint(message = INVALID_DUE_DATE)
    private String dueDate;

    @Valid
    @Parameter(description = "From Date")
    @DateConstraint(message = INVALID_FROM_DATE)
    private String fromDate;

    @Valid
    @Parameter(description = "To Date")
    @DateConstraint(message = INVALID_TO_DATE)
    private String toDate;

    @Valid
    @Parameter(description = "Time Period")
    @Pattern(regexp = ALLOW_MAX_100_CHAR, message = INVALID_TIME_PERIOD)
    private String timePeriod;

    //TODO need to be remove
    @Valid
    @Parameter(description = "Other Info")
    @Pattern(regexp = ALLOW_ONLY_ALPHABETS, message = INVALID_OTHER_INFO)
    private String otherInfo;

    @Valid
    @Parameter(description = "Additional Info")
    @Size(max = 2500, message = INVALID_ADDITIONAL_INFO)
    private String additionalInfo;

    @Valid
    @Parameter(description = "Exception Id")
    @Pattern(regexp = ALLOW_ONLY_UUID_MAX_OF_THIRTY_SIX_CHAR, message = INVALID_EXCEPTION_ID)
    private String exceptionIdToResolve;

}
