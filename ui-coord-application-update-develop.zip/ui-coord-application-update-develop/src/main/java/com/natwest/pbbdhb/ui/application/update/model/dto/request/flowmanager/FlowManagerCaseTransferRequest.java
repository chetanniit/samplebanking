package com.natwest.pbbdhb.ui.application.update.model.dto.request.flowmanager;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;

/**
 * FlowManagerCaseTransfer API Request
 */
@Data
@Schema(description = "Flow Manager CaseTransfer Request Object")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Validated
@Valid
public class FlowManagerCaseTransferRequest {
    private String caseId;
    private String userFullName;
    private String userRACFId;
    private String note;
}