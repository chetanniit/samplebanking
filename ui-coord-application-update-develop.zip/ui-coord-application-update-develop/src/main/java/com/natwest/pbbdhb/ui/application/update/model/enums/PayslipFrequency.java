package com.natwest.pbbdhb.ui.application.update.model.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum PayslipFrequency {
    WEEKLY,
    FORTNIGHTLY,
    MONTHLY,
    FOUR_WEEKLY

}
