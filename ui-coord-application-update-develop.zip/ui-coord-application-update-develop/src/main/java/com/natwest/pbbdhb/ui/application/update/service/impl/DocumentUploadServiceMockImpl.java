package com.natwest.pbbdhb.ui.application.update.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.natwest.pbbdhb.ui.application.update.model.dto.document.DocumentUploadResponseDto;
import com.natwest.pbbdhb.ui.application.update.model.dto.document.SuccessfulUpload;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.document.DocumentRequest;
import com.natwest.pbbdhb.ui.application.update.service.DocumentUploadService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Objects;

/**
 * Implementation class for DocumentUploadService interface when mock is enabled
 */
@Service
@Slf4j
@Primary
@ConditionalOnExpression("${mock.doc.upload.endpoint:false}")
public class DocumentUploadServiceMockImpl implements DocumentUploadService {
    /**
     * method is used for uploading document for the given mortgage/application id
     *
     * @param brand           - brand could be NWB/RBS
     * @param caseId          -caseId
     * @param referenceNumber -type of applicationId
     * @param documentRequest - Document request object contains channel, application id and multipart
     * @return - DocumentUploadResponseDto
     * @throws JsonProcessingException - throw JsonParsingException
     */
    @Override
    public DocumentUploadResponseDto uploadDocument(String brand, String caseId, String referenceNumber, DocumentRequest documentRequest) throws JsonProcessingException {
        log.info("inside uploadDocument method of mock DocumentUploadService");
        if (Objects.nonNull(caseId)) {
            return prepareDocumentUploadResponseForCaseId();
        } else {
            return prepareDocumentUploadResponseForReferenceNumber();
        }
    }

    private DocumentUploadResponseDto prepareDocumentUploadResponseForCaseId() {
        return DocumentUploadResponseDto.builder()
                .successfulUploads(Collections.singletonList(SuccessfulUpload.builder()
                        .documentId("6ededde1-4927-4e33-81dd-e1ccc46514b5").originalFileName("MockCase.pdf").build()))
                .build();
    }

    private DocumentUploadResponseDto prepareDocumentUploadResponseForReferenceNumber() {
        return DocumentUploadResponseDto.builder()
                .successfulUploads(Collections.singletonList(SuccessfulUpload.builder()
                        .documentId("6ededde1-4928-4e34-81dd-e1ccc46514b6").originalFileName("MockReference.pdf").build()))
                .build();
    }
}