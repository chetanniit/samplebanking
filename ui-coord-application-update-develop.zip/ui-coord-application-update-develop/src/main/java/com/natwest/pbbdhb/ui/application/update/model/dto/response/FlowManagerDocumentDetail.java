package com.natwest.pbbdhb.ui.application.update.model.dto.response;

import com.natwest.pbbdhb.ui.application.update.model.dto.request.firequest.DocumentFor;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * DocumentDetail object used in BasicPackagingDocumentResponse object
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FlowManagerDocumentDetail {

    private String userFullName;

    private String userRACFId;

    private String requestedDate;

    private String updatedByFullName;

    private String updatedByRACFID;

    private String updatedDate;

    private String requestId;

    private String state;

    private List<DocumentFor> requiredFor;

    private String documentIdentifier;

    private String category;

    private List<String> reRequestReason;

    private List<String> purpose;

    private String dueDate;

    private String fromDate;

    private String toDate;

    private String count;

    private String frequency;

    private List<FlowManagerDocumentReceivedInfo> documentInfo;

    private String requestType;

    private String fiType;

    private String customerResponse;

    private String classificationCode;

    private String additionalInfo;
}
