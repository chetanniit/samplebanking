package com.natwest.pbbdhb.ui.application.update.model.dto;

import lombok.*;

import java.util.List;

/**
 * Response object for request FI API from flow manager
 */
@Data
@Builder
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@NoArgsConstructor(access = AccessLevel.PUBLIC)
public class FlowManagerAddDocumentResponse {
    private String message;
    private int responseCode;
    private List<FlowManagerDocumentRequest> duplicateRequests;
}
