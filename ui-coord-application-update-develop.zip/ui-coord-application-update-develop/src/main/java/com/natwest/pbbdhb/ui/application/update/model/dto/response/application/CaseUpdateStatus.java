package com.natwest.pbbdhb.ui.application.update.model.dto.response.application;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;

/**
 * Application broker information object
 */
@Data
@Schema(description = "Case information update object")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Validated
@Valid
public class CaseUpdateStatus {
    private String status;
}
