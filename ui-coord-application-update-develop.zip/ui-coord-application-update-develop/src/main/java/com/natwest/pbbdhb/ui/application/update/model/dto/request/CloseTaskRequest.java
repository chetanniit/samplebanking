package com.natwest.pbbdhb.ui.application.update.model.dto.request;

import com.natwest.pbbdhb.ui.application.update.validator.format.DateTimeConstraint;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.*;

/**
 * This class is used to create close task request
 */
@Data
@Schema(description = "Close Task Object")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Validated
public class CloseTaskRequest {

    @Valid
    @Schema(required = true, type = "String", description = "Reference Number")
    @Pattern(regexp = ALLOW_ONLY_NUMBERS_AND_MAX_OF_TEN_DIGITS, message = INVALID_REFERENCE_NUMBER)
    @NotNull(message = INVALID_REFERENCE_NUMBER)
    private String referenceNumber;

    @Valid
    @Schema(required = true, type = "String", description = "Application Sequence Number")
    @Pattern(regexp = ALLOW_ONLY_NUMBERS_AND_MAX_OF_TWO_DIGITS, message = INVALID_SEQUENCE_ID)
    @NotNull(message = INVALID_SEQUENCE_ID)
    private String applicationSequenceNumber;

    @Valid
    @Schema(required = true, type = "String", description = "Task Id")
    @NotNull(message = INVALID_TASK_ID)
    @Pattern(regexp = ALLOW_MAX_FIFTY_CHARACTERS, message = INVALID_TASK_ID)
    private String taskId;

    @Valid
    @Schema(required = true, type = "String", description = "Task Code")
    @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_NUMBER, message = INVALID_TASK_CODE)
    @NotNull(message = INVALID_TASK_CODE)
    private String taskCode;

    @Valid
    @Schema(required = true, type = "String", description = "Task Name")
    @NotNull(message = INVALID_TASK_NAME)
    @Pattern(regexp = ALLOW_MAX_FIFTY_CHARACTERS, message = INVALID_TASK_NAME)
    private String taskName;

    @Valid
    @Schema(type = "String", description = "Date")
    @DateTimeConstraint
    private String date;

    @Valid
    @Schema(type = "String", description = "Stage number")
    @Pattern(regexp = ALLOW_ONLY_NUMBERS_AND_MAX_OF_TWO_DIGITS, message = INVALID_STAGE_NUMBER)
    private String stageNumber;

    @Valid
    @Schema(required = true, type = "String", description = "Operator name")
    @Pattern(regexp = ALLOW_ONLY_ALPHABETS_AND_SPACE, message = INVALID_OPERATOR_NAME)
    @NotNull(message = INVALID_OPERATOR_NAME)
    private String operatorName;

    @Valid
    @Schema(required = true, type = "String", description = "Operator RACFID")
    @Pattern(regexp = ALLOW_ONLY_ALPHABETS, message = INVALID_OPERATOR_RACFID)
    @NotNull(message = INVALID_OPERATOR_RACFID)
    private String operatorRacfId;

}
