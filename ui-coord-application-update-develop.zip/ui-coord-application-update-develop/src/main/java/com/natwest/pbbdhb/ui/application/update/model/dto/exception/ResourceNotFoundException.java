package com.natwest.pbbdhb.ui.application.update.model.dto.exception;

/**
 * Class to map the details when ResourceNotFoundException occurs
 */
public class ResourceNotFoundException extends RuntimeException {
    private static final long serialVersionUID = 4064440551003516363L;

    /**
     * Constructor to set the value for message
     * @param message - Error message
     */
    public ResourceNotFoundException(String message) {
        super(message);
    }
}
