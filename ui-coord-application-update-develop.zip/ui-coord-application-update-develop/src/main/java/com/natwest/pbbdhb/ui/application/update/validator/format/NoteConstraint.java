package com.natwest.pbbdhb.ui.application.update.validator.format;

import com.natwest.pbbdhb.ui.application.update.validator.NoteValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.INVALID_REASON;

/**
 * This interface is to validate Reason field
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
@Constraint(validatedBy = NoteValidator.class)
public @interface NoteConstraint {
    /**
     * return error message
     * @return string
     */
    String message() default INVALID_REASON;

    /**
     * return boolean
     * @return boolean
     */
    boolean required() default false;

    /**
     * return object
     * @return Class
     */
    Class<?>[] groups() default {};

    /**
     * return object
     * @return class
     */
    Class<? extends Payload>[] payload() default {};
}
