package com.natwest.pbbdhb.ui.application.update.model.dto.response.stp;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Case allocation response object
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CaseAllocationResponse {

    private String caseId;

    private String referenceNumber;

    private String channel;

    private String loanPurpose;

    private String podRating;

    private String stpType;

    private String stpOutcome;

    private String createdDateTime;

    private String createdBy;

    private String updatedDateTime;

    private String updatedBy;

    private String failedReason;

    private String state;

    private String caseOwner;

    private List<String> transferNotes;

    private Object message;

}
