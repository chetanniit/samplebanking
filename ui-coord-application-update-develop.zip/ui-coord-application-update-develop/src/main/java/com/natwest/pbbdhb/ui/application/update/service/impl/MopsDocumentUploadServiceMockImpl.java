package com.natwest.pbbdhb.ui.application.update.service.impl;

import com.natwest.pbbdhb.ui.application.update.model.dto.document.DocumentUploadResponseDto;
import com.natwest.pbbdhb.ui.application.update.model.dto.document.SuccessfulUpload;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.document.DocumentUploadRequest;
import com.natwest.pbbdhb.ui.application.update.service.MopsDocumentUploadService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import java.util.Collections;


/**
 * Implementation class for MopsDocumentUploadService interface when mock is enabled
 */
@Service
@Slf4j
@Primary
@ConditionalOnExpression("${mock.mops.doc.upload.endpoint:false}")
public class MopsDocumentUploadServiceMockImpl implements MopsDocumentUploadService {

    /**
     * This method is used to upload the document to docin-downstream system
     *
     * @param documentUploadRequest - request
     * @return DocumentUploadResponseDto - response
     */
    public DocumentUploadResponseDto uploadSingleDocument(DocumentUploadRequest documentUploadRequest) {
        log.info("uploadSingleDocument method enters in MopsDocumentUploadServiceMockImpl class");
        String fileName = documentUploadRequest.getFile().getOriginalFilename();
        return DocumentUploadResponseDto.builder()
                .successfulUploads(Collections.singletonList(SuccessfulUpload.builder()
                        .documentId("6ededde1-4928-4e34-81dd-e1ccc46514b6").originalFileName("81234567_1_Payslip.pdf").build()))
                .build();
    }

}
