package com.natwest.pbbdhb.ui.application.update.model.dto.exception;


import lombok.*;
import org.springframework.http.HttpStatus;

import java.util.Date;
import java.util.List;

/**
 * Model object to map the values to return error details
 */
@NoArgsConstructor(access = AccessLevel.PUBLIC)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@Builder
@Setter
@Getter
@ToString
public class ErrorResponse {
    private int responseCode;
    private HttpStatus responseStatus;
    private List<String> errorMessages;
    private Date timeStamp;
}
