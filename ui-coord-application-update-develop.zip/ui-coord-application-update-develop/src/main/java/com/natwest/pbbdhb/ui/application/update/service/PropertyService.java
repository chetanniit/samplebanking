package com.natwest.pbbdhb.ui.application.update.service;

import com.natwest.pbbdhb.property.dto.PropertyDetailsDto;

import javax.json.JsonPatch;

/**
 * This class is used to perform operations related to property
 */
public interface PropertyService {
    /**
     * Method to update the property information for the given case id
     *
     * @param brand   - brand
     * @param caseId  - case id String
     * @param request - request object
     * @return PropertyDetailsDto - response object
     */
    PropertyDetailsDto updatePropertyInformation(String brand, String caseId, PropertyDetailsDto request);

    /**
     * Method to patch update the property information for the given case id in capie service
     *
     * @param brand   - brand
     * @param caseId  - case id String
     * @param jsonPatch - jsonPatch object
     * @return PropertyDetailsDto - response object
     */
    PropertyDetailsDto patchUpdatePropertyInformation(String brand, String caseId, JsonPatch jsonPatch);
}
