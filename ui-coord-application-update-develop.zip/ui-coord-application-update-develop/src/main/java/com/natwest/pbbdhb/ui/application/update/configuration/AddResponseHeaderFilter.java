package com.natwest.pbbdhb.ui.application.update.configuration;

import org.springframework.stereotype.Component;

import javax.servlet.Filter;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.NO_CACHE;
import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.CSP_VALUE;
import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.NO_REFERRER;
import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.X_XSS_PROTECTION_VALUE;

/**
 * This filter class adds response headers in all the API response.
 */
@Component
public class AddResponseHeaderFilter implements Filter {

    public static final String CONTENT_SECURITY_POLICY = "Content-Security-Policy";
    public static final String CACHE_CONTROL = "Cache-control";
    public static final String PRAGMA = "Pragma";
    public static final String REFERRER_POLICY = "Referrer-Policy";
    public static final String X_XSS_PROTECTION = "X-XSS-Protection";

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
            throws IOException, ServletException {
        HttpServletResponse httpServletResponse = (HttpServletResponse) servletResponse;
        httpServletResponse.setHeader(CONTENT_SECURITY_POLICY, CSP_VALUE);
        httpServletResponse.setHeader(CACHE_CONTROL, NO_CACHE);
        httpServletResponse.setHeader(PRAGMA, NO_CACHE);
        httpServletResponse.setHeader(REFERRER_POLICY,NO_REFERRER);
        httpServletResponse.setHeader(X_XSS_PROTECTION, X_XSS_PROTECTION_VALUE);
        filterChain.doFilter(servletRequest, servletResponse);
    }
}
