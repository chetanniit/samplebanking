package com.natwest.pbbdhb.ui.application.update.model.dto.response.stp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ExceptionAllocationResponse {

    private String exceptionId;

    private String reviewId;

    private String status;

    private String caseId;

    private String type;

    private String errorCode;

    private String errorDescription;

    private String createdOn;

    private String userId;

    private String caseOwner;

    private String updatedBy;

    private String updatedDateTime;

    private String referenceNumber;

}
