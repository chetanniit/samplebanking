package com.natwest.pbbdhb.ui.application.update.service;

import com.natwest.pbbdhb.adbo.dto.CaseDetailsDto;

import javax.json.JsonPatch;

/**
 * This service is used to call the adbo case endPoints of CAPIE service
 */
public interface ADBOCaseService {
    /**
     * Method to update the case information for the given case id in CAPIE system
     *
     * @param brand     - brand
     * @param caseId    - caseId
     * @param jsonPatch - jsonPatch
     * @return CaseDetailsDto
     */
    CaseDetailsDto updateADBOCaseInformation(String brand, String caseId, JsonPatch jsonPatch);

}
