package com.natwest.pbbdhb.ui.application.update.service;

import com.natwest.pbbdhb.ui.application.update.model.dto.capie.ManualKeyInCaseUpdateRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.SuccessResponse;

/**
 * This service is used to call update application data API for manually key in cases
 */
public interface ManualKeyInCaseUpdateService {

    /**
     * Endpoint to update application detail for manual key in case
     *
     * @param brand                        - brand
     * @param caseId                       - caseId
     * @param dipId                        - dipId
     * @param manualKeyInCaseUpdateRequest - manualKeyInCaseUpdateRequest
     * @return SuccessResponse
     */
    SuccessResponse updateApplicationDataForManualKeyInCases(String brand, String caseId, String dipId,
                                                             ManualKeyInCaseUpdateRequest manualKeyInCaseUpdateRequest);
}
