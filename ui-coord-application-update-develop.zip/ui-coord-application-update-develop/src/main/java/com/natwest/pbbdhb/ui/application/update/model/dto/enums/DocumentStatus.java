package com.natwest.pbbdhb.ui.application.update.model.dto.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Document status
 */
@AllArgsConstructor
@Getter
public enum DocumentStatus {
    AV_SCAN_FAILED,
    AV_SCAN_SUCCESS,
    CLOSED,
    TRANSCRIBED,
    TRANSCRIPTION_FAILED,
    UPLOAD_SUCCESS,
    REMOVED;
}