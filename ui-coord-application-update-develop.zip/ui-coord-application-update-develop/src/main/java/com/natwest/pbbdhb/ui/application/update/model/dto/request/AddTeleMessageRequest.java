package com.natwest.pbbdhb.ui.application.update.model.dto.request;

import com.natwest.pbbdhb.ui.application.update.validator.format.DateConstraint;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.*;


/**
 * AddTeleMessageDocumentRequest class is the request for /telemessage endpoint
 * and validation for all the fields are captured here
 */
@Data
@Schema(description = "Add TeleMessage Document Request Object")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Validated
@Valid
public class AddTeleMessageRequest {

    @Valid
    @Parameter(description = "document identifier")
    @Size(min = 2, max = 10, message = INVALID_DOCUMENT_IDENTIFIER)
    @NotNull(message = INVALID_DOCUMENT_IDENTIFIER)
    private String documentIdentifier;

    @Valid
    @Parameter(required = true, description = "category")
    @NotBlank(message = INVALID_CATEGORY)
    private String category;

    @Valid
    @Parameter(required = true, description = "caller info")
    @Size(max = 100, message = INVALID_CALLER_INFO)
    @NotBlank(message = INVALID_CALLER_INFO)
    private String callerInfo;

    @Valid
    @Parameter(required = true, description = "call reason")
    @Size(max = 2500, message = INVALID_CALL_REASON)
    @NotBlank(message = INVALID_CALL_REASON)
    private String callReason;

    @Valid
    @Parameter(description = "due date")
    @DateConstraint(message = INVALID_DUE_DATE)
    @NotNull(message = INVALID_DUE_DATE)
    private String dueDate;
}
