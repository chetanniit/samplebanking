package com.natwest.pbbdhb.ui.application.update.model.dto.capie;

import com.natwest.pbbdhb.commondictionaries.enums.cases.LoanPurpose;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.util.List;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.*;

@Data
@Schema(description = "Manual Key In Case Update Request Object")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Validated
@Valid
public class ManualKeyInCaseUpdateRequest {
    @Valid
    @Parameter(required = true, description = "mortgage reference number")
    @Size(max = 15, message = INVALID_MORTGAGE_REFERENCE_NUMBER)
    @NotBlank(message = INVALID_MORTGAGE_REFERENCE_NUMBER)
    @Schema(example = "88888888")
    private String mortgageRefNo;

    @Valid
    @Parameter(required = true, description = "application sequence number")
    @Size(max = 2, message = INVALID_APPLICATION_SEQUENCE_NUMBER)
    @NotBlank(message = INVALID_APPLICATION_SEQUENCE_NUMBER)
    @Schema(example = "01")
    private String applSeq;

    @Valid
    @NotEmpty(message = INVALID_APPLICANTS)
    private List<ManualKeyInApplicantDetail> applicants;

    @Valid
    @Parameter(description = "Loan Purpose")
    @Schema(implementation = LoanPurpose.class)
    @Pattern(regexp = REGEXP_ALLOW_LOAN_PURPOSE_VALUE, message = INVALID_LOAN_PURPOSE)
    private String loanPurpose;
}
