package com.natwest.pbbdhb.ui.application.update.model.dto;

import com.natwest.pbbdhb.ui.application.update.model.dto.request.firequest.DocumentFor;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Object used in request FI API response from flow manager
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FlowManagerDocumentRequest {

    private List<DocumentFor> requiredFor;
    private String taskCode;
    private String documentIdentifier;
    private String category;
    private List<String> reRequestReason;
    private List<String> purpose;
    private String dueDate;
    private String fromDate;
    private String toDate;
    private String count;
    private String frequency;
    private String state;
    private String requestType;
    private String additionalInfo;
    private String exceptionIdToResolve;
}
