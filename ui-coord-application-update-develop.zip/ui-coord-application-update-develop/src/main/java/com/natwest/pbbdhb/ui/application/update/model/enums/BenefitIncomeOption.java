package com.natwest.pbbdhb.ui.application.update.model.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum BenefitIncomeOption {
    UNIVERSAL_CREDIT,
    CHILD_BENEFIT,
    DISABLEMENT_LIVING_ALLOWANCE,
    CHILD_TAX_CREDIT,
    WORKING_FAMILIES_TAX_CREDIT,
    OTHER

}
