package com.natwest.pbbdhb.ui.application.update.model.dto.exception;

import org.springframework.http.HttpStatus;

/**
 * Class to handle ManualKeyInCaseUpdateException
 */
public class ManualKeyInCaseUpdateException extends RuntimeException {
    private static final long serialVersionUID = -2107444230598409988L;
    private final HttpStatus httpStatusCode;

    /**
     * Constructor to initialize ManualKeyInCaseUpdateException
     *
     * @param message        errorMessage
     * @param httpStatusCode httpStatusCode
     */
    public ManualKeyInCaseUpdateException(String message, HttpStatus httpStatusCode) {
        super(message);
        this.httpStatusCode = httpStatusCode;
    }

    public HttpStatus getHttpStatusCode() {
        return httpStatusCode;
    }
}
