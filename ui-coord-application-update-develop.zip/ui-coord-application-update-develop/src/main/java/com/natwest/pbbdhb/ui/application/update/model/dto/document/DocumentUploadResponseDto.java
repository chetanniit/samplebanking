package com.natwest.pbbdhb.ui.application.update.model.dto.document;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.Parameter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Value;
import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;

@Builder
@Value
@AllArgsConstructor
@Validated
public class DocumentUploadResponseDto {

    @JsonProperty("message")
    @Parameter(required = true)
    @NotNull
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    String message;

    @JsonProperty("successfulUploads")
    @Parameter(required = true)
    @NotNull
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    @Builder.Default
    List<SuccessfulUpload> successfulUploads = new ArrayList<>();

    @JsonProperty("unsuccessfulUploads")
    @Parameter(required = true)
    @NotNull
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    @Builder.Default
    List<UnsuccessfulUpload> unsuccessfulUploads = new ArrayList<>();

}
