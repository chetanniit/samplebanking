package com.natwest.pbbdhb.ui.application.update.util;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.Map;

/**
 * Property reader to read the properties related to error
 */
@ConfigurationProperties(prefix = "error")
@Getter
@Setter
public class ErrorMessageConfigReader {
    private Map<String, String> message;
}
