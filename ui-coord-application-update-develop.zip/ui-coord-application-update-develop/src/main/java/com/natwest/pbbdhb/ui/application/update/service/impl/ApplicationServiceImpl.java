package com.natwest.pbbdhb.ui.application.update.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natwest.pbbdhb.ui.application.update.mapper.FlowManagerRequestMapper;
import com.natwest.pbbdhb.ui.application.update.model.dto.exception.ArraySizeLimitExceededException;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.ApplicationInformationUpdateRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.CaseUpdateCaseOwnerRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.UpdateCaseOwnerRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.flowmanager.FlowManagerApplicationInformationUpdateRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.application.ApplicationInformationUpdateResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.application.CaseUpdatedCaseOwnerResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.application.UpdatedCaseOwnerResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.userinformation.UserInformationResponse;
import com.natwest.pbbdhb.ui.application.update.service.ApplicationService;
import com.natwest.pbbdhb.ui.application.update.service.auth.AuthorizationService;
import com.natwest.pbbdhb.ui.application.update.util.ErrorConstant;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.*;

@Service
@Slf4j
public class ApplicationServiceImpl implements ApplicationService {

    @Value("${msvc.flow-manager.parent.endpoint}")
    private String flowManagerParentEndpoint;

    @Value("${msvc.flow-manager.update-application.endpoint}")
    private String flowManagerUpdateApplicationEndpoint;

    @Value("${msvc.flow-manager.case-update-application.endpoint}")
    private String flowManagerCaseUpdateApplicationEndpoint;

    @Value("${msvc.flow-manager.update-case-owner.endpoint}")
    private String flowManagerUpdateCaseOwnerEndpoint;

    @Value("${msvc.flow-manager.case-update-case-owner.endpoint}")
    private String flowManagerCaseUpdateCaseOwnerEndpoint;

    @Value("${update.application.owner.array.limit}")
    private int updateApplicationOwnerArrayLimit;

    @Autowired
    @Qualifier("customSecureRestTemplate")
    private RestTemplate restTemplate;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private AuthorizationService authorizationService;

    @Autowired
    private FlowManagerRequestMapper flowManagerRequestMapper;


    /**
     * Method to update application information in application collection
     *
     * @param brand   - brand
     * @param request - applicationInformationUpdateRequest
     * @return ApplicationInformationUpdateResponse
     */
    @Override
    public ResponseEntity<ApplicationInformationUpdateResponse> updateApplicationInformation(String brand, ApplicationInformationUpdateRequest request, String referenceNumber, String caseId) {
        ApplicationInformationUpdateResponse applicationInformationUpdateResponse = null;
        log.info("Inside updateApplicationInformation method for referenceNumber: {} " , referenceNumber);

        UserInformationResponse userData = authorizationService.getUserData();
        FlowManagerApplicationInformationUpdateRequest flowManagerApplicationInformationUpdateRequest = flowManagerRequestMapper
                .toFlowManagerApplicationInformationUpdateRequest(request);

        Optional.ofNullable(userData).ifPresent(userInfo -> {
            flowManagerApplicationInformationUpdateRequest.setUserFullName(userData.getUsername());
            flowManagerApplicationInformationUpdateRequest.setUserRACFId(userData.getRacfID());
        });

        HttpHeaders headers = new HttpHeaders();
        headers.add("brand", brand);

        Map<String, Object> urlParams = new HashMap<>();

        String endPoint = flowManagerParentEndpoint ;

        if(StringUtils.isNotBlank(referenceNumber)) {
            flowManagerApplicationInformationUpdateRequest.setReferenceNumber(referenceNumber);
            urlParams.put(REFERENCE_NUMBER, referenceNumber);
            endPoint = endPoint + flowManagerUpdateApplicationEndpoint;
        } else if(StringUtils.isNotBlank(caseId)){
            flowManagerApplicationInformationUpdateRequest.setCaseId(caseId);
            urlParams.put(CASE_ID, caseId);
            endPoint = endPoint + flowManagerCaseUpdateApplicationEndpoint;
        }

        log.info("endPoint : {}", endPoint);

        URI builder = UriComponentsBuilder.fromUriString(endPoint).buildAndExpand(urlParams).toUri();

        HttpEntity<FlowManagerApplicationInformationUpdateRequest> httpEntity = new HttpEntity<>(flowManagerApplicationInformationUpdateRequest, headers);

        ResponseEntity<String> responseEntity = restTemplate.exchange(builder, HttpMethod.PATCH, httpEntity, String.class);
        try {
            applicationInformationUpdateResponse = objectMapper.readValue(responseEntity.getBody(), ApplicationInformationUpdateResponse.class);
        } catch (JsonProcessingException e) {
            log.error("Exception occurred while response object conversion: {}", e.getMessage(), e);
        }
        return ResponseEntity.status(responseEntity.getStatusCode()).body(applicationInformationUpdateResponse);
    }

    @Override
    public ResponseEntity<UpdatedCaseOwnerResponse> updateApplicationOwner(String brand, UpdateCaseOwnerRequest request) {
        UpdatedCaseOwnerResponse response = null;
        log.info("Inside updateApplicationCaseOwner method");

        if (Objects.nonNull(request) && Objects.nonNull(request.getCaseOwnerRequest()) && request.getCaseOwnerRequest().size() > updateApplicationOwnerArrayLimit) {
            throw new ArraySizeLimitExceededException(ErrorConstant.ERROR_CODE_413_UPDATE_OWNER_ARRAY_SIZE_LIMIT_EXCEED);
        }

        String endPoint = flowManagerParentEndpoint + flowManagerUpdateCaseOwnerEndpoint;
        HttpEntity<UpdateCaseOwnerRequest> httpEntity = new HttpEntity<>(request, getHttpHeaders(brand));

        ResponseEntity<String> responseEntity = restTemplate.exchange(getUri(endPoint), HttpMethod.PATCH, httpEntity, String.class);

        try {
            response = objectMapper.readValue(responseEntity.getBody(), UpdatedCaseOwnerResponse.class);
        } catch (JsonProcessingException e) {
            log.error("Exception occurred while UpdatedCaseOwnerResponse object conversion: {}", e.getMessage(), e);
        }
        return ResponseEntity.status(responseEntity.getStatusCode()).body(response);

    }

    @Override
    public ResponseEntity<CaseUpdatedCaseOwnerResponse> updateApplicationOwner(String brand, CaseUpdateCaseOwnerRequest request) {
        CaseUpdatedCaseOwnerResponse response = null;
        log.info("Inside updateApplicationCaseOwner method");

        if (Objects.nonNull(request) && Objects.nonNull(request.getCaseOwnerRequest()) && request.getCaseOwnerRequest().size() > updateApplicationOwnerArrayLimit) {
            throw new ArraySizeLimitExceededException(ErrorConstant.ERROR_CODE_413_UPDATE_OWNER_ARRAY_SIZE_LIMIT_EXCEED);
        }

        String endPoint = flowManagerParentEndpoint + flowManagerCaseUpdateCaseOwnerEndpoint;
        HttpEntity<CaseUpdateCaseOwnerRequest> httpEntity = new HttpEntity<>(request, getHttpHeaders(brand));

        ResponseEntity<String> responseEntity = restTemplate.exchange(getUri(endPoint), HttpMethod.PATCH, httpEntity, String.class);

        try {
            response = objectMapper.readValue(responseEntity.getBody(), CaseUpdatedCaseOwnerResponse.class);
        } catch (JsonProcessingException e) {
            log.error("Exception occurred while CaseUpdatedCaseOwnerResponse object conversion: {}", e.getMessage(), e);
        }
        return ResponseEntity.status(responseEntity.getStatusCode()).body(response);
    }

    @NotNull
    private URI getUri(String endPoint) {
        Map<String, Object> urlParams = new HashMap<>();
        log.info("uri endPoint : {}", endPoint);
        return UriComponentsBuilder.fromUriString(endPoint).buildAndExpand(urlParams).toUri();
    }

    @NotNull
    private HttpHeaders getHttpHeaders(String brand) {
        HttpHeaders headers = new HttpHeaders();
        headers.add(BRAND, brand);
        return headers;
    }

}
