package com.natwest.pbbdhb.ui.application.update.events.handlers;

import com.natwest.pbbdhb.ui.application.update.events.ApplicantInfoUpdateEvent;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.ApplicationInformationUpdateRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.UpdateApplicantInformation;
import com.natwest.pbbdhb.ui.application.update.service.ApplicationUpdateService;
import com.natwest.pbbdhb.ui.application.update.util.DBUpdateRetryPropertiesReader;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.core.annotation.Order;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Component;

import java.util.Collections;

/**
 * This class is used to handle ApplicantInfoUpdateEvent
 *
 */
@Component
@AllArgsConstructor
@Slf4j
@EnableAsync
@EnableRetry
public class ApplicantInfoUpdateEventListener {

    @Autowired
    private final ApplicationUpdateService applicationUpdateService;

    @Autowired
    private final DBUpdateRetryPropertiesReader dbUpdateRetryPropertiesReader;

    /**
     * This method is used to handle ApplicantInfoUpdateEvent
     *
     * @param applicantInfoUpdateEvent - object
     */
    @EventListener
    @Order(0)
    @Async
    @Retryable(value = RuntimeException.class, maxAttemptsExpression = "#{@dbUpdateRetryPropertiesReader.getCount()}", backoff = @Backoff(delayExpression = "#{@dbUpdateRetryPropertiesReader.getWaitDelay()}"))
    public void onApplicantInfoUpdateEvent(ApplicantInfoUpdateEvent applicantInfoUpdateEvent) {
        log.info("onApplicantInfoUpdateEvent listener method enters in ApplicantInfoUpdateEventListener class");
        ApplicationInformationUpdateRequest request = ApplicationInformationUpdateRequest.builder()
                .applicants(Collections.singletonList(getUpdatedApplicantInfo(applicantInfoUpdateEvent)))
                .build();

        applicationUpdateService.updateApplicationInformation(applicantInfoUpdateEvent.getBrand(), request, null, applicantInfoUpdateEvent.getCaseId());

    }

    /**
     * This method is used to create UpdateApplicantInformation request
     *
     * @param applicantInfoUpdateEvent - input object
     * @return UpdateApplicantInformation - output object
     */
    private UpdateApplicantInformation getUpdatedApplicantInfo(ApplicantInfoUpdateEvent applicantInfoUpdateEvent) {
        log.info("getUpdatedApplicantInfo method enters in ApplicantInfoUpdateEventListener class");
        return UpdateApplicantInformation.builder()
                .emailAddress(applicantInfoUpdateEvent.getEmailAddress())
                .mobileNumber(applicantInfoUpdateEvent.getMobileNumber())
                .mainApplicant(applicantInfoUpdateEvent.getMainApplicant())
                .build();
    }

    /**
     * This method is used to handle retry failure
     *
     * @param e - exception object input
     * @param applicantInfoUpdateEvent - input
     */
    @Recover
    public void applicantInfoUpdateEventRecover(RuntimeException e, ApplicantInfoUpdateEvent applicantInfoUpdateEvent){
        log.info("applicantInfoUpdateEventRecover method enters in CaseInfoUpdateEventListener class");
        String logMessage = String.format("All the retries are exhausted for this event: %s with exception : %s",
                applicantInfoUpdateEvent,e.getMessage());
        log.error(logMessage);
    }
}
