package com.natwest.pbbdhb.ui.application.update.validator;

import com.natwest.pbbdhb.ui.application.update.validator.format.DateFormatConstraint;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationUtil.isValidDateInFuture;

/**
 * This class is to validate Date format is in future
 */
public class DateFormatValidator implements ConstraintValidator<DateFormatConstraint, String> {
    @Override
    public boolean isValid(String dateStr, ConstraintValidatorContext context) {
        return isValidDateInFuture(dateStr);
    }
}
