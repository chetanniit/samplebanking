package com.natwest.pbbdhb.ui.application.update.validator;

import com.natwest.pbbdhb.ui.application.update.validator.format.DateConstraint;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationUtil.isValidDate;

/**
 * This class is to validate Date format yyyy-MM-dd
 */
public class DateValidator implements ConstraintValidator<DateConstraint, String> {
    @Override
    public boolean isValid(String dateStr, ConstraintValidatorContext context) {
        return isValidDate(dateStr);
    }
}
