package com.natwest.pbbdhb.ui.application.update.validator;

import com.natwest.pbbdhb.ui.application.update.validator.format.DateTimeConstraint;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationUtil.isValidDateTime;

/**
 * This class is to validate DateTime format
 */
public class DateTimeFormatValidator implements ConstraintValidator<DateTimeConstraint, String> {


    /**
     * @param dateStr - date string as input
     * @param context - ConstraintValidatorContext as input
     * @return boolean
     * This method is to validate dateTime format
     */
    @Override
    public boolean isValid(String dateStr, ConstraintValidatorContext context) {

        return isValidDateTime(dateStr);
    }
}
