package com.natwest.pbbdhb.ui.application.update.model.dto.exception;

/**
 * Class to map the details when UnProcessableEntityException occurs
 */
public class UnProcessableEntityException extends RuntimeException {
    private static final long serialVersionUID = 4064440551003516363L;

    /**
     * Constructor to set the value for message
     * @param message - Error message
     */
    public UnProcessableEntityException(String message) {
        super(message);
    }
}
