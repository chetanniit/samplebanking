package com.natwest.pbbdhb.ui.application.update.model.dto.exception;

/**
 * Class to map the details when PreConditionFailedException occurs
 */
public class PreConditionFailedException extends RuntimeException{

    private static final long serialVersionUID = 1L;

    /**
     * Constructor to set the value for message
     * @param message - Error message
     */
    public PreConditionFailedException(String message){
        super(message);
    }
}
