package com.natwest.pbbdhb.ui.application.update.util;

/**
 * This class has all the constants related to errors
 */
public class ErrorConstant {

    public static final String ERROR_CODE_400 = "400";
    public static final String ERROR_CODE_500 = "500";
    public static final String ERROR_CODE_403_USER_NOT_AUTHORISED = "403-user-not-authorised";
    public static final String ERROR_CODE_404_RECORD_NOT_FOUND = "404-record-not-found";
    public static final String ERROR_CODE_404_USER_NOT_VALID = "404-user-not-valid";
    public static final String ERROR_CODE_412_NOT_ELIGIBLE_TO_CLOSE = "412-not-eligible-to-close";
    public static final String ERROR_CODE_412_ACTION_NOT_ALLOWED = "412-action-not-allowed";
    public static final String ERROR_CODE_422_UNPROCESSABLE_ENTITY = "422-unprocessable-entity";
    public static final String ERROR_CODE_412_CASEID_NOT_VALID= "412-caseid_not_valid";
    public static final String ERROR_CODE_412_FILE_NAME_NOT_VALID= "412-file-name-not-valid";
    public static final String ERROR_CODE_412_FILE_SIZE_LIMIT_EXCEED= "412-file-size-limit-exceed";

    public static final String ERROR_CODE_503 = "503";
    public static final String ERROR_CODE_412 = "412";
    public static final String ERROR_CODE_413 = "413";

    public static final String REQUEST_IS_TOO_BIG = "The request is too big.";

    public static final String ERROR_CODE_400_INVALID_REQUEST_SYNTAX_ERROR = "400-invalid-request-syntax-error";
    public static final String ERROR_CODE_413_UPDATE_OWNER_ARRAY_SIZE_LIMIT_EXCEED = "413-update-owner-array-size-limit-exceed";
    public static final String ERROR_CODE_412_CUSTOMER_RESPONSE = "412-customer-response";
    public static final String ERROR_CODE_412_ORIGINAL_FILE_NAME = "412-original-file-name";
    public static final String ERROR_CODE_412_CUSTOMER_RESPONSE_ORIGINAL_FILE_NAME = "412-customer-response-original-file-name";
    private ErrorConstant() {}
}
