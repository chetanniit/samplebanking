package com.natwest.pbbdhb.ui.application.update.service;

import com.natwest.pbbdhb.ui.application.update.model.dto.request.application.CaseTransferRequest;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.SuccessResponse;

/**
 *  This class to used perform operations to save StpOutcome
 */
public interface StpOutcomeService {
    /**
     * Method to move the case to referred state
     *
     * @param brand               - brand
     * @param caseTransferRequest - caseTransferRequest
     * @param caseId - caseId
     * @return SuccessResponse
     */
    SuccessResponse transferCase(String brand, CaseTransferRequest caseTransferRequest, String caseId);
}
