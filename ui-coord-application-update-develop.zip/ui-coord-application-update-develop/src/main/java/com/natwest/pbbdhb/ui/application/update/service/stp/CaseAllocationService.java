package com.natwest.pbbdhb.ui.application.update.service.stp;

import com.natwest.pbbdhb.ui.application.update.model.dto.response.stp.ExceptionAllocationResponse;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.stp.ExceptionDeallocationResponse;
import org.springframework.http.ResponseEntity;

/**
 *  This interface is used to perform operations related to case allocation
 */
public interface CaseAllocationService {

    ResponseEntity<ExceptionAllocationResponse> allocateCase(String brand, String exceptionId);

    /**
     * This method is used to deallocate the case in PM DB
     * @param brand
     * @param exceptionId
     * @return - return ResponseEntity object
     */
    ResponseEntity<ExceptionDeallocationResponse> deallocateCase(String brand, String exceptionId);
}
