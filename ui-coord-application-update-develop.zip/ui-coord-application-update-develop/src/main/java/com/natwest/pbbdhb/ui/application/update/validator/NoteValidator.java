package com.natwest.pbbdhb.ui.application.update.validator;

import com.natwest.pbbdhb.ui.application.update.model.dto.request.TaskRequest;
import com.natwest.pbbdhb.ui.application.update.validator.format.NoteConstraint;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationUtil.validateTaskNoteRequest;

/**
 * This class is to validate reason field
 */
public class NoteValidator implements ConstraintValidator<NoteConstraint, TaskRequest> {
    @Override
    public boolean isValid(TaskRequest request, ConstraintValidatorContext context) {
        return validateTaskNoteRequest(request);
    }
}
