package com.natwest.pbbdhb.ui.application.update.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.natwest.pbbdhb.cases.validation.RequestValidationDto;
import com.natwest.pbbdhb.cases.validation.ValidationErrorDto;
import com.natwest.pbbdhb.ui.application.update.model.dto.document.DocumentUploadResponseDto;
import com.natwest.pbbdhb.ui.application.update.model.dto.document.GlobalErrorResponseDto;
import com.natwest.pbbdhb.ui.application.update.model.dto.exception.*;
import com.natwest.pbbdhb.ui.application.update.model.dto.response.application.ApplicationInformationUpdateResponse;
import com.natwest.pbbdhb.ui.application.update.util.ErrorMessageConfigReader;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.tomcat.util.http.fileupload.impl.FileSizeLimitExceededException;
import org.apache.tomcat.util.http.fileupload.impl.SizeLimitExceededException;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import javax.json.JsonException;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import java.text.MessageFormat;
import java.util.*;
import java.util.stream.Collectors;

import static com.natwest.pbbdhb.ui.application.update.util.ApplicationConstants.*;
import static com.natwest.pbbdhb.ui.application.update.util.ErrorConstant.*;

/**
 * This class is used to handle the exceptions during execution
 */
@RestControllerAdvice
@Order(Ordered.HIGHEST_PRECEDENCE)
@Slf4j
@AllArgsConstructor(access = AccessLevel.PUBLIC)
public class ApplicationUpdateControllerAdvice extends ResponseEntityExceptionHandler {

    private final ErrorMessageConfigReader errorMessageConfigReader;
    private final ObjectMapper objectMapper;
    private static final String ENUM_PARSE_ERROR = "JSON parse error: Cannot deserialize value of type [%s] from value [%s]";

    /**
     * Handler to handle ConstraintViolationException
     *
     * @param exception - ConstraintViolationException object
     * @param request   - WebRequest object
     * @return - ErrorResponse
     */
    @ExceptionHandler(ConstraintViolationException.class)
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleConstraintViolationException(ConstraintViolationException exception, WebRequest request) {
        List<String> errorMessages = exception.getConstraintViolations()
                .stream()
                .map(ConstraintViolation::getMessage)
                .map(this::constructErrorMessage)
                .collect(Collectors.toList());
        log.error("ConstraintViolationException while processing request, Error messages - {}", errorMessages);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ErrorResponse(HttpStatus.BAD_REQUEST.value(),
                HttpStatus.BAD_REQUEST, errorMessages, new Date()));
    }

    private String constructErrorMessage(String content) {
        return MessageFormat.format(errorMessageConfigReader.getMessage().get(ERROR_CODE_400), content);
    }

    /**
     * Handler to handle MethodArgumentNotValidException
     *
     * @param ex      - MethodArgumentNotValidException object
     * @param headers - HttpHeaders
     * @param status  - HttpStatus
     * @param request - WebRequest Object
     * @return ResponseEntity
     */
    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers,
                                                                  HttpStatus status, WebRequest request) {

        List<FieldError> fieldErrors = ex.getBindingResult().getFieldErrors();

        List<String> errorMessages = fieldErrors.stream()
                .map(DefaultMessageSourceResolvable::getDefaultMessage)
                .map(this::constructErrorMessage)
                .collect(Collectors.toList());

        log.error("MethodArgumentNotValidException while processing request, Error messages - {}", errorMessages);

        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ErrorResponse(HttpStatus.BAD_REQUEST.value(),
                HttpStatus.BAD_REQUEST, errorMessages, new Date()));
    }

    /**
     * Handler to handle MissingRequestHeaderException which occurs when the brand is missing in the request header
     *
     * @param exception - MissingRequestHeaderException object
     * @param request   - WebRequest object
     * @return ErrorResponse
     */
    @ExceptionHandler(MissingRequestHeaderException.class)
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleMissingRequestHeaderException(MissingRequestHeaderException exception, WebRequest request) {
        String errorMessage = BRAND.equalsIgnoreCase(exception.getHeaderName()) ? MISSING_BRAND : exception.getMessage();
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ErrorResponse(HttpStatus.BAD_REQUEST.value(),
                HttpStatus.BAD_REQUEST, Collections.singletonList(errorMessage), new Date()));
    }

    /**
     * Handler to handle ResourceNotFoundException which occurs when data/user is not found
     *
     * @param ex      - ResourceNotFoundException object
     * @param request - WebRequest object
     * @return ErrorResponse
     */
    @ExceptionHandler(ResourceNotFoundException.class)
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleResourceNotFoundException(ResourceNotFoundException ex, WebRequest request) {
        String errorMessage = errorMessageConfigReader.getMessage().get(ex.getMessage());
        log.error("ResourceNotFoundException : Error message - {}", errorMessage);

        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ErrorResponse(HttpStatus.NOT_FOUND.value(),
                HttpStatus.NOT_FOUND, Collections.singletonList(errorMessage), new Date()));
    }

    /**
     * Handler to handle ClosedTaskException which occurs when task is already closed
     *
     * @param ex      - ClosedTaskException
     * @param request - WebRequest object
     * @return ErrorResponse
     */
    @ExceptionHandler(ClosedTaskException.class)
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleClosedTaskException(ClosedTaskException ex, WebRequest request) {
        String errorMessage = errorMessageConfigReader.getMessage().get(ex.getMessage());
        log.error("ClosedTaskException : Error message - {}", errorMessage);

        return ResponseEntity.status(HttpStatus.PRECONDITION_FAILED).body(new ErrorResponse(HttpStatus.PRECONDITION_FAILED.value(),
                HttpStatus.PRECONDITION_FAILED, Collections.singletonList(errorMessage), new Date()));
    }

    /**
     * Handler to handle PreConditionFailedException Exception
     *
     * @param ex      - PreConditionFailedException
     * @param request - WebRequest object
     * @return ErrorResponse
     */
    @ExceptionHandler(PreConditionFailedException.class)
    @ResponseBody
    public ResponseEntity<ErrorResponse> handlePreConditionFailedException(PreConditionFailedException ex, WebRequest request) {
        String errorMessage = errorMessageConfigReader.getMessage().get(ex.getMessage());
        log.error("PreConditionFailedException : Error message - {}", errorMessage);

        return ResponseEntity.status(HttpStatus.PRECONDITION_FAILED).body(new ErrorResponse(HttpStatus.PRECONDITION_FAILED.value(),
                HttpStatus.PRECONDITION_FAILED, Collections.singletonList(errorMessage), new Date()));
    }

    /**
     * Handler to handle UserNotValidException which occurs when the given user is not valid
     *
     * @param ex      - UserNotValidException
     * @param request - WebRequest object
     * @return ErrorResponse
     */
    @ExceptionHandler(UserNotValidException.class)
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleUserNotValidException(UserNotValidException ex, WebRequest request) {
        String errorMessage = errorMessageConfigReader.getMessage().get(ex.getMessage());
        log.error("UserNotValidException : Error message - {}", errorMessage);

        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ErrorResponse(HttpStatus.NOT_FOUND.value(),
                HttpStatus.NOT_FOUND, Collections.singletonList(errorMessage), new Date()));
    }

    /**
     * Handler to handle UserNotAuthorizedException which occurs
     * when the given user is not Authorized to perform the task
     *
     * @param ex       - UserNotAuthorizedException
     * @param request- WebRequest object
     * @return ErrorResponse
     */
    @ExceptionHandler(UserNotAuthorizedException.class)
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleUserNotAuthorizedException(UserNotAuthorizedException ex, WebRequest request) {
        String errorMessage = errorMessageConfigReader.getMessage().get(ex.getMessage());
        log.error("UserNotAuthorizedException : Error message - {}", errorMessage);

        return ResponseEntity.status(HttpStatus.FORBIDDEN).body(new ErrorResponse(HttpStatus.FORBIDDEN.value(),
                HttpStatus.FORBIDDEN, Collections.singletonList(errorMessage), new Date()));
    }

    /**
     * Handler to handle HttpClientErrorException
     *
     * @param ex HttpClientErrorException
     * @return ErrorResponse
     */
    @ExceptionHandler({HttpClientErrorException.class})
    @ResponseBody
    public ResponseEntity<Object> handleHttpClientErrorException(HttpClientErrorException ex) {
        log.error("Error occurred while processing the request : {}", ex.getResponseBodyAsString());

        if (StringUtils.isNotBlank(ex.getResponseBodyAsString()) && ex.getResponseBodyAsString().contains(UNSUCCESSFUL_UPLOADS)) {
            log.info("DocumentUploadResponseDto : {}", ex.getResponseBodyAsString());
            return ResponseEntity.status(ex.getStatusCode()).body(convertToObject(ex.getResponseBodyAsString()));
        }

        ResponseEntity<Object> BAD_REQUEST = getPropertyResponseEntity(ex);
        if (BAD_REQUEST != null) return BAD_REQUEST;

        switch (ex.getStatusCode()) {
            case PRECONDITION_FAILED:
            case BAD_REQUEST:
                return ResponseEntity.status(ex.getStatusCode()).body(ex.getResponseBodyAsString());
            case NOT_FOUND:
                return getDataNotFoundResponseEntity(ex);
            case CONFLICT:
                return getConflictResponseEntity(ex);
            default:
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body(new ErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(),
                                HttpStatus.INTERNAL_SERVER_ERROR, Collections.singletonList(ex.getMessage()), new Date()));

        }
    }

    @Nullable
    private ResponseEntity<Object> getPropertyResponseEntity(HttpClientErrorException ex) {
        String errorMessage = null;
        if (Objects.nonNull(ex.getMessage())) {
            errorMessage = ex.getMessage();
        }
        if (Objects.isNull(errorMessage)) {
            errorMessage = StringUtils.EMPTY;
        }

        if(errorMessage.contains(PROPERTY_DETAILS) && errorMessage.contains(VALUATION)){
            List<String> errorMsg = new ArrayList<>();
            RequestValidationDto validationDto = getRequestValidationDto(ex);
            Optional.ofNullable(validationDto)
                    .ifPresent(requestValidationDto -> requestValidationDto.getErrors().forEach(validationErrorDto -> {
                switch (validationErrorDto.getField()){
                    case VALUATION_TYPE:
                        errorMsg.add(constructErrorMessage(INVALID_VALUATION_TYPE));
                        break;
                    case VALUATION_DATE:
                        errorMsg.add(constructErrorMessage(INVALID_VALUATION_DATE));
                        break;
                    case VALUATION_AMOUNT:
                        errorMsg.add(constructErrorMessage(INVALID_VALUATION_AMOUNT));
                        break;
                    default:
                        // No default case implemented. Adding default case for sonar fix.
                }
            }));
            if(CollectionUtils.isNotEmpty(errorMsg))
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ErrorResponse(HttpStatus.BAD_REQUEST.value(),
                        HttpStatus.BAD_REQUEST, errorMsg, new Date()));
        }
        return null;
    }

    private RequestValidationDto getRequestValidationDto(HttpClientErrorException ex){
        RequestValidationDto response = RequestValidationDto.builder().build();
        try {
            response = objectMapper.readValue(ex.getResponseBodyAsString(), RequestValidationDto.class);
        } catch (JsonMappingException e) {
            log.error("JsonMappingException exception occurred while converting ApplicationInformationUpdateResponse: ", e);
        } catch (JsonProcessingException e) {
            log.error("JsonProcessingException exception occurred while converting ApplicationInformationUpdateResponse: ", e);
        }
        return response;
    }

    @NotNull
    private ResponseEntity<Object> getDataNotFoundResponseEntity(HttpClientErrorException ex) {
        if (StringUtils.isNotBlank(ex.getResponseBodyAsString()) && ex.getResponseBodyAsString()
                .contains(NOT_FOUND_REQUESTED_ROUTE)) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR,
                            Collections.singletonList(errorMessageConfigReader.getMessage().get(ERROR_CODE_500)), new Date()));
        }
        return ResponseEntity.status(ex.getStatusCode()).body(ex.getResponseBodyAsString());
    }

    private ResponseEntity<Object> getConflictResponseEntity(HttpClientErrorException ex) {
        if (ex.getResponseBodyAsString().contains(FAILURE)) {
            ApplicationInformationUpdateResponse response = getApplicationInformationUpdateResponse(ex);
            return ResponseEntity.status(ex.getStatusCode()).body(response);
        } else {
            return ResponseEntity.status(ex.getStatusCode()).body(ex.getResponseBodyAsString());
        }
    }

    private ApplicationInformationUpdateResponse getApplicationInformationUpdateResponse(HttpClientErrorException ex) {
        ApplicationInformationUpdateResponse response = ApplicationInformationUpdateResponse.builder().build();
        try {
            response = objectMapper.readValue(ex.getResponseBodyAsString(), ApplicationInformationUpdateResponse.class);
        } catch (JsonMappingException e) {
            log.error("JsonMappingException exception occurred while converting ApplicationInformationUpdateResponse: ", e);
        } catch (JsonProcessingException e) {
            log.error("JsonProcessingException exception occurred while converting ApplicationInformationUpdateResponse: ", e);
        }
        return response;
    }

    /**
     * Handler to handle UnSupportedMediaType Exception
     *
     * @param ex - UnSupportedMediaType Exception
     * @return ErrorResponse
     */
    @ExceptionHandler({HttpClientErrorException.UnsupportedMediaType.class})
    @ResponseBody
    public ResponseEntity<Object> handleUnsupportedMediaTypeException(HttpClientErrorException.UnsupportedMediaType ex) {
        log.error("Error occurred while processing the request : {}", ex.getResponseBodyAsString());

        return ResponseEntity.status(ex.getStatusCode()).body(convertToObject(ex.getResponseBodyAsString()));
    }


    private DocumentUploadResponseDto convertToObject(String content) {
        DocumentUploadResponseDto errorResponse = DocumentUploadResponseDto.builder().build();
        try {
            errorResponse = objectMapper.readValue(content, DocumentUploadResponseDto.class);
        } catch (JsonMappingException e) {
            log.error("JsonMappingException exception occurred while converting the HttpClientError response to errorResponse: ", e);
        } catch (JsonProcessingException e) {
            log.error("JsonProcessingException exception occurred while converting the HttpClientError response to errorResponse: ", e);
        }
        return errorResponse;
    }

    @ExceptionHandler({HttpServerErrorException.class})
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleHttpServerErrorException(HttpServerErrorException ex) {
        log.error("Server error occurred while processing the request : {}", ex.getResponseBodyAsString());
        String errorMessage = null;
        if (Objects.nonNull(ex.getMessage())) {
            errorMessage = ex.getMessage();
        }
        if (Objects.isNull(errorMessage)) {
            errorMessage = StringUtils.EMPTY;
        }

        ResponseEntity<ErrorResponse> BAD_REQUEST = getObjectResponseEntity(errorMessage);
        if (BAD_REQUEST != null) return BAD_REQUEST;

        if (HttpStatus.SERVICE_UNAVAILABLE.value() == ex.getRawStatusCode()) {
            return ResponseEntity.status(ex.getStatusCode()).body(new ErrorResponse(HttpStatus.SERVICE_UNAVAILABLE.value(),
                    ex.getStatusCode(), Collections.singletonList(errorMessageConfigReader.getMessage().get(ERROR_CODE_503)), new Date()));
        }
        if (HttpStatus.PRECONDITION_FAILED.value() == ex.getRawStatusCode()) {
            return ResponseEntity.status(ex.getStatusCode()).body(new ErrorResponse(HttpStatus.PRECONDITION_FAILED.value(),
                    ex.getStatusCode(), Collections.singletonList(errorMessageConfigReader.getMessage().get(ERROR_CODE_412)), new Date()));
        }
        if (HttpStatus.BAD_REQUEST.value() == ex.getRawStatusCode()) {
            return ResponseEntity.status(ex.getStatusCode()).body(new ErrorResponse(HttpStatus.BAD_REQUEST.value(), ex.getStatusCode(),
                    Collections.singletonList(errorMessageConfigReader.getMessage().get(ERROR_CODE_400)), new Date()));
        }
        if (HttpStatus.GATEWAY_TIMEOUT.value() == ex.getRawStatusCode()) {
            return ResponseEntity.status(ex.getStatusCode())
                    .body(new ErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), ex.getStatusCode(),
                            Collections.singletonList(errorMessageConfigReader.getMessage().get(ERROR_CODE_500)), new Date()));
        }
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(),
                HttpStatus.INTERNAL_SERVER_ERROR, Collections.singletonList(errorMessageConfigReader.getMessage().get(ERROR_CODE_500)),
                new Date()));
    }

    @ExceptionHandler({FileSizeLimitExceededException.class})
    public ResponseEntity<ErrorResponse> handleFileSizeLimitExceededException(FileSizeLimitExceededException ex) {

        return ResponseEntity.status(HttpStatus.PAYLOAD_TOO_LARGE).body(new ErrorResponse(HttpStatus.PAYLOAD_TOO_LARGE.value(),
                HttpStatus.PAYLOAD_TOO_LARGE, Collections.singletonList(errorMessageConfigReader.getMessage().get(ERROR_CODE_413)), new Date()));
    }

    @ExceptionHandler({SizeLimitExceededException.class})
    public ResponseEntity<GlobalErrorResponseDto> handleSizeLimitExceededException(SizeLimitExceededException ex) {

        return ResponseEntity.status(HttpStatus.PAYLOAD_TOO_LARGE)
                .body(GlobalErrorResponseDto.builder()
                        .message(ex.getLocalizedMessage()).build());
    }

    /**
     * Handler to handle UserNotAuthorizedException which occurs
     * when the given user is not Authorized to perform the task
     *
     * @param ex       - UserNotAuthorizedException
     * @param request- WebRequest object
     * @return ErrorResponse
     */
    @ExceptionHandler(AccessDeniedException.class)
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleAccessDeniedException(AccessDeniedException ex, WebRequest request) {
        log.error("AccessDeniedException : Error message - {}", ex.getMessage());

        return ResponseEntity.status(HttpStatus.FORBIDDEN).body(new ErrorResponse(HttpStatus.FORBIDDEN.value(),
                HttpStatus.FORBIDDEN, Collections.singletonList(errorMessageConfigReader.getMessage().get(ERROR_CODE_403_USER_NOT_AUTHORISED)), new Date()));
    }

    @ExceptionHandler(TokenExpiredException.class)
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleTokenExpiredException(TokenExpiredException ex, WebRequest request) {
        log.error("TokenExpiredException : Error messages - {}", ex.getMessage());

        return ResponseEntity.status(HttpStatus.FORBIDDEN).body(new ErrorResponse(HttpStatus.FORBIDDEN.value(),
                HttpStatus.FORBIDDEN, Collections.singletonList(ex.getMessage()), new Date()));
    }

    @ExceptionHandler(AuthenticationException.class)
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleTokenNotFoundException(AuthenticationException ex, WebRequest request) {
        log.error("UsernameNotFoundException : Error messages - {}", ex.getMessage());

        return ResponseEntity.status(HttpStatus.FORBIDDEN).body(new ErrorResponse(HttpStatus.FORBIDDEN.value(),
                HttpStatus.FORBIDDEN, Collections.singletonList(ex.getMessage()), new Date()));
    }

    /**
     * Handler to handle UnProcessableEntityException which occurs when data is not processable
     *
     * @param ex - UnProcessableEntityException object
     * @return ErrorResponse
     */
    @ExceptionHandler(UnProcessableEntityException.class)
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleUnProcessableEntityException(UnProcessableEntityException ex) {
        String errorMessage = errorMessageConfigReader.getMessage().get(ex.getMessage());
        log.error("UnProcessableEntityException : Error message - {}", errorMessage);

        return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body(new ErrorResponse(HttpStatus.UNPROCESSABLE_ENTITY.value(),
                HttpStatus.UNPROCESSABLE_ENTITY, Collections.singletonList(errorMessage), new Date()));
    }

    /**
     * This method is used to handle HttpMessageNotReadableException
     *
     * @param ex      - exception object
     * @param headers - header object
     * @param status  - status object
     * @param request - request object
     * @return ResponseEntity
     */
    @Override
    protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex,
                                                                  HttpHeaders headers, HttpStatus status, WebRequest request) {
        log.error("handleHttpMessageNotReadable exception occurred: {}", ex);
        String errorMessage = null;
        if (Objects.nonNull(ex) && Objects.nonNull(ex.getMessage())) {
            errorMessage = ex.getMessage();
        }
        if (Objects.isNull(errorMessage)) {
            errorMessage = StringUtils.EMPTY;
        }

        Object BAD_REQUEST = getObjectResponseEntity(errorMessage);
        if (BAD_REQUEST != null) return (ResponseEntity<Object>) BAD_REQUEST;

        Throwable cause = ex.getCause();
        if (cause instanceof InvalidFormatException) {
            InvalidFormatException invalidFormatException = (InvalidFormatException) cause;
            if (invalidFormatException.getTargetType().isEnum()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ErrorResponse(HttpStatus.BAD_REQUEST.value(),
                        HttpStatus.BAD_REQUEST, Collections.singletonList(String.format(ENUM_PARSE_ERROR, invalidFormatException.getTargetType().getName(), invalidFormatException.getValue())), new Date()));
            }
        }


        if (errorMessage.contains(BUSINESS_ESTABLISHMENT_DATE)) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ErrorResponse(HttpStatus.BAD_REQUEST.value(),
                    HttpStatus.BAD_REQUEST, Collections.singletonList(constructErrorMessage(INVALID_BUSINESS_ESTABLISHMENT_DATE)),
                    new Date()));
        }

        if (errorMessage.contains(EMPLOYMENT_START_DATE)) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ErrorResponse(HttpStatus.BAD_REQUEST.value(),
                    HttpStatus.BAD_REQUEST, Collections.singletonList(constructErrorMessage(INVALID_EMPLOYMENT_START_DATE)), new Date()));
        }

        if (errorMessage.contains(NOTIFICATION_REQUIRED_FIELD)) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ErrorResponse(HttpStatus.BAD_REQUEST.value(),
                    HttpStatus.BAD_REQUEST, Collections.singletonList(constructErrorMessage(INVALID_NOTIFICATION_REQUIRED)), new Date()));
        }

        if (errorMessage.contains(MAIN_APPLICANT)) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ErrorResponse(HttpStatus.BAD_REQUEST.value(),
                    HttpStatus.BAD_REQUEST, Collections.singletonList(constructErrorMessage(INVALID_MAIN_APPLICANT)), new Date()));
        }

        if (errorMessage.contains(PRIMARY)) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ErrorResponse(HttpStatus.BAD_REQUEST.value(),
                    HttpStatus.BAD_REQUEST, Collections.singletonList(constructErrorMessage(INVALID_PRIMARY)), new Date()));
        }

        if (errorMessage.contains(MORTGAGE_ADVISED)) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ErrorResponse(HttpStatus.BAD_REQUEST.value(),
                    HttpStatus.BAD_REQUEST, Collections.singletonList(constructErrorMessage(INVALID_MORTGAGE_ADVISED)), new Date()));
        }

        if (cause instanceof JsonMappingException) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ErrorResponse(HttpStatus.BAD_REQUEST.value(),
                    HttpStatus.BAD_REQUEST, Collections.singletonList(errorMessageConfigReader.getMessage().get(ERROR_CODE_400_INVALID_REQUEST_SYNTAX_ERROR)), new Date()));
        }

        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ErrorResponse(HttpStatus.BAD_REQUEST.value(),
                HttpStatus.BAD_REQUEST, Collections.singletonList(errorMessage), new Date()));
    }

    @Nullable
    private ResponseEntity<ErrorResponse> getObjectResponseEntity(String errorMessage) {
        if(errorMessage.contains(PROPERTY_DETAILS) && errorMessage.contains(VALUATION)){
            if (errorMessage.contains(RECEIVED)) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ErrorResponse(HttpStatus.BAD_REQUEST.value(),
                        HttpStatus.BAD_REQUEST, Collections.singletonList(constructErrorMessage(INVALID_VALUATION_RECEIVED)),
                        new Date()));
            }
            if (errorMessage.contains(AMOUNT)) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ErrorResponse(HttpStatus.BAD_REQUEST.value(),
                        HttpStatus.BAD_REQUEST, Collections.singletonList(constructErrorMessage(INVALID_VALUATION_AMOUNT)),
                        new Date()));
            }
            if (errorMessage.contains(VALUATION)) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ErrorResponse(HttpStatus.BAD_REQUEST.value(),
                        HttpStatus.BAD_REQUEST, Collections.singletonList(constructErrorMessage(INVALID_VALUATION)),
                        new Date()));
            }
        }
        return null;
    }

    @ExceptionHandler(JsonException.class)
    @ResponseBody
    public ResponseEntity<RequestValidationDto> handleJsonException(JsonException e) {
        log.error("handleJsonException occurred:{}",e);
        String originalMsg = e.getMessage();
        String containingString = "contains no value for name ";
        String wrongField = originalMsg.substring(
                originalMsg.indexOf(containingString) + containingString.length() + 1,
                originalMsg.length() - 1);
        ValidationErrorDto validationErrorDto = ValidationErrorDto.builder()
                .object("Json patch request")
                .field(wrongField)
                .message("Error during patching document. Unrecognized property: '" + wrongField + "'")
                .build();
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(getErrorObject(Collections.singletonList(validationErrorDto)));
    }

    private RequestValidationDto getErrorObject(List<ValidationErrorDto> errorList) {
        return RequestValidationDto.builder()
                .errorCount(errorList.size())
                .errors(errorList)
                .build();
    }

    /**
     * To handle ArraySize in Request Object
     *
     * @param ex - ArraySizeLimitExceededException
     * @return - ErrorResponse
     */
    @ExceptionHandler(ArraySizeLimitExceededException.class)
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleArraySizeLimitExceededException(ArraySizeLimitExceededException ex, WebRequest request) {
        log.error("ArraySizeLimitExceededException : Error messages - {}", ex.getMessage());

        return ResponseEntity.status(HttpStatus.PAYLOAD_TOO_LARGE)
                .body(new ErrorResponse(
                        HttpStatus.PAYLOAD_TOO_LARGE.value(),
                        HttpStatus.PAYLOAD_TOO_LARGE,
                        Collections.singletonList(errorMessageConfigReader.getMessage().get(ERROR_CODE_413_UPDATE_OWNER_ARRAY_SIZE_LIMIT_EXCEED)),
                        new Date()
                        )
                );
    }

    @ExceptionHandler(ManualKeyInCaseUpdateException.class)
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleManualKeyInCaseUpdateException(ManualKeyInCaseUpdateException ex) {
        log.error("ManualKeyInCaseUpdateException : {}", ex.getMessage());
        List<String> errors = getManualKeyInUpdateErrors(ex.getMessage());
        if (CollectionUtils.isEmpty(errors)) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR,
                            Collections.singletonList(errorMessageConfigReader.getMessage().get(ERROR_CODE_500)), new Date()));
        }
        return ResponseEntity.status(ex.getHttpStatusCode()).body(new ErrorResponse(ex.getHttpStatusCode().value(),
                ex.getHttpStatusCode(),
                errors,
                new Date()));
    }

    private List<String> getManualKeyInUpdateErrors(String message) {
        List<ManualKeyInAPIErrorResponse> response = null;
        try {
            response = objectMapper.readValue(message, new TypeReference<List<ManualKeyInAPIErrorResponse>>() {
            });
        } catch (JsonMappingException e) {
            log.error("JsonMappingException exception occurred while converting ManualKeyInAPIErrorResponse: ", e);
        } catch (JsonProcessingException e) {
            log.error("JsonProcessingException exception occurred while converting ManualKeyInAPIErrorResponse: ", e);
        }
        return Optional.ofNullable(response).orElseGet(Collections::emptyList).stream().map(ManualKeyInAPIErrorResponse::getMessage)
                .collect(Collectors.toList());
    }
}
