package com.natwest.pbbdhb.ui.application.update.model.dto.enums;

import lombok.AllArgsConstructor;

/**
 * enum class ApplicationIdType contain values needed for downstream service(DocIn)
 **/
@AllArgsConstructor
public enum ApplicationIdType {
    MORTGAGE_REFERENCE_NUMBER,
    CASE_ID
}
