# ui-coord-application-update

ui-coord-application-update exposes the API for the post submission dashboard to help the users update the Mortgage application data

**context-root** <pcf_host_url>/mortgages/v1/ui-application-update\
**swagger**      <pcf_host_url>/<context-root>/swagger-ui/index.html

## Local Testing

    Add these VM options or change corresponsing properties in bootstrap.yml
    -Dspring.profiles.active=local -Dspring.profiles.include=unsecure

## PCF Deployment

For working with PCF, you need to open your terminal inside the `pcf-config` directory.

Once inside there, you can execute the following commands

```bash
# To see PCF commands
./scripts/pcf.sh --help
```
### Create App
```bash
# In order to create an app using DX-APM, the following variables need to be set
export VCAP_APPLICATION='$VCAP_APPLICATION' CF_INSTANCE_INDEX='${CF_INSTANCE_INDEX}'
./scripts/pcf.sh create-app <ENV>
```
Example:

    export VCAP_APPLICATION='$VCAP_APPLICATION' CF_INSTANCE_INDEX='${CF_INSTANCE_INDEX}'; ./scripts/pcf.sh create-app dev

### Update App
```bash
export VCAP_APPLICATION='$VCAP_APPLICATION' CF_INSTANCE_INDEX='${CF_INSTANCE_INDEX}'
./scripts/pcf.sh update-app <ENV>
```
Example:

    export VCAP_APPLICATION='$VCAP_APPLICATION' CF_INSTANCE_INDEX='${CF_INSTANCE_INDEX}'; ./scripts/pcf.sh update-app dev

### Restaging App
```bash
./scripts/pcf.sh action-restage <ENV>
```
Example: 

./scripts/pcf.sh action-restage dev

### Deploying a snapshot build

```bash
./scripts/deploy.sh <ENV> - pcf_url=<SNAPSHOT_URL>
```

Example: `./scripts/deploy.sh dev - pcf_url=https://artifactory.server.rbsgrp.net/artifactory/pbbdhb-libs-snapshots-local/com/natwest/pbbdhb/ui-coord-application-update/1.3.0-SNAPSHOT/ui-application-update-0.1.0-20220206.112502-1-dist.jar`

### Deploying a release build

```bash
./scripts/deploy.sh <ENV> <VERSION>
```

Example: `./scripts/deploy.sh dev 1.3.0`

## Code Formatting

It is recommended that all developers use the default Intellij code formatter.

1. File > Settings > Other Settings > Save Actions
2. Enable `Activate save actions on save`, `Optimize imports`
3. Execute Ctrl + ALT + L to autoformat any new changes / files